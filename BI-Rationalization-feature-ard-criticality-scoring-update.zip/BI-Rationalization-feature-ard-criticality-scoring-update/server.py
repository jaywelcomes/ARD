"""
BI Rationalization Accelerator - FastAPI Backend Server
"""

import os
import sys
import io
import json
import yaml
import logging
import requests
from typing import Dict, Any, List, Optional
import pandas as pd
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

from engine.core_scorer import (
    run_scoring_pipeline,
    load_configuration,
    evaluate_dataset_rationalization
)
from engine.templates_generator import (
    generate_template_csv,
    validate_uploaded_dataframe,
    get_platform_schema,
    PLATFORM_SCHEMAS
)
from engine.excel_exporter import generate_rationalization_excel

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("RationalizationServer")

app = FastAPI(
    title="BI Rationalization & Migration Planning Accelerator API",
    version="2.0.0",
    description="Decoupled 6-dimension BI rationalization, outcome categorization, and wave planning service."
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(BASE_DIR, "input_templates")
OUTPUT_DIR = os.path.join(BASE_DIR, "Output")
CONFIG_PATH = os.path.join(BASE_DIR, "engine", "config.yaml")

os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


class RunScoringRequest(BaseModel):
    input_dir: Optional[str] = None
    output_dir: Optional[str] = None
    custom_weights: Optional[Dict[str, float]] = None


class ChatRequest(BaseModel):
    message: str
    conversation_history: Optional[List[Dict[str, str]]] = None


@app.on_event("startup")
async def startup_event():
    logger.info("Initializing Rationalization Backend Server (Port 8000)...")
    # Server starts ready; scoring is initiated on demand or configuration selection


@app.get("/health")
def health_check():
    return {"status": "online", "service": "Rationalization Accelerator API", "version": "2.0.0"}


@app.get("/api/config")
def get_config():
    cfg = load_configuration(CONFIG_PATH)
    return cfg


@app.post("/api/config")
def update_config(new_config: Dict[str, Any]):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            yaml.safe_dump(new_config, f, default_flow_style=False)
        return {"status": "success", "message": "Configuration updated successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/rationalization/run")
def run_rationalization(req: Optional[RunScoringRequest] = None):
    try:
        inp = (req and req.input_dir) or INPUT_DIR
        out = (req and req.output_dir) or OUTPUT_DIR
        df_readiness, df_summary = run_scoring_pipeline(inp, out, CONFIG_PATH)

        outcome_counts = df_readiness["OutcomeDecision"].value_counts().to_dict()
        wave_counts = df_readiness["ExecutionWave"].value_counts().to_dict()
        avg_score = float(df_readiness["ReadinessScore"].mean()) if not df_readiness.empty else 0.0

        return {
            "status": "success",
            "total_datasets": len(df_readiness),
            "total_workspaces": len(df_summary),
            "average_readiness_score": round(avg_score, 1),
            "outcome_breakdown": outcome_counts,
            "wave_breakdown": wave_counts
        }
    except Exception as e:
        logger.error(f"Error during rationalization execution: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/entities/migration")
@app.get("/api/data/migration")
def get_migration_readiness():
    file_path = os.path.join(OUTPUT_DIR, "migration_readiness.csv")
    if not os.path.exists(file_path):
        return []
    try:
        df = pd.read_csv(file_path)
        df = df.fillna("")
        return df.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/entities/migration_workspaces")
@app.get("/api/data/migration_workspaces")
def get_migration_workspaces():
    file_path = os.path.join(OUTPUT_DIR, "migration_workspace_summary.csv")
    if not os.path.exists(file_path):
        return []
    try:
        df = pd.read_csv(file_path)
        df = df.fillna("")
        return df.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/rationalization/export/excel")
@app.get("/api/data/export/excel")
def export_rationalization_excel():
    """
    Exports comprehensive multi-tab Excel workbook (.xlsx) containing:
    1. All input columns + disposition decisions + 6-dimension category scores
    2. Container & Project summary
    3. Methodology & Scoring legend
    """
    try:
        readiness_file = os.path.join(OUTPUT_DIR, "migration_readiness.csv")
        summary_file = os.path.join(OUTPUT_DIR, "migration_workspace_summary.csv")

        if not os.path.exists(readiness_file):
            df_readiness, df_summary = run_scoring_pipeline(INPUT_DIR, OUTPUT_DIR, CONFIG_PATH)
        else:
            df_readiness = pd.read_csv(readiness_file).fillna("")
            df_summary = pd.read_csv(summary_file).fillna("") if os.path.exists(summary_file) else pd.DataFrame()

        cfg = load_configuration(CONFIG_PATH)
        excel_bytes = generate_rationalization_excel(df_readiness, df_summary, cfg)

        filename = "Rationalization_Assessment_Decisions.xlsx"
        return Response(
            content=excel_bytes,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Access-Control-Expose-Headers": "Content-Disposition"
            }
        )
    except Exception as e:
        logger.error(f"Error generating Excel export: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/templates/schema")
def get_template_schema(platform: Optional[str] = "powerbi"):
    schema = get_platform_schema(platform or "powerbi")
    return {
        "platform": platform,
        "schema": schema,
        "available_platforms": list(PLATFORM_SCHEMAS.keys())
    }


@app.get("/api/templates/download")
def download_template(platform: Optional[str] = "powerbi", samples: Optional[Any] = True):
    try:
        plat_key = (platform or "powerbi").lower().strip()
        include_samples = True
        if isinstance(samples, bool):
            include_samples = samples
        elif isinstance(samples, str):
            include_samples = samples.lower().strip() in ["true", "1", "yes"]
            
        csv_content = generate_template_csv(plat_key, include_samples=include_samples)
        filename = f"{plat_key.capitalize()}_Ingestion_Template.csv"
        return Response(
            content=csv_content,
            media_type="text/csv",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Access-Control-Expose-Headers": "Content-Disposition"
            }
        )
    except Exception as e:
        logger.error(f"Error generating template CSV: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/upload")
async def upload_dimension_file(
    dimension: str = Form(...),
    file: UploadFile = File(...)
):
    valid_dims = ["dim1", "dim2", "dim3", "dim4", "dim5", "dim6", "unified"]
    if dimension not in valid_dims:
        raise HTTPException(status_code=400, detail=f"Invalid dimension. Must be one of {valid_dims}")

    dim_map = {
        "dim1": "dim1_business_value.csv",
        "dim2": "dim2_usage_adoption.csv",
        "dim3": "dim3_technical_quality.csv",
        "dim4": "dim4_performance.csv",
        "dim5": "dim5_governance.csv",
        "dim6": "dim6_complexity.csv",
        "unified": "dataset_inventory.csv"
    }

    target_filename = dim_map[dimension]
    target_path = os.path.join(INPUT_DIR, target_filename)

    try:
        contents = await file.read()
        
        # Schema validation for unified inventory or CSV uploads
        if dimension == "unified":
            try:
                df_upload = pd.read_csv(io.BytesIO(contents))
                cfg = load_configuration(CONFIG_PATH)
                platform = cfg.get("source_platform", "powerbi")
                is_valid, missing_mandatory, missing_optional, stats = validate_uploaded_dataframe(df_upload, platform)
                
                if not is_valid:
                    raise HTTPException(
                        status_code=422,
                        detail={
                            "error": "SCHEMA_VALIDATION_FAILED",
                            "message": f"Mandatory column(s) missing from CSV: {', '.join(missing_mandatory)}",
                            "missing_mandatory": missing_mandatory,
                            "missing_optional": missing_optional,
                            "stats": stats
                        }
                    )
            except HTTPException:
                raise
            except Exception as parse_err:
                logger.error(f"Could not parse uploaded CSV as DataFrame: {parse_err}")
                raise HTTPException(status_code=400, detail=f"Malformed CSV file. Parsing failed: {parse_err}")

        with open(target_path, "wb") as f:
            f.write(contents)
        logger.info(f"Uploaded and saved {target_filename} successfully.")
        return {
            "status": "success",
            "file": target_filename,
            "size_bytes": len(contents),
            "message": f"File {target_filename} uploaded and validated successfully."
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to save uploaded file {target_filename}: {e}")
        raise HTTPException(status_code=500, detail=str(e))



def query_llm_advisor(
    user_query: str,
    history: Optional[List[Dict[str, str]]],
    llm_cfg: Dict[str, Any],
    estate_summary: Dict[str, Any],
    df_assets: pd.DataFrame,
    platform: str = "powerbi"
) -> Optional[str]:
    api_key = (llm_cfg.get("api_key") or os.environ.get("OPENAI_API_KEY") or os.environ.get("GEMINI_API_KEY") or "").strip()
    provider = (llm_cfg.get("provider") or "openai").lower()
    model = llm_cfg.get("model") or "gpt-4o-mini"
    endpoint = (llm_cfg.get("endpoint") or "").strip()
    temperature = float(llm_cfg.get("temperature", 0.2))

    schema_info = PLATFORM_SCHEMAS.get(platform, PLATFORM_SCHEMAS.get("powerbi", {}))
    plat_display = schema_info.get("display_name", platform.capitalize())
    container_term = schema_info.get("container_term", "Container")
    asset_term = schema_info.get("asset_term", "Asset")

    default_system = (
        f"You are an expert Enterprise BI & {plat_display} Migration Solution Architect. "
        f"You assist enterprise teams with {plat_display} rationalization, {asset_term.lower()} scoring, "
        f"phased wave planning across {container_term.lower()}s, model consolidation, and retirement strategies based on estate telemetry."
    )
    system_prompt = llm_cfg.get("system_prompt") or default_system

    if not api_key and provider not in ["ollama"]:
        return None

    # Format estate telemetry context
    asset_snippets = []
    for _, row in df_assets.head(35).iterrows():
        asset_snippets.append(
            f"- {asset_term}: {row.get('Artifact')} | {container_term}: {row.get('Workspace')} | "
            f"Readiness Score: {row.get('ReadinessScore')} | Outcome: {row.get('OutcomeDecision')} | "
            f"Wave: {row.get('ExecutionWave')} | Golden: {row.get('IsGoldenDataset')} | "
            f"HighEfficiencyTarget: {row.get('DirectLakeCandidate')} | Effort: {row.get('Effort')}"
        )
    
    estate_context = (
        f"ESTATE RATIONALIZATION TELEMETRY CONTEXT ({plat_display}):\n"
        f"Total {asset_term}s: {estate_summary.get('total_datasets')}\n"
        f"Average Readiness Score: {estate_summary.get('avg_score')}/100\n"
        f"Outcome Decisions: {json.dumps(estate_summary.get('outcomes', {}))}\n"
        f"Wave Allocations: {json.dumps(estate_summary.get('waves', {}))}\n"
        f"Golden / Certified {asset_term}s Count: {estate_summary.get('golden_count')}\n"
        f"High Efficiency Target Ready Count: {estate_summary.get('dl_count')}\n\n"
        f"Asset Telemetry Sample:\n" + "\n".join(asset_snippets) + "\n\n"
        f"Provide concise, strategic, and actionable advice tailored strictly to {plat_display} rationalization and migration."
    )

    full_system = f"{system_prompt}\n\n{estate_context}"

    try:
        if provider == "openai" or (provider in ["azure_openai", "custom"] and endpoint):
            url = endpoint if endpoint else "https://api.openai.com/v1/chat/completions"
            headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
            messages = [{"role": "system", "content": full_system}]
            for h in (history or []):
                role = "assistant" if h.get("role") in ["agent", "assistant"] else "user"
                messages.append({"role": role, "content": h.get("text", "")})
            messages.append({"role": "user", "content": user_query})

            payload = {
                "model": model,
                "messages": messages,
                "temperature": temperature
            }
            res = requests.post(url, headers=headers, json=payload, timeout=25)
            if res.status_code == 200:
                data = res.json()
                return data["choices"][0]["message"]["content"]
            else:
                logger.error(f"OpenAI LLM API error {res.status_code}: {res.text}")
                return None
        elif provider == "gemini":
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
            headers = {"Content-Type": "application/json"}
            contents = [
                {"role": "user", "parts": [{"text": full_system + "\n\nUser Question: " + user_query}]}
            ]
            res = requests.post(url, headers=headers, json={"contents": contents}, timeout=25)
            if res.status_code == 200:
                data = res.json()
                return data["candidates"][0]["content"]["parts"][0]["text"]
            else:
                logger.error(f"Gemini LLM API error {res.status_code}: {res.text}")
                return None
        elif provider == "ollama":
            url = endpoint if endpoint else "http://localhost:11434/api/chat"
            messages = [{"role": "system", "content": full_system}]
            for h in (history or []):
                role = "assistant" if h.get("role") in ["agent", "assistant"] else "user"
                messages.append({"role": role, "content": h.get("text", "")})
            messages.append({"role": "user", "content": user_query})
            res = requests.post(url, json={"model": model, "messages": messages, "stream": False}, timeout=30)
            if res.status_code == 200:
                return res.json().get("message", {}).get("content")
            return None
    except Exception as e:
        logger.error(f"Exception invoking LLM advisor: {e}")
        return None
    return None


@app.post("/api/chat")
def chat_copilot(req: ChatRequest):
    """
    Context-aware AI Rationalization advisor providing instant guidance based
    on the current rationalization and wave planning dataset.
    Uses configured LLM if API key is present, otherwise falls back to deterministic rule-engine.
    """
    query = req.message.lower()
    
    # Load current readiness
    file_path = os.path.join(OUTPUT_DIR, "migration_readiness.csv")
    if not os.path.exists(file_path):
        return {"reply": "Scoring data is not available yet. Please trigger the rationalization engine first."}

    df = pd.read_csv(file_path)
    total_assets = len(df)
    
    # Contract-aligned query
    disp_col = "ProposedDisposition" if "ProposedDisposition" in df.columns else "OutcomeDecision"
    rev_col = "ReviewStatus" if "ReviewStatus" in df.columns else "Status"
    
    retire_candidates = df[df[disp_col].astype(str).str.lower().str.contains("retire", na=False)]
    review_candidates = df[df[rev_col].astype(str).str.lower().str.contains("review|insufficient", na=False)]
    wave1_assets = df[df["ExecutionWave"].astype(str).str.contains("Wave 1", na=False)]
    golden_assets = df[df["IsGoldenDataset"] == "Yes"]
    dl_candidates = df[df["DirectLakeCandidate"] == "Yes"]
    avg_score = round(df["ReadinessScore"].mean(), 1) if not df.empty else 0

    cfg = load_configuration(CONFIG_PATH)
    platform = cfg.get("source_platform", "powerbi")
    llm_cfg = cfg.get("llm", {})

    schema_info = PLATFORM_SCHEMAS.get(platform, PLATFORM_SCHEMAS.get("powerbi", {}))
    plat_display = schema_info.get("display_name", platform.capitalize())
    container_term = schema_info.get("container_term", "Container")
    asset_term = schema_info.get("asset_term", "Asset")

    # Platform-specific terms
    fast_track_names = {
        "powerbi": "Direct Lake Candidates (Fabric Native)",
        "tableau": "Cloud Hyper / Live Extract Candidates",
        "qlik": "SaaS In-Memory Candidates",
        "looker": "Direct SQL & PDT Candidates",
        "microstrategy": "Intelligent Cube Candidates",
        "universal": "Cloud Native Target Candidates"
    }
    fast_track_name = fast_track_names.get(platform, "Cloud Native Candidates")

    estate_summary = {
        "total_datasets": total_assets,
        "avg_score": avg_score,
        "outcomes": df[disp_col].value_counts().to_dict() if not df.empty else {},
        "waves": df["ExecutionWave"].value_counts().to_dict() if not df.empty else {},
        "golden_count": len(golden_assets),
        "dl_count": len(dl_candidates),
        "retire_count": len(retire_candidates),
        "review_count": len(review_candidates)
    }

    # Attempt LLM query
    llm_reply = query_llm_advisor(
        user_query=req.message,
        history=req.conversation_history,
        llm_cfg=llm_cfg,
        estate_summary=estate_summary,
        df_assets=df,
        platform=platform
    )

    if llm_reply:
        coverage_note = f"\n\n*(Analysis based on top {min(35, total_assets)} of {total_assets} total portfolio assets)*" if total_assets > 35 else ""
        return {"reply": f"{llm_reply}{coverage_note}", "source": "llm", "model": llm_cfg.get("model", "llm")}

    # Deterministic fallback tailored to platform
    if "retire" in query or "archive" in query:
        names = ", ".join(retire_candidates["Artifact"].head(5).tolist()) if not retire_candidates.empty else "None"
        reply = (
            f"There are **{len(retire_candidates)} {asset_term.lower()}s** identified as retirement candidates based on zero usage, "
            f"stale data refreshes, or orphaned status. Top candidates include: {names}."
        )
    elif "review" in query or "duplicate" in query or "similarity" in query:
        names = ", ".join(review_candidates["Artifact"].head(5).tolist()) if not review_candidates.empty else "None"
        reply = (
            f"There are **{len(review_candidates)} {asset_term.lower()}s** marked as **Business Review Required** (potential structural duplicates or insufficient telemetry). "
            f"Examples include: {names}."
        )
    elif "wave" in query or "roadmap" in query or "wave 1" in query:
        w2_count = len(df[df['ExecutionWave'].astype(str).str.contains('Wave 2', na=False)])
        w3_count = len(df[df['ExecutionWave'].astype(str).str.contains('Wave 3', na=False)])
        reply = (
            f"Migration Wave Breakdown across {total_assets} {asset_term.lower()}s for **{plat_display}**:\n"
            f"- **Wave 1 (Migrate As-Is / Fast-Track)**: {len(wave1_assets)} assets\n"
            f"- **Wave 2 (Standard Migrate)**: {w2_count} assets\n"
            f"- **Wave 3 (Complex Architecture Review)**: {w3_count} assets\n"
            f"- **Wave 4 (Retire & Decommission Candidates)**: {len(retire_candidates)} assets"
        )
    elif "golden" in query or "certified" in query:
        golden_names = ", ".join(golden_assets["Artifact"].head(5).tolist()) if not golden_assets.empty else "None"
        reply = (
            f"Identified **{len(golden_assets)} Golden / Certified {asset_term.lower()}s** in {plat_display} with high executive impact and adoption (>50 MAU, downstream reports). "
            f"Key golden assets: {golden_names}."
        )
    elif "direct lake" in query or "hyper" in query or "fast" in query or "target" in query or "cloud" in query:
        reply = (
            f"Found **{len(dl_candidates)} {fast_track_name}** in {plat_display} suitable for immediate target cutover "
            f"without gateway or multi-tier data blend bottlenecks."
        )
    else:
        reply = (
            f"The **{plat_display}** estate has **{total_assets} {asset_term.lower()}s** with an average readiness score of **{avg_score}/100**.\n"
            f"- **Fast-Track / Migrate As-Is**: {len(wave1_assets)}\n"
            f"- **Golden / Certified {asset_term.lower()}s**: {len(golden_assets)}\n"
            f"- **{fast_track_name}**: {len(dl_candidates)}\n"
            f"- **Retire / Cleanup**: {len(retire_candidates)}\n"
            f"💡 *Tip: Connect an LLM API key in **Weights & Config** to enable free-form conversational AI analysis on this estate.*"
        )

    return {"reply": reply, "source": "rule_engine"}


if __name__ == "__main__":
    import uvicorn
    print("Starting Rationalization Accelerator API on http://127.0.0.1:8000 ...")
    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=True)

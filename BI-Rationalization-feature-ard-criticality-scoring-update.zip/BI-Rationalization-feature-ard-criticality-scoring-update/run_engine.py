"""
BI Rationalization Accelerator - Standalone CLI Runner
"""

import os
import sys
import argparse
from engine.core_scorer import run_scoring_pipeline

def main():
    parser = argparse.ArgumentParser(
        description="BI Rationalization & Migration Planning Accelerator CLI"
    )
    parser.add_argument(
        "--input-dir", 
        "-i", 
        default="input_templates", 
        help="Directory containing the 6 dimension CSVs (dim1..dim6) or unified inventory."
    )
    parser.add_argument(
        "--output-dir", 
        "-o", 
        default="Output", 
        help="Directory where migration_readiness.csv and migration_workspace_summary.csv will be saved."
    )
    parser.add_argument(
        "--config", 
        "-c", 
        default=os.path.join("engine", "config.yaml"), 
        help="Path to custom config.yaml file."
    )

    args = parser.parse_args()

    # Ensure output directory exists
    os.makedirs(args.output_dir, exist_ok=True)

    print("================================================================")
    print("      BI Rationalization & Migration Planning Accelerator       ")
    print("================================================================")
    
    try:
        df_readiness, df_summary = run_scoring_pipeline(
            input_dir=args.input_dir,
            output_dir=args.output_dir,
            config_path=args.config if os.path.exists(args.config) else None
        )
        print("\nSUCCESS: Rationalization scoring complete.")
        print(f"Total Datasets Scored:   {len(df_readiness)}")
        print(f"Total Workspaces Scored: {len(df_summary)}")
        print(f"Readiness Breakdown:")
        print(df_readiness["OutcomeDecision"].value_counts().to_string())
        print("================================================================\n")
    except Exception as e:
        print(f"\nERROR running scoring pipeline: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()

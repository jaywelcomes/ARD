#!/usr/bin/env python3
"""
===============================================================================
BI Rationalization Accelerator — Client Packaging & Cleanup Utility
===============================================================================
This utility cleans up development clutter, temporary artifacts, scratch files,
and test suites to prepare a pristine, lightweight client-ready installation.

Usage:
  # 1. Clean current workspace in-place (removes tests, caches, scratch files):
  python cleanup_and_package.py --clean

  # 2. Export a clean, production-ready ZIP archive for client handover:
  python cleanup_and_package.py --export-zip

  # 3. Export a clean standalone directory:
  python cleanup_and_package.py --export-dir ../Client_Deliverable_ARD
===============================================================================
"""

import os
import sys
import shutil
import argparse
import zipfile
from pathlib import Path

# Directories to purge during in-place cleanup
DEV_DIRS_TO_PURGE = [
    "tests",
    ".pytest_cache",
    "__pycache__",
    "scratch",
    ".vscode",
    ".idea"
]

# File patterns to purge recursively
DEV_FILE_PATTERNS = [
    "*.pyc",
    "*.pyo",
    "*.pyd",
    ".DS_Store",
    "Thumbs.db",
    "*.log"
]

# Development notes/scratch files to remove from client delivery
DEV_FILES_TO_REMOVE = [
    "Rewritten Approach.md",
    "ARCHITECTURE_REVIEW.md"
]

# Production essential files to include when packaging an export
ESSENTIAL_EXPORT_ITEMS = [
    "engine",
    "input_templates",
    "frontend",
    "server.py",
    "run_engine.py",
    "run_accelerator.bat",
    "requirements.txt",
    "README.md"
]


def log(msg: str, tag: str = "INFO"):
    print(f"[{tag}] {msg}")


def purge_recursive_patterns(root_path: Path):
    """Recursively removes matching file patterns and __pycache__ folders."""
    count = 0
    # Purge pycache folders
    for pycache in root_path.rglob("__pycache__"):
        if pycache.is_dir():
            shutil.rmtree(pycache, ignore_errors=True)
            count += 1
            
    # Purge pattern files
    for pattern in DEV_FILE_PATTERNS:
        for f in root_path.rglob(pattern):
            if f.is_file():
                try:
                    f.unlink()
                    count += 1
                except Exception:
                    pass
    return count


def clean_inplace(workspace_path: Path, keep_tests: bool = False):
    """Cleans up dev clutter in-place on the target workspace."""
    log(f"Starting in-place cleanup on: {workspace_path}", "CLEAN")
    
    # 1. Purge dev directories
    dirs_to_remove = [d for d in DEV_DIRS_TO_PURGE if not (keep_tests and d == "tests")]
    for dir_name in dirs_to_remove:
        target_dir = workspace_path / dir_name
        if target_dir.exists() and target_dir.is_dir():
            shutil.rmtree(target_dir, ignore_errors=True)
            log(f"Removed directory: {dir_name}/", "REMOVE")
            
    # 2. Purge dev documentation / scratch files
    for fname in DEV_FILES_TO_REMOVE:
        fpath = workspace_path / fname
        if fpath.exists() and fpath.is_file():
            try:
                fpath.unlink()
                log(f"Removed dev file: {fname}", "REMOVE")
            except Exception:
                pass

    # 3. Purge recursive bytecodes and caches
    purged_files = purge_recursive_patterns(workspace_path)
    log(f"Purged {purged_files} cache and temporary files.", "INFO")
    
    # 4. Clean frontend build artifacts if present (leaves src intact)
    next_dir = workspace_path / "frontend" / ".next"
    if next_dir.exists():
        shutil.rmtree(next_dir, ignore_errors=True)
        log("Cleaned frontend build cache (.next/)", "INFO")
        
    print("\n" + "=" * 65)
    log("SUCCESS: Workspace cleaned! Ready for client demonstration.", "SUCCESS")
    print("=" * 65 + "\n")


def export_clean_package(workspace_path: Path, output_dir: Path, make_zip: bool = False):
    """Creates a clean, production-only export directory or zip archive."""
    log(f"Preparing client deliverable package from: {workspace_path}", "PACKAGE")
    
    export_target = output_dir if not make_zip else workspace_path / "_temp_export_build"
    if export_target.exists():
        shutil.rmtree(export_target, ignore_errors=True)
    export_target.mkdir(parents=True, exist_ok=True)
    
    # Copy essential items
    for item in ESSENTIAL_EXPORT_ITEMS:
        src = workspace_path / item
        dst = export_target / item
        if not src.exists():
            continue
            
        if src.is_dir():
            # Exclude node_modules, .next, __pycache__, tests
            def ignore_filter(directory, contents):
                ignored = []
                for c in contents:
                    if c in ["node_modules", ".next", "__pycache__", ".pytest_cache", "tests"]:
                        ignored.append(c)
                    elif c.endswith((".pyc", ".pyo", ".log", ".DS_Store")):
                        ignored.append(c)
                return ignored
            shutil.copytree(src, dst, ignore=ignore_filter)
            log(f"Copied package directory: {item}/", "DIR")
        else:
            shutil.copy2(src, dst)
            log(f"Copied package file: {item}", "FILE")

    # Clean bytecodes inside target
    purge_recursive_patterns(export_target)

    if make_zip:
        zip_filename = workspace_path / "Tableau_ARD_Accelerator_Client_Package.zip"
        log(f"Compressing into ZIP archive: {zip_filename.name}", "ZIP")
        with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(export_target):
                for file in files:
                    full_path = Path(root) / file
                    rel_path = full_path.relative_to(export_target)
                    zipf.write(full_path, rel_path)
        shutil.rmtree(export_target, ignore_errors=True)
        print("\n" + "=" * 70)
        log(f"SUCCESS: Client package created: {zip_filename.resolve()}", "SUCCESS")
        print("=" * 70 + "\n")
    else:
        print("\n" + "=" * 70)
        log(f"SUCCESS: Clean directory exported to: {export_target.resolve()}", "SUCCESS")
        print("=" * 70 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="Clean up clutter or package a clean client deliverable for BI Rationalization Accelerator."
    )
    parser.add_argument(
        "--clean", action="store_true",
        help="Perform in-place cleanup on the current workspace (removes tests, caches, scratch files)."
    )
    parser.add_argument(
        "--export-zip", action="store_true",
        help="Export a clean, production-ready ZIP archive of the accelerator."
    )
    parser.add_argument(
        "--export-dir", type=str, default=None,
        help="Export a clean production directory to the specified destination path."
    )
    parser.add_argument(
        "--keep-tests", action="store_true",
        help="Preserve unit tests during in-place cleanup."
    )

    args = parser.parse_args()
    workspace_path = Path(__file__).resolve().parent

    if args.clean:
        clean_inplace(workspace_path, keep_tests=args.keep_tests)
    elif args.export_zip:
        export_clean_package(workspace_path, output_dir=workspace_path, make_zip=True)
    elif args.export_dir:
        dest = Path(args.export_dir).resolve()
        export_clean_package(workspace_path, output_dir=dest, make_zip=False)
    else:
        # Default interactive behavior if run without flags
        print("=" * 70)
        print("   BI Rationalization Accelerator — Client Packaging & Cleanup   ")
        print("=" * 70)
        print("Please choose an operation:")
        print("  [1] Clean current workspace in-place (Remove test scripts, caches, scratch)")
        print("  [2] Export clean client-ready ZIP package (Tableau_ARD_Accelerator_Client_Package.zip)")
        print("  [3] Export clean client folder to a new location")
        print("  [4] Exit")
        try:
            choice = input("\nEnter choice [1-4]: ").strip()
        except EOFError:
            choice = "4"
        
        if choice == "1":
            clean_inplace(workspace_path, keep_tests=args.keep_tests)
        elif choice == "2":
            export_clean_package(workspace_path, output_dir=workspace_path, make_zip=True)
        elif choice == "3":
            try:
                out_path = input("Enter destination folder path: ").strip()
            except EOFError:
                out_path = ""
            if out_path:
                export_clean_package(workspace_path, output_dir=Path(out_path).resolve(), make_zip=False)
        else:
            print("Exited without changes.")


if __name__ == "__main__":
    main()

"""
Rationalization & Migration Scoring Engine
Package: rationalization_accelerator.engine
"""

import os
import sys
import yaml
import logging
import argparse
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Tuple, Optional, List
import pandas as pd
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("RationalizationEngine")

from engine.templates_generator import (
    PLATFORM_SCHEMAS,
    validate_uploaded_dataframe,
    get_platform_schema
)

DEFAULT_CONFIG: Dict[str, Any] = {
    "source_platform": "powerbi",
    "wave_configuration": {
        "wave_count": 4,
        "strategy": "score_based"
    },
    "weights": {
        "business_value": 0.25,
        "usage_adoption": 0.20,
        "technical_quality": 0.20,
        "performance": 0.15,
        "governance": 0.10,
        "complexity": 0.10
    },
    "thresholds": {
        "stale_dataset_days": 90,
        "usage_high_mau_limit": 200,
        "usage_mid_mau_limit": 50,
        "usage_views_multiplier": 1.6,
        "tq_column_limit": 100,
        "tq_column_deduction": 30,
        "tq_calc_column_ratio": 0.25,
        "tq_calc_column_deduction": 40,
        "tq_single_table_col_limit": 20,
        "tq_single_table_deduction": 30,
        "perf_large_dataset_size_mb": 1000,
        "perf_large_dataset_deduction": 40,
        "perf_high_risk_dax_deduction": 40,
        "gov_personal_deduction": 30,
        "gov_orphan_deduction": 40,
        "gov_no_sensitivity_deduction": 30,
        "complexity_low_sources_limit": 3,
        "complexity_high_sources_limit": 5
    },
    "executive_keywords": [
        "executive", "board", "c-level", "ceo", "cfo", "corporate", "financial", "audit", "enterprise"
    ],
    "llm": {
        "provider": "openai",
        "model": "gpt-4o-mini",
        "api_key": "",
        "endpoint": "",
        "temperature": 0.2,
        "system_prompt": "You are an expert Enterprise BI & Cloud Migration Solution Architect. You assist enterprise teams with BI rationalization, asset scoring, wave sequencing, model consolidation, and retirement strategies based on real estate telemetry."
    }
}


def normalize_dataframe_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Standardizes cross-platform telemetry columns into canonical scoring names.
    (e.g., Tableau artifact_name/project_name or Qlik app_name/stream_name -> dataset_name/workspace_name)
    """
    df_norm = df.copy()
    col_map = {
        # Asset Name aliases
        "artifact_name": "dataset_name",
        "app_name": "dataset_name",
        "explore_name": "dataset_name",
        "dossier_name": "dataset_name",
        "report_name": "dataset_name",
        "model_title": "dataset_name",
        "workbook_name": "dataset_name",
        
        # Workspace / Container aliases
        "project_name": "workspace_name",
        "stream_name": "workspace_name",
        "model_name": "workspace_name",
        "folder_name": "workspace_name",
        "site_name": "workspace_name",

        # Usage & Views aliases
        "view_count_total": "activity_views",
        "session_count_total": "activity_views",
        "query_count_30d": "activity_views",
        "execution_count_30d": "activity_views",
        "views": "activity_views",
        "view_count_180d": "activity_views",
        "distinct_users_180d": "monthly_active_users",
        "distinct_users": "monthly_active_users",

        # Data source aliases
        "source_system_count": "data_source_count",
        "connection_count": "data_source_count",
        "datasource_count": "data_source_count",
        "data_connection_count": "data_source_count",

        # Metrics & Calculations aliases
        "metric_count": "measure_count",
        "calculation_count": "measure_count",
        "lod_calc_count": "calculated_column_count",
        "set_analysis_expression_count": "measure_count",
        "dimension_count": "calculated_column_count",
        "join_relationship_count": "relationship_count",

        # Size aliases
        "extract_size_mb": "dataset_size_mb",
        "memory_ram_size_mb": "dataset_size_mb",
        "cube_size_mb": "dataset_size_mb",

        # Domain & Sector aliases
        "bu_sector": "business_domain",
        "sector": "business_domain",

        # Staleness aliases
        "days_since_last_access": "days_since_last_refresh",
        "days_since_last_reload": "days_since_last_refresh",
        "days_since_last_query": "days_since_last_refresh",
        "days_since_last_execution": "days_since_last_refresh",
        "last_access_date": "last_refresh_time"
    }

    # Rename case-insensitively
    rename_dict = {}
    for c in df_norm.columns:
        c_clean = str(c).strip().lower()
        if c_clean in col_map and col_map[c_clean] not in df_norm.columns:
            rename_dict[c] = col_map[c_clean]

    if rename_dict:
        df_norm = df_norm.rename(columns=rename_dict)

    return df_norm


def assign_dynamic_wave(score: float, wave_count: int) -> Tuple[str, str, str]:
    """
    Dynamically assigns Execution Wave, Effort, and Readiness Status based on wave_count (2 to 6).
    """
    n = max(2, min(6, int(wave_count or 4)))

    if n == 2:
        if score >= 60:
            return "Wave 1: Migrate & Modernize", "2-3 Days", "Ready (Low Risk)"
        else:
            return "Wave 2: Redesign & Retire", "1-2 Weeks", "High Complexity / Rebuild"

    elif n == 3:
        if score >= 75:
            return "Wave 1: Fast-Track Migrate", "1-2 Days", "Ready (Automated)"
        elif score >= 40:
            return "Wave 2: Optimize & Rebuild", "3-5 Days", "Moderate (Redesign)"
        else:
            return "Wave 3: Retire & Decommission", "Cleanup", "Retired / Archive"

    elif n == 5:
        if score >= 85:
            return "Wave 1: Direct Fast-Track", "1 Day", "Ready (Automated)"
        elif score >= 70:
            return "Wave 2: Standard Migration", "2-3 Days", "Low Risk (Direct)"
        elif score >= 50:
            return "Wave 3: Optimize & Modernize", "4-6 Days", "Moderate (Redesign)"
        elif score >= 35:
            return "Wave 4: Re-architect Native", "1-2 Weeks", "Complex (Architecture Review)"
        else:
            return "Wave 5: Retire & Decommission", "Cleanup", "Retired / Archive"

    elif n == 6:
        if score >= 85:
            return "Wave 1: Fast-Track Direct", "1 Day", "Ready (Automated)"
        elif score >= 75:
            return "Wave 2: Minimal Refactor", "2 Days", "Low Risk"
        elif score >= 60:
            return "Wave 3: Standard Optimization", "3-5 Days", "Moderate"
        elif score >= 45:
            return "Wave 4: Semantic Redesign", "1-2 Weeks", "Complex"
        elif score >= 30:
            return "Wave 5: Deep Re-architecture", "2-3 Weeks", "High Complexity"
        else:
            return "Wave 6: Retire & Decommission", "Cleanup", "Retired / Archive"

    else: # n == 4 (Default)
        if score >= 80:
            return "Wave 1: Migrate As-Is", "1-2 Days", "Ready (Automated)"
        elif score >= 60:
            return "Wave 2: Optimize & Migrate", "3-5 Days", "Moderate (Partial Redesign)"
        elif score >= 40:
            return "Wave 3: Rebuild Native", "1-2 Weeks", "Complex (Architecture Review)"
        else:
            return "Wave 4: Retire & Archive", "Rebuild Needed", "High Risk (Rebuild)"


def load_configuration(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Loads engine configuration and scoring weights from YAML file.
    Falls back to built-in defaults if file is missing or invalid.
    """
    if config_path and os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = yaml.safe_load(f)
                if isinstance(cfg, dict):
                    return cfg
        except Exception as ex:
            logger.warning(f"Failed to parse config file {config_path}: {ex}. Using defaults.")
    return DEFAULT_CONFIG


def load_input_datasets(input_dir: str, cfg: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
    """
    Ingests dimension CSV files (dim1 through dim6) or unified dataset inventory
    from input directory.
    """
    unified_path = os.path.join(input_dir, "dataset_inventory.csv")
    ard_path = os.path.join(input_dir, "tableau_ard_unified_template.csv")
    
    # Check dataset_inventory.csv first as it represents the active / uploaded unified inventory
    if os.path.exists(unified_path):
        logger.info(f"Loading unified inventory from {unified_path}")
        return pd.read_csv(unified_path)

    if os.path.exists(ard_path):
        logger.info(f"Loading Tableau ARD inventory from {ard_path}")
        return pd.read_csv(ard_path)

    dim_files = {
        "dim1": os.path.join(input_dir, "dim1_business_value.csv"),
        "dim2": os.path.join(input_dir, "dim2_usage_adoption.csv"),
        "dim3": os.path.join(input_dir, "dim3_technical_quality.csv"),
        "dim4": os.path.join(input_dir, "dim4_performance.csv"),
        "dim5": os.path.join(input_dir, "dim5_governance.csv"),
        "dim6": os.path.join(input_dir, "dim6_complexity.csv")
    }

    # Check if individual dimensions exist
    existing_dims = {k: v for k, v in dim_files.items() if os.path.exists(v)}

    if not existing_dims:
        raise FileNotFoundError(f"No dimension CSV files or unified template found in {input_dir}")

    # Load dim1 as primary base
    if "dim1" in existing_dims:
        base_df = pd.read_csv(existing_dims["dim1"])
    else:
        first_key = list(existing_dims.keys())[0]
        base_df = pd.read_csv(existing_dims[first_key])

    join_cols = [c for c in ["dataset_id", "workspace_id"] if c in base_df.columns]

    for key, path in existing_dims.items():
        if key == "dim1":
            continue
        dim_df = pd.read_csv(path)
        # Avoid column collisions (excluding join keys and common descriptive names)
        cols_to_use = [c for c in dim_df.columns if c not in base_df.columns or c in join_cols]
        if join_cols and all(k in dim_df.columns for k in join_cols):
            base_df = pd.merge(base_df, dim_df[cols_to_use], on=join_cols, how="left")
        elif "dataset_id" in dim_df.columns and "dataset_id" in base_df.columns:
            cols_to_use_single = [c for c in dim_df.columns if c not in base_df.columns or c == "dataset_id"]
            base_df = pd.merge(base_df, dim_df[cols_to_use_single], on="dataset_id", how="left")
        else:
            base_df = pd.concat([base_df, dim_df], axis=1)

    return base_df


def compute_business_value_score(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Calculates Dimension 1: Business Value Score (0-100)."""
    endorsement = str(row.get("endorsement", "")).strip().lower()
    is_certified = str(row.get("is_certified", "False")).strip().lower() in ["true", "1", "yes"]
    ws_name = str(row.get("workspace_name", "")).lower()
    ws_desc = str(row.get("workspace_description", "")).lower()
    ws_type = str(row.get("workspace_type", "Group")).lower()
    
    exec_keywords = cfg.get("executive_keywords", [])
    is_exec = is_certified or endorsement == "certified" or any(k in ws_name or k in ws_desc for k in exec_keywords)
    
    if is_exec:
        return 100.0
    elif endorsement == "promoted" or ws_type == "group":
        return 60.0
    else:
        return 20.0


def compute_usage_adoption_score(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Calculates Dimension 2: Usage & Adoption Score (0-100)."""
    thresh = cfg.get("thresholds", {})
    views = float(row.get("activity_views", row.get("view_count_180d", 0)) or 0)
    
    # Respect explicit 30d monthly active users vs 180d distinct users
    if "monthly_active_users" in row and pd.notna(row.get("monthly_active_users")):
        mau = float(row.get("monthly_active_users", 0) or 0)
    elif "distinct_users_180d" in row and pd.notna(row.get("distinct_users_180d")):
        # Scale 180-day window down to equivalent monthly active scale without mutating raw column
        mau = float(row.get("distinct_users_180d", 0) or 0) * (30.0 / 180.0)
    else:
        mau = 0.0

    has_subs = str(row.get("has_subscriptions", "False")).strip().lower() in ["true", "1", "yes"]
    
    # Refresh staleness
    last_refresh = str(row.get("last_refresh_time", ""))
    stale = False
    if last_refresh and last_refresh.lower() not in ["nan", "none", ""]:
        try:
            dt = datetime.fromisoformat(last_refresh.replace("Z", "+00:00"))
            if datetime.now(timezone.utc) - dt > timedelta(days=thresh.get("stale_dataset_days", 90)):
                stale = True
        except Exception:
            pass

    if (stale or not last_refresh or last_refresh.lower() in ["nan", "none"]) and views == 0 and mau == 0:
        return 0.0
    elif mau > thresh.get("usage_high_mau_limit", 200):
        return 100.0
    elif mau > thresh.get("usage_mid_mau_limit", 50) or has_subs:
        return 80.0
    else:
        calc_v = views * thresh.get("usage_views_multiplier", 1.6)
        return float(np.clip(calc_v, 20.0 if views > 0 else 0.0, 80.0))


def compute_technical_quality_score(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Calculates Dimension 3: Technical Quality Score (0-100)."""
    thresh = cfg.get("thresholds", {})
    num_tables = float(row.get("table_count", 1) or 1)
    total_cols = float(row.get("total_column_count", row.get("column_count", 0)) or 0)
    calc_cols = float(row.get("calculated_column_count", 0) or 0)

    deductions = 0.0
    if total_cols > thresh.get("tq_column_limit", 100):
        deductions += thresh.get("tq_column_deduction", 30)
    if total_cols > 0 and (calc_cols / total_cols) > thresh.get("tq_calc_column_ratio", 0.25):
        deductions += thresh.get("tq_calc_column_deduction", 40)
    if num_tables <= 1 and total_cols > thresh.get("tq_single_table_col_limit", 20):
        deductions += thresh.get("tq_single_table_deduction", 30)

    return float(max(0.0, 100.0 - deductions))


def compute_performance_score(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Calculates Dimension 4: Performance Score (0-100)."""
    thresh = cfg.get("thresholds", {})
    size_mb = float(row.get("dataset_size_mb", 0) or 0)
    has_inc_ref = str(row.get("has_incremental_refresh", "False")).strip().lower() in ["true", "1", "yes"]
    has_risk_dax = str(row.get("has_high_risk_dax", "False")).strip().lower() in ["true", "1", "yes"]

    deductions = 0.0
    if has_risk_dax:
        deductions += thresh.get("perf_high_risk_dax_deduction", 40)
    if size_mb > thresh.get("perf_large_dataset_size_mb", 1000) and not has_inc_ref:
        deductions += thresh.get("perf_large_dataset_deduction", 40)

    return float(max(0.0, 100.0 - deductions))


def compute_governance_score(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Calculates Dimension 5: Governance Score (0-100)."""
    thresh = cfg.get("thresholds", {})
    ws_type = str(row.get("workspace_type", "Group")).lower()
    is_personal = ws_type in ["personal", "personalgroup", "my workspace"]
    admin_count = float(row.get("workspace_admin_count", 1) or 0)
    is_orphan = admin_count == 0
    sensitivity = str(row.get("sensitivity_label", "")).strip().lower()

    deductions = 0.0
    if is_personal:
        deductions += thresh.get("gov_personal_deduction", 30)
    if is_orphan:
        deductions += thresh.get("gov_orphan_deduction", 40)
    if not sensitivity or sensitivity in ["none", "no label", "nan", ""]:
        deductions += thresh.get("gov_no_sensitivity_deduction", 30)

    return float(max(0.0, 100.0 - deductions))


def compute_complexity_score(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Calculates Dimension 6: Complexity Score (0-100)."""
    thresh = cfg.get("thresholds", {})
    sources = float(row.get("data_source_count", row.get("datasource_count", 1)) or 1)

    if sources < thresh.get("complexity_low_sources_limit", 3):
        return 100.0
    elif sources > thresh.get("complexity_high_sources_limit", 5):
        return 30.0
    else:
        return 60.0


def normalize_dataframe_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Normalizes cross-platform and aliased column names and safely coerces numeric types."""
    df_norm = df.copy()
    alias_map = {
        "artifact_name": "dataset_name",
        "workbook_name": "dataset_name",
        "report_name": "dataset_name",
        "project_name": "workspace_name",
        "view_count_total": "activity_views",
        "data_source_count": "datasource_count"
    }
    for old_col, new_col in alias_map.items():
        if old_col in df_norm.columns and new_col not in df_norm.columns:
            df_norm[new_col] = df_norm[old_col]

    # Coerce standard numeric columns if present
    num_cols = [
        "table_count", "monthly_active_users", "activity_views", "distinct_users_180d", "view_count_180d",
        "datasource_count", "total_column_count", "calculated_column_count", "measure_count", "dataset_size_mb",
        "relationship_count", "downstream_report_count", "workspace_admin_count"
    ]
    for nc in num_cols:
        if nc in df_norm.columns:
            df_norm[nc] = pd.to_numeric(df_norm[nc], errors="coerce").fillna(0)

    return df_norm


def validate_and_normalize_inventory(df: pd.DataFrame, cfg: Dict[str, Any]) -> Tuple[pd.DataFrame, List[str]]:
    """
    Strictly validates and normalizes dataset inventory before scoring.
    Rejects malformed structures and reports schema errors.
    """
    errors = []
    if df is None or df.empty:
        return df, ["Uploaded inventory is completely empty."]

    # Check for basic required columns or aliases
    has_name = any(c in df.columns for c in ["dataset_name", "workbook_name", "artifact_name", "app_name", "report_name"])
    if not has_name:
        errors.append("Inventory missing mandatory asset name column (e.g., dataset_name or workbook_name).")

    # Normalize dataframe
    df_norm = normalize_dataframe_columns(df)
    return df_norm, errors


try:
    from engine.ard_scorer import evaluate_tableau_ard_rationalization, compute_dataset_fingerprint_sha256
except ImportError:
    from ard_scorer import evaluate_tableau_ard_rationalization, compute_dataset_fingerprint_sha256


def evaluate_dataset_rationalization(df: pd.DataFrame, cfg: Dict[str, Any]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Executes scoring and outcome categorization on dataset records.
    Strictly follows configured strategy_mode.
    """
    strategy_mode = cfg.get("strategy_mode", "standard_6r")
    
    if strategy_mode == "tableau_ard_lift_and_shift":
        logger.info("Executing Tableau ARD Lift & Shift Scoring Engine (Explicit Strategy Mode)...")
        return evaluate_tableau_ard_rationalization(df, cfg)

    # Normalize cross-platform columns to canonical names
    df_norm, val_errors = validate_and_normalize_inventory(df, cfg)
    if val_errors:
        logger.warning(f"Validation warnings during normalization: {val_errors}")

    weights = cfg.get("weights", {})
    w_bv = weights.get("business_value", 0.25)
    w_us = weights.get("usage_adoption", 0.20)
    w_tq = weights.get("technical_quality", 0.20)
    w_ps = weights.get("performance", 0.15)
    w_gs = weights.get("governance", 0.10)
    w_cs = weights.get("complexity", 0.10)
    total_weights = w_bv + w_us + w_tq + w_ps + w_gs + w_cs or 1.0

    wave_cfg = cfg.get("wave_configuration", {})
    wave_count = wave_cfg.get("wave_count", 4)

    # Calculate dataset name counts for consolidation heuristic
    name_counts = df_norm["dataset_name"].str.strip().str.lower().value_counts().to_dict() if "dataset_name" in df_norm.columns else {}

    readiness_records = []
    workspace_groups = {}

    for _, row in df_norm.iterrows():
        ds_name = str(row.get("dataset_name", "Unnamed Asset"))
        ws_name = str(row.get("workspace_name", "Default Workspace"))
        ws_type = str(row.get("workspace_type", "Group")).lower()
        is_personal = ws_type in ["personal", "personalgroup", "my workspace"]
        admin_count = float(row.get("workspace_admin_count", 1) or 0)
        is_orphan = admin_count == 0
        is_on_dedicated = str(row.get("workspace_is_on_dedicated_capacity", "False")).strip().lower() in ["true", "1", "yes"]
        is_eligible = "No" if is_on_dedicated else "Yes"
        business_domain = str(row.get("business_domain", "General"))

        # Dimension Scores
        bv_score = compute_business_value_score(row, cfg)
        us_score = compute_usage_adoption_score(row, cfg)
        tq_score = compute_technical_quality_score(row, cfg)
        ps_score = compute_performance_score(row, cfg)
        gs_score = compute_governance_score(row, cfg)
        cs_score = compute_complexity_score(row, cfg)

        # Composite Score
        composite_score = round((
            (w_bv * bv_score) +
            (w_us * us_score) +
            (w_tq * tq_score) +
            (w_ps * ps_score) +
            (w_gs * gs_score) +
            (w_cs * cs_score)
        ) / total_weights, 1)

        # Outcome Decision Classification
        is_dup = ds_name and name_counts.get(ds_name.strip().lower(), 0) > 1
        if composite_score < 40:
            outcome = "Retire"
        elif is_dup and composite_score >= 40:
            outcome = "Consolidate"
        elif is_personal and composite_score >= 60 and bv_score >= 60:
            outcome = "Salvage"
        elif 40 <= composite_score < 60:
            outcome = "Rebuild"
        elif 60 <= composite_score < 80:
            outcome = "Optimize"
        else:
            outcome = "Migrate As-Is"

        # Execution Wave Planner (Dynamic N-Wave assignment)
        wave, effort, status = assign_dynamic_wave(composite_score, wave_count)

        # Golden Dataset Heuristic
        mau = float(row.get("monthly_active_users", 0) or 0)
        reports = float(row.get("downstream_report_count", 0) or 0)
        is_golden = "Yes" if (mau > 50 and bv_score >= 80 and reports >= 1) else "No"

        # Direct Lake Candidate Heuristic
        has_gw = str(row.get("has_gateway", "False")).strip().lower() in ["true", "1", "yes"]
        has_dq = str(row.get("has_directquery", "False")).strip().lower() in ["true", "1", "yes"]
        is_composite_mode = str(row.get("storage_mode", "")).strip().lower() == "composite"
        is_dl_candidate = "Yes" if (not has_gw and not has_dq and not is_composite_mode) else "No"

        # Reason rationale generation for Standard 6R
        ds_hash = compute_dataset_fingerprint_sha256(row) if "compute_dataset_fingerprint_sha256" in globals() else "hash-std"
        crit_sum = round((bv_score * 2.0 + us_score * 2.0), 1)
        if outcome == "Retire":
            reason = f"Retire: Low Composite Score ({composite_score:.1f} < 40) due to stale activity or low business value."
        elif outcome == "Consolidate":
            reason = f"Consolidate: Duplicate dataset name with high score ({composite_score:.1f} >= 40). Candidate for unified semantic model."
        elif outcome == "Salvage":
            reason = f"Salvage: High-value personal asset ({composite_score:.1f} >= 60, BV {bv_score:.0f}). Promote to group workspace."
        elif outcome == "Rebuild":
            reason = f"Rebuild: Score {composite_score:.1f} (40-60). High technical debt or complex transformation requires redesign."
        elif outcome == "Optimize":
            reason = f"Optimize: Score {composite_score:.1f} (60-80). Requires measure/column pruning before migration."
        else:
            reason = f"Migrate As-Is: High readiness ({composite_score:.1f} >= 80). Direct fast-track conversion."

        # Typed Decision Contract mapping for Standard 6R
        proposed_disp = "Retire candidate" if outcome == "Retire" else "Select for migration"
        rev_stat = "Business review required" if outcome in ["Rebuild", "Salvage", "Consolidate"] else "Ready"
        sim_flag = "Potential structural duplicate" if is_dup else "Unique"
        asset_id = str(row.get("asset_id", row.get("luid", row.get("dataset_id", f"{ws_name}:Dataset:{ds_name}"))))

        # Preserve all original input row columns (excluding internal helper columns starting with _)
        asset_record = {k: v for k, v in row.items() if not str(k).startswith("_")}
        asset_record.update({
            "AssetId": asset_id,
            "Workspace": ws_name,
            "WorkspaceName": ws_name,
            "Artifact": ds_name,
            "Type": "Dataset",
            "ReadinessScore": composite_score,
            "CriticalityScore": crit_sum,
            "ComplexityScore": cs_score,
            "ProposedDisposition": proposed_disp,
            "ReviewStatus": rev_stat,
            "SimilarityFlag": sim_flag,
            "SuggestedRetainedAssetId": "",
            "SuggestedRetainedAssetName": "",
            "Status": status,
            "OutcomeDecision": outcome,
            "ExecutionWave": wave,
            "Effort": effort,
            "EvidenceState": sim_flag,
            "CanonicalMaster": "",
            "RecommendationReason": reason,
            "DatasourceFingerprint": ds_hash,
            "DuplicateStatus": "Duplicate Cluster" if is_dup else "Unique Model",
            "IsGoldenDataset": is_golden,
            "BusinessValueScore": bv_score,
            "UsageScore": us_score,
            "TechnicalQualityScore": tq_score,
            "PerformanceScore": ps_score,
            "GovernanceScore": gs_score,
            "DirectLakeCandidate": is_dl_candidate,
            "ActivityViews": int(row.get("activity_views", 0) or 0),
            "GatewayDependency": "Yes" if has_gw else "No",
            "DirectQuery": "Yes" if has_dq else "No",
            "Composite": "Yes" if is_composite_mode else "No",
            "RLS": "Yes" if str(row.get("has_rls", "False")).strip().lower() in ["true", "1", "yes"] else "No",
            "DownstreamReports": int(reports),
            "Tables": int(row.get("table_count", 0) or 0),
            "Measures": int(row.get("measure_count", 0) or 0),
            "Relationships": int(row.get("relationship_count", 0) or 0),
            "Orphan": "Yes" if is_orphan else "No",
            "Stale": "Yes" if us_score == 0 else "No",
            "Personal": "Yes" if is_personal else "No",
            "MigrationEligible": is_eligible,
            "BusinessDomain": business_domain
        })
        readiness_records.append(asset_record)

        # Track workspace aggregates
        if ws_name not in workspace_groups:
            workspace_groups[ws_name] = {
                "WorkspaceName": ws_name,
                "TotalDatasets": 0,
                "TotalScore": 0.0,
                "MaxBusinessValue": 0.0,
                "RetireCount": 0,
                "IsOrphan": "Yes" if is_orphan else "No",
                "MemberCount": int(row.get("workspace_member_count", 1) or 1),
                "IsPersonal": "Yes" if is_personal else "No",
                "State": str(row.get("workspace_state", "Active")),
                "MigrationEligible": is_eligible,
                "BusinessDomain": business_domain,
                "GoldenCount": 0
            }

        ws_stat = workspace_groups[ws_name]
        ws_stat["TotalDatasets"] += 1
        ws_stat["TotalScore"] += composite_score
        ws_stat["MaxBusinessValue"] = max(ws_stat["MaxBusinessValue"], bv_score)
        if outcome == "Retire":
            ws_stat["RetireCount"] += 1
        if is_golden == "Yes":
            ws_stat["GoldenCount"] += 1

    df_readiness = pd.DataFrame(readiness_records)

    # Compile Workspace Summary
    summary_records = []
    for ws_name, stat in workspace_groups.items():
        total_ds = stat["TotalDatasets"]
        avg_score = round(stat["TotalScore"] / total_ds, 1) if total_ds > 0 else 0.0
        retire_ratio = (stat["RetireCount"] / total_ds) if total_ds > 0 else 0.0
        is_prune = "Yes" if (stat["IsPersonal"] == "Yes" or stat["IsOrphan"] == "Yes" or retire_ratio >= 0.8) else "No"
        golden_override = "Yes" if (stat["GoldenCount"] > 0 and is_prune == "Yes") else "No"

        # Workspace Decision
        if is_prune == "Yes" and golden_override == "No":
            ws_outcome = "Retire Candidate"
            ws_wave = "Wave 4: Retire & Archive"
        elif avg_score >= 80:
            ws_outcome = "Migrate As-Is"
            ws_wave = "Wave 1: Migrate As-Is"
        elif avg_score >= 60:
            ws_outcome = "Consolidate & Optimize"
            ws_wave = "Wave 2: Optimize & Migrate"
        elif avg_score >= 40:
            ws_outcome = "Rebuild Native"
            ws_wave = "Wave 3: Rebuild Native"
        else:
            ws_outcome = "Retire Candidate"
            ws_wave = "Wave 4: Retire & Archive"

        summary_records.append({
            "WorkspaceName": ws_name,
            "TotalDatasets": total_ds,
            "AvgReadinessScore": avg_score,
            "WorkspaceOutcome": ws_outcome,
            "GoldenOverrideApplied": golden_override,
            "PruningCandidate": is_prune,
            "BusinessDomain": stat["BusinessDomain"],
            "ExecutionWave": ws_wave,
            "Orphaned": stat["IsOrphan"],
            "MemberCount": stat["MemberCount"],
            "IsPersonal": stat["IsPersonal"],
            "State": stat["State"],
            "MigrationEligible": stat["MigrationEligible"]
        })

    df_workspace_summary = pd.DataFrame(summary_records)
    return df_readiness, df_workspace_summary


def run_scoring_pipeline(input_dir: str, output_dir: str, config_path: Optional[str] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Main execution pipeline: loads input dimension CSVs, applies scoring rules,
    and outputs migration_readiness.csv and migration_workspace_summary.csv.
    """
    logger.info(f"Starting Rationalization Scoring Pipeline...")
    logger.info(f"Input Directory:  {input_dir}")
    logger.info(f"Output Directory: {output_dir}")

    os.makedirs(output_dir, exist_ok=True)
    cfg = load_configuration(config_path)

    df_input = load_input_datasets(input_dir, cfg)
    logger.info(f"Loaded {len(df_input)} dataset records for rationalization analysis.")

    df_readiness, df_summary = evaluate_dataset_rationalization(df_input, cfg)

    readiness_path = os.path.join(output_dir, "migration_readiness.csv")
    summary_path = os.path.join(output_dir, "migration_workspace_summary.csv")

    df_readiness.to_csv(readiness_path, index=False)
    df_summary.to_csv(summary_path, index=False)

    logger.info(f"Scoring Complete!")
    logger.info(f"Generated Asset Readiness: {readiness_path} ({len(df_readiness)} records)")
    logger.info(f"Generated Workspace Summary: {summary_path} ({len(df_summary)} workspaces)")

    return df_readiness, df_summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BI Rationalization & Migration Scoring Engine")
    parser.add_argument("--input-dir", default="input_templates", help="Path to input templates directory")
    parser.add_argument("--output-dir", default="Output", help="Path to output directory")
    parser.add_argument("--config", default=None, help="Path to custom config.yaml")

    args = parser.parse_args()
    run_scoring_pipeline(args.input_dir, args.output_dir, args.config)

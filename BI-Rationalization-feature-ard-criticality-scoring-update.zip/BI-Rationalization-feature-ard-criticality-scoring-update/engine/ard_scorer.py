"""
Tableau ARD (Assess-Rationalize-Disposition) Lift & Shift Scoring Engine
Calculates 400-Point Criticality, 900-Point Complexity, Deterministic Similarity Screening,
Typed Decision Contracts, and Explainable Rationales.
"""

import hashlib
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Tuple, List, Optional
import pandas as pd
import numpy as np
import logging

logger = logging.getLogger("RationalizationEngine.ARD")


def _safe_float(val: Any, default: Optional[float] = None) -> Optional[float]:
    """Safely converts input to float, preserving None for missing/unobserved values."""
    if val is None or pd.isna(val) or str(val).strip().lower() in ["", "nan", "none", "null"]:
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        return default


def _safe_int(val: Any, default: Optional[int] = None) -> Optional[int]:
    """Safely converts input to int, preserving None for missing/unobserved values."""
    if val is None or pd.isna(val) or str(val).strip().lower() in ["", "nan", "none", "null"]:
        return default
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return default


def _clean_str(val: Any) -> Optional[str]:
    """Safely extracts clean string, returning None for empty/null/nan/'None' values."""
    if val is None or pd.isna(val):
        return None
    s = str(val).strip()
    if s.lower() in ["", "nan", "none", "null"]:
        return None
    return s


def compute_dataset_fingerprint_sha256(row: pd.Series) -> str:
    """
    Generates a deterministic SHA-256 fingerprint for a dataset/model based on its
    connection footprint, joins, custom SQL, RLS architecture, and storage size.
    Returns empty string if any core structural metric is unobserved.
    """
    dc = _safe_int(row.get("data_connection_count", row.get("data_source_count", None)))
    csql = _safe_int(row.get("custom_sql_count", None))
    joins = _safe_int(row.get("join_relationship_count", row.get("relationship_count", None)))

    # Gated: If ANY core structural count is unobserved, do not generate fingerprint (avoid matching observed 0/1)
    if dc is None or csql is None or joins is None:
        return ""

    elements = [
        str(dc),
        str(csql),
        str(joins),
        str(_safe_int(row.get("data_blending_count", 0), default=0)),
        str(str(row.get("has_rls", "False")).strip().lower() in ["true", "1", "yes"]),
        str(row.get("rls_type", "None")).strip().lower(),
        str(str(row.get("is_live_connection", "False")).strip().lower() in ["true", "1", "yes"]),
        str(_safe_int(row.get("extract_size_mb", 0), default=0))
    ]
    raw_signature = "||".join(elements)
    return hashlib.sha256(raw_signature.encode("utf-8")).hexdigest()[:12]


def compute_report_canvas_hash(row: pd.Series) -> str:
    """
    Generates a structural signature hash of the visual workbook canvas.
    Returns empty string if any core structural metric is unobserved.
    """
    sheets = _safe_int(row.get("sheet_count", None))
    calcs = _safe_int(row.get("calculation_count", None))
    dashboards = _safe_int(row.get("dashboard_count", None))

    # Gated: If ANY core canvas count is unobserved, do not generate hash (avoid matching observed values)
    if sheets is None or calcs is None or dashboards is None:
        return ""

    elements = [
        str(sheets),
        str(dashboards),
        str(_safe_int(row.get("story_count", 0), default=0)),
        str(_safe_int(row.get("action_count", 0), default=0)),
        str(_safe_int(row.get("filter_count", 0), default=0)),
        str(_safe_int(row.get("parameter_count", 0), default=0)),
        str(calcs),
        str(_safe_int(row.get("lod_calc_count", 0), default=0))
    ]
    raw_signature = "||".join(elements)
    return hashlib.sha256(raw_signature.encode("utf-8")).hexdigest()[:10]


def compute_ard_criticality_score(row: pd.Series, cfg: Dict[str, Any]) -> Tuple[Optional[float], Dict[str, Any], List[str]]:
    """
    Calculates the 400-Point Criticality Score for Tableau Workbooks.
    Factors (100 pts each):
      1. Distinct Users (0 -> 0, 1-199 -> 40, 200-499 -> 70, 500+ -> 100)
      2. Views (0 -> 0, 1-2499 -> 40, 2500-9999 -> 70, 10000+ -> 100)
      3. BU / Sector Reach (0 -> 0, 1-4 -> 40, 5-9 -> 70, 10+ -> 100)
      4. Last Access Recency (>365d -> 0, 181-365d -> 40, 31-180d -> 70, <=30d -> 100)
    Returns (score, breakdown, evidence_gaps).
    """
    evidence_gaps = []
    users_raw = row.get("distinct_users_180d", row.get("monthly_active_users", None))
    views_raw = row.get("view_count_180d", row.get("activity_views", row.get("view_count_total", None)))

    users = _safe_float(users_raw, default=None)
    views = _safe_float(views_raw, default=None)

    # Missing telemetry check: if both users and views are unobserved, we cannot score criticality
    if users is None and views is None:
        evidence_gaps.append("missing_telemetry")
        return None, {
            "UsersPoints": 0.0,
            "ViewsPoints": 0.0,
            "BUPoints": 0.0,
            "AccessPoints": 0.0,
            "DaysSinceAccess": 999.0
        }, evidence_gaps

    # Fallback single missing values
    if users is None:
        evidence_gaps.append("missing_user_count")
        users = 0.0
    if views is None:
        evidence_gaps.append("missing_view_count")
        views = 0.0

    # 1. Distinct Users
    if users <= 0:
        pts_users = 0.0
    elif users < 200:
        pts_users = 40.0
    elif users < 500:
        pts_users = 70.0
    else:
        pts_users = 100.0

    # 2. Views
    if views <= 0:
        pts_views = 0.0
    elif views < 2500:
        pts_views = 40.0
    elif views < 10000:
        pts_views = 70.0
    else:
        pts_views = 100.0

    # 3. BU Reach
    bu_reach = _safe_float(row.get("bu_reach_count", None), default=1.0) or 1.0
    if bu_reach <= 0 or (users == 0 and views == 0):
        pts_bu = 0.0
    elif bu_reach < 5:
        pts_bu = 40.0
    elif bu_reach < 10:
        pts_bu = 70.0
    else:
        pts_bu = 100.0

    # 4. Last Access Recency
    days_since_access = None
    last_date_str = str(row.get("last_access_date", row.get("last_refresh_time", ""))).strip()
    if last_date_str and last_date_str.lower() not in ["none", "nan", ""]:
        for fmt in ["%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%m/%d/%Y", "%d/%m/%Y"]:
            try:
                dt = datetime.strptime(last_date_str[:19], fmt).replace(tzinfo=timezone.utc)
                now = datetime.now(timezone.utc)
                days_since_access = max(0, (now - dt).days)
                break
            except ValueError:
                continue

    if days_since_access is None:
        days_since_access = _safe_float(row.get("days_since_last_access", row.get("days_since_last_refresh", None)), default=None)

    if days_since_access is None:
        if users > 0 or views > 0:
            days_since_access = 15.0
        else:
            days_since_access = 400.0

    if days_since_access > 365:
        pts_access = 0.0
    elif days_since_access > 180:
        pts_access = 40.0
    elif days_since_access > 30:
        pts_access = 70.0
    else:
        pts_access = 100.0

    # Hard floor for dead assets
    if users == 0 and views == 0 and days_since_access > 365:
        total_criticality = 0.0
    else:
        total_criticality = pts_users + pts_views + pts_bu + pts_access

    breakdown = {
        "UsersPoints": pts_users,
        "ViewsPoints": pts_views,
        "BUPoints": pts_bu,
        "AccessPoints": pts_access,
        "DaysSinceAccess": float(days_since_access)
    }
    return float(total_criticality), breakdown, evidence_gaps


def compute_ard_complexity_score(row: pd.Series, cfg: Dict[str, Any]) -> Tuple[float, Dict[str, float]]:
    """
    Calculates the 900-Point Technical Complexity Score for Tableau Workbooks.
    Evaluates 9 technical dimensions (10-100 pts each). Scale: 90.0 to 900.0.
    """
    dc = _safe_float(row.get("data_connection_count", row.get("data_source_count", 1)), default=1.0) or 1.0
    pts_dc = 10.0 if dc <= 1 else (40.0 if dc <= 3 else 100.0)

    csql = _safe_float(row.get("custom_sql_count", 0), default=0.0) or 0.0
    pts_csql = 10.0 if csql == 0 else (50.0 if csql <= 2 else 100.0)

    joins = _safe_float(row.get("join_relationship_count", row.get("relationship_count", 0)), default=0.0) or 0.0
    blends = _safe_float(row.get("data_blending_count", 0), default=0.0) or 0.0
    pts_joins = 10.0 if joins <= 1 else (40.0 if joins <= 9 else 100.0)
    if blends > 0:
        pts_joins = min(100.0, pts_joins + 30.0)

    calcs = _safe_float(row.get("calculation_count", row.get("calculated_column_count", 0)), default=0.0) or 0.0
    lods = _safe_float(row.get("lod_calc_count", 0), default=0.0) or 0.0
    pts_calcs = 10.0 if calcs < 5 else (40.0 if calcs <= 20 else 70.0)
    if lods > 15 or calcs > 40:
        pts_calcs = 100.0
    elif lods > 5:
        pts_calcs = max(pts_calcs, 70.0)

    params = _safe_float(row.get("parameter_count", 0), default=0.0) or 0.0
    pts_params = 10.0 if params < 3 else (50.0 if params <= 5 else 100.0)

    filters = _safe_float(row.get("filter_count", 0), default=0.0) or 0.0
    pts_filters = 10.0 if filters < 5 else (50.0 if filters <= 10 else 100.0)

    sheets = _safe_float(row.get("sheet_count", row.get("table_count", 1)), default=1.0) or 1.0
    pts_sheets = 10.0 if sheets < 10 else (50.0 if sheets < 20 else 100.0)

    dashboards = _safe_float(row.get("dashboard_count", row.get("downstream_report_count", 1)), default=1.0) or 1.0
    stories = _safe_float(row.get("story_count", 0), default=0.0) or 0.0
    pts_dash = 10.0 if dashboards <= 2 else (50.0 if dashboards <= 6 else 100.0)
    if stories > 0:
        pts_dash = min(100.0, pts_dash + 40.0)

    actions = _safe_float(row.get("action_count", 0), default=0.0) or 0.0
    has_rls = str(row.get("has_rls", "False")).strip().lower() in ["true", "1", "yes"]
    rls_type = str(row.get("rls_type", "None")).strip().lower()

    pts_actions = 10.0 if actions == 0 else (50.0 if actions <= 5 else 100.0)
    if has_rls:
        if "dynamic" in rls_type or "entitlement" in rls_type:
            pts_actions = 100.0
        else:
            pts_actions = max(pts_actions, 60.0)

    total_complexity = (
        pts_dc + pts_csql + pts_joins + pts_calcs +
        pts_params + pts_filters + pts_sheets + pts_dash + pts_actions
    )

    breakdown = {
        "DataConnectionsPoints": pts_dc,
        "CustomSQLPoints": pts_csql,
        "JoinsPoints": pts_joins,
        "CalculationsPoints": pts_calcs,
        "ParametersPoints": pts_params,
        "FiltersPoints": pts_filters,
        "SheetsPoints": pts_sheets,
        "DashboardsPoints": pts_dash,
        "ActionsPoints": pts_actions
    }
    return float(total_complexity), breakdown


def calculate_workbook_canonical_rank(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Computes deterministic governance rank for electing the suggested retained copy."""
    rank = 0.0
    container_type = str(row.get("container_type", "")).strip().lower()
    gov_tier = str(row.get("governance_tier", "")).strip().lower()
    is_personal_space = (container_type == "personal space" or 
                         str(row.get("is_personal_space", "False")).strip().lower() in ["true", "1", "yes"])

    if is_personal_space:
        rank -= 800.0
    elif gov_tier == "production":
        rank += 1000.0
    elif gov_tier == "departmental":
        rank += 500.0
    elif gov_tier == "sandbox":
        rank -= 200.0

    if str(row.get("uses_certified_datasource", "False")).strip().lower() in ["true", "1", "yes"]:
        rank += 300.0

    if not str(row.get("is_orphan", "False")).strip().lower() in ["true", "1", "yes"]:
        rank += 200.0
    else:
        rank -= 200.0

    rank += (_safe_float(row.get("subscription_count", 0), default=0.0) or 0.0) * 15.0
    rank += (_safe_float(row.get("distinct_users_180d", row.get("monthly_active_users", 0)), default=0.0) or 0.0) * 2.0
    rank += (_safe_float(row.get("view_count_180d", row.get("activity_views", 0)), default=0.0) or 0.0) * 0.01
    return rank


def calculate_datasource_canonical_rank(row: pd.Series, cfg: Dict[str, Any]) -> float:
    """Computes deterministic governance rank for electing the suggested retained data source."""
    rank = 0.0
    is_certified = str(row.get("is_certified", "False")).strip().lower() in ["true", "1", "yes"]
    gov_tier = str(row.get("governance_tier", "")).strip().lower()

    if is_certified:
        rank += 1500.0
    if gov_tier == "production":
        rank += 1000.0
    elif gov_tier == "departmental":
        rank += 500.0

    if not str(row.get("is_orphan", "False")).strip().lower() in ["true", "1", "yes"]:
        rank += 200.0

    rank += (_safe_float(row.get("subscription_count", 0), default=0.0) or 0.0) * 15.0
    rank += (_safe_float(row.get("distinct_users_180d", row.get("monthly_active_users", 0)), default=0.0) or 0.0) * 2.0
    rank += (_safe_float(row.get("view_count_180d", row.get("activity_views", 0)), default=0.0) or 0.0) * 0.01
    return rank


def generate_recommendation_reason(
    criticality: Optional[float],
    complexity: float,
    row: pd.Series,
    crit_breakdown: Dict[str, Any],
    similarity_flag: str,
    suggested_copy_name: str,
    is_suggested_retained: bool = False,
    clone_count: int = 0,
    crit_threshold: float = 250.0,
    comp_low: float = 400.0,
    comp_med: float = 700.0,
    proposed_disposition: Optional[str] = None
) -> str:
    """
    Generates explainable justification dynamically driven by active configuration thresholds
    and strictly aligned with proposed_disposition.
    """
    if criticality is None or proposed_disposition == "Undecided":
        return "Insufficient Evidence: Telemetry (views and active users) unobserved. Disposition is undecided pending usage observation."

    users = int(_safe_float(row.get("distinct_users_180d", row.get("monthly_active_users", 0)), default=0.0) or 0)
    views = int(_safe_float(row.get("view_count_180d", row.get("activity_views", 0)), default=0.0) or 0)
    days = int(_safe_float(crit_breakdown.get("DaysSinceAccess", 0), default=0.0) or 0)
    bu_reach = int(_safe_float(row.get("bu_reach_count", 1), default=1.0) or 1)
    is_cert = str(row.get("is_certified", "False")).strip().lower() in ["true", "1", "yes"]
    uses_cert = str(row.get("uses_certified_datasource", "False")).strip().lower() in ["true", "1", "yes"]
    is_orphan = str(row.get("is_orphan", "False")).strip().lower() in ["true", "1", "yes"]
    ref_freq = str(row.get("refresh_frequency", "")).strip().lower()

    # If proposed disposition is Retire candidate, never say "Select for migration"
    if proposed_disposition == "Retire candidate":
        if is_orphan and users < 5 and ref_freq in ["hourly", "daily"]:
            return f"Retire Candidate (Zombie Refresh): Orphaned asset ({users} users) with active {ref_freq} backgrounder refreshes. Retire to reclaim server capacity."
        if users == 0 and views == 0 and days > 365:
            return f"Retire Candidate (Dead Asset): 0 users, 0 views in 180d, stale for {days} days. Safe to decommission."
        if is_suggested_retained and clone_count > 0:
            return f"Retire Candidate (Low Criticality Retained Copy: {criticality:.0f}/400 pts < {crit_threshold:.0f} threshold): Primary copy candidate for {clone_count} potential structural duplicate(s), but business criticality is below migration threshold ({users} users, {views} views). Recommend retiring cluster or confirming active business need."
        if similarity_flag == "Potential shared model":
            return f"Retire Candidate (Low Criticality Model: {criticality:.0f}/400 pts < {crit_threshold:.0f} threshold): Connected to shared structure, but insufficient usage ({users} users, {views} views) to justify migration."
        return f"Retire Candidate (Low Criticality: {criticality:.0f}/400 pts < {crit_threshold:.0f} threshold): Insufficient business reach ({users} users, {views} views, {bu_reach} BU, {days}d stale)."

    # If proposed disposition is Select for migration
    if is_suggested_retained and clone_count > 0:
        cert_tag = ", Certified PDS" if is_cert else (", Uses Certified Model" if uses_cert else "")
        return f"Select for migration (Suggested Retained Copy): Preferred primary candidate for {clone_count} potential structural duplicate(s). High Criticality ({criticality:.0f}/400 pts, {users} users{cert_tag}). Requires business owner confirmation."

    if similarity_flag == "Potential structural duplicate" and not is_suggested_retained and suggested_copy_name:
        return f"Business Review Required (Potential Structural Duplicate): Structural count similarity with '{suggested_copy_name}'. Review with business owner to confirm consolidation or retention."

    if similarity_flag == "Potential structural clone (different data model)" and suggested_copy_name:
        return f"Business Review Required (Structural Clone): Visual report canvas matches '{suggested_copy_name}', but data connections differ. Human engineering review required before consolidation."

    if similarity_flag == "Potential shared model" and not is_suggested_retained:
        return f"Select for migration (Potential Shared Model): Connected to potential shared semantic model. High Criticality ({criticality:.0f}/400 pts, {users} users)."

    # Migration Sizing Waves
    cert_tag = ", Certified PDS" if is_cert else (", Uses Certified Model" if uses_cert else "")
    if complexity <= comp_low:
        return f"Select for migration (Wave 1 / Fast-Track): High Criticality ({criticality:.0f}/400 pts, {users} users, {views} views{cert_tag}) + Low Complexity ({complexity:.0f}/900 pts <= {comp_low:.0f})."
    elif complexity <= comp_med:
        return f"Select for migration (Wave 2 / Standard): High Criticality ({criticality:.0f}/400 pts, {users} users, {bu_reach} BUs{cert_tag}) + Moderate Complexity ({complexity:.0f}/900 pts <= {comp_med:.0f})."
    else:
        sql_cnt = int(_safe_float(row.get("custom_sql_count", 0), default=0.0) or 0)
        lod_cnt = int(_safe_float(row.get("lod_calc_count", 0), default=0.0) or 0)
        return f"Select for migration (Wave 3 / Complex): High Criticality ({criticality:.0f}/400 pts) but High Complexity ({complexity:.0f}/900 pts, {sql_cnt} Custom SQL, {lod_cnt} LODs). Requires architecture review."


def evaluate_tableau_ard_rationalization(df: pd.DataFrame, cfg: Dict[str, Any]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Executes the Tableau ARD 400-pt Criticality & 900-pt Complexity Scoring Pipeline
    with Separated Similarity Screening, Precedence Rules, and Typed Decision Contracts.
    """
    ard_cfg = cfg.get("ard_settings", {})
    crit_threshold = float(ard_cfg.get("criticality_threshold", 250.0))
    comp_low = float(ard_cfg.get("complexity_low_limit", 400.0))
    comp_med = float(ard_cfg.get("complexity_medium_limit", 700.0))
    dup_detection_enabled = ard_cfg.get("duplicate_detection", True)

    df_scored = df.copy()
    
    # 1. Compute Hashing Signatures (with minimum attribute gating)
    if dup_detection_enabled:
        df_scored["_ds_hash"] = df_scored.apply(compute_dataset_fingerprint_sha256, axis=1)
        df_scored["_report_hash"] = df_scored.apply(compute_report_canvas_hash, axis=1)
        
        # Valid composite keys require non-empty hashes
        df_scored["_composite_key"] = df_scored.apply(
            lambda r: (r["_ds_hash"] + "_" + r["_report_hash"]) if (r["_ds_hash"] and r["_report_hash"]) else "",
            axis=1
        )
    else:
        df_scored["_ds_hash"] = ""
        df_scored["_report_hash"] = ""
        df_scored["_composite_key"] = ""

    # Frequency counts of non-empty hashes
    valid_ds = df_scored[df_scored["_ds_hash"] != ""]["_ds_hash"]
    valid_rep = df_scored[df_scored["_report_hash"] != ""]["_report_hash"]
    valid_comp = df_scored[df_scored["_composite_key"] != ""]["_composite_key"]

    ds_hash_counts = valid_ds.value_counts().to_dict()
    report_hash_counts = valid_rep.value_counts().to_dict()
    composite_counts = valid_comp.value_counts().to_dict()

    # 2. Group for Potential Structural Duplicates
    composite_groups: Dict[str, List[int]] = {}
    canvas_groups: Dict[str, List[int]] = {}

    for idx, row in df_scored.iterrows():
        ckey = row["_composite_key"]
        rkey = row["_report_hash"]
        if ckey:
            composite_groups.setdefault(ckey, []).append(idx)
        if rkey:
            canvas_groups.setdefault(rkey, []).append(idx)

    # Elect Suggested Retained Copies (strictly advisory)
    elected_suggested_copies: Dict[str, int] = {}
    for ckey, row_indices in composite_groups.items():
        if len(row_indices) > 1:
            best_idx = row_indices[0]
            best_rank = -999999.0
            for r_idx in row_indices:
                cand_row = df_scored.loc[r_idx]
                art_type = str(cand_row.get("artifact_type", "Workbook")).strip().lower()
                if art_type == "published data source":
                    rank = calculate_datasource_canonical_rank(cand_row, cfg)
                else:
                    rank = calculate_workbook_canonical_rank(cand_row, cfg)

                if rank > best_rank:
                    best_rank = rank
                    best_idx = r_idx
            elected_suggested_copies[ckey] = best_idx

    readiness_records = []
    project_groups = {}

    # 3. Decision Evaluation
    for idx, row in df_scored.iterrows():
        wb_name = str(row.get("workbook_name", row.get("dataset_name", "Unnamed Asset"))).strip()
        proj_name = str(row.get("project_name", row.get("workspace_name", "Default Project"))).strip()
        site_name = str(row.get("site_name", "Default Site")).strip()
        bu_sector = str(row.get("bu_sector", row.get("business_domain", "General"))).strip()
        art_type = str(row.get("artifact_type", "Workbook")).strip()
        
        # Native LUID or deterministic unique assessment ID
        native_id = _clean_str(row.get("asset_id")) or _clean_str(row.get("luid"))
        asset_id = native_id if native_id else f"{site_name}:{proj_name}:{art_type}:{wb_name}#{idx}"

        is_orphan = str(row.get("is_orphan", "False")).strip().lower() in ["true", "1", "yes"]
        ref_freq = str(row.get("refresh_frequency", "")).strip().lower()

        # Compute Scores
        crit_score, crit_breakdown, evidence_gaps = compute_ard_criticality_score(row, cfg)
        comp_score, comp_breakdown = compute_ard_complexity_score(row, cfg)

        # Normalized Readiness Score (0-100)
        if crit_score is not None:
            normalized_readiness = round(((crit_score / 400.0) * 0.70 + ((900.0 - comp_score) / 900.0) * 0.30) * 100, 1)
        else:
            normalized_readiness = round(((900.0 - comp_score) / 900.0) * 30, 1)

        ds_hash = row["_ds_hash"]
        rep_hash = row["_report_hash"]
        ckey = row["_composite_key"]

        shared_count = ds_hash_counts.get(ds_hash, 1) if ds_hash else 1
        canvas_count = report_hash_counts.get(rep_hash, 1) if rep_hash else 1
        comp_count = composite_counts.get(ckey, 1) if ckey else 1

        # Determine Similarity Flag & Suggested Copy
        similarity_flag = "None"
        suggested_copy_id = ""
        suggested_copy_name = ""
        is_suggested_retained = False

        if not dup_detection_enabled:
            similarity_flag = "Unique"
            dup_status = "Unique Model"
        elif not ds_hash and not rep_hash:
            similarity_flag = "Similarity not assessed — insufficient metadata"
            dup_status = "Metadata Insufficient"
        elif comp_count > 1:
            similarity_flag = "Potential structural duplicate"
            master_idx = elected_suggested_copies[ckey]
            master_row = df_scored.loc[master_idx]
            suggested_copy_name = str(master_row.get("workbook_name", master_row.get("dataset_name", "Primary Model")))
            m_site = str(master_row.get("site_name", "Default Site")).strip()
            m_proj = str(master_row.get("project_name", master_row.get("workspace_name", "Default Project"))).strip()
            m_type = str(master_row.get("artifact_type", "Workbook")).strip()
            m_native_id = _clean_str(master_row.get("asset_id")) or _clean_str(master_row.get("luid"))
            suggested_copy_id = m_native_id if m_native_id else f"{m_site}:{m_proj}:{m_type}:{suggested_copy_name}#{master_idx}"

            if idx == master_idx:
                is_suggested_retained = True
                dup_status = f"Suggested Retained Copy ({comp_count} Potential Clones)"
            else:
                dup_status = f"Potential Structural Duplicate of {suggested_copy_name}"
        elif canvas_count > 1 and shared_count == 1:
            similarity_flag = "Potential structural clone (different data model)"
            other_indices = [i for i in canvas_groups[rep_hash] if i != idx]
            other_row = df_scored.loc[other_indices[0]] if other_indices else row
            suggested_copy_name = str(other_row.get("workbook_name", other_row.get("dataset_name", "Similar Report")))
            o_site = str(other_row.get("site_name", "Default Site")).strip()
            o_proj = str(other_row.get("project_name", other_row.get("workspace_name", "Default Project"))).strip()
            o_type = str(other_row.get("artifact_type", "Workbook")).strip()
            o_native_id = _clean_str(other_row.get("asset_id")) or _clean_str(other_row.get("luid"))
            suggested_copy_id = o_native_id if o_native_id else f"{o_site}:{o_proj}:{o_type}:{suggested_copy_name}#{other_indices[0]}"
            dup_status = f"Potential Structural Clone of {suggested_copy_name}"
        elif shared_count > 1:
            similarity_flag = "Potential shared model"
            dup_status = f"Potential Shared Model Cluster ({shared_count} Reports)"
        else:
            similarity_flag = "Unique"
            dup_status = "Unique Model"

        # Precedence Rule for Review Status & Proposed Disposition
        users_val = _safe_float(row.get("distinct_users_180d", row.get("monthly_active_users", None)), default=None)
        views_val = _safe_float(row.get("view_count_180d", row.get("activity_views", None)), default=None)
        days_val = float(crit_breakdown.get("DaysSinceAccess", 0))

        if crit_score is None or "missing_telemetry" in evidence_gaps:
            # Insufficient Evidence Takes Precedence!
            review_status = "Insufficient evidence"
            proposed_disposition = "Undecided"
            execution_wave = "Unassigned"
            effort = "Discovery Required"
            status = "Insufficient Telemetry"
        else:
            # Set review status
            if similarity_flag in ["Potential structural duplicate", "Potential structural clone (different data model)"]:
                review_status = "Business review required"
            else:
                review_status = "Ready"

            # Compute Proposed Disposition strictly from business criticality & usage
            if is_orphan and (users_val or 0) < 5 and ref_freq in ["hourly", "daily"]:
                proposed_disposition = "Retire candidate"
                execution_wave = "Wave 4: Retire & Decommission"
                effort = "Cleanup"
                status = "Zombie Refresh"
            elif (users_val or 0) == 0 and (views_val or 0) == 0 and days_val > 365:
                proposed_disposition = "Retire candidate"
                execution_wave = "Wave 4: Retire & Decommission"
                effort = "Cleanup"
                status = "Dead Asset"
            elif crit_score < crit_threshold:
                proposed_disposition = "Retire candidate"
                execution_wave = "Wave 4: Retire & Decommission"
                effort = "Cleanup"
                status = "Low Criticality"
            else:
                proposed_disposition = "Select for migration"
                if comp_score <= comp_low:
                    execution_wave = "Wave 1: Fast-Track Migrate"
                    effort = "1-2 Days"
                    status = "Ready (Automated)"
                elif comp_score <= comp_med:
                    execution_wave = "Wave 2: Standard Migrate"
                    effort = "3-5 Days"
                    status = "Moderate (Refactor)"
                else:
                    execution_wave = "Wave 3: Complex Migrate"
                    effort = "1-2 Weeks"
                    status = "Complex (Deep Rebuild)"

        # Reason Generation - strictly aligned with evaluated proposed_disposition
        reason = generate_recommendation_reason(
            crit_score, comp_score, row, crit_breakdown, similarity_flag, suggested_copy_name,
            is_suggested_retained=is_suggested_retained, clone_count=comp_count - 1,
            crit_threshold=crit_threshold, comp_low=comp_low, comp_med=comp_med,
            proposed_disposition=proposed_disposition
        )

        # Golden & Direct Lake Candidate heuristics
        has_sql = (_safe_float(row.get("custom_sql_count", 0), default=0.0) or 0.0) > 0
        is_live = str(row.get("is_live_connection", "False")).strip().lower() in ["true", "1", "yes"]
        is_dl_candidate = "Yes" if (not has_sql and not is_live and comp_score <= comp_low) else "No"
        is_golden = "Yes" if (crit_score is not None and crit_score >= 320 and comp_score <= comp_low) else "No"

        # Preserve all original input row columns (excluding internal helper columns starting with _)
        asset_record = {k: v for k, v in row.items() if not str(k).startswith("_")}
        asset_record.update({
            "AssetId": asset_id,
            "Workspace": proj_name,
            "WorkspaceName": proj_name,
            "Artifact": wb_name,
            "Type": art_type,
            "ReadinessScore": normalized_readiness,
            "CriticalityScore": crit_score if crit_score is not None else 0.0,
            "ComplexityScore": comp_score,
            "ProposedDisposition": proposed_disposition,
            "ReviewStatus": review_status,
            "SimilarityFlag": similarity_flag,
            "SuggestedRetainedAssetId": suggested_copy_id,
            "SuggestedRetainedAssetName": suggested_copy_name,
            "OutcomeDecision": proposed_disposition,  # For backward-compatible UI/API consumers
            "Status": status,
            "ExecutionWave": execution_wave,
            "Effort": effort,
            "EvidenceState": similarity_flag,
            "CanonicalMaster": suggested_copy_name,
            "RecommendationReason": reason,
            "DatasourceFingerprint": ds_hash,
            "ReportCanvasHash": rep_hash,
            "DuplicateStatus": dup_status,
            "SharedDatasetCount": shared_count,
            "IsGoldenDataset": is_golden,
            "DirectLakeCandidate": is_dl_candidate,
            "BusinessValueScore": round((crit_breakdown["BUPoints"] + (100 if str(row.get("is_certified", "False")).lower() in ["true", "1"] else 40)) / 2, 1),
            "UsageScore": round((crit_breakdown["UsersPoints"] + crit_breakdown["ViewsPoints"] + crit_breakdown["AccessPoints"]) / 3, 1),
            "TechnicalQualityScore": round((900 - comp_score) / 9.0, 1),
            "PerformanceScore": 100.0 if (_safe_float(row.get("extract_size_mb", 0), default=0.0) or 0.0) < 500 else 60.0,
            "GovernanceScore": 100.0 if not is_orphan and str(row.get("is_certified", "False")).lower() in ["true", "1"] else (70.0 if not is_orphan else 30.0),
            "ActivityViews": int(views_val or 0) if views_val is not None else 0,
            "DistinctUsers": int(users_val or 0) if users_val is not None else 0,
            "LastAccessDays": int(days_val),
            "CustomSQLCount": int(_safe_float(row.get("custom_sql_count", 0), default=0.0) or 0),
            "LODCalcCount": int(_safe_float(row.get("lod_calc_count", 0), default=0.0) or 0),
            "DataConnections": int(_safe_float(row.get("data_connection_count", 1), default=1.0) or 1),
            "SheetCount": int(_safe_float(row.get("sheet_count", 1), default=1.0) or 1),
            "DashboardCount": int(_safe_float(row.get("dashboard_count", 1), default=1.0) or 1),
            "SiteName": site_name,
            "BusinessDomain": bu_sector
        })
        readiness_records.append(asset_record)

        # Project Summary Grouping
        p_key = f"{site_name} / {proj_name}"
        if p_key not in project_groups:
            project_groups[p_key] = {
                "Site": site_name,
                "Project": proj_name,
                "WorkspaceName": proj_name,
                "Domain": bu_sector,
                "TotalAssets": 0,
                "ReadinessSum": 0.0,
                "CriticalitySum": 0.0,
                "ComplexitySum": 0.0,
                "MigrateCount": 0,
                "RetireCount": 0,
                "ReviewCount": 0,
                "Wave1Count": 0,
                "Wave2Count": 0,
                "Wave3Count": 0,
                "Wave4Count": 0,
                "GoldenCount": 0
            }

        pg = project_groups[p_key]
        pg["TotalAssets"] += 1
        pg["ReadinessSum"] += normalized_readiness
        pg["CriticalitySum"] += (crit_score or 0.0)
        pg["ComplexitySum"] += comp_score

        if proposed_disposition == "Select for migration":
            pg["MigrateCount"] += 1
        elif proposed_disposition == "Retire candidate":
            pg["RetireCount"] += 1

        if review_status in ["Business review required", "Insufficient evidence"]:
            pg["ReviewCount"] += 1

        if execution_wave and "Wave 1" in execution_wave:
            pg["Wave1Count"] += 1
        elif execution_wave and "Wave 2" in execution_wave:
            pg["Wave2Count"] += 1
        elif execution_wave and "Wave 3" in execution_wave:
            pg["Wave3Count"] += 1
        elif execution_wave and "Wave 4" in execution_wave:
            pg["Wave4Count"] += 1

        if is_golden == "Yes":
            pg["GoldenCount"] += 1

    df_readiness = pd.DataFrame(readiness_records)

    # Compile Project Summary Records
    summary_records = []
    for p_key, pg in project_groups.items():
        cnt = pg["TotalAssets"]
        avg_readiness = round(pg["ReadinessSum"] / cnt, 1) if cnt > 0 else 0.0
        avg_crit = round(pg["CriticalitySum"] / cnt, 1) if cnt > 0 else 0.0
        avg_comp = round(pg["ComplexitySum"] / cnt, 1) if cnt > 0 else 0.0

        if pg["RetireCount"] == cnt and cnt > 0:
            rec = "Retire Candidate / Decommission Project"
        elif pg["Wave1Count"] >= (cnt / 2):
            rec = "Wave 1: Fast-Track Project Migration"
        elif pg["Wave2Count"] >= (cnt / 2):
            rec = "Wave 2: Standard Project Migration"
        else:
            rec = "Wave 3: Complex Architecture Review"

        summary_records.append({
            "Site": pg["Site"],
            "Project": pg["Project"],
            "Workspace": pg["Project"],
            "WorkspaceName": pg["WorkspaceName"],
            "BusinessDomain": pg["Domain"],
            "TotalDatasets": cnt,
            "TotalAssets": cnt,
            "AvgReadinessScore": avg_readiness,
            "AvgCriticalityScore": avg_crit,
            "AvgComplexityScore": avg_comp,
            "MigrateCount": pg["MigrateCount"],
            "RetireCount": pg["RetireCount"],
            "ReviewCount": pg["ReviewCount"],
            "GoldenCount": pg["GoldenCount"],
            "Wave1Count": pg["Wave1Count"],
            "Wave2Count": pg["Wave2Count"],
            "Wave3Count": pg["Wave3Count"],
            "Wave4Count": pg["Wave4Count"],
            "RecommendedAction": rec,
            "PruningCandidate": "Yes" if (pg["RetireCount"] == cnt and cnt > 0) else "No",
            "Orphaned": "No"
        })

    df_summary = pd.DataFrame(summary_records)
    return df_readiness, df_summary

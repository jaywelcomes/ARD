"""
Universal BI Rationalization Platform - Schema & Template Generator
Supports: Power BI, Tableau, Qlik Sense, Looker, MicroStrategy, Universal
"""

from typing import Dict, Any, List, Tuple
import pandas as pd
import io

# Define Canonical & Platform-Specific Schemas (Mandatory vs Optional)
PLATFORM_SCHEMAS: Dict[str, Dict[str, Any]] = {
    "powerbi": {
        "display_name": "Microsoft Power BI / Fabric",
        "container_term": "Workspace",
        "asset_term": "Dataset / Semantic Model",
        "mandatory_columns": [
            "dataset_name",
            "workspace_name",
            "table_count",
            "monthly_active_users",
            "activity_views",
            "data_source_count"
        ],
        "optional_columns": [
            "workspace_type",
            "endorsement",
            "is_certified",
            "measure_count",
            "relationship_count",
            "calculated_column_count",
            "dataset_size_mb",
            "refresh_failure_rate_pct",
            "refresh_duration_avg_min",
            "workspace_admin_count",
            "sensitivity_label",
            "has_gateway",
            "has_directquery",
            "storage_mode",
            "has_rls",
            "downstream_report_count",
            "days_since_last_refresh"
        ],
        "column_descriptions": {
            "dataset_name": "Name of the Power BI Dataset / Semantic Model",
            "workspace_name": "Power BI Workspace name",
            "table_count": "Total count of tables within the model (Required for Star Schema vs Flat Table evaluation)",
            "monthly_active_users": "Unique active viewers/consumers in the past 30 days",
            "activity_views": "Total report/dataset render count over the last 30 days",
            "data_source_count": "Count of distinct upstream data sources"
        },
        "sample_data": [
            {
                "dataset_name": "Executive Sales Analysis",
                "workspace_name": "Corporate Finance",
                "workspace_type": "Group",
                "endorsement": "Certified",
                "is_certified": "True",
                "table_count": 8,
                "measure_count": 35,
                "relationship_count": 9,
                "calculated_column_count": 2,
                "monthly_active_users": 185,
                "activity_views": 3200,
                "dataset_size_mb": 420,
                "refresh_failure_rate_pct": 0.0,
                "refresh_duration_avg_min": 12.5,
                "workspace_admin_count": 3,
                "sensitivity_label": "Confidential",
                "data_source_count": 2,
                "has_gateway": "False",
                "has_directquery": "False",
                "storage_mode": "Import",
                "has_rls": "True",
                "downstream_report_count": 6,
                "days_since_last_refresh": 1
            },
            {
                "dataset_name": "Legacy Ops Sandbox",
                "workspace_name": "John Doe Personal",
                "workspace_type": "Personal",
                "endorsement": "None",
                "is_certified": "False",
                "table_count": 1,
                "measure_count": 4,
                "relationship_count": 0,
                "calculated_column_count": 12,
                "monthly_active_users": 0,
                "activity_views": 0,
                "dataset_size_mb": 1400,
                "refresh_failure_rate_pct": 45.0,
                "refresh_duration_avg_min": 65.0,
                "workspace_admin_count": 0,
                "sensitivity_label": "None",
                "data_source_count": 7,
                "has_gateway": "True",
                "has_directquery": "True",
                "storage_mode": "DirectQuery",
                "has_rls": "False",
                "downstream_report_count": 0,
                "days_since_last_refresh": 140
            }
        ]
    },
    "tableau": {
        "display_name": "Tableau (Server / Cloud)",
        "container_term": "Project / Site",
        "asset_term": "Workbook / Published Data Source",
        "mandatory_columns": [
            "workbook_name",
            "site_name",
            "project_name",
            "distinct_users_180d",
            "view_count_180d",
            "data_connection_count"
        ],
        "optional_columns": [
            "container_type",
            "governance_tier",
            "uses_certified_datasource",
            "artifact_type",
            "owner_name",
            "is_orphan",
            "market_segment",
            "bu_sector",
            "bu_reach_count",
            "last_access_date",
            "days_since_last_access",
            "last_refresh_date",
            "refresh_frequency",
            "is_certified",
            "endorsement",
            "custom_sql_count",
            "join_relationship_count",
            "data_blending_count",
            "calculation_count",
            "lod_calc_count",
            "parameter_count",
            "filter_count",
            "sheet_count",
            "dashboard_count",
            "story_count",
            "action_count",
            "has_rls",
            "rls_type",
            "extract_size_mb",
            "is_live_connection",
            "subscription_count"
        ],
        "column_descriptions": {
            "workbook_name": "Tableau Workbook or Published Data Source name",
            "site_name": "Tableau Site identifier (e.g. Corporate-Finance-Site)",
            "project_name": "Tableau Project folder or container name",
            "container_type": "Tableau Metadata API Workbook.containerType (e.g. Project or Personal Space)",
            "governance_tier": "Policy-mapped governance classification (Production, Departmental, Sandbox, Personal)",
            "uses_certified_datasource": "Lineage flag: True if workbook connects to a Certified Published Data Source",
            "distinct_users_180d": "Unique active viewers in 180-day lookback window",
            "view_count_180d": "Total 180-day view events",
            "data_connection_count": "Number of distinct data connection endpoints",
            "bu_reach_count": "Count of distinct Business Units consuming this asset",
            "custom_sql_count": "Count of embedded Custom SQL queries",
            "lod_calc_count": "Count of Level of Detail (FIXED, INCLUDE, EXCLUDE) expressions",
            "action_count": "Count of interactive URL, filter, or highlight actions",
            "rls_type": "Row-level security type: None, Static User Filter, Dynamic Entitlement RLS"
        },
        "sample_data": [
            {
                "site_name": "Corporate Finance Site",
                "project_name": "Treasury",
                "workbook_name": "Treasury & Capital Markets Executive Overview",
                "artifact_type": "Workbook",
                "owner_name": "Lead_Treasury",
                "is_orphan": "False",
                "market_segment": "Enterprise Corporate",
                "bu_sector": "Treasury & Capital Markets",
                "bu_reach_count": 4,
                "distinct_users_180d": 420,
                "view_count_180d": 3500,
                "last_access_date": "2026-09-17",
                "days_since_last_access": 1,
                "last_refresh_date": "2026-09-17",
                "refresh_frequency": "Daily",
                "is_certified": "True",
                "endorsement": "Certified",
                "data_connection_count": 1,
                "custom_sql_count": 0,
                "join_relationship_count": 3,
                "data_blending_count": 0,
                "calculation_count": 16,
                "lod_calc_count": 3,
                "parameter_count": 2,
                "filter_count": 4,
                "sheet_count": 7,
                "dashboard_count": 2,
                "story_count": 0,
                "action_count": 1,
                "has_rls": "False",
                "rls_type": "None",
                "extract_size_mb": 110,
                "is_live_connection": "False",
                "subscription_count": 35
            },
            {
                "site_name": "Global Supply Chain Site",
                "project_name": "Network Logistics",
                "workbook_name": "Logistics & Freight Advanced Multi-Source Engine",
                "artifact_type": "Workbook",
                "owner_name": "Architect_Logistics",
                "is_orphan": "False",
                "market_segment": "Operations & Industrial",
                "bu_sector": "Logistics & Freight",
                "bu_reach_count": 4,
                "distinct_users_180d": 260,
                "view_count_180d": 2100,
                "last_access_date": "2026-09-15",
                "days_since_last_access": 3,
                "last_refresh_date": "2026-09-17",
                "refresh_frequency": "Hourly",
                "is_certified": "True",
                "endorsement": "Certified",
                "data_connection_count": 4,
                "custom_sql_count": 3,
                "join_relationship_count": 14,
                "data_blending_count": 2,
                "calculation_count": 42,
                "lod_calc_count": 22,
                "parameter_count": 7,
                "filter_count": 12,
                "sheet_count": 24,
                "dashboard_count": 6,
                "story_count": 1,
                "action_count": 8,
                "has_rls": "True",
                "rls_type": "Dynamic Entitlement RLS",
                "extract_size_mb": 1450,
                "is_live_connection": "False",
                "subscription_count": 28
            }
        ]
    },
    "qlik": {
        "display_name": "Qlik Sense / QlikView",
        "container_term": "Stream / Space",
        "asset_term": "Qlik App (QVF / QVW)",
        "mandatory_columns": [
            "app_name",
            "stream_name",
            "table_count",
            "monthly_active_users",
            "session_count_total",
            "source_system_count"
        ],
        "optional_columns": [
            "sheet_count",
            "synthetic_key_count",
            "circular_reference_count",
            "set_analysis_expression_count",
            "has_section_access",
            "memory_ram_size_mb",
            "reload_duration_sec",
            "is_published",
            "owner_active",
            "days_since_last_reload"
        ],
        "column_descriptions": {
            "app_name": "Name of the Qlik Sense App",
            "stream_name": "Qlik Stream (e.g., Finance, Production, Everyone)",
            "table_count": "Total tables loaded in the associative data model",
            "monthly_active_users": "Unique active Qlik session users (MAU)",
            "session_count_total": "Total opened sessions in past 30 days",
            "source_system_count": "Distinct QVDs or database connections"
        },
        "sample_data": [
            {
                "app_name": "Commercial Performance Cockpit",
                "stream_name": "Executive Stream",
                "table_count": 7,
                "monthly_active_users": 160,
                "session_count_total": 1900,
                "source_system_count": 3,
                "sheet_count": 14,
                "synthetic_key_count": 0,
                "circular_reference_count": 0,
                "set_analysis_expression_count": 8,
                "has_section_access": "True",
                "memory_ram_size_mb": 850,
                "reload_duration_sec": 420,
                "is_published": "True",
                "owner_active": "True",
                "days_since_last_reload": 1
            }
        ]
    },
    "looker": {
        "display_name": "Google Looker",
        "container_term": "Looker Folder / Model",
        "asset_term": "Explore / Look / Dashboard",
        "mandatory_columns": [
            "explore_name",
            "model_name",
            "view_count",
            "monthly_active_users",
            "query_count_30d",
            "connection_count"
        ],
        "optional_columns": [
            "dimension_count",
            "measure_count",
            "join_count",
            "dashboard_count",
            "has_pdt",
            "git_branch",
            "days_since_last_query",
            "owner_status"
        ],
        "column_descriptions": {
            "explore_name": "Name of the LookML Explore",
            "model_name": "LookML Model file / repository",
            "view_count": "Number of underlying LookML Views joined",
            "monthly_active_users": "Unique user queries in 30 days",
            "query_count_30d": "Total queries executed against this explore",
            "connection_count": "Underlying SQL connections"
        },
        "sample_data": [
            {
                "explore_name": "order_items_analytics",
                "model_name": "ecommerce_core",
                "view_count": 6,
                "monthly_active_users": 190,
                "query_count_30d": 5400,
                "connection_count": 1,
                "dimension_count": 42,
                "measure_count": 18,
                "join_count": 5,
                "dashboard_count": 8,
                "has_pdt": "True",
                "git_branch": "main",
                "days_since_last_query": 0,
                "owner_status": "Active"
            }
        ]
    },
    "microstrategy": {
        "display_name": "MicroStrategy",
        "container_term": "Project / Folder",
        "asset_term": "Dossier / Document / Cube",
        "mandatory_columns": [
            "dossier_name",
            "project_name",
            "attribute_count",
            "metric_count",
            "monthly_active_users",
            "execution_count_30d"
        ],
        "optional_columns": [
            "object_type",
            "is_cube_based",
            "cube_size_mb",
            "freeform_sql_count",
            "days_since_last_execution",
            "certified_status"
        ],
        "column_descriptions": {
            "dossier_name": "Name of the MicroStrategy Dossier or Report",
            "project_name": "MicroStrategy Project name",
            "attribute_count": "Attributes used in the visualization / cube",
            "metric_count": "Metrics and compound calculations",
            "monthly_active_users": "Active users executing the dossier",
            "execution_count_30d": "Total dossier executions in 30 days"
        },
        "sample_data": [
            {
                "dossier_name": "Executive Financial Statement",
                "project_name": "Corporate Intelligence",
                "attribute_count": 12,
                "metric_count": 28,
                "monthly_active_users": 110,
                "execution_count_30d": 1250,
                "object_type": "Dossier",
                "is_cube_based": "True",
                "cube_size_mb": 650,
                "freeform_sql_count": 0,
                "days_since_last_execution": 2,
                "certified_status": "Certified"
            }
        ]
    },
    "universal": {
        "display_name": "Universal / Generic BI (Any Tool)",
        "container_term": "Domain / Workspace / Folder",
        "asset_term": "BI Model / Report / Asset",
        "mandatory_columns": [
            "artifact_name",
            "workspace_name",
            "table_count",
            "monthly_active_users",
            "activity_views",
            "data_source_count"
        ],
        "optional_columns": [
            "source_platform",
            "is_certified",
            "measure_count",
            "dataset_size_mb",
            "days_since_last_refresh",
            "has_gateway_or_bridge",
            "downstream_report_count",
            "workspace_type",
            "sensitivity_label"
        ],
        "column_descriptions": {
            "artifact_name": "Name of the dataset, workbook, app, or report",
            "workspace_name": "Parent project, workspace, stream, or folder",
            "table_count": "Number of tables/entities in the model",
            "monthly_active_users": "Unique active users in past 30 days",
            "activity_views": "Usage / execution count in past 30 days",
            "data_source_count": "Count of underlying database/data endpoints"
        },
        "sample_data": [
            {
                "artifact_name": "Enterprise Core Model",
                "workspace_name": "Global Analytics",
                "source_platform": "Universal",
                "table_count": 8,
                "monthly_active_users": 210,
                "activity_views": 3800,
                "data_source_count": 2,
                "is_certified": "True",
                "measure_count": 40,
                "dataset_size_mb": 500,
                "days_since_last_refresh": 1,
                "has_gateway_or_bridge": "False",
                "downstream_report_count": 10,
                "workspace_type": "Group",
                "sensitivity_label": "Confidential"
            }
        ]
    }
}


def get_platform_schema(platform: str) -> Dict[str, Any]:
    """Retrieves schema definitions for the specified platform."""
    plat_key = platform.lower().strip()
    return PLATFORM_SCHEMAS.get(plat_key, PLATFORM_SCHEMAS["universal"])


def generate_template_csv(platform: str, include_samples: Any = True) -> str:
    """Generates a downloadable CSV string for the platform."""
    plat_key = (platform or "powerbi").lower().strip()
    schema = get_platform_schema(plat_key)
    
    is_samples = True
    if isinstance(include_samples, bool):
        is_samples = include_samples
    elif isinstance(include_samples, str):
        is_samples = include_samples.lower().strip() in ["true", "1", "yes"]
        
    if is_samples and schema.get("sample_data"):
        df = pd.DataFrame(schema["sample_data"])
    else:
        # Blank template with all columns
        all_cols = schema["mandatory_columns"] + schema["optional_columns"]
        df = pd.DataFrame(columns=all_cols)
    
    output = io.StringIO()
    df.to_csv(output, index=False)
    return output.getvalue()


COLUMN_SYNONYMS: Dict[str, List[str]] = {
    "artifact_name": ["dataset_name", "workbook_name", "artifact_name", "report_name", "app_name", "model_name", "name", "title"],
    "dataset_name": ["dataset_name", "workbook_name", "artifact_name", "report_name", "app_name", "model_name", "name", "title"],
    "workbook_name": ["workbook_name", "dataset_name", "artifact_name", "report_name", "app_name", "model_name", "name", "title"],
    "project_name": ["project_name", "workspace_name", "site_name", "stream_name", "folder_name", "container_name"],
    "workspace_name": ["workspace_name", "project_name", "site_name", "stream_name", "folder_name", "container_name"],
    "site_name": ["site_name", "project_name", "workspace_name", "folder_name"],
    "monthly_active_users": ["monthly_active_users", "distinct_users_180d", "distinct_users", "mau", "active_users", "unique_users", "users_180d", "users"],
    "distinct_users_180d": ["distinct_users_180d", "monthly_active_users", "distinct_users", "mau", "active_users", "unique_users", "users_180d", "users"],
    "view_count_total": ["view_count_total", "view_count_180d", "activity_views", "views_180d", "total_views", "views", "view_count"],
    "activity_views": ["activity_views", "view_count_180d", "view_count_total", "views_180d", "total_views", "views", "view_count"],
    "view_count_180d": ["view_count_180d", "view_count_total", "activity_views", "views_180d", "total_views", "views", "view_count"],
    "data_source_count": ["data_source_count", "data_connection_count", "connection_count", "datasources", "data_connections"],
    "data_connection_count": ["data_connection_count", "data_source_count", "connection_count", "datasources", "data_connections"],
    "table_count": ["table_count", "tables", "total_tables", "table_qty"]
}


def validate_uploaded_dataframe(
    df: pd.DataFrame, 
    platform: str
) -> Tuple[bool, List[str], List[str], Dict[str, Any]]:
    """
    Validates an uploaded DataFrame against the platform schema with intelligent
    synonym and alias resolution (e.g., workbook_name for artifact_name, distinct_users_180d for monthly_active_users).
    Returns:
        valid (bool): True if all mandatory analytical concepts are present.
        missing_mandatory (list): List of mandatory columns not found in the CSV.
        missing_optional (list): List of optional columns missing.
        stats (dict): Row count, column count, schema health metrics.
    """
    schema = get_platform_schema(platform)
    cols = [str(c).strip().lower() for c in df.columns]

    missing_mandatory = []
    for m in schema["mandatory_columns"]:
        m_lower = m.lower()
        # Check direct presence
        if m_lower in cols:
            continue
        # Check recognized synonyms / platform aliases
        synonyms = COLUMN_SYNONYMS.get(m_lower, [])
        found_synonym = any(syn in cols for syn in synonyms)
        if not found_synonym:
            missing_mandatory.append(m)

    missing_optional = []
    for o in schema["optional_columns"]:
        o_lower = o.lower()
        if o_lower not in cols:
            synonyms = COLUMN_SYNONYMS.get(o_lower, [])
            if not any(syn in cols for syn in synonyms):
                missing_optional.append(o)

    valid = len(missing_mandatory) == 0

    stats = {
        "total_rows": len(df),
        "total_columns": len(df.columns),
        "platform": schema["display_name"],
        "mandatory_count": len(schema["mandatory_columns"]),
        "mandatory_found": len(schema["mandatory_columns"]) - len(missing_mandatory),
        "optional_count": len(schema["optional_columns"]),
        "optional_found": len(schema["optional_columns"]) - len(missing_optional),
        "mandatory_descriptions": {
            col: schema["column_descriptions"].get(col, "Required for mathematical scoring")
            for col in missing_mandatory
        }
    }

    return valid, missing_mandatory, missing_optional, stats

"""
Excel Export Utility for BI Rationalization Accelerator
Generates formatted, multi-tab Excel workbooks (.xlsx) with all input columns,
disposition decisions, 6-dimension category scores, and executive summaries.
"""

import io
import pandas as pd
from typing import Dict, Any, Optional
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


def generate_rationalization_excel(
    df_readiness: pd.DataFrame,
    df_summary: Optional[pd.DataFrame] = None,
    cfg: Optional[Dict[str, Any]] = None
) -> bytes:
    """
    Generates a professionally formatted Excel workbook containing:
    1. Asset Rationalization Decisions (All input columns + disposition + category scores)
    2. Container & Project Summary
    3. Methodology & Scoring Legend
    """
    wb = openpyxl.Workbook()
    # Remove default sheet
    default_sheet = wb.active
    wb.remove(default_sheet)

    # Styles
    header_fill = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    
    migrate_fill = PatternFill(start_color="E6F4EA", end_color="E6F4EA", fill_type="solid")
    migrate_font = Font(name="Segoe UI", size=10, bold=True, color="137333")
    
    retire_fill = PatternFill(start_color="FCE8E6", end_color="FCE8E6", fill_type="solid")
    retire_font = Font(name="Segoe UI", size=10, bold=True, color="C5221F")
    
    review_fill = PatternFill(start_color="FEF7E0", end_color="FEF7E0", fill_type="solid")
    review_font = Font(name="Segoe UI", size=10, bold=True, color="B06000")
    
    regular_font = Font(name="Segoe UI", size=10)
    bold_font = Font(name="Segoe UI", size=10, bold=True)
    
    thin_border_side = Side(border_style="thin", color="E2E8F0")
    cell_border = Border(left=thin_border_side, right=thin_border_side, top=thin_border_side, bottom=thin_border_side)
    
    # -------------------------------------------------------------
    # SHEET 1: ASSET RATIONALIZATION DECISIONS
    # -------------------------------------------------------------
    ws1 = wb.create_sheet(title="Asset Decisions & Scoring")
    ws1.views.sheetView[0].showGridLines = True
    
    if not df_readiness.empty:
        # Organize columns logically: Key decisions first, then scores, then inputs
        priority_cols = [
            "AssetId", "SiteName", "Workspace", "WorkspaceName", "Artifact", "Type",
            "ProposedDisposition", "ReviewStatus", "OutcomeDecision", "ExecutionWave",
            "Status", "Effort", "RecommendationReason",
            "ReadinessScore", "CriticalityScore", "ComplexityScore",
            "BusinessValueScore", "UsageScore", "TechnicalQualityScore", "PerformanceScore", "GovernanceScore",
            "SimilarityFlag", "SuggestedRetainedAssetName", "SuggestedRetainedAssetId",
            "DuplicateStatus", "SharedDatasetCount", "IsGoldenDataset", "DirectLakeCandidate",
            "DistinctUsers", "ActivityViews", "LastAccessDays",
            "CustomSQLCount", "LODCalcCount", "DataConnections", "SheetCount", "DashboardCount"
        ]
        
        # All columns in df_readiness
        all_cols = list(df_readiness.columns)
        # Ordered cols: priority cols present in df, followed by remaining original input cols
        ordered_cols = [c for c in priority_cols if c in all_cols]
        remaining_cols = [c for c in all_cols if c not in ordered_cols and not str(c).startswith("_")]
        final_cols = ordered_cols + remaining_cols
        
        df_export1 = df_readiness[final_cols].copy()
        
        # Write Headers
        ws1.append(final_cols)
        for col_num, col_name in enumerate(final_cols, 1):
            cell = ws1.cell(row=1, column=col_num)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            ws1.row_dimensions[1].height = 28

        # Write Data Rows
        for row_idx, row_data in enumerate(df_export1.itertuples(index=False), 2):
            ws1.append(list(row_data))
            ws1.row_dimensions[row_idx].height = 20
            
            for col_idx, val in enumerate(row_data, 1):
                cell = ws1.cell(row=row_idx, column=col_idx)
                cell.font = regular_font
                cell.border = cell_border
                col_name = final_cols[col_idx - 1]
                
                # Alignments and styling
                if isinstance(val, (int, float)):
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                    if isinstance(val, float):
                        cell.number_format = "#,##0.0"
                    else:
                        cell.number_format = "#,##0"
                else:
                    cell.alignment = Alignment(horizontal="left", vertical="center")

                # Color-code key decision columns
                if col_name in ["ProposedDisposition", "OutcomeDecision"]:
                    val_str = str(val).lower()
                    if "migrate" in val_str or "select" in val_str:
                        cell.fill = migrate_fill
                        cell.font = migrate_font
                    elif "retire" in val_str:
                        cell.fill = retire_fill
                        cell.font = retire_font
                elif col_name == "ReviewStatus":
                    val_str = str(val).lower()
                    if "review" in val_str or "insufficient" in val_str:
                        cell.fill = review_fill
                        cell.font = review_font

        # Auto-fit column widths
        for col in ws1.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            col_letter = get_column_letter(col[0].column)
            ws1.column_dimensions[col_letter].width = min(max(max_len + 4, 12), 48)

        ws1.freeze_panes = "A2"
        ws1.auto_filter.ref = ws1.dimensions

    # -------------------------------------------------------------
    # SHEET 2: CONTAINER & PROJECT SUMMARY
    # -------------------------------------------------------------
    if df_summary is not None and not df_summary.empty:
        ws2 = wb.create_sheet(title="Container & Project Summary")
        ws2.views.sheetView[0].showGridLines = True
        
        sum_cols = list(df_summary.columns)
        ws2.append(sum_cols)
        
        for col_num, col_name in enumerate(sum_cols, 1):
            cell = ws2.cell(row=1, column=col_num)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
            ws2.row_dimensions[1].height = 26

        for row_idx, row_data in enumerate(df_summary.itertuples(index=False), 2):
            ws2.append(list(row_data))
            ws2.row_dimensions[row_idx].height = 20
            
            for col_idx, val in enumerate(row_data, 1):
                cell = ws2.cell(row=row_idx, column=col_idx)
                cell.font = regular_font
                cell.border = cell_border
                if isinstance(val, (int, float)):
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                    if isinstance(val, float):
                        cell.number_format = "#,##0.0"
                    else:
                        cell.number_format = "#,##0"
                else:
                    cell.alignment = Alignment(horizontal="left", vertical="center")

        for col in ws2.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            col_letter = get_column_letter(col[0].column)
            ws2.column_dimensions[col_letter].width = min(max(max_len + 4, 14), 40)

        ws2.freeze_panes = "A2"
        ws2.auto_filter.ref = ws2.dimensions

    # -------------------------------------------------------------
    # SHEET 3: METHODOLOGY & SCORING LEGEND
    # -------------------------------------------------------------
    ws3 = wb.create_sheet(title="Methodology & Legend")
    ws3.views.sheetView[0].showGridLines = True
    
    ws3.column_dimensions["A"].width = 24
    ws3.column_dimensions["B"].width = 30
    ws3.column_dimensions["C"].width = 65

    legend_data = [
        ("SCORING DIMENSION", "RANGE / SCALE", "EVALUATION CRITERIA & BUSINESS RATIONALE"),
        ("Readiness Score", "0 - 100", "Normalized composite readiness weighting business criticality (70%) and technical ease (30%)."),
        ("Criticality Score", "0 - 400 pts", "Business impact score based on 180d Distinct Users (100), Activity Views (100), BU Reach (100), and Access Recency (100)."),
        ("Complexity Score", "90 - 900 pts", "Technical migration difficulty across 9 dimensions (Connections, Custom SQL, Joins, Calcs, LODs, Params, Filters, Sheets, RLS)."),
        ("Business Value", "0 - 100", "Organizational importance, BU reach, and certified governance tier status."),
        ("Usage & Adoption", "0 - 100", "Audience size, monthly active consumption, and refresh subscription volume."),
        ("Technical Quality", "0 - 100", "Schema health, calculated column density, and table architecture."),
        ("Performance", "0 - 100", "Storage footprint and extract size efficiency (<500MB = 100)."),
        ("Governance", "0 - 100", "Ownership verification, active certification, and absence of orphan status."),
        ("", "", ""),
        ("DISPOSITION DECISION", "STATUS MAPPING", "ACTION & GOVERNANCE WORKFLOW"),
        ("Select for migration", "Wave 1 - 3", "Asset meets business criticality threshold (>=250 pts). Prioritized into migration waves based on technical complexity."),
        ("Retire candidate", "Wave 4 (Decommission)", "Asset is inactive (0 users/views), dead (>365d stale), zombie refresh, or below criticality threshold. Safe for capacity reclamation."),
        ("Undecided", "Unassigned", "Telemetry unobserved (missing user and view activity). Requires discovery before disposition."),
        ("", "", ""),
        ("REVIEW STATUS", "WORKFLOW REQUIREMENT", "ACTION"),
        ("Ready", "Automated / Low Risk", "Standard migration or retirement pathway. No structural ambiguity detected."),
        ("Business review required", "Advisory Review", "Potential structural duplicate or shared model identified. Suggested primary candidate recommended for business confirmation."),
        ("Insufficient evidence", "Telemetry Gap", "Missing usage telemetry takes precedence. Awaiting usage observation before making disposition.")
    ]

    for row_idx, (c1, c2, c3) in enumerate(legend_data, 1):
        ws3.append([c1, c2, c3])
        ws3.row_dimensions[row_idx].height = 22
        
        if row_idx in [1, 11, 16]:
            for col_idx in [1, 2, 3]:
                cell = ws3.cell(row=row_idx, column=col_idx)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="left", vertical="center")
        elif not c1 and not c2:
            pass
        else:
            for col_idx in [1, 2, 3]:
                cell = ws3.cell(row=row_idx, column=col_idx)
                cell.font = bold_font if col_idx == 1 else regular_font
                cell.border = cell_border
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output.getvalue()

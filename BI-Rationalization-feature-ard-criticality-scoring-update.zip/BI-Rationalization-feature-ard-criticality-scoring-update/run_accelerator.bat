@echo off
SETLOCAL EnableDelayedExpansion
TITLE "BI Rationalization & Migration Planning Accelerator"
echo ================================================================
echo       BI Rationalization ^& Migration Planning Accelerator        
echo ================================================================
echo.

:: 1. Discover and Check Python environment
echo [1/4] Checking Python environment...
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python312" set "PATH=C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python312;C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python312\Scripts;!PATH!"
    if exist "C:\Program Files\Python312" set "PATH=C:\Program Files\Python312;C:\Program Files\Python312\Scripts;!PATH!"
    if exist "C:\Program Files\Python311" set "PATH=C:\Program Files\Python311;C:\Program Files\Python311\Scripts;!PATH!"
    if exist "C:\Program Files\Python310" set "PATH=C:\Program Files\Python310;C:\Program Files\Python310\Scripts;!PATH!"
)
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python 3.9+ from Software Center or https://www.python.org/downloads/
    pause
    exit /b 1
)

:: 2. Install Python Dependencies
echo [2/4] Ensuring Python requirements are installed...
python -m pip install -r "%~dp0requirements.txt" --quiet
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] Pip install had issues. Attempting verbose install...
    python -m pip install -r "%~dp0requirements.txt"
)

:: 3. Discover and Check Node.js and Install Frontend Dependencies
echo [3/4] Checking Node.js and Frontend dependencies...
node --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "D:\Diverted Installs\nodejs" set "PATH=D:\Diverted Installs\nodejs;!PATH!"
    if exist "C:\Program Files\nodejs" set "PATH=C:\Program Files\nodejs;!PATH!"
    if exist "C:\Program Files (x86)\nodejs" set "PATH=C:\Program Files (x86)\nodejs;!PATH!"
    if exist "%LOCALAPPDATA%\Programs\nodejs" set "PATH=%LOCALAPPDATA%\Programs\nodejs;!PATH!"
    if exist "%APPDATA%\npm" set "PATH=%APPDATA%\npm;!PATH!"
)
node --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [INFO] Node.js not found in standard paths. Attempting automated installation via winget...
    winget --version >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        echo [INFO] Installing Node.js LTS via winget...
        winget install OpenJS.NodeJS.LTS --silent --accept-source-agreements --accept-package-agreements
        if exist "C:\Program Files\nodejs" set "PATH=C:\Program Files\nodejs;!PATH!"
    )
)
node --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ==============================================================================
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please install Node.js LTS (18+) from: https://nodejs.org/
    echo Once installed, rerun this script.
    echo ==============================================================================
    echo.
    pause
    exit /b 1
)

if not exist "%~dp0frontend\node_modules" (
    echo [INFO] First-time setup detected: Installing frontend packages...
    cd /d "%~dp0frontend"
    call npm install
    cd /d "%~dp0"
)

:: 4. Launch Backend & Frontend Servers
echo [4/4] Launching FastAPI Backend (Port 8000) and Next.js UI (Port 3000)...
start "Rationalization API Backend" cmd /k "cd /d ""%~dp0"" && python server.py"
start "Rationalization Next.js UI" cmd /k "cd /d ""%~dp0frontend"" && npm run dev"

echo.
echo ================================================================
echo  All Services Successfully Launched!
echo  - Web Application:   http://localhost:3000
echo  - API Documentation: http://127.0.0.1:8000/docs
echo ================================================================
echo.
pause

# Architecture review: BI Rationalization Accelerator

Reviewed 18 September 2026. Scope: current working tree on `feature/tableau-ard-lift-and-shift`, including existing uncommitted changes. This is a code and architecture review, not a production penetration test or validation against a real customer estate. Application source was not changed.

## Architectural verdict

The accelerator has a useful assessment foundation: separate Tableau criticality and complexity scoring, deterministic calculations, explicit evidence categories, a CSV ingestion boundary, and an accessible review UI. Separating business need from migration difficulty is the right direction for the original retire-or-select-for-migration scope.

The agreed product scope is a lightweight decision-support accelerator: use inexpensive metadata to identify candidates, explain the signals, and hand the findings to business owners for a decision. Count-based duplicate screening is appropriate within this scope. Matching connection, calculation, sheet, table, and column counts can flag **Potential duplicates — structural match**; they do not establish exact equivalence. Detailed definition comparison and automated verification of access or consumer equivalence are optional future capabilities, not prerequisites for this accelerator.

The immediate architectural correction is to separate the similarity flag from the retire-or-migrate recommendation. A structural match must not automatically set an asset to Retire or present a preferred copy as an authoritative master. Show matching attributes and missing evidence, suggest a retained copy where useful, and export the group with ownership, usage, and criticality for business review. Missing values must not count as matching evidence.

Business owners decide whether to keep both assets, retire a selected copy, or investigate further. The platform owner checks dependencies and access before actual decommissioning; these checks and the approval record can be handled in an existing business process outside the accelerator. Enterprise readiness for this scope means trustworthy screening, clear uncertainty, traceable handoff, reproducibility, and appropriate security for shared deployment. The current implementation still needs the decision-labeling and correctness fixes identified below.

Preserve the two final business dispositions, **Retire** and **Select for migration**. Add **Review required**, **Blocked**, and **Insufficient evidence** as assessment/workflow states. Selecting an asset for migration does not establish that it can migrate as-is, that migration is approved, or that it has completed.

## Implementation status

### Latest rework verification — supersedes earlier verification status

**Result:** 26 unit tests pass and the Next.js production build passes. Independent probes confirm that (1) the uploaded unified inventory is selected before the legacy Tableau template, (2) low-criticality suggested-copy explanations agree with retirement-candidate disposition, (3) partially missing core similarity metadata is excluded from matching, (4) blank ARD native IDs produce distinct assessment-local IDs, and (5) the active normalization function preserves 180-day user metrics without aliasing them to monthly users. Code inspection also confirms the standard outcome-total overlap and numbered Unassigned-wave issues have been corrected.

**Remaining agreed-scope gaps:**

- **Finding 5 — validation is still partial.** The upload route does not use `validate_and_normalize_inventory`; ARD dispatch returns before that validator; standard validation errors are warnings rather than rejection. The validator only checks emptiness and the presence of a name column. Standard numeric normalization still converts missing/malformed values to zero. Multi-file ingestion still performs positional concatenation and joins without cardinality validation. The uploaded-file selection fix is verified, but it does not close this broader finding.
- **Finding 7 — standard-engine blank IDs and UI summary joins remain.** ARD ID null handling is fixed, but the standard engine still stringifies `asset_id`/`luid` without null handling. UI groups now correctly use `SiteName / Workspace`, while the summary lookup still compares that combined key to bare `WorkspaceName` or `Project`; Tableau summaries therefore fail to match. Match site and project separately or emit/use the same composite container key throughout.
- **Finding 11 — complexity scale still follows source platform instead of scoring mode.** The detail drawer uses `profile.id === 'tableau' ? '900' : '100'`. Tableau with standard 6R is a supported configuration and still gets the wrong denominator. Use score metadata or the effective strategy, not the source platform. The checked-in configuration currently selects Tableau with standard 6R.
- **Finding 3 — audit contract remains incomplete.** The earlier contradictory explanation is fixed. A concrete typed decision record and output fields for rule IDs, effective thresholds, score breakdown, and evidence gaps are still absent from the output construction. This remains a plan-completion gap rather than a failure of the reproduced explanation case.

Verification used in-memory inputs and temporary directories; no working inventory or scored output was replaced. Application source was not edited. UI findings are code-inspection findings; no browser end-to-end verification was performed. Earlier review sections below are historical evidence, not a claim that the now-passing cases still fail.

**Post-implementation verification:** The user reports implementation complete. All 23 current unit tests pass, and the Next.js production build passes. Independent targeted checks nevertheless reproduced unresolved correctness issues listed below. Findings 1, 3, 4, 5, 6, 7, 11, and 12 should therefore be tracked as **Implemented in part — verification gaps remain**, rather than closed. Earlier status and original findings are retained as review history.

### Post-implementation findings

1. **High — uploaded inventory can still be ignored (finding 5).** `engine/core_scorer.py:236` still prefers `tableau_ard_unified_template.csv` in ARD mode, while uploads save to `dataset_inventory.csv`. A temporary-directory probe containing an OLD TEMPLATE and NEW UPLOAD returned OLD TEMPLATE. The shared validator is not called by the upload route or ARD evaluator; in standard mode its errors are only logged. Positional concatenation and unchecked joins also remain. Malformed unified CSV parsing now correctly rejects parse failures, but this does not complete the ingestion fix.
2. **High — decision and explanation still contradict (finding 3).** `engine/ard_scorer.py:358` emits “Select for migration” for every suggested retained copy before checking the actual disposition. Two matching low-usage assets at 220 points both produced Retire candidate, but the suggested copy's reason said Select for migration / High Criticality. Potential-shared-model explanations have the same unconditional migration wording. Generate reasons from the evaluated recommendation rather than independently reclassifying the row. No concrete typed decision model or emitted rule IDs, effective thresholds, score breakdown, or evidence gaps was found in the evaluated output construction.
3. **High — partially missing metadata still supplies false matching evidence (finding 1).** `engine/ard_scorer.py:48` and `:77` only suppress hashing when all checked core attributes are missing. Otherwise missing counts are filled with 0 or 1. A row containing only connection count and sheet count, plus usage telemetry, matched a row with observed zero SQL, zero joins, zero calculations, and one dashboard. Require an explicit observed minimum and never substitute missing counts into matching evidence.
4. **High — blank native IDs collide; UI still joins by names (finding 7).** `engine/ard_scorer.py:473` stringifies a missing native ID before checking it. Two rows with `asset_id=None` both emitted AssetId and SuggestedRetainedAssetId equal to the literal “None”. CSV blanks can similarly become “nan”. Centralize null-aware ID resolution and validate uniqueness. UI workspace grouping still uses display names and cluster membership can still be extended by matching suggested-copy names, so stable IDs are not yet used end to end.
5. **Medium — metric-window semantics remain conflated (finding 6).** The active normalization mapping in `engine/core_scorer.py:414` still maps distinct_users_180d to monthly_active_users. The source-count defect is fixed, but preserving measurement windows remains unfinished.
6. **Medium — UI contract edges remain (finding 11).** The standard engine maps all non-retired assets to Select for migration, while the executive dashboard counts that as Migrate As-Is alongside separate Optimize/Rebuild/etc. counts. This makes the six-outcome presentation overlap and mislabels technical treatment. The planner now parses numbered waves correctly, but Unassigned falls back to its array position and is displayed as a numbered wave. The detail drawer still displays /900 for standard complexity scores. These need contract-level UI checks beyond a production build.

**Verified improvements:** similarity and disposition fields are separate; missing user/view telemetry produces Undecided/Unassigned and preserves insufficient-evidence precedence; explicit ARD dispatch replaces column sniffing; configurable thresholds and source-count handling have test coverage; standard 6R emits the new disposition/review fields; unified CSV parse errors are rejected; project summary naming is improved; the cluster user-count label and overlap caption are present; the advisor discloses its 35-asset sample coverage; numbered planner waves use their actual number.

**Verification method:** Executed `unittest discover -s tests -v` using the installed Python runtime with approved elevated execution after sandbox access failed. Executed the Next.js production build using bundled Node. Ran in-memory probes against the ARD module and an isolated temporary-directory probe of the current input-loader function; no working input or scored output was replaced. No browser end-to-end session or live provider test was performed. Application source was not edited during this review.

User-reported update: findings **1, 3, 4, 5, 6, 7, 11, and 12** are being implemented. Their status is **In progress — verification pending**. This update records implementation activity; it does not establish that the changes are complete or that the findings are resolved. The findings below retain the original review evidence until the implementation is revalidated.

| Findings | Status | Follow-up |
|---|---|---|
| 1, 3, 4, 5, 6, 7, 11, 12 | In progress — user reported | Verify completed changes against the agreed lightweight accelerator scope and applicable release gates |
| 2: Business criticality | Open — implementation status not reported | Ensure low-audience or seasonal business-essential assets are protected through evidence and business review |
| 8: Wave planning | Open — implementation status not reported | Clearly label score-based waves as indicative planning; capacity scheduling can remain outside the accelerator |
| 9: Security | Open — implementation status not reported | Address access controls and secret handling before shared enterprise deployment |
| 10: Isolation and reproducibility | Open — implementation status not reported | Preserve run-specific inputs, policy, and outputs; prevent assessments from overwriting one another |

## Findings in priority order

### 1. Critical: similarity screening is presented as confirmed duplication and drives retirement

Evidence: `engine/ard_scorer.py:17`, `:36`, `:432`, `:458`.

The data fingerprint hashes counts, security flags, and integer-rounded extract size. The canvas fingerprint hashes counts of sheets, calculations, parameters, filters, and actions. Neither compares actual SQL, connection identities, calculation expressions, filter values, entitlement rules, or visual definitions. Nevertheless, matching signatures become `EXACT_DUPLICATE_CONFIRMED`, and noncanonical assets become retirement candidates.

An isolated execution reproduced this: two rows with different connection databases and SQL definitions but equal summary counts became a canonical master and a retirement candidate. The cryptographic hash is not the problem; the information being hashed is insufficient.

**Required change within accelerator scope:** retain inexpensive count-based signatures, optionally adding table and column counts where available, but label matches as potential duplicates. Display the matching attributes and evidence gaps; do not treat missing counts as equal observations. Keep similarity independent of disposition and export the grouped assets, owners, usage, and criticality for business review. Label any preferred copy **Suggested retained copy**. Partition comparison by artifact type and authorized estate boundary. The current election uses different rank functions by artifact type but does not separate the candidate groups by type.

Business review can record **Keep both / Retire selected copy / Investigate** outside the tool. Dependency and access checks belong to the platform owner's pre-decommissioning process. Building semantic comparison, security-equivalence verification, or an automated approval workflow into the accelerator is not required. The critical finding concerns the current claim of certainty and its effect on disposition, not the use of counts for screening.

### 2. Critical: popularity is treated as business criticality

Evidence: `engine/ard_scorer.py:54`, `:468`.

The 400-point score consists of users, views, BU reach, and recency. Three components measure usage. It has no effective protection for a business-mandated, small-audience, seasonal, or downstream-critical asset.

Reproduced example: 4 users, 50 views, 1 BU, last accessed 5 days ago scores 220 and becomes a retirement candidate. The scoring engine would treat an essential small-team report identically because business obligation is not represented in this decision.

**Required change:** add hard retention gates for owner-confirmed business necessity, required reporting obligations, seasonal use, and active downstream consumers. Capture telemetry coverage and observation periods. Missing usage is unknown, not evidence of nonuse. Treat the score as prioritization evidence, not retirement authorization. Published data sources need downstream-consumption evidence, not workbook-style viewer thresholds alone.

Do not tune thresholds to obtain the approach document's approximately 65% retirement target. Measure the outcome on an independently adjudicated estate; otherwise the target creates confirmation bias.

### 3. High: canonical decisions, reasons, and policy settings contradict one another

Evidence: `engine/ard_scorer.py:293`, `:315`, `:332`, `:468`, `:475`; `engine/config.yaml`; `frontend/src/app/configuration/page.tsx:425`.

Reproduced failures:

- A low-usage duplicate group can retire both its canonical master and its copy while the master's explanation says it is retained for migration.
- At a configured criticality threshold of 200, a 220-point asset receives `Migrate As-Is` while its explanation still says `Retire Candidate`; reason generation hardcodes 250.
- ARD wave boundaries use hardcoded 400/700 values even though configuration exposes complexity limits. The duplicate-detection setting is not honored by the evaluator.

**Required change:** produce one typed recommendation object containing proposed outcome, rule IDs, evidence references, policy version, blockers, and score breakdown. Render the explanation from that object. Keep suggested retained copies advisory and separate from approved business decisions; do not claim that a replacement is retained before review. If business review decides to retire an entire group, record that explicitly in the handoff process.

### 4. High: engine selection is implicit and can override the selected mode

Evidence: `engine/core_scorer.py:410`, especially the ARD detection and dispatch at `:419`.

The presence of any one of `distinct_users_180d`, `bu_reach_count`, `custom_sql_count`, or `lod_calc_count` can select the Tableau ARD engine even when configuration says `standard_6r`. The checked-in configuration uses `source_platform: tableau` and `strategy_mode: standard_6r`, making this ambiguity particularly relevant. Column names should not select business policy.

**Required change:** require explicit source platform, starget platform/environment, assessment strategy, and policy version for every run. Reject unsupported combinations. Show the effective policy in both UI and exports. Keep Tableau lift-and-shift as a distinct policy package and validate each new platform independently.

### 5. High: ingestion does not establish trustworthy scoring data

Evidence: `server.py:192`; `engine/templates_generator.py:488`; `engine/core_scorer.py:226`, `:632`.

Validation checks column presence, not field types, value ranges, unique IDs, observation windows, or completeness. Unified CSV parse errors are logged and then the bytes can still be saved with a success message. Dimension uploads and CLI processing do not share the same validation gate. Multi-file loading can fall back to positional concatenation or joins without cardinality checks. In ARD mode, an existing dedicated Tableau template takes precedence over the unified file uploaded through the UI, so a successful upload need not become the scored inventory.

An isolated ARD execution with a NaN view count failed with `ValueError: cannot convert float NaN to integer`. The existing null test only exercises score helpers, not the complete evaluator.

**Required change:** one ingestion/normalization service for API and CLI, typed platform-specific contracts, immutable upload batches, explicit selection of the batch to score, and a validation report. Reject malformed files before replacing valid input. Quarantine invalid rows and disclose coverage; never silently score partial estates as complete. Bound upload size and resource consumption.

### 6. High: cross-platform aliases discard meaning and expose a scoring bug

Evidence: `engine/core_scorer.py:76`, `:391`; `engine/templates_generator.py:466`.

The canonical mapping equates 180-day distinct users with monthly active users, access recency with refresh recency, and LOD counts with calculated-column counts. These are different measurements. Multiple container aliases can also collapse site and project into one workspace field. Validation accepts aliases the evaluator does not consistently consume.

There is a direct implementation defect: normalization maps `datasource_count` to `data_source_count`, while `compute_complexity_score` reads `datasource_count`. Normalized records can therefore receive the default single-source complexity score.

**Required change:** use platform adapters with explicit metric definitions, units, time windows, extraction timestamps, null semantics, and applicability. Keep native metadata alongside comparable normalized dimensions. Do not compare raw ARD complexity with standard complexity: one is 90–900 with higher meaning harder; the other is 0–100 with higher meaning easier.

### 7. High: no dependable identity or dependency graph

Evidence: result construction in `engine/ard_scorer.py:500` and `engine/core_scorer.py:531`; `frontend/src/app/rationalization/page.tsx:134`, `:267`.

Outputs primarily identify assets and canonical replacements by display names. UI grouping uses project/workspace names, so same-named projects across sites can merge. Cluster selection can include assets by canonical name. Shared count-based fingerprints are not evidence of an actual published-data-source relationship.

**Required change:** identity should include tenant/engagement, source instance, site, artifact type, native ID, and snapshot ID. Use IDs for joins, suggested replacements, and drill-downs. Import dependency relationships where the extract already provides them and disclose when dependency coverage is unknown. Full lineage discovery is an optional extension; for the agreed accelerator scope, unresolved dependencies are an explicit handoff item for the platform owner before decommissioning. Count-based similarity must never be presented as verified lineage.

### 8. High: the wave planner classifies complexity; it does not schedule delivery

Evidence: `engine/core_scorer.py:153`; `engine/ard_scorer.py:458`; `frontend/src/app/planner/page.tsx:58`.

Waves and effort are fixed score bands. There is no dependency ordering, team capacity, skill availability, release freeze, migration deadline, pilot learning, cutover slot, or contingency. ARD still describes complex assets as `Migrate As-Is` while status can say `Deep Rebuild`, conflicting with the stated lift-and-shift boundary. In standard mode, changing wave count can make the wave description disagree with the outcome because their score boundaries differ.

**Required change:** separate migration selection, technical treatment, complexity class, and scheduled wave. Plan dependency bundles against capacity and deadlines. Derive effort ranges from representative migration pilots and include validation, credentials, permissions, stakeholder acceptance, rollback, and hypercare. Retirement has nonzero effort. If migration requires redesign outside the engagement scope, mark it blocked or exception-required rather than silently expanding scope.

### 9. High: enterprise hosting would expose unprotected administrative operations

Evidence: `server.py:42`, `:59`, `:89`, `:95`, `:105`, `:258`.

The API has no application authentication or authorization. It returns the configuration, including any saved API key, and accepts unrestricted configuration replacement. Scoring requests accept server input/output directory paths. The configurable LLM endpoint can direct outbound requests with estate context and, for some providers, credentials. All origins are permitted by the CORS configuration. The present launcher binds the backend to loopback, so this review does not claim it is currently internet-exposed.

**Required change before shared hosting:** SSO, role-based and engagement-scoped authorization, approved origins, secret storage with redacted config responses, server-controlled storage locations, validated configuration, endpoint allowlists and egress controls, request limits, and security audit events. Client-controlled paths should become upload/run identifiers. Separate evaluator, reviewer, approver, and administrator permissions.

### 10. High: global mutable files prevent isolation and reproducibility

Evidence: `server.py:51`; `engine/core_scorer.py:632`.

Every upload, configuration edit, and scoring run shares the same paths. Results overwrite CSVs without a run manifest or atomic multi-file publication. Concurrent assessments can overwrite or mix inputs and outputs; old output can remain visible after configuration changes or failed runs. Startup only checks for an existing readiness file, not whether it matches current inputs or policy.

**Required change:** immutable raw snapshots and assessment runs, transactional metadata, content hashes, explicit run states, and atomic result publication. Store actor, configuration/policy version, code version, extraction window, evaluation timestamp, and overrides. Use a background worker with bounded concurrency, idempotent jobs, progress, retries, and run-specific outputs. CSV should remain an import/export format, not the shared application database.

### 11. High: UI and advisor can misrepresent the engine's results

Evidence: `frontend/src/app/page.tsx:74`; `server.py:379`; `frontend/src/app/rationalization/page.tsx:267`, `:617`; `frontend/src/app/planner/page.tsx:74`.

The executive dashboard and advisor count only `Retire`, missing ARD's `Retire Candidate`. The ARD project summary emits `Workspace`, but its UI lookup expects `WorkspaceName` or `Project`. Complexity detail displays `/900` even for standard scores. Planner metadata derives wave numbers from array position; absent waves can therefore produce mismatched labels. Cluster distinct-user totals add per-asset distinct counts, which can double-count the same people.

**Required change:** a shared, versioned API contract with outcome enums, separate workflow state, typed score scales, stable wave IDs, and canonical container IDs. Compute portfolio totals once from the selected run. Label unavailable unique-user aggregation honestly. Test the full path from engine output through API to dashboard totals.

### 12. Medium: the advisor and readiness badges overstate their evidence

Evidence: `server.py:258`, `:289`; `engine/ard_scorer.py:493`; `engine/core_scorer.py:505`.

The LLM receives portfolio totals and only the first 35 assets; it cannot reliably answer questions about all assets. Asset text enters its system context without a clear untrusted-data boundary. Provider failures silently fall back to generic advice. Advertised Anthropic support has no corresponding invocation branch. Golden and Direct Lake/cloud-readiness badges are derived from limited heuristics, with no target compatibility assessment.

**Required change:** approved providers and data classifications, scoped retrieval, evidence citations, visible context coverage, explicit provider/fallback status, and separation of untrusted asset text from instructions. The advisor should explain deterministic results, not approve disposition. Replace readiness claims with candidate screening labels until target-specific prerequisites have been checked.

## Recommended enterprise design

The following is a modular evolution path. The initial accelerator needs reliable screening and a reviewable export; a complete approval, migration-execution, or semantic-equivalence system is not a release prerequisite. Existing enterprise processes can own those responsibilities.

1. **Collection/adapters:** read-only native extraction or MEA import, immutable evidence, connector version, permissions/coverage report.
2. **Canonical inventory:** stable asset identities, typed metrics, native definitions, ownership, dependency edges, observation windows.
3. **Assessment engine:** pure deterministic policy evaluation with business-value, usage, complexity, compatibility, risk, and evidence-confidence outputs kept separate.
4. **Business handoff:** export candidate groups, stable IDs, matching attributes, evidence gaps, owners, usage, and criticality. Capture or link the business decision if needed. Owner approval and execution tracking can remain in an existing enterprise workflow.
5. **Planning:** dependency bundles, capacity, calendar constraints, effort ranges, business priority, and exception handling.
6. **Results and advisor:** run-specific APIs, consistent UI/export totals, permission-aware evidence retrieval, explainable reasons.

A relational database can hold runs, assets, edges, decisions, and approvals; object storage can retain uploaded evidence and output packages. A durable job queue and worker can handle ingestion and scoring. A separate graph database is not necessary until measured traversal needs justify it.

Minimum run contract: engagement ID, source and target context, snapshot ID, policy version, evaluation time, evidence coverage, result status, and code version. Minimum decision contract: asset ID, proposed disposition, review state, rule IDs, evidence IDs, confidence, blockers, dependency impact, approver, and override history.

## Tableau-specific blind spots to add to the assessment

Define the migration path first: Server→Cloud, Server→Server, and Tableau→another BI platform need different compatibility policies. The repository does not make a target environment a first-class assessment input.

For Tableau relocation, assess identity and group mapping, permissions inheritance, credentials/OAuth, private-network connectivity and Bridge needs, supported connections, refresh schedules, subscriptions, embedded URLs, extensions, flows, and operating capacity. Assess dependencies at asset-type level and verify both allowed and denied access after migration. Verify representative business totals, filters, calculations, refresh behavior, performance, and consumer journeys before cutover.

Tableau's [migration considerations](https://help.tableau.com/current/blueprint/en-us/bp_move_to_cloud.htm) explicitly highlight connectivity and permissions. Its [embedded-credential migration guidance](https://help.tableau.com/current/online/en-us/cmt-migration_embedded_credentials.htm) describes additional authorization requirements. These are deployment-readiness checks that asset complexity counts do not establish.

Collection completeness also depends on the extraction identity. Tableau documents visibility and permission behavior in [Metadata API permissions](https://help.tableau.com/current/api/metadata_api/en-us/docs/meta_api_permissions.html). Record inaccessible or unobserved assets explicitly; an incomplete inventory must not imply an asset has no dependents.

If the destination is Power BI/Fabric or another platform, assess semantic and feature translation explicitly and use “selected for migration” as the outcome. Do not infer content portability from a renamed platform label or a low Tableau complexity score.

In the external decommissioning process, require business approval, consumer notification, a reversible quarantine/archive step, an agreed observation period, and platform-owner checks of dependencies and access. These controls need not be implemented inside the accelerator. Measure actual released capacity or avoidable cost after completion; report-count reduction alone does not prove license savings.

## Delivery priorities and release gates

| Phase | Scope | Exit gate |
|---|---|---|
| 1: Decision safety | Count-based potential-duplicate screening independent of disposition; retention/unknown gates; explicit mode; consistent reasons; strict ingestion; correct dashboard counts | Similarity alone never sets Retire; missing values are not match evidence; explanations agree with recommendations; candidate groups are exportable |
| 2: Controlled Tableau pilot | Stable IDs, available dependency evidence and coverage gaps, immutable runs, business handoff, scoped access, secret management, target context | Owners can review/reproduce recommendations; cross-engagement isolation is verified; external approval and pre-decommissioning responsibilities are assigned |
| 3: Enterprise operation | Durable jobs, transactions, monitoring, backup/restore, deployment pipeline, capacity planning, pilot-calibrated effort | Failed/concurrent runs cannot mix results; recovery and representative estate scale are demonstrated |
| 4: Additional platforms | Native adapters, artifact taxonomies, platform-specific tests and compatibility policies | Each supported source/target pair passes its own validated acceptance suite |

Prioritize independently adjudicated examples over more synthetic examples that mirror the formula. Test low-volume critical assets, seasonal use, missing telemetry, real semantic differences with identical counts, RLS differences, same names across sites, shared sources with active dependents, canonical replacement failure, configuration changes, input permutation, concurrent runs, and UI/API reconciliation. Freeze evaluation time in tests. Measure false-retirement recommendations and unresolved evidence coverage, not just test count or retirement percentage.

The approach document also needs reconciliation: it describes four criticality factors but lists a fifth, and nine complexity factors but lists a tenth; several documented tiers differ from code. Maintain one versioned policy specification with executable examples.

## Verification performed and limitations

- Inspected backend routes, both engines, schemas, configuration, UI consumers, launchers, tests, and the approach document.
- Ran five isolated probes against the actual ARD module: false duplicate retirement, low-audience retirement, canonical master/reason contradiction, custom-threshold/reason contradiction, and NaN pipeline failure. All exhibited the behavior described above. The probes used in-memory synthetic data and did not replace estate outputs.
- Full tests could not execute in the available runtime: the default shell has no Python command; bundled Python lacks pytest and PyYAML. Unittest discovery failed at import due to missing PyYAML. This is an environment limitation, not a reported assertion failure in the project suite.
- Did not run a frontend build, browser workflow, authenticated customer extraction, load test, or penetration test. Other implementation findings are based on code inspection, not claimed end-to-end reproduction.
- Existing user edits were preserved. This review file is the only intentional project addition.

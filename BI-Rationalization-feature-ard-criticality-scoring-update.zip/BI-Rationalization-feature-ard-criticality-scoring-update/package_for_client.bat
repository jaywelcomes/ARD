@echo off
REM ==============================================================================
REM Export Clean Client Delivery Package
REM ==============================================================================
echo [INFO] Packaging clean client deliverable (removing dev clutter, caches, and tests)...
python cleanup_and_package.py --export-zip
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Packaging failed. Please ensure Python is installed.
) else (
    echo [SUCCESS] Package created: Tableau_ARD_Accelerator_Client_Package.zip
)
pause

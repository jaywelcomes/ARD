Rationalize-Disposition (ARD) Accelerator: Approach & Scoring Logic
1. Approach & Telemetry Ingestion
Export metadata from Tableau Server / Cloud sites using Capgemini's Metadata Extract Agent (MEA) and consolidate into a master extract containing:

Usage & Criticality Metrics: Views (last 180 days), Distinct Users (last 180 days), Last Access Date / Staleness, BU / Sector Mapping, and Certification / Endorsement status.
Content & Complexity Metrics: Data Connections, Custom SQL, Joins & Relationships, Calculations & LODs, Parameters, Filters, Worksheets, Dashboards, Actions, and Security/RLS.
Processing: Ingest master extract into the ARD Accelerator to compute:
Business Criticality Score (0 to 400 pts) $\rightarrow$ Drives the binary Disposition Recommendation (Retire vs. Migrate As-Is).
Technical Complexity Score (90 to 900 pts) $\rightarrow$ Drives Migration Wave Sequencing & Effort Sizing.
2. Business Criticality Scoring Mechanism (Disposition Driver)
Points are allocated across 4 core factors, with an explicit Zero / Inactive tier (0 pts) to ensure truly dead assets are never falsely elevated.

$$\text{Total Criticality Points} = \sum (\text{Factor Points}) \quad [\text{Min: } 0, \text{ Max: } 400]$$

ID	Criticality Factor	6-Pillar Alignment	Zero / Inactive (0 pts)	Low (40 pts)	Medium (70 pts)	High (100 pts)
1	Distinct Users (last 180 days)	Usage & Adoption	0 users	1 – 199	200 – 499	500+
2	Views (last 180 days)	Usage & Adoption	0 views	1 – 2,499	2,500 – 9,999	10,000+
3	BU / Sector Reach	Business Value	0 / Unmapped	1 – 4 Business Units	5 – 9 Business Units	10+ Business Units
4	Last Access Recency	Usage & Adoption	> 365 days / Never	181 – 365 days	31 – 180 days	$\le$ 30 days
5	Governance & Certification (Replaces TBD)	Business Value	Unendorsed / Personal	Standard / Team	Promoted / Departmental	Certified / Enterprise
Scoring Ranges & Disposition:

Dead / Inactive: $0 - 159\text{ pts} \rightarrow$ Retire candidate (Wave 4)
Low Criticality: $160 - 249\text{ pts} \rightarrow$ Retire candidate (Score < 250)
High Criticality: $250 - 400\text{ pts} \rightarrow$ Select for migration (Waves 1 – 3)
3. Complexity Scoring Mechanism (Wave Planning Driver)
Evaluates technical debt and architectural friction across 9 content factors.

$$\text{Total Complexity Points} = \sum (\text{Factor Points}) \quad [\text{Min: } 90, \text{ Max: } 900]$$

ID	Complexity Factor	6-Pillar Alignment	Low Complexity (10 pts)	Medium Complexity (50 pts)	High Complexity (100 pts)
1	Data Connections	Complexity	1 connection	2 – 3 connections	4+ connections
2	Custom SQL Queries	Complexity	0 (Native tables)	1 – 2 queries	3+ queries (or multi-table SQL)
3	Joins + Relationships	Complexity	0 – 1 (Single table)	2 – 9 joins	10+ joins
4	Calculations & LODs	Technical Quality	< 5 calculations	5 – 15 calculations	> 15 (or nested FIXED LODs)
5	Parameters	Technical Quality	< 3 parameters	3 – 5 parameters	> 5 parameters
6	Filters	Technical Quality	< 5 quick filters	5 – 10 filters	> 10 filters (or context filters)
7	Worksheets	Technical Quality	< 10 sheets	10 – 19 sheets	20+ sheets
8	Dashboards / Stories	Technical Quality	1 – 2 dashboards	3 – 6 dashboards	7+ dashboards
9	Interactive Actions	Technical Quality	0 actions	1 – 5 actions	> 5 actions (URL/Highlight/Set)
10	Security / RLS / User Filters (Replaces TBD)	Governance	No RLS / Public	Simple User Filters	Entitlement Table / Dynamic RLS
Complexity Tiers:

Low Complexity: $90 - 400\text{ pts}$
Medium Complexity: $401 - 700\text{ pts}$
High Complexity: $701 - 900\text{ pts}$
4. Dashboard-Level Disposition & Wave Matrix
Recommendation	Target Portfolio %	Criticality Score Range	Complexity Tier	Target Wave & Effort Sizing
Retire / Decommission	~65%	< 250 pts	Any ($90 - 900$)	Wave 4: Archival & Decommissioning (0 effort)
Migrate As-Is (Fast-Track)	~35% Total	250 – 400 pts	Low ($90 - 400$)	Wave 1: 1 – 2 Days per dashboard
Migrate As-Is (Standard)	(part of 35%)	250 – 400 pts	Medium ($401 - 700$)	Wave 2: 3 – 5 Days per dashboard
Migrate As-Is (Complex)	(part of 35%)	250 – 400 pts	High ($701 - 900$)	Wave 3: 1 – 2 Weeks per dashboard
Consolidate / Rebuild	Out of Scope	N/A	N/A	Deferred to post-migration modernization
🧠 Review of Your Proposed Pillar Grouping Approach
Your Question: "The signal that you are agreeing and adding any per recommendation, we can group it under the 6 pillars we originally have. The one contributing to the decision making of retire or migrate can be given weightage accordingly and the remaining 4 pillars can be made 1 so it is used for wave planning and not for rationalization. Do you agree with this approach or see any problem?"

Verdict: 100% Agree. This is an exceptional architectural fit.
Here is why this approach works well and why it protects your core application:

┌──────────────────────────────────────────────────────────────────────────────────┐
│                      THE 6-PILLAR DUAL-ENGINE ARCHITECTURE                       │
├──────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   ENGINE 1: RATIONALIZATION DISPOSITION (Go / No-Go)                             │
│   ├── Pillar 1: Business Value (BU Reach, Certification)       ──┐               │
│   └── Pillar 2: Usage & Adoption (MAU, Views, Last Access)     ──┴─► Score >= 250 │
│                                                                     (Migrate)    │
│                                                                     Score < 250  │
│                                                                     (Retire)     │
│                                                                                  │
│   ENGINE 2: WAVE PLANNING & EFFORT ESTIMATION                                    │
│   Combined into a single Composite Complexity Index (90-900 pts):                │
│   ├── Pillar 3: Technical Quality (LODs, Worksheets, Filters)   ──┐              │
│   ├── Pillar 4: Performance (Extract vs Live, Size)             ──┼─► Wave 1-3   │
│   ├── Pillar 5: Governance (RLS, User Filters, Ownership)       ──┤  (Sequencing)│
│   └── Pillar 6: Complexity (Connections, Custom SQL, Joins)     ──┘              │
│                                                                                  │
└──────────────────────────────────────────────────────────────────────────────────┘
Why this is mathematically and practically sound:
Eliminates False Retirement (The Critical Flaw of Combined Scoring):
By removing Pillars 3, 4, 5, and 6 from the Retire/Migrate formula, a dashboard with 25 complex LODs and 5 Custom SQL queries that is used by 100 people every day will NEVER be retired. Its complexity will only determine that it belongs in Wave 3 with a 2-week effort estimate.
Preserves 100% of Your Core Application Schema:
All 6 pillars in your database, UI grids, charts, and API schemas remain intact. You don't need to throw away your 6-pillar UI or data models.
Clean Mapping to License Renewal Urgency:
It directly solves the client's problem: "Retire the dead weight (65%), lift-and-shift all active assets (35%), and stage the high-effort ones in the right wave before the license renewal date."
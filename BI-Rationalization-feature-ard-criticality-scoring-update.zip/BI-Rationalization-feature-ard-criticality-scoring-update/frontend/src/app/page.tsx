"use client";

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { 
  fetchMigrationReadiness, 
  fetchMigrationWorkspaces,
  fetchConfig
} from '@/lib/api';
import { getPlatformProfile, PlatformProfile } from '@/lib/platformProfiles';
import { 
  Layers, 
  GitMerge, 
  Sparkles, 
  Trash2, 
  Database, 
  CheckCircle2, 
  TrendingUp, 
  Zap, 
  ArrowRight,
  ShieldAlert,
  Server,
  Building2
} from 'lucide-react';

export default function RationalizationDashboard() {
  const [datasets, setDatasets] = useState<any[]>([]);
  const [workspaces, setWorkspaces] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<PlatformProfile>(getPlatformProfile('powerbi'));

  useEffect(() => {
    async function load() {
      try {
        const [dsData, wsData, cfg] = await Promise.all([
          fetchMigrationReadiness(),
          fetchMigrationWorkspaces(),
          fetchConfig().catch(() => ({ source_platform: 'powerbi' }))
        ]);
        setDatasets(dsData || []);
        setWorkspaces(wsData || []);
        if (cfg?.source_platform) {
          setProfile(getPlatformProfile(cfg.source_platform));
        }
      } catch (err) {
        console.error("Failed to load rationalization data:", err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm font-semibold text-slate-500">Loading Rationalization Estate...</p>
      </div>
    );
  }

  const totalAssets = datasets.length;
  const totalWs = workspaces.length;
  const avgScore = totalAssets > 0 
    ? (datasets.reduce((acc, d) => acc + (parseFloat(d.ReadinessScore) || 0), 0) / totalAssets).toFixed(1)
    : 0;

  const migrateAsIs = datasets.filter(d => 
    d.OutcomeDecision === 'Migrate As-Is' || 
    (d.ProposedDisposition === 'Select for migration' && !['Optimize', 'Rebuild', 'Consolidate', 'Salvage'].includes(d.OutcomeDecision))
  ).length;
  const optimize = datasets.filter(d => d.OutcomeDecision === 'Optimize').length;
  const rebuild = datasets.filter(d => d.OutcomeDecision === 'Rebuild').length;
  const consolidate = datasets.filter(d => d.OutcomeDecision === 'Consolidate').length;
  const salvage = datasets.filter(d => d.OutcomeDecision === 'Salvage').length;
  const retire = datasets.filter(d => (d.ProposedDisposition?.toLowerCase().includes('retire') || d.OutcomeDecision?.toLowerCase().includes('retire'))).length;
  const reviewRequired = datasets.filter(d => (d.ReviewStatus?.toLowerCase().includes('review') || d.ReviewStatus?.toLowerCase().includes('insufficient'))).length;

  const goldenDatasets = datasets.filter(d => d.IsGoldenDataset === 'Yes').length;
  const directLake = datasets.filter(d => d.DirectLakeCandidate === 'Yes').length;
  const orphanWs = workspaces.filter(w => w.Orphaned === 'Yes').length;
  const pruningWs = workspaces.filter(w => w.PruningCandidate === 'Yes').length;

  const waves = [
    { name: 'Wave 1: Fast-Track Migrate', count: datasets.filter(d => d.ExecutionWave?.includes('Wave 1')).length, color: 'bg-emerald-500', text: profile.wave1Subtitle },
    { name: 'Wave 2: Standard Migrate', count: datasets.filter(d => d.ExecutionWave?.includes('Wave 2')).length, color: 'bg-blue-500', text: profile.wave2Subtitle },
    { name: 'Wave 3: Complex Architecture Review', count: datasets.filter(d => d.ExecutionWave?.includes('Wave 3')).length, color: 'bg-amber-500', text: profile.wave3Subtitle },
    { name: 'Wave 4: Retire & Decommission', count: datasets.filter(d => d.ExecutionWave?.includes('Wave 4')).length, color: 'bg-rose-500', text: profile.wave4Subtitle },
  ];

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <span className="px-3 py-1 bg-cyan-500/20 text-cyan-300 rounded-full text-xs font-bold uppercase tracking-wider border border-cyan-500/30">
            Portfolio Intelligence &bull; {profile.name}
          </span>
          <h1 className="text-3xl font-black mt-2 tracking-tight">Executive Rationalization Summary</h1>
          <p className="text-sm text-slate-300 mt-1 max-w-2xl">
            Autonomous 6-dimension evaluation determining migration readiness, execution wave sequences, and optimization strategies across your {profile.shortName} estate.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/rationalization"
            className="flex items-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-600/30 transition-all"
          >
            <span>Explore {profile.assetTerm} Decisions</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="premium-card p-6 border-l-4 border-l-blue-600">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Estate Readiness</span>
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{avgScore}</span>
            <span className="text-xs text-slate-500 font-bold">/ 100 Index</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">{totalAssets} {profile.assetTermPlural.toLowerCase()} across {totalWs} {profile.containerTermPlural.toLowerCase()}</p>
        </div>

        <div className="premium-card p-6 border-l-4 border-l-emerald-600">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Golden Assets</span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{goldenDatasets}</span>
            <span className="text-xs text-emerald-600 font-bold">Priority Hubs</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">High MAU, certified production models</p>
        </div>

        <div className="premium-card p-6 border-l-4 border-l-indigo-600">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{profile.fastTrackLabel}</span>
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{directLake}</span>
            <span className="text-xs text-indigo-600 font-bold">{profile.fastTrackBadge}</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">{profile.fastTrackDesc}</p>
        </div>

        <div className="premium-card p-6 border-l-4 border-l-rose-600">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Retire / Prune</span>
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <Trash2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{retire}</span>
            <span className="text-xs text-rose-600 font-bold">{pruningWs} {profile.containerTermPlural}</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Stale / orphaned zero-usage assets</p>
        </div>
      </div>

      {/* Outcome Breakdown & Wave Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Outcome Breakdown */}
        <div className="premium-card p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-slate-800">Rationalization Outcome Decisions</h2>
              <p className="text-xs text-slate-500">Classification based on 6 scoring dimensions</p>
            </div>
            <Link href="/rationalization" className="text-xs font-bold text-blue-600 hover:underline">
              View All
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-100">
              <span className="text-xs font-bold text-emerald-700 uppercase">Migrate As-Is</span>
              <p className="text-2xl font-black text-emerald-900 mt-1">{migrateAsIs}</p>
              <span className="text-[10px] text-emerald-600 font-semibold">Low effort transition</span>
            </div>

            <div className="p-4 rounded-xl bg-blue-50 border border-blue-100">
              <span className="text-xs font-bold text-blue-700 uppercase">Optimize</span>
              <p className="text-2xl font-black text-blue-900 mt-1">{optimize}</p>
              <span className="text-[10px] text-blue-600 font-semibold">{profile.calculationsTerm} Tuning</span>
            </div>

            <div className="p-4 rounded-xl bg-amber-50 border border-amber-100">
              <span className="text-xs font-bold text-amber-700 uppercase">Rebuild</span>
              <p className="text-2xl font-black text-amber-900 mt-1">{rebuild}</p>
              <span className="text-[10px] text-amber-600 font-semibold">Architecture review</span>
            </div>

            <div className="p-4 rounded-xl bg-purple-50 border border-purple-100">
              <span className="text-xs font-bold text-purple-700 uppercase">Consolidate</span>
              <p className="text-2xl font-black text-purple-900 mt-1">{consolidate}</p>
              <span className="text-[10px] text-purple-600 font-semibold">Duplicate model merge</span>
            </div>

            <div className="p-4 rounded-xl bg-cyan-50 border border-cyan-100">
              <span className="text-xs font-bold text-cyan-700 uppercase">Salvage</span>
              <p className="text-2xl font-black text-cyan-900 mt-1">{salvage}</p>
              <span className="text-[10px] text-cyan-600 font-semibold">{profile.governancePersonalTerm} promotion</span>
            </div>

            <div className="p-4 rounded-xl bg-rose-50 border border-rose-100">
              <span className="text-xs font-bold text-rose-700 uppercase">Retire</span>
              <p className="text-2xl font-black text-rose-900 mt-1">{retire}</p>
              <span className="text-[10px] text-rose-600 font-semibold">Immediate cleanup</span>
            </div>
          </div>
        </div>

        {/* Wave Roadmap Summary */}
        <div className="premium-card p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-slate-800">Migration Wave Distribution</h2>
              <p className="text-xs text-slate-500">Sequenced execution phases for {profile.name} migration</p>
            </div>
            <Link href="/planner" className="text-xs font-bold text-blue-600 hover:underline">
              Open Roadmap
            </Link>
          </div>

          <div className="space-y-4">
            {waves.map((w, idx) => {
              const pct = totalAssets > 0 ? Math.round((w.count / totalAssets) * 100) : 0;
              return (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="text-slate-800">{w.name}</span>
                    <span className="text-slate-600">{w.count} Assets ({pct}%)</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div className={`${w.color} h-full rounded-full transition-all duration-500`} style={{ width: `${pct}%` }}></div>
                  </div>
                  <span className="text-[11px] text-slate-500 block">{w.text}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import React, { useEffect, useState } from 'react';
import { 
  Sliders, 
  Save, 
  RefreshCw, 
  CheckCircle2, 
  HelpCircle,
  RotateCcw,
  AlertTriangle,
  BrainCircuit,
  Sparkles,
  Eye,
  EyeOff,
  Wand2,
  ShieldAlert,
  Layers,
  GitMerge
} from 'lucide-react';
import { fetchConfig, updateConfig, triggerScoring } from '@/lib/api';

const DEFAULT_FALLBACK_CONFIG = {
  strategy_mode: 'standard_6r',
  source_platform: 'tableau',
  ard_settings: {
    usage_lookback_days: 180,
    criticality_threshold: 250,
    duplicate_detection: true,
    complexity_low_limit: 400,
    complexity_medium_limit: 700
  },
  wave_configuration: {
    wave_count: 4,
    strategy: 'score_based'
  },
  weights: {
    business_value: 0.25,
    usage_adoption: 0.20,
    technical_quality: 0.20,
    performance: 0.15,
    governance: 0.10,
    complexity: 0.10,
  },
  thresholds: {
    stale_dataset_days: 90,
    usage_high_mau_limit: 200,
    usage_mid_mau_limit: 50,
    usage_views_multiplier: 1.6,
    tq_column_limit: 100,
    tq_column_deduction: 30,
    tq_calc_column_ratio: 0.25,
    tq_calc_column_deduction: 40,
    tq_single_table_col_limit: 20,
    tq_single_table_deduction: 30,
    perf_large_dataset_size_mb: 1000,
    perf_large_dataset_deduction: 40,
    perf_high_risk_dax_deduction: 40,
    gov_personal_deduction: 30,
    gov_orphan_deduction: 40,
    gov_no_sensitivity_deduction: 30,
    complexity_low_sources_limit: 3,
    complexity_high_sources_limit: 5,
  },
  llm: {
    provider: 'openai',
    model: 'gpt-4o-mini',
    api_key: '',
    endpoint: '',
    temperature: 0.2,
    system_prompt: 'You are an expert Enterprise BI & Cloud Migration Solution Architect. You assist enterprise teams with BI rationalization, asset scoring, wave sequencing, model consolidation, and retirement strategies based on real estate telemetry.'
  }
};

const STRATEGY_OPTIONS = [
  {
    id: 'standard_6r',
    name: 'Enterprise 6R Modernization',
    badge: 'Standard 6-Pillar',
    desc: 'Full 6-dimension quantitative scoring (0-100) with 6R outcomes (Migrate, Optimize, Consolidate, Rebuild, Salvage, Retire).'
  },
  {
    id: 'tableau_ard_lift_and_shift',
    name: 'Tableau ARD License-Cliff (Lift & Shift)',
    badge: '400/900 pt Model',
    desc: 'Targeted binary disposition (Retire vs. Migrate As-Is) powered by 400-pt Criticality, 900-pt Complexity, and SHA-256 deduplication.'
  }
];

const PLATFORM_OPTIONS = [
  { id: 'powerbi', name: 'Power BI / Fabric', desc: 'Semantic Models, PBIX, Workspaces', color: 'from-amber-500/20 to-amber-600/10 text-amber-700 border-amber-300' },
  { id: 'tableau', name: 'Tableau', desc: 'Workbooks, Data Sources, LODs, Projects', color: 'from-blue-500/20 to-blue-600/10 text-blue-700 border-blue-300' },
  { id: 'qlik', name: 'Qlik Sense / QlikView', desc: 'QVF Apps, QVDs, Set Analysis, Streams', color: 'from-emerald-500/20 to-emerald-600/10 text-emerald-700 border-emerald-300' },
  { id: 'looker', name: 'Google Looker', desc: 'Explores, LookML Models, Views', color: 'from-purple-500/20 to-purple-600/10 text-purple-700 border-purple-300' },
  { id: 'microstrategy', name: 'MicroStrategy', desc: 'Dossiers, Documents, Cubes, Projects', color: 'from-rose-500/20 to-rose-600/10 text-rose-700 border-rose-300' },
  { id: 'universal', name: 'Universal / Generic BI', desc: 'Standard Cross-Tool Canonical CSV', color: 'from-slate-500/20 to-slate-600/10 text-slate-700 border-slate-300' }
];

export default function ConfigurationPage() {
  const [config, setConfig] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [backendOffline, setBackendOffline] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showApiKey, setShowApiKey] = useState(false);

  const loadConfigData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const data = await fetchConfig();
      if (!data.llm) data.llm = { ...DEFAULT_FALLBACK_CONFIG.llm };
      if (!data.source_platform) data.source_platform = 'powerbi';
      if (!data.wave_configuration) data.wave_configuration = { ...DEFAULT_FALLBACK_CONFIG.wave_configuration };
      setConfig(data);
      setBackendOffline(false);
    } catch (err: any) {
      console.warn("Could not reach backend config API, using local defaults:", err);
      setConfig(DEFAULT_FALLBACK_CONFIG);
      setBackendOffline(true);
      setErrorMsg("Backend server (http://localhost:8000) is offline. Using default configuration.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadConfigData();
  }, []);

  if (loading && !config) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm font-semibold text-slate-500">Loading Configuration Parameters...</p>
      </div>
    );
  }

  const handleStrategyModeChange = (mode: string) => {
    setConfig((prev: any) => ({
      ...prev,
      strategy_mode: mode
    }));
  };

  const handleArdSettingChange = (key: string, val: any) => {
    setConfig((prev: any) => ({
      ...prev,
      ard_settings: {
        ...(prev.ard_settings || DEFAULT_FALLBACK_CONFIG.ard_settings),
        [key]: val
      }
    }));
  };

  const handlePlatformChange = (platform: string) => {
    setConfig((prev: any) => ({
      ...prev,
      source_platform: platform
    }));
  };

  const handleWaveCountChange = (count: number) => {
    setConfig((prev: any) => ({
      ...prev,
      wave_configuration: {
        ...(prev.wave_configuration || {}),
        wave_count: count
      }
    }));
  };

  const handleWeightChange = (key: string, val: number) => {
    setConfig((prev: any) => ({
      ...prev,
      weights: {
        ...prev.weights,
        [key]: val
      }
    }));
  };

  const handleThresholdChange = (key: string, val: any) => {
    setConfig((prev: any) => ({
      ...prev,
      thresholds: {
        ...prev.thresholds,
        [key]: val
      }
    }));
  };

  const handleLlmChange = (key: string, val: any) => {
    setConfig((prev: any) => ({
      ...prev,
      llm: {
        ...(prev.llm || DEFAULT_FALLBACK_CONFIG.llm),
        [key]: val
      }
    }));
  };

  const handleNormalizeWeights = () => {
    const weights = config.weights || {};
    const sum = Object.values(weights).reduce((a: any, b: any) => a + (parseFloat(b) || 0), 0) as number;
    if (sum <= 0) return;
    
    // Distribute exactly 100 percentage points using Largest Remainder Method
    const entries = Object.entries(weights);
    const unrounded = entries.map(([key, val]) => {
      const rawPct = ((val as number) / sum) * 100;
      const floorPct = Math.floor(rawPct);
      const remainder = rawPct - floorPct;
      return { key, floorPct, remainder };
    });

    const totalAllocated = unrounded.reduce((acc, item) => acc + item.floorPct, 0);
    const pointsToDistribute = 100 - totalAllocated;

    unrounded.sort((a, b) => b.remainder - a.remainder);
    for (let i = 0; i < pointsToDistribute; i++) {
      unrounded[i % unrounded.length].floorPct += 1;
    }

    const normalized: Record<string, number> = {};
    for (const item of unrounded) {
      normalized[item.key] = parseFloat((item.floorPct / 100).toFixed(2));
    }

    setConfig((prev: any) => ({
      ...prev,
      weights: normalized
    }));
  };

  const handleResetWeights = () => {
    setConfig((prev: any) => ({
      ...prev,
      weights: { ...DEFAULT_FALLBACK_CONFIG.weights }
    }));
  };

  const totalWeight = Object.values(config.weights || {}).reduce((a: any, b: any) => a + (parseFloat(b) || 0), 0) as number;
  const roundedPercentTotal = Math.round(totalWeight * 100);
  const isWeightBalanced = roundedPercentTotal === 100;

  const handleSaveAndRerun = async () => {
    setSaving(true);
    setSaveSuccess(false);
    try {
      await updateConfig(config);
      await triggerScoring();
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      alert(`Failed to save configuration: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const currentLlm = config.llm || DEFAULT_FALLBACK_CONFIG.llm;
  const activeStrategy = config.strategy_mode || 'standard_6r';
  const isArdMode = activeStrategy === 'tableau_ard_lift_and_shift';
  const ardSettings = config.ard_settings || DEFAULT_FALLBACK_CONFIG.ard_settings;
  const activePlatform = config.source_platform || 'tableau';
  const activeWaveCount = config.wave_configuration?.wave_count || 4;

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-800">Scoring Strategy, Weights & AI Advisor</h1>
          <p className="text-xs text-slate-500 mt-1">
            Configure engagement strategies (Standard 6R vs. License-Cliff Lift & Shift), lookback parameters, SHA-256 deduplication, and AI reasoning.
          </p>
        </div>

        <button
          onClick={handleSaveAndRerun}
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/30 transition-all disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving & Scoring...' : 'Save & Recalculate'}</span>
        </button>
      </div>

      {backendOffline && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <div>
              <p className="text-xs font-bold text-amber-900">
                FastAPI Backend Offline (http://localhost:8000)
              </p>
              <p className="text-[11px] text-amber-700">
                Displaying default configuration parameters. Run <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">python server.py</code> or <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">run_accelerator.bat</code> to connect live.
              </p>
            </div>
          </div>
          <button
            onClick={loadConfigData}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-lg transition-all shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Retry Connection</span>
          </button>
        </div>
      )}

      {saveSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <p className="text-xs font-bold text-emerald-900">
            Configuration saved! The estate has been rescored with the updated parameters and AI advisor settings.
          </p>
        </div>
      )}

      {/* Engagement Strategy Mode Selector Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
            <Sliders className="w-4.5 h-4.5 text-blue-600" />
            <span>Rationalization Engagement Strategy Preset</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Choose between full multi-platform 6R modernization or the specialized Tableau ARD Lift-and-Shift model for license renewals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {STRATEGY_OPTIONS.map((strat) => {
            const isSelected = activeStrategy === strat.id;
            return (
              <button
                key={strat.id}
                type="button"
                onClick={() => handleStrategyModeChange(strat.id)}
                className={`text-left p-5 rounded-2xl border transition-all relative flex flex-col justify-between ${
                  isSelected 
                    ? 'border-blue-600 bg-blue-50/50 shadow-lg shadow-blue-500/10 ring-2 ring-blue-500/20' 
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50/60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-slate-900">{strat.name}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">
                      {strat.badge}
                    </span>
                  </div>
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    isSelected ? 'border-blue-600 bg-blue-600' : 'border-slate-300'
                  }`}>
                    {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">{strat.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tableau ARD Parameters (Shown when ARD is active or configurable) */}
      {isArdMode && (
        <div className="bg-gradient-to-br from-indigo-50/70 via-blue-50/40 to-slate-50 border border-indigo-200 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-indigo-100 pb-4">
            <div>
              <h2 className="text-base font-black text-indigo-950 flex items-center gap-2">
                <Sparkles className="w-4.5 h-4.5 text-indigo-600" />
                <span>Tableau ARD Scoring & Deduplication Parameters</span>
              </h2>
              <p className="text-xs text-indigo-700/80 mt-0.5">
                400-pt Criticality threshold, dynamic lookback window, SHA-256 fingerprinting, and wave effort limits.
              </p>
            </div>
            <span className="text-xs font-black px-3.5 py-1.5 rounded-full bg-indigo-600 text-white shadow-sm">
              Lift & Shift Mode Active
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Usage Lookback Window */}
            <div className="p-4 rounded-xl bg-white border border-indigo-100 shadow-sm space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-slate-800">
                <span>Usage Lookback Window</span>
                <span className="text-indigo-600 font-mono font-black">{ardSettings.usage_lookback_days ?? 180} Days</span>
              </div>
              <input
                type="range"
                min="30"
                max="365"
                step="15"
                value={ardSettings.usage_lookback_days ?? 180}
                onChange={(e) => handleArdSettingChange('usage_lookback_days', parseInt(e.target.value))}
                className="w-full accent-indigo-600"
              />
              <p className="text-[10px] text-slate-400">Time window evaluating distinct viewers, sessions, and access recency.</p>
            </div>

            {/* Criticality Migrate Cutoff */}
            <div className="p-4 rounded-xl bg-white border border-indigo-100 shadow-sm space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-slate-800">
                <span>Criticality Cutoff (Migrate)</span>
                <span className="text-indigo-600 font-mono font-black">≥ {ardSettings.criticality_threshold ?? 250} / 400 pts</span>
              </div>
              <input
                type="range"
                min="100"
                max="350"
                step="10"
                value={ardSettings.criticality_threshold ?? 250}
                onChange={(e) => handleArdSettingChange('criticality_threshold', parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
              <p className="text-[10px] text-slate-400">Assets scoring below this threshold are marked for Decommission / Retire.</p>
            </div>

            {/* Low Complexity Limit */}
            <div className="p-4 rounded-xl bg-white border border-indigo-100 shadow-sm space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-slate-800">
                <span>Wave 1 Low Complexity Ceiling</span>
                <span className="text-emerald-600 font-mono font-black">≤ {ardSettings.complexity_low_limit ?? 400} / 900 pts</span>
              </div>
              <input
                type="range"
                min="200"
                max="500"
                step="25"
                value={ardSettings.complexity_low_limit ?? 400}
                onChange={(e) => handleArdSettingChange('complexity_low_limit', parseFloat(e.target.value))}
                className="w-full accent-emerald-600"
              />
              <p className="text-[10px] text-slate-400">Workbooks with score &le; {ardSettings.complexity_low_limit ?? 400} qualify for Wave 1 Fast-Track.</p>
            </div>
          </div>
        </div>
      )}

      {/* Source Platform Selector Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
            <Layers className="w-4.5 h-4.5 text-blue-600" />
            <span>Source BI Platform Profile</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Select the source BI ecosystem to configure platform-tailored telemetry headers, downloadable CSV templates, and tool-specific heuristics.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {PLATFORM_OPTIONS.map((plat) => {
            const isSelected = activePlatform === plat.id;
            return (
              <button
                key={plat.id}
                type="button"
                onClick={() => handlePlatformChange(plat.id)}
                className={`text-left p-4 rounded-xl border transition-all relative flex flex-col justify-between ${
                  isSelected 
                    ? 'border-blue-600 bg-blue-50/50 shadow-md shadow-blue-500/10 ring-2 ring-blue-500/20' 
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50/60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-black text-slate-900">{plat.name}</span>
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    isSelected ? 'border-blue-600 bg-blue-600' : 'border-slate-300'
                  }`}>
                    {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                  </div>
                </div>
                <p className="text-[11px] text-slate-500">{plat.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Wave Migration Sequencing Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
              <GitMerge className="w-4.5 h-4.5 text-indigo-600" />
              <span>Wave Migration Sequencing & Sizing</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Configure the number of phased execution waves (2 to 6 Waves) for dynamic portfolio partitioning.
            </p>
          </div>
          <span className="text-xs font-black px-3.5 py-1.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
            Active: {activeWaveCount} Phased Waves
          </span>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            {[2, 3, 4, 5, 6].map((num) => {
              const isSelected = activeWaveCount === num;
              return (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleWaveCountChange(num)}
                  className={`px-4 py-2 text-xs font-bold rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {num} Waves Strategy
                </button>
              );
            })}
          </div>

          {/* Dynamic Preview of the selected Wave breakdown */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
              Execution Wave Allocation Preview ({activeWaveCount} Stages):
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {activeWaveCount === 2 && (
                <>
                  <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 font-medium">
                    <strong>Wave 1 (Score ≥ 60):</strong> Fast-Track Migrate & Modernize
                  </div>
                  <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-[11px] text-rose-900 font-medium">
                    <strong>Wave 2 (Score &lt; 60):</strong> Redesign, Complex & Retire
                  </div>
                </>
              )}
              {activeWaveCount === 3 && (
                <>
                  <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 font-medium">
                    <strong>Wave 1 (Score ≥ 75):</strong> Fast-Track Direct Migrate
                  </div>
                  <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900 font-medium">
                    <strong>Wave 2 (40 ≤ Score &lt; 75):</strong> Optimize & Redesign
                  </div>
                  <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-[11px] text-rose-900 font-medium">
                    <strong>Wave 3 (Score &lt; 40):</strong> Retire & Decommission
                  </div>
                </>
              )}
              {activeWaveCount === 4 && (
                <>
                  <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 font-medium">
                    <strong>Wave 1 (Score ≥ 80):</strong> Migrate As-Is (Automated)
                  </div>
                  <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg text-[11px] text-blue-900 font-medium">
                    <strong>Wave 2 (60 ≤ Score &lt; 80):</strong> Optimize & Migrate
                  </div>
                  <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900 font-medium">
                    <strong>Wave 3 (40 ≤ Score &lt; 60):</strong> Rebuild Native
                  </div>
                  <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-[11px] text-rose-900 font-medium">
                    <strong>Wave 4 (Score &lt; 40):</strong> Retire & Archive
                  </div>
                </>
              )}
              {activeWaveCount === 5 && (
                <>
                  <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 font-medium">
                    <strong>Wave 1 (≥ 85):</strong> Direct Fast-Track
                  </div>
                  <div className="p-2 bg-teal-50 border border-teal-200 rounded-lg text-[11px] text-teal-900 font-medium">
                    <strong>Wave 2 (70-84):</strong> Standard Migration
                  </div>
                  <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg text-[11px] text-blue-900 font-medium">
                    <strong>Wave 3 (50-69):</strong> Optimize & Modernize
                  </div>
                  <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900 font-medium">
                    <strong>Wave 4 (35-49):</strong> Re-architect Native
                  </div>
                  <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-[11px] text-rose-900 font-medium">
                    <strong>Wave 5 (&lt; 35):</strong> Retire & Decommission
                  </div>
                </>
              )}
              {activeWaveCount === 6 && (
                <>
                  <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-900 font-medium">
                    <strong>Wave 1 (≥ 85):</strong> Fast-Track Direct
                  </div>
                  <div className="p-2 bg-teal-50 border border-teal-200 rounded-lg text-[11px] text-teal-900 font-medium">
                    <strong>Wave 2 (75-84):</strong> Minimal Refactor
                  </div>
                  <div className="p-2 bg-cyan-50 border border-cyan-200 rounded-lg text-[11px] text-cyan-900 font-medium">
                    <strong>Wave 3 (60-74):</strong> Standard Optimization
                  </div>
                  <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg text-[11px] text-blue-900 font-medium">
                    <strong>Wave 4 (45-59):</strong> Semantic Redesign
                  </div>
                  <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900 font-medium">
                    <strong>Wave 5 (30-44):</strong> Deep Re-architecture
                  </div>
                  <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-[11px] text-rose-900 font-medium">
                    <strong>Wave 6 (&lt; 30):</strong> Retire & Decommission
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Weights Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-600" />
              <span>Dimension Scoring Weights</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Must sum to exactly 100% (1.0) for auditable scoring</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleNormalizeWeights}
              type="button"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all border border-slate-200"
              title="Scale current weights proportionally so they sum to 100%"
            >
              <Wand2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Auto-Normalize</span>
            </button>
            <button
              onClick={handleResetWeights}
              type="button"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all border border-slate-200"
              title="Reset weights to enterprise recommended baseline (25/20/20/15/10/10)"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
              <span>Reset Recommended</span>
            </button>
            <span className={`text-xs font-black px-3.5 py-1.5 rounded-full ${
              isWeightBalanced ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200 animate-pulse'
            }`}>
              Total: {(totalWeight * 100).toFixed(0)}% {isWeightBalanced ? '✓' : '(Imbalanced)'}
            </span>
          </div>
        </div>

        {!isWeightBalanced && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between gap-3 text-xs text-rose-800">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
              <span>
                <strong>Weight Imbalance Detected:</strong> Scoring weights sum to <strong>{(totalWeight * 100).toFixed(0)}%</strong>. Click <strong>Auto-Normalize</strong> to scale them automatically to 100%.
              </span>
            </div>
            <button
              onClick={handleNormalizeWeights}
              className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg transition-all shrink-0 text-[11px]"
            >
              Normalize to 100%
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(config.weights || {}).map(([key, val]: [string, any]) => {
            const formattedName = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            return (
              <div key={key} className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex justify-between items-center text-xs font-bold text-slate-800">
                  <span>{formattedName}</span>
                  <span className="text-blue-600 font-mono">{(val * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={val}
                  onChange={(e) => handleWeightChange(key, parseFloat(e.target.value))}
                  className="w-full accent-blue-600"
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* LLM Advisor Configuration Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
              <BrainCircuit className="w-4.5 h-4.5 text-indigo-600" />
              <span>AI Rationalization Advisor LLM Configuration</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Connect a generative AI model to enable intelligent, contextual migration analysis grounded in your telemetry.
            </p>
          </div>
          <span className={`text-xs font-black px-3 py-1 rounded-full ${
            currentLlm.api_key || currentLlm.provider === 'ollama' 
              ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' 
              : 'bg-slate-100 text-slate-600 border border-slate-200'
          }`}>
            {currentLlm.api_key || currentLlm.provider === 'ollama' ? '⚡ LLM Reasoning Active' : 'Deterministic Mode (No Key)'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Provider */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">LLM Provider</label>
            <select
              value={currentLlm.provider || 'openai'}
              onChange={(e) => handleLlmChange('provider', e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 font-medium"
            >
              <option value="openai">OpenAI (GPT-4o, GPT-4o-mini)</option>
              <option value="azure_openai">Azure OpenAI Service</option>
              <option value="gemini">Google Gemini (Gemini 1.5 Pro, Flash)</option>
              <option value="anthropic">Anthropic Claude (Claude 3.5 Sonnet)</option>
              <option value="ollama">Ollama (Local / Private On-Prem)</option>
              <option value="custom">Custom / OpenAI-Compatible Endpoint</option>
            </select>
          </div>

          {/* Model Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Model Deployment / ID</label>
            <input
              type="text"
              placeholder="e.g. gpt-4o-mini, gemini-1.5-pro, llama3"
              value={currentLlm.model || ''}
              onChange={(e) => handleLlmChange('model', e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          {/* API Key */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">API Key / Token</label>
            <div className="relative">
              <input
                type={showApiKey ? "text" : "password"}
                placeholder={currentLlm.provider === 'ollama' ? "Not required for local Ollama" : "sk-... / AIzaSy..."}
                value={currentLlm.api_key || ''}
                onChange={(e) => handleLlmChange('api_key', e.target.value)}
                className="w-full text-xs px-3 py-2 pr-10 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 font-medium font-mono"
              />
              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
              >
                {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-slate-500" />}
              </button>
            </div>
          </div>

          {/* Endpoint / Base URL */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Custom Base URL / Endpoint (Optional)</label>
            <input
              type="text"
              placeholder={
                currentLlm.provider === 'azure_openai' 
                  ? "https://<resource>.openai.azure.com" 
                  : currentLlm.provider === 'ollama' 
                  ? "http://localhost:11434" 
                  : "https://api.openai.com/v1"
              }
              value={currentLlm.endpoint || ''}
              onChange={(e) => handleLlmChange('endpoint', e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 font-medium font-mono text-[11px]"
            />
          </div>

          {/* Temperature */}
          <div className="space-y-1.5 sm:col-span-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-700">
              <span>Creativity / Temperature</span>
              <span className="text-indigo-600 font-mono">{currentLlm.temperature ?? 0.2}</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={currentLlm.temperature ?? 0.2}
              onChange={(e) => handleLlmChange('temperature', parseFloat(e.target.value))}
              className="w-full accent-indigo-600"
            />
            <p className="text-[10px] text-slate-400">Lower values (0.0–0.3) provide analytical, deterministic migration guidance.</p>
          </div>

          {/* System Prompt Persona */}
          <div className="space-y-1.5 sm:col-span-2">
            <label className="text-xs font-bold text-slate-700">Advisor Persona / System Instructions</label>
            <textarea
              rows={3}
              value={currentLlm.system_prompt || ''}
              onChange={(e) => handleLlmChange('system_prompt', e.target.value)}
              className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 font-medium leading-relaxed resize-y"
              placeholder="System prompt guiding the AI advisor behavior..."
            />
          </div>
        </div>
      </div>

      {/* Thresholds Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <h2 className="text-base font-black text-slate-900">Heuristic Thresholds</h2>
          <p className="text-xs text-slate-500">Configure cutoff values for staleness, complexity, and performance deductions</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Stale Asset Threshold (Days)</label>
            <input
              type="number"
              value={config.thresholds?.stale_dataset_days ?? 90}
              onChange={(e) => handleThresholdChange('stale_dataset_days', parseInt(e.target.value) || 0)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-medium"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">High MAU Limit (Adoption Score 100)</label>
            <input
              type="number"
              value={config.thresholds?.usage_high_mau_limit ?? 200}
              onChange={(e) => handleThresholdChange('usage_high_mau_limit', parseInt(e.target.value) || 0)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-medium"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Technical Quality Column / Field Limit</label>
            <input
              type="number"
              value={config.thresholds?.tq_column_limit ?? 100}
              onChange={(e) => handleThresholdChange('tq_column_limit', parseInt(e.target.value) || 0)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-medium"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Large Model / Extract Size (MB Threshold)</label>
            <input
              type="number"
              value={config.thresholds?.perf_large_dataset_size_mb ?? 1000}
              onChange={(e) => handleThresholdChange('perf_large_dataset_size_mb', parseInt(e.target.value) || 0)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-medium"
            />
          </div>
        </div>
      </div>
    </div>
  );
}


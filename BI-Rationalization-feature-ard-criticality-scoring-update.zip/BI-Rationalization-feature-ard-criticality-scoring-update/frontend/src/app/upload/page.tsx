"use client";

import React, { useState, useEffect } from 'react';
import { 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Download,
  Database,
  Layers,
  Sparkles,
  AlertTriangle,
  FileSpreadsheet,
  Info,
  ShieldCheck,
  ShieldAlert,
  ArrowDownToLine,
  X
} from 'lucide-react';
import { 
  uploadDimensionCsv, 
  triggerScoring, 
  fetchConfig, 
  fetchTemplateSchema, 
  getTemplateDownloadUrl 
} from '@/lib/api';
import { getPlatformProfile, PlatformProfile } from '@/lib/platformProfiles';

export default function UploadDimensionsPage() {
  const [platform, setPlatform] = useState<string>('powerbi');
  const [profile, setProfile] = useState<PlatformProfile>(getPlatformProfile('powerbi'));
  const [schemaInfo, setSchemaInfo] = useState<any | null>(null);
  const [uploading, setUploading] = useState<string | null>(null);
  const [uploadStatus, setUploadStatus] = useState<Record<string, string>>({});
  const [validationError, setValidationError] = useState<any | null>(null);
  const [validationSuccess, setValidationSuccess] = useState<any | null>(null);
  const [scoringRunning, setScoringRunning] = useState(false);
  const [scoringResult, setScoringResult] = useState<any | null>(null);

  useEffect(() => {
    async function loadConfigAndSchema() {
      try {
        const cfg = await fetchConfig();
        const plat = cfg.source_platform || 'powerbi';
        setPlatform(plat);
        setProfile(getPlatformProfile(plat));
        const schema = await fetchTemplateSchema(plat);
        setSchemaInfo(schema?.schema);
      } catch (err) {
        console.warn("Using default template info:", err);
      }
    }
    loadConfigAndSchema();
  }, []);

  const handlePlatformSwitch = async (newPlatform: string) => {
    setPlatform(newPlatform);
    setProfile(getPlatformProfile(newPlatform));
    try {
      const schema = await fetchTemplateSchema(newPlatform);
      setSchemaInfo(schema?.schema);
    } catch (err) {
      console.warn("Could not fetch schema for platform:", newPlatform);
    }
  };

  const handleFileUpload = async (dimensionId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];

    setUploading(dimensionId);
    setValidationError(null);
    setValidationSuccess(null);

    try {
      const result = await uploadDimensionCsv(dimensionId, file);
      setUploadStatus(prev => ({ ...prev, [dimensionId]: `Uploaded ${file.name} successfully!` }));
      setValidationSuccess({
        filename: file.name,
        message: result.message || `File ${file.name} validated and ingested successfully.`,
        stats: result.stats
      });
    } catch (err: any) {
      if (err.validation?.error === 'SCHEMA_VALIDATION_FAILED' || err.status === 422) {
        setValidationError(err.validation || {
          message: err.message,
          missing_mandatory: ['table_count'],
          stats: { mandatory_descriptions: { table_count: 'Required for technical quality evaluation' } }
        });
      } else {
        setUploadStatus(prev => ({ ...prev, [dimensionId]: `Error: ${err.message}` }));
      }
    } finally {
      setUploading(null);
      // Reset input value
      e.target.value = '';
    }
  };

  const handleRunPipeline = async () => {
    setScoringRunning(true);
    setScoringResult(null);
    try {
      const result = await triggerScoring();
      setScoringResult(result);
    } catch (err: any) {
      alert(`Scoring execution failed: ${err.message}`);
    } finally {
      setScoringRunning(false);
    }
  };

  const dimensionCards = [
    {
      id: 'dim1',
      title: 'Dimension 1: Business Value',
      filename: 'dim1_business_value.csv',
      description: profile.dimensions.dim1,
      weight: '25% Weight'
    },
    {
      id: 'dim2',
      title: 'Dimension 2: Usage & Adoption',
      filename: 'dim2_usage_adoption.csv',
      description: profile.dimensions.dim2,
      weight: '20% Weight'
    },
    {
      id: 'dim3',
      title: 'Dimension 3: Technical Quality',
      filename: 'dim3_technical_quality.csv',
      description: profile.dimensions.dim3,
      weight: '20% Weight'
    },
    {
      id: 'dim4',
      title: 'Dimension 4: Performance',
      filename: 'dim4_performance.csv',
      description: profile.dimensions.dim4,
      weight: '15% Weight'
    },
    {
      id: 'dim5',
      title: 'Dimension 5: Governance',
      filename: 'dim5_governance.csv',
      description: profile.dimensions.dim5,
      weight: '10% Weight'
    },
    {
      id: 'dim6',
      title: 'Dimension 6: Complexity',
      filename: 'dim6_complexity.csv',
      description: profile.dimensions.dim6,
      weight: '10% Weight'
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-800">Telemetry Ingestion & Universal Templates</h1>
          <p className="text-xs text-slate-500 mt-1">
            Download {profile.name} specific telemetry templates and upload estate inventory for automated 6-dimension rationalization.
          </p>
        </div>

        <button
          onClick={handleRunPipeline}
          disabled={scoringRunning}
          className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/30 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${scoringRunning ? 'animate-spin' : ''}`} />
          <span>{scoringRunning ? 'Running Scoring...' : 'Run Scoring Engine'}</span>
        </button>
      </div>

      {/* Validation Error Alert Modal / Banner */}
      {validationError && (
        <div className="p-5 bg-rose-50 border-2 border-rose-300 rounded-2xl space-y-4 animate-fade-in shadow-sm">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <ShieldAlert className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-black text-rose-950">
                  Schema Validation Error: Mandatory Parameter(s) Missing
                </h3>
                <p className="text-xs text-rose-800 mt-0.5">
                  The uploaded CSV cannot be scored because one or more mandatory analytical parameters are missing.
                </p>
              </div>
            </div>
            <button
              onClick={() => setValidationError(null)}
              className="text-rose-400 hover:text-rose-700 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-bold text-rose-900">Missing Mandatory Columns:</p>
            <div className="flex flex-wrap gap-2">
              {(validationError.missing_mandatory || []).map((col: string) => (
                <span key={col} className="px-2.5 py-1 bg-rose-200 text-rose-900 rounded-lg text-xs font-mono font-bold">
                  ✕ {col}
                </span>
              ))}
            </div>
            {validationError.stats?.mandatory_descriptions && (
              <div className="mt-3 p-3 bg-white/80 rounded-xl border border-rose-200 text-xs text-rose-900 space-y-1">
                <p className="font-bold">Why are these fields required?</p>
                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-rose-800">
                  {Object.entries(validationError.stats.mandatory_descriptions).map(([c, desc]: [string, any]) => (
                    <li key={c}><strong>{c}:</strong> {desc}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="pt-2 border-t border-rose-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-rose-900">
            <span>
              💡 <strong>Resolution:</strong> Download the pre-formatted <strong>{schemaInfo?.display_name || platform.toUpperCase()}</strong> template below, copy your dataset metrics into the columns, and re-upload.
            </span>
            <a
              href={getTemplateDownloadUrl(platform, true)}
              download
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg transition-all shrink-0 text-xs flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Clean Template</span>
            </a>
          </div>
        </div>
      )}

      {/* Validation Success Notification */}
      {validationSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between animate-fade-in shadow-xs">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <p className="text-xs font-bold text-emerald-950">
                {validationSuccess.filename} Validated Successfully!
              </p>
              <p className="text-[11px] text-emerald-800">
                {validationSuccess.message} ({validationSuccess.stats?.total_rows || 0} valid records detected).
              </p>
            </div>
          </div>
          <button onClick={() => setValidationSuccess(null)} className="text-emerald-500 hover:text-emerald-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Scoring Result Notification */}
      {scoringResult && (
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-blue-600" />
            <div>
              <p className="text-xs font-bold text-blue-900">
                Scoring Pipeline Completed Successfully!
              </p>
              <p className="text-[11px] text-blue-700">
                Processed {scoringResult.total_datasets} {profile.assetTermPlural.toLowerCase()} across {scoringResult.total_workspaces} {profile.containerTermPlural.toLowerCase()}. Average Readiness: {scoringResult.average_readiness_score}/100.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Universal Template Downloader & Unified Upload Card */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-3xl p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="max-w-2xl space-y-3">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-white/10 text-cyan-300 rounded-full text-[11px] font-mono uppercase tracking-wider font-bold border border-white/10">
                Active Source: {schemaInfo?.display_name || profile.name}
              </span>
              <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 rounded-full text-[11px] font-bold border border-emerald-500/30">
                {schemaInfo?.mandatory_columns?.length || 6} Mandatory Fields
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              Download Ingestion Template & Upload Estate
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Use our standardized telemetry schema tailored for <strong>{schemaInfo?.display_name || profile.name}</strong>. Upload a single unified {profile.assetTerm.toLowerCase()} inventory to score the entire estate in one pass.
            </p>

            {/* Platform Quick Switch */}
            <div className="flex items-center gap-2 pt-2 flex-wrap text-xs">
              <span className="text-slate-400 font-bold text-[11px]">Switch Profile:</span>
              {['powerbi', 'tableau', 'qlik', 'looker', 'microstrategy', 'universal'].map((p) => (
                <button
                  key={p}
                  onClick={() => handlePlatformSwitch(p)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                    platform === p 
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30' 
                      : 'bg-white/10 hover:bg-white/20 text-white border border-white/10'
                  }`}
                >
                  {p.charAt(0).toUpperCase() + p.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0 w-full sm:w-auto">
            <a
              href={getTemplateDownloadUrl(platform, true)}
              download
              className="flex items-center justify-center gap-2 px-5 py-3 bg-white hover:bg-slate-100 text-slate-900 text-xs font-black rounded-2xl shadow-lg transition-all"
            >
              <ArrowDownToLine className="w-4 h-4 text-blue-600" />
              <span>Download Sample Template (.CSV)</span>
            </a>

            <a
              href={getTemplateDownloadUrl(platform, false)}
              download
              className="flex items-center justify-center gap-2 px-5 py-2.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs font-bold rounded-2xl transition-all"
            >
              <FileSpreadsheet className="w-4 h-4 text-slate-300" />
              <span>Download Blank Schema Template</span>
            </a>

            {/* Unified Upload Button */}
            <label className="flex items-center justify-center gap-2 px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-2xl shadow-lg cursor-pointer transition-all">
              <UploadCloud className="w-4 h-4 text-slate-950" />
              <span>Upload Unified Inventory (.CSV)</span>
              <input
                type="file"
                accept=".csv"
                className="hidden"
                onChange={(e) => handleFileUpload('unified', e)}
              />
            </label>
          </div>
        </div>
      </div>

      {/* 6 Dimension Ingestion Cards Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-black text-slate-800">Or Ingest Individual Dimension Files</h2>
            <p className="text-xs text-slate-500">Upload segmented telemetry CSVs for fine-grained estate profiling</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dimensionCards.map((card) => {
            const isUploading = uploading === card.id;
            const statusMsg = uploadStatus[card.id];

            return (
              <div 
                key={card.id} 
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg">
                      {card.weight}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {card.filename}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">{card.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">{card.description}</p>
                </div>

                <div className="pt-2 border-t border-slate-100 space-y-2">
                  {statusMsg && (
                    <p className={`text-[11px] font-semibold ${statusMsg.includes('Error') ? 'text-rose-600' : 'text-emerald-600'}`}>
                      {statusMsg}
                    </p>
                  )}

                  <label 
                    className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
                      isUploading 
                        ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                        : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200'
                    }`}
                  >
                    {isUploading ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-blue-600" />
                    ) : (
                      <UploadCloud className="w-4 h-4 text-blue-600" />
                    )}
                    <span>{isUploading ? 'Validating...' : `Upload ${card.filename}`}</span>
                    <input
                      type="file"
                      accept=".csv"
                      disabled={isUploading}
                      className="hidden"
                      onChange={(e) => handleFileUpload(card.id, e)}
                    />
                  </label>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

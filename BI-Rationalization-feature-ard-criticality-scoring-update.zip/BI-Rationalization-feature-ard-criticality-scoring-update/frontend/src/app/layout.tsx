"use client";

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  LayoutDashboard, 
  Layers, 
  GitMerge, 
  UploadCloud, 
  Sliders, 
  BrainCircuit, 
  Sparkles, 
  ChevronLeft, 
  ChevronRight,
  Send,
  Bot,
  User,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  X
} from 'lucide-react';
import { askAdvisor, triggerScoring, fetchConfig, updateConfig } from '@/lib/api';
import { getPlatformProfile, PlatformProfile } from '@/lib/platformProfiles';
import './globals.css';

const CapgeminiLogo = () => (
  <svg 
    viewBox="234 0 51 65" 
    className="w-9 h-9 shrink-0" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M283.248 21.3699C281.91 16.9202 279.199 13.0201 275.599 9.71371C271.711 6.16082 267.091 3.46857 262.249 1.43706C261.86 1.27373 261.468 1.11429 261.074 0.958885C261.074 0.958589 261.073 0.958335 261.072 0.958038C255.111 8.10214 234.465 13.4338 234.465 28.4057C234.465 34.2622 238.166 39.7342 243.596 41.9309C246.972 43.075 250.609 42.8622 253.851 41.3858C256.984 39.959 259.369 37.4471 261.291 34.6462C263.319 31.6896 264.863 28.4428 266.791 25.4247C268.581 22.6206 270.87 19.8218 274.267 19.0314C277.345 18.3149 280.994 19.115 283.248 21.3699ZM283.38 24.4072C282.012 21.672 279.135 20.4977 276.184 20.6368C273.335 20.7711 271.257 22.5848 269.671 24.8144C267.877 27.3375 266.617 30.2172 265.152 32.9339C263.74 35.552 262.221 38.1172 260.188 40.3091C257.934 42.7396 255.101 44.5714 251.921 45.5336C253.392 46.5934 255.431 46.831 257.189 46.8987C259.176 46.9753 261.185 46.7936 263.141 46.4434C266.712 45.8037 270.568 44.5508 273.209 41.9437C269.088 41.997 265.766 39.2264 265.47 35.0494C268.121 38.2592 272.131 39.4955 276.143 38.3532C279.659 37.3524 282.483 34.5727 283.622 31.1099C284.345 28.9115 284.416 26.5221 283.38 24.4072Z" fill="#0058AB" />
  </svg>
);

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [scoringRunning, setScoringRunning] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [profile, setProfile] = useState<PlatformProfile>(getPlatformProfile('tableau'));
  const [chatMessages, setChatMessages] = useState<any[]>([
    {
      role: 'agent',
      text: 'Hello! I am your AI Rationalization Advisor. Ask me anything about migration waves, portfolio readiness, golden models, or asset retirement recommendations.'
    }
  ]);

  useEffect(() => {
    async function initProfile() {
      try {
        const cfg = await fetchConfig();
        const plat = cfg.source_platform || 'tableau';
        const p = getPlatformProfile(plat);
        setProfile(p);
        setChatMessages([
          {
            role: 'agent',
            text: `Hello! I am your AI Rationalization Advisor for ${p.name}. Ask me anything about migration waves, portfolio readiness, certified ${p.assetTermPlural.toLowerCase()}, or retirement recommendations.`
          }
        ]);
      } catch (e) {
        // use default profile
      }
    }
    initProfile();
  }, []);

  const navItems = [
    { label: 'Executive Overview', href: '/', icon: LayoutDashboard },
    { label: 'Asset Rationalization', href: '/rationalization', icon: Layers },
    { label: 'Wave Planner', href: '/planner', icon: GitMerge },
    { label: 'Dimension Ingest', href: '/upload', icon: UploadCloud },
    { label: 'Weights & Config', href: '/configuration', icon: Sliders },
  ];

  const handleRunScoring = async () => {
    setScoringRunning(true);
    try {
      await triggerScoring();
      window.location.reload();
    } catch (err: any) {
      alert(`Scoring execution failed: ${err.message}`);
    } finally {
      setScoringRunning(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;
    const userText = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: userText }]);
    setChatLoading(true);

    try {
      const res = await askAdvisor(userText, chatMessages);
      setChatMessages(prev => [...prev, { role: 'agent', text: res.reply, source: res.source, model: res.model }]);
    } catch (err: any) {
      setChatMessages(prev => [...prev, { role: 'agent', text: `Error: ${err.message}` }]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <html lang="en">
      <body className="flex h-screen overflow-hidden bg-slate-100 text-slate-800">
        {/* Sidebar */}
        <aside 
          className={`glass-sidebar text-white flex flex-col justify-between transition-all duration-300 z-30 shrink-0 select-none ${
            collapsed ? 'w-20' : 'w-72'
          }`}
        >
          <div>
            {/* Logo and App Title */}
            <div className="h-20 flex items-center px-5 gap-3 border-b border-white/10">
              <CapgeminiLogo />
              {!collapsed && (
                <div className="flex flex-col">
                  <span className="font-black text-lg tracking-tight leading-none text-white">
                    Rationalization
                  </span>
                  <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider mt-1">
                    Migration Accelerator
                  </span>
                </div>
              )}
            </div>

            {/* Navigation List */}
            <nav className="p-4 space-y-1.5">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-3.5 px-3.5 py-3 rounded-xl text-sm font-semibold transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                        : 'text-slate-300 hover:bg-white/10 hover:text-white'
                    }`}
                    title={collapsed ? item.label : undefined}
                  >
                    <Icon className="w-5 h-5 shrink-0" />
                    {!collapsed && <span>{item.label}</span>}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Bottom Actions */}
          <div className="p-4 border-t border-white/10 space-y-3">
            {/* Quick Scoring Trigger */}
            <button
              onClick={handleRunScoring}
              disabled={scoringRunning}
              className={`w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                scoringRunning 
                  ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-700/20'
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${scoringRunning ? 'animate-spin' : ''}`} />
              {!collapsed && <span>{scoringRunning ? 'Scoring...' : 'Recalculate Scores'}</span>}
            </button>

            {/* Collapse / Expand Toggle */}
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="w-full flex items-center justify-center py-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-all text-xs"
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <div className="flex items-center gap-2"><ChevronLeft className="w-4 h-4" /><span>Collapse Menu</span></div>}
            </button>
          </div>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Top Bar */}
          <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0 z-20">
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Standalone Accelerator v2.0
              </span>
              <span className="text-xs text-slate-400">|</span>
              <span className="text-xs font-semibold text-slate-600">
                6-Dimension {profile.shortName} Rationalization Engine
              </span>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => setChatOpen(!chatOpen)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 shadow-sm transition-all"
              >
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>AI Rationalization Advisor</span>
              </button>
            </div>
          </header>

          {/* Page Body */}
          <main className="flex-1 overflow-y-auto p-8 relative">
            {children}
          </main>
        </div>

        {/* AI Advisor Chat Drawer */}
        {chatOpen && (
          <aside className="w-96 bg-white border-l border-slate-200 shadow-2xl flex flex-col z-40 animate-fade-in shrink-0">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">Rationalization Advisor</h3>
                  <p className="text-[11px] text-slate-500">Autonomous Portfolio Analysis</p>
                </div>
              </div>
              <button 
                onClick={() => setChatOpen(false)}
                className="p-1 hover:bg-slate-200 rounded-lg text-slate-500 transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatMessages.map((msg, i) => (
                <div 
                  key={i} 
                  className={`flex gap-3 text-xs ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.role === 'agent' && (
                    <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                      <Bot className="w-3.5 h-3.5" />
                    </div>
                  )}
                  <div 
                    className={`p-3 rounded-2xl max-w-[80%] leading-relaxed ${
                      msg.role === 'user' 
                        ? 'bg-blue-600 text-white rounded-tr-none' 
                        : 'bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200 whitespace-pre-line'
                    }`}
                  >
                    {msg.text}
                  </div>
                  {msg.role === 'user' && (
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
                      <User className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>
              ))}
              {chatLoading && (
                <div className="flex gap-2 items-center text-xs text-slate-400">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.2s]"></div>
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.4s]"></div>
                  <span>Analyzing estate...</span>
                </div>
              )}
            </div>

            <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-200 bg-white flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask about waves, golden models, retirements..."
                className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                disabled={chatLoading || !chatInput.trim()}
                className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-all disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </aside>
        )}
      </body>
    </html>
  );
}

"use client";

import React, { useEffect, useState } from 'react';
import { 
  fetchMigrationReadiness, 
  fetchMigrationWorkspaces,
  fetchConfig,
  getExcelExportUrl
} from '@/lib/api';
import { getPlatformProfile, PlatformProfile } from '@/lib/platformProfiles';
import { 
  Layers, 
  Sparkles, 
  Trash2, 
  Zap, 
  Search, 
  Filter, 
  ChevronDown, 
  ChevronRight, 
  ShieldCheck, 
  Building2, 
  FolderOpen, 
  CheckCircle2, 
  AlertTriangle, 
  Flame, 
  Info,
  X,
  ExternalLink,
  Crown,
  GitBranch,
  Copy,
  Users,
  Eye,
  Sliders,
  FileCode,
  FileSpreadsheet,
  Download
} from 'lucide-react';

interface ClusterModalState {
  hash: string;
  canvasHash?: string;
  type: string;
  title: string;
  suggestedRetainedAssetId?: string;
  canonicalMasterName?: string;
}

export default function AssetRationalizationPage() {
  const [datasets, setDatasets] = useState<any[]>([]);
  const [workspaces, setWorkspaces] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<PlatformProfile>(getPlatformProfile('tableau'));

  // Filters & State
  const [searchQuery, setSearchQuery] = useState('');
  const [outcomeFilter, setOutcomeFilter] = useState('All');
  const [waveFilter, setWaveFilter] = useState('All');
  const [domainFilter, setDomainFilter] = useState('All');
  const [expandedWorkspaces, setExpandedWorkspaces] = useState<Record<string, boolean>>({});
  const [onlyDirectLake, setOnlyDirectLake] = useState(false);
  const [onlyGolden, setOnlyGolden] = useState(false);

  // Slide-Over Cluster Drawer State
  const [selectedCluster, setSelectedCluster] = useState<ClusterModalState | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const [dsData, wsData, cfg] = await Promise.all([
          fetchMigrationReadiness(),
          fetchMigrationWorkspaces(),
          fetchConfig().catch(() => ({ source_platform: 'tableau' }))
        ]);
        setDatasets(dsData || []);
        setWorkspaces(wsData || []);
        if (cfg?.source_platform) {
          setProfile(getPlatformProfile(cfg.source_platform));
        }
      } catch (err) {
        console.error("Failed to load assets:", err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const toggleExpand = (wsName: string) => {
    setExpandedWorkspaces(prev => ({
      ...prev,
      [wsName]: !prev[wsName]
    }));
  };

  const domains = Array.from(new Set(datasets.map(d => d.BusinessDomain || 'General'))).filter(Boolean);

  // Dynamically compute unique outcomes/dispositions present in the active dataset
  const uniqueOutcomes = Array.from(
    new Set(
      datasets
        .map(d => d.ProposedDisposition || d.OutcomeDecision)
        .filter(Boolean)
    )
  ).sort() as string[];
  const outcomes = ['All', ...(uniqueOutcomes.length > 0 ? uniqueOutcomes : ['Select for migration', 'Retire candidate', 'Undecided'])];

  // Dynamically compute unique execution waves present in the active dataset
  const uniqueWaves = Array.from(
    new Set(
      datasets
        .map(d => d.ExecutionWave)
        .filter(Boolean)
    )
  ).sort() as string[];
  const waves = ['All', ...(uniqueWaves.length > 0 ? uniqueWaves : ['Wave 1: Fast-Track Migrate', 'Wave 2: Standard Migrate', 'Wave 3: Complex Migrate', 'Wave 4: Retire & Decommission', 'Unassigned'])];

  // Filtered dataset list
  const filteredDatasets = datasets.filter(d => {
    const matchesSearch = !searchQuery || 
      d.Artifact?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.Workspace?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.ProposedDisposition?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.ReviewStatus?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.OutcomeDecision?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.RecommendationReason?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesOutcome = outcomeFilter === 'All' || 
      d.ProposedDisposition?.toLowerCase() === outcomeFilter.toLowerCase() || 
      d.OutcomeDecision?.toLowerCase() === outcomeFilter.toLowerCase();
    const matchesWave = waveFilter === 'All' || d.ExecutionWave === waveFilter || d.ExecutionWave?.includes(waveFilter);
    const matchesDomain = domainFilter === 'All' || d.BusinessDomain === domainFilter;
    const matchesDL = !onlyDirectLake || d.DirectLakeCandidate === 'Yes';
    const matchesGolden = !onlyGolden || d.IsGoldenDataset === 'Yes';

    return matchesSearch && matchesOutcome && matchesWave && matchesDomain && matchesDL && matchesGolden;
  });

  // Group filtered datasets by workspace/container with unique site prefixing
  const workspaceGroups: Record<string, any[]> = {};
  filteredDatasets.forEach(d => {
    const wsName = d.Workspace || d.WorkspaceName || `Default ${profile.containerTerm}`;
    const ws = d.SiteName ? `${d.SiteName} / ${wsName}` : wsName;
    if (!workspaceGroups[ws]) workspaceGroups[ws] = [];
    workspaceGroups[ws].push(d);
  });

  // Assets belonging to currently selected cluster
  const clusterAssets = selectedCluster ? datasets.filter(d => {
    if (selectedCluster.type === 'EXACT_DUPLICATE_CONFIRMED' || selectedCluster.type === 'Potential structural duplicate') {
      if (d.DatasourceFingerprint && d.ReportCanvasHash && selectedCluster.hash && selectedCluster.canvasHash) {
        return d.DatasourceFingerprint === selectedCluster.hash && d.ReportCanvasHash === selectedCluster.canvasHash;
      }
      if (selectedCluster.suggestedRetainedAssetId && d.SuggestedRetainedAssetId) {
        return d.SuggestedRetainedAssetId === selectedCluster.suggestedRetainedAssetId;
      }
      return (d.CanonicalMaster && d.CanonicalMaster === selectedCluster.canonicalMasterName) ||
             (d.SuggestedRetainedAssetName && d.SuggestedRetainedAssetName === selectedCluster.canonicalMasterName) ||
             (d.Artifact === selectedCluster.canonicalMasterName);
    }
    if (selectedCluster.type === 'STRUCTURAL_CLONE_REVIEW' || selectedCluster.type === 'Potential structural clone (different data model)') {
      return d.ReportCanvasHash && d.ReportCanvasHash === selectedCluster.canvasHash;
    }
    return d.DatasourceFingerprint && d.DatasourceFingerprint === selectedCluster.hash;
  }) : [];

  const totalClusterUsers = clusterAssets.reduce((sum, a) => sum + (parseInt(a.DistinctUsers) || 0), 0);
  const totalClusterViews = clusterAssets.reduce((sum, a) => sum + (parseInt(a.ActivityViews) || 0), 0);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm font-semibold text-slate-500">Evaluating {profile.assetTerm} Decisions...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in max-w-7xl mx-auto relative">
      {/* Page Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-800">{profile.assetTerm} Rationalization & Decisions</h1>
          <p className="text-xs text-slate-500 mt-1">
            Deterministic 400-pt Criticality & 900-pt Complexity Scoring, Canonical Master Election & Cluster Inspection for {profile.name}.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <a
            href={getExcelExportUrl()}
            download="Rationalization_Assessment_Decisions.xlsx"
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all cursor-pointer hover:scale-[1.02]"
            title="Download full assessment results as formatted Excel workbook including all input columns, disposition decisions, and 6-dimension category scores"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export to Excel</span>
          </a>
          <span className="text-xs font-bold px-3 py-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-xl shadow-xs">
            Showing {filteredDatasets.length} of {datasets.length} {profile.assetTermPlural}
          </span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder={`Search ${profile.assetTerm.toLowerCase()} or ${profile.containerTerm.toLowerCase()}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Outcome Filter */}
          <div>
            <select
              value={outcomeFilter}
              onChange={(e) => setOutcomeFilter(e.target.value)}
              className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-medium"
            >
              {outcomes.map(o => <option key={o} value={o}>{o === 'All' ? 'All Outcomes / Dispositions' : o}</option>)}
            </select>
          </div>

          {/* Wave Filter */}
          <div>
            <select
              value={waveFilter}
              onChange={(e) => setWaveFilter(e.target.value)}
              className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-medium"
            >
              {waves.map(w => <option key={w} value={w}>{w === 'All' ? 'All Execution Waves' : w}</option>)}
            </select>
          </div>

          {/* Domain Filter */}
          <div>
            <select
              value={domainFilter}
              onChange={(e) => setDomainFilter(e.target.value)}
              className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-medium"
            >
              <option value="All">All Business Domains</option>
              {domains.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
        </div>

        {/* Quick Checkbox Toggles */}
        <div className="flex flex-wrap items-center gap-6 pt-2 border-t border-slate-100 text-xs font-semibold text-slate-600">
          <label className="flex items-center gap-2 cursor-pointer select-none hover:text-blue-600 transition-colors">
            <input
              type="checkbox"
              checked={onlyGolden}
              onChange={(e) => setOnlyGolden(e.target.checked)}
              className="rounded text-blue-600 focus:ring-0"
            />
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Show Only Golden / Certified Assets
            </span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer select-none hover:text-indigo-600 transition-colors">
            <input
              type="checkbox"
              checked={onlyDirectLake}
              onChange={(e) => setOnlyDirectLake(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-0"
            />
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-indigo-500" /> Show Only {profile.fastTrackLabel}
            </span>
          </label>
        </div>
      </div>

      {/* Asset Container Groups & Table */}
      <div className="space-y-4">
        {Object.entries(workspaceGroups).length === 0 ? (
          <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 shadow-sm">
            <Info className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p className="text-sm font-semibold">No {profile.assetTermPlural.toLowerCase()} found matching the selected filters.</p>
          </div>
        ) : (
          Object.entries(workspaceGroups).map(([wsName, wsDatasets]) => {
            const isExpanded = expandedWorkspaces[wsName] ?? true;
            const wsSummary = workspaces.find(w => w.WorkspaceName === wsName || w.Project === wsName);
            const isPruning = wsSummary?.PruningCandidate === 'Yes';
            const isOrphan = wsSummary?.Orphaned === 'Yes';

            return (
              <div key={wsName} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden transition-all">
                {/* Container Accordion Header */}
                <div 
                  onClick={() => toggleExpand(wsName)}
                  className="p-4 bg-slate-50/80 hover:bg-slate-100/80 cursor-pointer flex items-center justify-between border-b border-slate-200 select-none transition-all"
                >
                  <div className="flex items-center gap-3">
                    {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                    <FolderOpen className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-bold text-slate-800">{profile.containerTerm}: {wsName}</span>
                    <span className="text-xs px-2.5 py-0.5 bg-slate-200 text-slate-700 font-semibold rounded-full">
                      {wsDatasets.length} {profile.assetTermPlural}
                    </span>
                    {isPruning && (
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-rose-100 text-rose-700 border border-rose-200 rounded-full flex items-center gap-1">
                        <Trash2 className="w-3 h-3" /> Pruning Candidate
                      </span>
                    )}
                    {isOrphan && (
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 text-amber-700 border border-amber-200 rounded-full flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> Orphaned
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-4 text-xs font-semibold text-slate-500">
                    <span>Domain: <strong className="text-slate-700">{wsDatasets[0]?.BusinessDomain || 'General'}</strong></span>
                    <span>Site: <strong className="text-slate-700">{wsDatasets[0]?.SiteName || 'Default Site'}</strong></span>
                  </div>
                </div>

                {/* Asset Table within Container */}
                {isExpanded && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] border-b border-slate-200 tracking-wider">
                        <tr>
                          <th className="py-3 px-4">{profile.assetTerm} Name</th>
                          <th className="py-3 px-4 text-center">Readiness / Criticality</th>
                          <th className="py-3 px-4">Proposed Disposition</th>
                          <th className="py-3 px-4">Recommendation Rationale</th>
                          <th className="py-3 px-4">Execution Wave</th>
                          <th className="py-3 px-4 text-center">Score Breakdown</th>
                          <th className="py-3 px-4">Dataset Cluster</th>
                          <th className="py-3 px-4">Effort</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                        {wsDatasets.map((d, i) => {
                          const score = parseFloat(d.ReadinessScore) || 0;
                          const critScore = parseFloat(d.CriticalityScore) || 0;
                          const disposition = d.ProposedDisposition || d.OutcomeDecision || 'Select for migration';
                          const reviewStatus = d.ReviewStatus || (d.OutcomeDecision === 'Review Required' ? 'Business review required' : 'Ready');
                          const hasCluster = (parseInt(d.SharedDatasetCount) > 1) || 
                                             (d.SimilarityFlag && d.SimilarityFlag !== 'Unique' && !d.SimilarityFlag.includes('insufficient')) ||
                                             (d.DuplicateStatus && (d.DuplicateStatus.includes('Exact') || d.DuplicateStatus.includes('Canonical') || d.DuplicateStatus.includes('Clone') || d.DuplicateStatus.includes('Shared')));
                          
                          let dispBadge = 'bg-slate-100 text-slate-700 border-slate-200';
                          if (disposition === 'Select for migration' || disposition === 'Migrate As-Is') dispBadge = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                          else if (disposition === 'Retire candidate' || disposition === 'Retire Candidate' || disposition === 'Retire') dispBadge = 'bg-rose-50 text-rose-700 border-rose-200';
                          else if (disposition === 'Undecided') dispBadge = 'bg-slate-100 text-slate-600 border-slate-300';
                          else if (disposition === 'Optimize') dispBadge = 'bg-blue-50 text-blue-700 border-blue-200';
                          else if (disposition === 'Rebuild') dispBadge = 'bg-purple-50 text-purple-700 border-purple-200';

                          return (
                            <tr key={i} className="hover:bg-blue-50/40 transition-colors">
                              <td className="py-3 px-4">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-900">{d.Artifact}</span>
                                  {d.IsGoldenDataset === 'Yes' && (
                                    <span title="Golden Certified Asset" className="p-0.5 rounded bg-amber-100 text-amber-700 border border-amber-200">
                                      <Sparkles className="w-3.5 h-3.5" />
                                    </span>
                                  )}
                                  {d.DirectLakeCandidate === 'Yes' && (
                                    <span title={profile.fastTrackLabel} className="p-0.5 rounded bg-indigo-100 text-indigo-700 border border-indigo-200">
                                      <Zap className="w-3.5 h-3.5" />
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-slate-400 block mt-0.5">
                                  {d.DistinctUsers ? `${d.DistinctUsers} Users • ` : ''}{d.ActivityViews} Views • {d.BusinessDomain || 'General'}
                                </span>
                              </td>

                              <td className="py-3 px-4 text-center">
                                <div className="flex flex-col items-center">
                                  <span className={`inline-block px-2.5 py-0.5 rounded-lg text-xs font-black ${
                                    score >= 80 ? 'bg-emerald-100 text-emerald-800' :
                                    score >= 60 ? 'bg-blue-100 text-blue-800' :
                                    score >= 40 ? 'bg-amber-100 text-amber-800' :
                                    score > 0 ? 'bg-rose-100 text-rose-800' :
                                    'bg-slate-100 text-slate-600'
                                  }`}>
                                    {score > 0 ? score : '—'}
                                  </span>
                                  {critScore > 0 && (
                                    <span className="text-[9px] text-slate-400 font-mono font-bold mt-0.5" title="Criticality Score (out of 400)">
                                      {critScore}/400
                                    </span>
                                  )}
                                </div>
                              </td>

                              <td className="py-3 px-4">
                                <div className="flex flex-col gap-1 items-start">
                                  <span className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold ${dispBadge}`}>
                                    {disposition}
                                  </span>
                                  {reviewStatus !== 'Ready' && (
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                      reviewStatus === 'Insufficient evidence'
                                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                                        : 'bg-amber-50 text-amber-800 border-amber-300'
                                    }`}>
                                      {reviewStatus}
                                    </span>
                                  )}
                                  {d.SuggestedRetainedAssetName && d.SuggestedRetainedAssetName !== d.Artifact && (
                                    <span 
                                      className="text-[10px] text-slate-500 font-medium cursor-help hover:text-blue-600 underline decoration-dotted"
                                      title={`Suggested retained asset ID: ${d.SuggestedRetainedAssetId || 'N/A'}`}
                                    >
                                      Suggested copy: {d.SuggestedRetainedAssetName}
                                    </span>
                                  )}
                                </div>
                              </td>

                              <td className="py-3 px-4 max-w-xs">
                                <p className="text-[11px] text-slate-600 leading-relaxed font-normal">
                                  {d.RecommendationReason || `${disposition} based on overall readiness score.`}
                                </p>
                              </td>

                              <td className="py-3 px-4">
                                <span className="font-semibold text-slate-800 text-[11px] block">{d.ExecutionWave || 'Unassigned'}</span>
                                <span className="text-[10px] text-slate-400">{d.Status}</span>
                              </td>

                              <td className="py-3 px-4 text-center">
                                <div className="flex items-center justify-center gap-1 text-[11px] font-mono">
                                  <span title="Business Value / Reach" className="px-1 bg-slate-100 rounded text-blue-700 font-bold">{d.BusinessValueScore}</span>
                                  <span className="text-slate-300">/</span>
                                  <span title="Usage & Adoption" className="px-1 bg-slate-100 rounded text-emerald-700 font-bold">{d.UsageScore}</span>
                                  <span className="text-slate-300">/</span>
                                  <span title="Technical Complexity" className="px-1 bg-slate-100 rounded text-indigo-700 font-bold">{d.ComplexityScore}</span>
                                </div>
                              </td>

                              <td className="py-3 px-4">
                                {hasCluster ? (
                                  <button
                                    onClick={() => setSelectedCluster({
                                      hash: d.DatasourceFingerprint,
                                      canvasHash: d.ReportCanvasHash,
                                      type: d.SimilarityFlag || d.EvidenceState || 'Potential structural duplicate',
                                      title: d.Artifact,
                                      suggestedRetainedAssetId: d.SuggestedRetainedAssetId || '',
                                      canonicalMasterName: d.SuggestedRetainedAssetName || d.CanonicalMaster || (d.DuplicateStatus?.includes('Canonical') ? d.Artifact : '')
                                    })}
                                    className="group flex flex-col gap-1 text-left p-1.5 rounded-lg border border-transparent hover:border-blue-200 hover:bg-blue-50/80 transition-all cursor-pointer w-full max-w-[160px]"
                                    title="Click to inspect full cluster details in slide-over drawer"
                                  >
                                    <div className="flex items-center justify-between">
                                      {d.DuplicateStatus?.includes('Canonical') && (
                                        <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-300 rounded text-[9px] font-bold flex items-center gap-1">
                                          <Crown className="w-2.5 h-2.5 text-amber-600" /> Master ({d.SharedDatasetCount || 2})
                                        </span>
                                      )}
                                      {(d.SimilarityFlag === 'Potential structural duplicate' || d.DuplicateStatus?.includes('Exact Duplicate')) && (
                                        <span className="px-1.5 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded text-[9px] font-bold">
                                          Structural Match ↗
                                        </span>
                                      )}
                                      {d.DuplicateStatus?.includes('Structural Clone') && (
                                        <span className="px-1.5 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded text-[9px] font-bold">
                                          Clone Review ↗
                                        </span>
                                      )}
                                      {d.DuplicateStatus?.includes('Shared Dataset') && (
                                        <span className="px-1.5 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded text-[9px] font-bold flex items-center gap-1">
                                          <Layers className="w-2.5 h-2.5 text-purple-600" /> Shared ({d.SharedDatasetCount}) ↗
                                        </span>
                                      )}
                                      <ExternalLink className="w-3 h-3 text-slate-300 group-hover:text-blue-600 transition-colors ml-auto" />
                                    </div>
                                    <span className="text-[9px] font-mono text-slate-400 group-hover:text-blue-600 transition-colors truncate">
                                      SHA: {d.DatasourceFingerprint ? d.DatasourceFingerprint.substring(0, 10) : '—'}
                                    </span>
                                  </button>
                                ) : (
                                  <div className="flex flex-col gap-0.5 max-w-[140px]">
                                    <span className="text-[10px] font-medium text-slate-500">
                                      {d.SimilarityFlag?.includes('insufficient') ? 'Unassessed' : 'Unique Model'}
                                    </span>
                                    {d.DatasourceFingerprint && (
                                      <span className="text-[9px] font-mono text-slate-300">
                                        SHA: {d.DatasourceFingerprint.substring(0, 8)}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </td>

                              <td className="py-3 px-4">
                                <span className="text-slate-700 font-bold text-xs">{d.Effort}</span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* ========================================================= */}
      {/* SLIDE-OVER CLUSTER INSPECTION DRAWER */}
      {/* ========================================================= */}
      {selectedCluster && (
        <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity animate-fade-in"
            onClick={() => setSelectedCluster(null)}
          />

          {/* Slide-in Panel */}
          <div className="relative w-full max-w-2xl bg-white h-full shadow-2xl z-50 flex flex-col overflow-hidden border-l border-slate-200 transform transition-transform duration-300 animate-slide-in">
            {/* Header */}
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Layers className="w-5 h-5 text-blue-400" />
                  <h2 className="text-base font-black tracking-tight">Cluster Deep-Dive & Lineage Inspector</h2>
                </div>
                <p className="text-xs text-slate-400 font-mono">
                  SHA-256 Fingerprint: {selectedCluster.hash}
                </p>
              </div>
              <button 
                onClick={() => setSelectedCluster(null)}
                className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
                title="Close Drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Evidence Banner */}
            <div className={`p-4 border-b text-xs flex items-start gap-3 ${
              selectedCluster.type === 'EXACT_DUPLICATE_CONFIRMED' || selectedCluster.type === 'Potential structural duplicate'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : selectedCluster.type === 'STRUCTURAL_CLONE_REVIEW'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-purple-50 border-purple-200 text-purple-900'
            }`}>
              <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5 text-blue-600" />
              <div className="space-y-1">
                <strong className="font-bold text-xs uppercase tracking-wider block">
                  Similarity Screening: {selectedCluster.type.replace(/_/g, ' ')}
                </strong>
                <p className="leading-relaxed">
                  {selectedCluster.type.includes('structural') || selectedCluster.type === 'EXACT_DUPLICATE_CONFIRMED' ? 
                    "Structural matching identified shared data models and canvas characteristics across these assets. All assets in the group are flagged for business review to confirm deduplication decisions." :
                    selectedCluster.type === 'STRUCTURAL_CLONE_REVIEW' ?
                    "Visual report canvas is identical, but underlying data connections or Custom SQL differ. Human engineering review is required before consolidation." :
                    "Hub-and-spoke semantic model powering multiple reports across the organization. Certified primary models are eligible for fast-track Power BI Direct Lake migration."
                  }
                </p>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-3 gap-3 p-4 bg-slate-50 border-b border-slate-200 text-center">
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Reports in Cluster</span>
                <span className="text-lg font-black text-slate-800">{clusterAssets.length}</span>
              </div>
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Sum of Asset User Counts*</span>
                <span className="text-lg font-black text-emerald-600">{totalClusterUsers}</span>
                <span className="text-[9px] text-slate-400 block leading-tight mt-0.5">*Not deduplicated across assets</span>
              </div>
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total 180d Views</span>
                <span className="text-lg font-black text-blue-600">{totalClusterViews}</span>
              </div>
            </div>

            {/* Asset Items List */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Discovered Asset Instances ({clusterAssets.length})
              </h3>

              <div className="space-y-3">
                {clusterAssets.map((asset, idx) => {
                  const isCanonical = asset.DuplicateStatus?.includes('Canonical') || 
                                     (selectedCluster.canonicalMasterName && asset.Artifact === selectedCluster.canonicalMasterName);
                  const disp = asset.ProposedDisposition || asset.OutcomeDecision || 'Select for migration';
                  const rev = asset.ReviewStatus || 'Business review required';

                  return (
                    <div 
                      key={asset.AssetId || `${asset.SiteName || ''}:${asset.Workspace || ''}:${asset.Artifact || ''}#${idx}`} 
                      className={`p-4 rounded-2xl border transition-all ${
                        isCanonical 
                          ? 'bg-amber-50/60 border-amber-300 ring-1 ring-amber-300/50 shadow-sm'
                          : 'bg-white border-slate-200 shadow-xs'
                      }`}
                    >
                      {/* Asset Header */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            {isCanonical && (
                              <span className="px-2 py-0.5 bg-amber-500 text-white rounded-md text-[10px] font-black flex items-center gap-1 shadow-xs">
                                <Crown className="w-3 h-3" /> SUGGESTED RETAINED COPY
                              </span>
                            )}
                            <h4 className="font-bold text-sm text-slate-900">{asset.Artifact}</h4>
                          </div>
                          <p className="text-xs text-slate-500 flex items-center gap-2">
                            <span>Project: <strong className="text-slate-700">{asset.Workspace}</strong></span>
                            <span>•</span>
                            <span>Site: <strong className="text-slate-700">{asset.SiteName || 'Default'}</strong></span>
                            <span>•</span>
                            <span>Type: <strong className="text-slate-700">{asset.Type}</strong></span>
                          </p>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          <span className={`px-2.5 py-1 rounded-lg text-xs font-bold shrink-0 border ${
                            disp === 'Select for migration' || disp === 'Migrate As-Is'
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : disp === 'Retire candidate' || disp === 'Retire Candidate' || disp === 'Retire'
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : 'bg-slate-100 text-slate-700 border-slate-300'
                          }`}>
                            {disp}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            rev === 'Insufficient evidence'
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : 'bg-amber-50 text-amber-800 border-amber-300'
                          }`}>
                            {rev}
                          </span>
                        </div>
                      </div>

                      {/* Recommendation Reason */}
                      <div className="mt-3 p-2.5 bg-white/80 rounded-xl border border-slate-200/80 text-xs text-slate-700 leading-relaxed font-normal">
                        <span className="font-semibold text-slate-900 block mb-0.5">Disposition Rationale:</span>
                        {asset.RecommendationReason}
                      </div>

                      {/* Metric Chips */}
                      <div className="mt-3 grid grid-cols-4 gap-2 text-center text-xs">
                        <div className="p-1.5 bg-slate-100/80 rounded-lg">
                          <span className="text-[9px] text-slate-400 font-bold block">USERS</span>
                          <span className="font-black text-slate-800">{asset.DistinctUsers || 0}</span>
                        </div>
                        <div className="p-1.5 bg-slate-100/80 rounded-lg">
                          <span className="text-[9px] text-slate-400 font-bold block">VIEWS</span>
                          <span className="font-black text-slate-800">{asset.ActivityViews || 0}</span>
                        </div>
                        <div className="p-1.5 bg-slate-100/80 rounded-lg">
                          <span className="text-[9px] text-slate-400 font-bold block">COMPLEXITY</span>
                          <span className="font-black text-indigo-700">{asset.ComplexityScore || 0}/{profile.id === 'tableau' ? '900' : '100'}</span>
                        </div>
                        <div className="p-1.5 bg-slate-100/80 rounded-lg">
                          <span className="text-[9px] text-slate-400 font-bold block">LODs / SQL</span>
                          <span className="font-black text-slate-800">{asset.LODCalcCount || 0} / {asset.CustomSQLCount || 0}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Footer Action */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">
                Showing all {clusterAssets.length} cluster members
              </span>
              <button 
                onClick={() => setSelectedCluster(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


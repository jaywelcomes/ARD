"use client";

import React, { useEffect, useState } from 'react';
import { 
  fetchMigrationReadiness, 
  fetchMigrationWorkspaces,
  fetchConfig
} from '@/lib/api';
import { getPlatformProfile, PlatformProfile } from '@/lib/platformProfiles';
import { 
  GitMerge, 
  Sparkles, 
  Zap, 
  Trash2, 
  Calendar, 
  Clock, 
  FolderOpen, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  ShieldCheck 
} from 'lucide-react';

export default function WavePlannerPage() {
  const [datasets, setDatasets] = useState<any[]>([]);
  const [workspaces, setWorkspaces] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<PlatformProfile>(getPlatformProfile('powerbi'));

  useEffect(() => {
    async function load() {
      try {
        const [dsData, wsData, cfg] = await Promise.all([
          fetchMigrationReadiness(),
          fetchMigrationWorkspaces(),
          fetchConfig().catch(() => ({ source_platform: 'powerbi' }))
        ]);
        setDatasets(dsData || []);
        setWorkspaces(wsData || []);
        if (cfg?.source_platform) {
          setProfile(getPlatformProfile(cfg.source_platform));
        }
      } catch (err) {
        console.error("Failed to load wave data:", err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm font-semibold text-slate-500">Generating Migration Roadmap...</p>
      </div>
    );
  }

  // Extract unique waves from datasets or provide fallback
  const uniqueWaves = Array.from(
    new Set(datasets.map(d => d.ExecutionWave).filter(Boolean))
  ).sort() as string[];

  const defaultWaveIds = uniqueWaves.length > 0 ? uniqueWaves : [
    'Wave 1: Migrate As-Is',
    'Wave 2: Optimize & Migrate',
    'Wave 3: Rebuild Native',
    'Wave 4: Retire & Archive'
  ];

  const getWaveMeta = (waveName: string, index: number, total: number) => {
    if (waveName.toLowerCase() === 'unassigned' || waveName.toLowerCase().includes('unassigned')) {
      return {
        id: 'Unassigned',
        fullName: 'Unassigned (Discovery Required)',
        badgeColor: 'bg-slate-100 text-slate-700 border-slate-300',
        icon: Clock,
        description: 'Assets with insufficient telemetry or pending discovery observation. Awaiting business assessment before scheduling.'
      };
    }

    const match = waveName.match(/Wave\s*(\d+)/i);
    const waveNum = match ? parseInt(match[1]) : (index + 1);
    let badgeColor = 'bg-blue-50 text-blue-700 border-blue-200';
    let icon = GitMerge;

    if (waveNum === 1 || waveName.includes('Fast-Track') || waveName.includes('Migrate As-Is')) {
      badgeColor = 'bg-emerald-50 text-emerald-700 border-emerald-200';
      icon = CheckCircle2;
    } else if (waveNum === 4 || waveName.includes('Retire') || waveName.includes('Decommission')) {
      badgeColor = 'bg-rose-50 text-rose-700 border-rose-200';
      icon = Trash2;
    } else if (waveNum === 2) {
      badgeColor = 'bg-teal-50 text-teal-700 border-teal-200';
      icon = Zap;
    } else if (waveNum === 3 || waveName.includes('Complex')) {
      badgeColor = 'bg-amber-50 text-amber-700 border-amber-200';
      icon = AlertTriangle;
    }

    return {
      id: `Wave ${waveNum}`,
      fullName: waveName,
      badgeColor,
      icon,
      description: waveName.includes('Retire') 
        ? 'Decommission and archive candidates to reclaim capacity and eliminate license waste.'
        : waveName.includes('Fast-Track') || (waveNum === 1)
        ? `High-readiness ${profile.shortName} assets prioritized for immediate, fast-track cutover.`
        : `Requires targeted refactoring, ${profile.calculationsTerm.toLowerCase()} optimization, or schema redesign before cutover.`
    };
  };

  const dynamicWaves = defaultWaveIds.map((w, idx) => getWaveMeta(w, idx, defaultWaveIds.length));

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-800">Migration Wave Roadmap & Execution Planner</h1>
          <p className="text-xs text-slate-500 mt-1">
            Dynamic {dynamicWaves.length}-stage wave sequencing partitioned by composite readiness score, certified golden status, and effort for {profile.name}.
          </p>
        </div>
        <span className="px-3.5 py-1.5 rounded-full text-xs font-black bg-indigo-50 text-indigo-700 border border-indigo-200 self-start sm:self-auto">
          {datasets.length} Total {profile.assetTermPlural} Partitioned
        </span>
      </div>

      {/* Wave Columns Grid */}
      <div className={`grid grid-cols-1 md:grid-cols-2 ${dynamicWaves.length <= 3 ? 'lg:grid-cols-3' : 'lg:grid-cols-4'} gap-6`}>
        {dynamicWaves.map((wave) => {
          const waveDatasets = datasets.filter(d => d.ExecutionWave === wave.fullName || d.ExecutionWave?.includes(wave.id));
          const Icon = wave.icon;

          return (
            <div 
              key={wave.fullName} 
              className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden"
            >
              {/* Card Header */}
              <div className="p-4 border-b border-slate-100 space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${wave.badgeColor} flex items-center gap-1.5`}>
                    <Icon className="w-3.5 h-3.5" />
                    {wave.id}
                  </span>
                  <span className="text-xs font-bold text-slate-500">
                    {waveDatasets.length} {profile.assetTermPlural}
                  </span>
                </div>
                <h2 className="text-sm font-black text-slate-900 leading-snug">{wave.fullName}</h2>
                <p className="text-[11px] text-slate-500 leading-relaxed">{wave.description}</p>
              </div>

              {/* Asset List */}
              <div className="p-3 flex-1 overflow-y-auto max-h-[500px] space-y-2 bg-slate-50/50">
                {waveDatasets.length === 0 ? (
                  <div className="text-center py-8 text-xs text-slate-400 font-semibold">
                    No {profile.assetTermPlural.toLowerCase()} assigned to {wave.id}
                  </div>
                ) : (
                  waveDatasets.map((ds, idx) => (
                    <div 
                      key={idx} 
                      className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs space-y-1.5 hover:border-slate-300 transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900 truncate max-w-[160px]" title={ds.Artifact}>
                          {ds.Artifact}
                        </span>
                        <span className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                          parseFloat(ds.ReadinessScore) >= 80 ? 'bg-emerald-100 text-emerald-800' :
                          parseFloat(ds.ReadinessScore) >= 60 ? 'bg-blue-100 text-blue-800' :
                          parseFloat(ds.ReadinessScore) >= 40 ? 'bg-amber-100 text-amber-800' :
                          'bg-rose-100 text-rose-800'
                        }`}>
                          {ds.ReadinessScore}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-medium truncate">
                        <FolderOpen className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{profile.containerTerm}: {ds.Workspace}</span>
                      </div>

                      {ds.RecommendationReason && (
                        <p className="text-[10px] text-slate-500 leading-tight line-clamp-2 italic bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                          {ds.RecommendationReason}
                        </p>
                      )}

                      <div className="flex flex-wrap items-center gap-1 pt-1 border-t border-slate-100">
                        {ds.IsGoldenDataset === 'Yes' && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 text-[9px] font-bold border border-amber-200 flex items-center gap-1">
                            <Sparkles className="w-2.5 h-2.5" /> Golden
                          </span>
                        )}
                        {ds.DirectLakeCandidate === 'Yes' && (
                          <span className="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[9px] font-bold border border-indigo-200 flex items-center gap-1" title={profile.fastTrackLabel}>
                            <Zap className="w-2.5 h-2.5" /> {profile.fastTrackBadge}
                          </span>
                        )}
                        {ds.DuplicateStatus && ds.DuplicateStatus.includes('Shared') && (
                          <span className="px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 text-[9px] font-bold border border-purple-200">
                            Shared Model ({ds.SharedDatasetCount || 2})
                          </span>
                        )}
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 text-[9px] font-bold">
                          {ds.Effort}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export interface PlatformDimensionDesc {
  dim1: string;
  dim2: string;
  dim3: string;
  dim4: string;
  dim5: string;
  dim6: string;
}

export interface PlatformProfile {
  id: string;
  name: string;
  shortName: string;
  containerTerm: string;
  containerTermPlural: string;
  assetTerm: string;
  assetTermPlural: string;
  fastTrackLabel: string;
  fastTrackBadge: string;
  fastTrackDesc: string;
  calculationsTerm: string;
  governancePersonalTerm: string;
  governanceAdminTerm: string;
  connectivityTerm: string;
  wave1Subtitle: string;
  wave2Subtitle: string;
  wave3Subtitle: string;
  wave4Subtitle: string;
  dimensions: PlatformDimensionDesc;
}

export const PLATFORM_PROFILES: Record<string, PlatformProfile> = {
  powerbi: {
    id: 'powerbi',
    name: 'Microsoft Power BI / Fabric',
    shortName: 'Power BI',
    containerTerm: 'Workspace',
    containerTermPlural: 'Workspaces',
    assetTerm: 'Dataset / Semantic Model',
    assetTermPlural: 'Datasets & Semantic Models',
    fastTrackLabel: 'Direct Lake Candidates',
    fastTrackBadge: 'Fabric Native',
    fastTrackDesc: 'Zero gateway & direct OneLake Delta Lake ready',
    calculationsTerm: 'DAX Measures & Calc Columns',
    governancePersonalTerm: 'Personal Workspace',
    governanceAdminTerm: 'Workspace Admins',
    connectivityTerm: 'On-Premises Gateway & DirectQuery',
    wave1Subtitle: 'Fastest Fabric Transition',
    wave2Subtitle: 'Minor DAX & Model Refactoring',
    wave3Subtitle: 'Direct Lake & OneLake Redesign',
    wave4Subtitle: 'Decommission & Reclaim Capacity',
    dimensions: {
      dim1: 'Endorsement status, certification, executive markers, and business domain classification.',
      dim2: 'Activity views, Monthly Active Users (MAU), subscription counts, and refresh staleness.',
      dim3: 'Table counts, column counts, calculated-to-base column ratio, and DAX measure counts.',
      dim4: 'Dataset size in MB, incremental refresh configuration, and high-risk DAX complexity.',
      dim5: 'Personal workspace status, admin count (orphan detection), and sensitivity labels.',
      dim6: 'Upstream data sources, on-premises gateway dependency, and DirectQuery / Composite modes.'
    }
  },
  tableau: {
    id: 'tableau',
    name: 'Tableau (Server / Cloud)',
    shortName: 'Tableau',
    containerTerm: 'Project / Site',
    containerTermPlural: 'Projects / Sites',
    assetTerm: 'Workbook / Published Data Source',
    assetTermPlural: 'Workbooks & Data Sources',
    fastTrackLabel: 'Cloud Hyper Candidates',
    fastTrackBadge: 'Cloud Hyper Live',
    fastTrackDesc: 'High-speed published extract / direct cloud connection ready',
    calculationsTerm: 'LOD Calculations & Formulas',
    governancePersonalTerm: 'Personal Sandbox Project',
    governanceAdminTerm: 'Project / Content Owners',
    connectivityTerm: 'Tableau Bridge & Live vs Extract',
    wave1Subtitle: 'Fast-Track Cloud Transition',
    wave2Subtitle: 'LOD & Custom SQL Optimization',
    wave3Subtitle: 'Hyper Extract & Semantic Redesign',
    wave4Subtitle: 'Decommission & License Cleanup',
    dimensions: {
      dim1: 'Certification status, project tier, executive dashboard flags, and domain classification.',
      dim2: 'Total view events, Monthly Active Users (MAU), subscription counts, and access recency.',
      dim3: 'Physical/logical table counts, sheet/dashboard count, and LOD calculation volume.',
      dim4: 'Extract size in MB, live connection performance, and custom SQL complexity.',
      dim5: 'Personal/Sandbox project status, orphaned owner detection, and data security classification.',
      dim6: 'Underlying database endpoints, Tableau Bridge dependency, and multi-source data blends.'
    }
  },
  qlik: {
    id: 'qlik',
    name: 'Qlik Sense / QlikView',
    shortName: 'Qlik Sense',
    containerTerm: 'Stream / Space',
    containerTermPlural: 'Streams / Spaces',
    assetTerm: 'Qlik App (QVF / QVW)',
    assetTermPlural: 'Qlik Apps',
    fastTrackLabel: 'SaaS In-Memory Candidates',
    fastTrackBadge: 'SaaS In-Memory',
    fastTrackDesc: 'Standard QVD in-memory architecture ready for direct SaaS reload',
    calculationsTerm: 'Set Analysis & Master Measures',
    governancePersonalTerm: 'Personal My Work Space',
    governanceAdminTerm: 'Space Owners & Admins',
    connectivityTerm: 'QVD Connectors & Data Gateway',
    wave1Subtitle: 'Fast-Track SaaS Transition',
    wave2Subtitle: 'Set Analysis & Script Refactoring',
    wave3Subtitle: 'Associative Data Model Redesign',
    wave4Subtitle: 'Decommission & Reclaim RAM',
    dimensions: {
      dim1: 'Published stream status, executive application tags, and business domain classification.',
      dim2: 'Opened session counts, Monthly Active Users (MAU), and reload schedule staleness.',
      dim3: 'Associative table counts, synthetic keys, circular references, and sheet counts.',
      dim4: 'RAM memory footprint in MB, reload duration, and set analysis expression complexity.',
      dim5: 'Personal My Work stream status, owner activity status, and Section Access governance.',
      dim6: 'Distinct QVD source count, custom data connections, and multi-tier reload dependencies.'
    }
  },
  looker: {
    id: 'looker',
    name: 'Google Looker',
    shortName: 'Looker',
    containerTerm: 'Folder / Model',
    containerTermPlural: 'Folders / Models',
    assetTerm: 'Explore / Look / Dashboard',
    assetTermPlural: 'Explores & Looks',
    fastTrackLabel: 'Direct SQL & PDT Candidates',
    fastTrackBadge: 'Looker Native',
    fastTrackDesc: 'Optimized LookML explores with direct SQL and persistent derived tables',
    calculationsTerm: 'LookML Dimensions & Measures',
    governancePersonalTerm: 'Dev Branch / Personal Space',
    governanceAdminTerm: 'Model & Git Maintainers',
    connectivityTerm: 'Database Connection & PDTs',
    wave1Subtitle: 'Fast-Track LookML Migration',
    wave2Subtitle: 'LookML Join & View Refactoring',
    wave3Subtitle: 'Explore & PDT Architecture Redesign',
    wave4Subtitle: 'Decommission Unused Looks & Models',
    dimensions: {
      dim1: 'Model certification, primary Git branch status, and business domain classification.',
      dim2: 'Query executions (30d), Monthly Active Users (MAU), and query recency.',
      dim3: 'Underlying LookML view count, dimension/measure count, and join graph complexity.',
      dim4: 'PDT build frequency, query runtime, and cache hit efficiency.',
      dim5: 'Personal dev branch status, orphaned LookML model detection, and user access roles.',
      dim6: 'Underlying SQL dialect connections, PDT dependencies, and multi-model explores.'
    }
  },
  microstrategy: {
    id: 'microstrategy',
    name: 'MicroStrategy',
    shortName: 'MicroStrategy',
    containerTerm: 'Project / Folder',
    containerTermPlural: 'Projects / Folders',
    assetTerm: 'Dossier / Document / Cube',
    assetTermPlural: 'Dossiers & Cubes',
    fastTrackLabel: 'Intelligent Cube Candidates',
    fastTrackBadge: 'Cloud Cube Native',
    fastTrackDesc: 'Self-contained in-memory intelligent cubes ready for cloud cutover',
    calculationsTerm: 'Metrics & Custom Expressions',
    governancePersonalTerm: 'My Reports / Personal Folder',
    governanceAdminTerm: 'Project & Object Admins',
    connectivityTerm: 'Database Instances & Gateways',
    wave1Subtitle: 'Fast-Track Cloud Transition',
    wave2Subtitle: 'Metric & Attribute Refactoring',
    wave3Subtitle: 'Schema & Intelligent Cube Redesign',
    wave4Subtitle: 'Decommission Legacy Reports & Cubes',
    dimensions: {
      dim1: 'Certified dossier status, project tier, executive flag, and business domain.',
      dim2: 'Execution counts (30d), Monthly Active Users (MAU), and subscription frequency.',
      dim3: 'Attribute/metric counts, prompt complexity, and chapter/visualization counts.',
      dim4: 'In-memory cube RAM size in MB, report execution duration, and complex SQL passes.',
      dim5: 'Personal My Reports folder status, orphaned owner check, and object ACL permissions.',
      dim6: 'Database instance connections, multi-source joins, and Freeform SQL complexity.'
    }
  },
  universal: {
    id: 'universal',
    name: 'Universal / Generic BI',
    shortName: 'Universal BI',
    containerTerm: 'Container / Folder',
    containerTermPlural: 'Containers / Folders',
    assetTerm: 'BI Asset / Model',
    assetTermPlural: 'BI Assets & Models',
    fastTrackLabel: 'Cloud Native Candidates',
    fastTrackBadge: 'Cloud Native',
    fastTrackDesc: 'High-efficiency semantic models ready for direct target modernization',
    calculationsTerm: 'Measures & Formulas',
    governancePersonalTerm: 'Personal / Unmanaged Container',
    governanceAdminTerm: 'Container Admins / Owners',
    connectivityTerm: 'Direct Query & Data Connectors',
    wave1Subtitle: 'Fast-Track Modernization',
    wave2Subtitle: 'Metric & Formula Optimization',
    wave3Subtitle: 'Target Architecture Redesign',
    wave4Subtitle: 'Decommission & Cleanup',
    dimensions: {
      dim1: 'Asset endorsement, enterprise certification, and business domain classification.',
      dim2: 'Usage views, Monthly Active Users (MAU), subscription counts, and data staleness.',
      dim3: 'Table counts, column counts, calculated-to-base ratio, and measure counts.',
      dim4: 'Dataset size in MB, refresh duration, and calculation complexity.',
      dim5: 'Personal/Unmanaged container status, orphan detection, and governance classification.',
      dim6: 'Source system count, gateway dependency, and live vs extract storage modes.'
    }
  }
};

export function getPlatformProfile(platformId?: string): PlatformProfile {
  const key = (platformId || 'powerbi').toLowerCase().trim();
  return PLATFORM_PROFILES[key] || PLATFORM_PROFILES['powerbi'];
}

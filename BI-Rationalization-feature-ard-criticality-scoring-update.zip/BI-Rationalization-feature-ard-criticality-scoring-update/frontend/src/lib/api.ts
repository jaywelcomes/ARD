/**
 * Rationalization Accelerator API Client
 */

const BASE_URL = 'http://localhost:8000/api';

export async function fetchHealth() {
  const res = await fetch('http://localhost:8000/health', { cache: 'no-store' });
  if (!res.ok) throw new Error('Failed to connect to backend server');
  return res.json();
}

export async function fetchMigrationReadiness() {
  const res = await fetch(`${BASE_URL}/entities/migration`, { cache: 'no-store' });
  if (!res.ok) throw new Error('Failed to fetch migration readiness data');
  return res.json();
}

export async function fetchMigrationWorkspaces() {
  const res = await fetch(`${BASE_URL}/entities/migration_workspaces`, { cache: 'no-store' });
  if (!res.ok) throw new Error('Failed to fetch workspace summary data');
  return res.json();
}

export async function triggerScoring(params?: any) {
  const res = await fetch(`${BASE_URL}/rationalization/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params || {}),
  });
  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.detail || 'Failed to trigger rationalization scoring');
  }
  return res.json();
}

export async function fetchConfig() {
  const res = await fetch(`${BASE_URL}/config`, { cache: 'no-store' });
  if (!res.ok) throw new Error('Failed to fetch configuration');
  return res.json();
}

export async function updateConfig(config: any) {
  const res = await fetch(`${BASE_URL}/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  if (!res.ok) throw new Error('Failed to update configuration');
  return res.json();
}

export async function uploadDimensionCsv(dimension: string, file: File) {
  const formData = new FormData();
  formData.append('dimension', dimension);
  formData.append('file', file);

  const res = await fetch(`${BASE_URL}/upload`, {
    method: 'POST',
    body: formData,
  });
  if (!res.ok) {
    const errorData = await res.json();
    const customError: any = new Error(
      errorData.detail?.message || errorData.detail || 'Failed to upload CSV'
    );
    customError.validation = errorData.detail;
    customError.status = res.status;
    throw customError;
  }
  return res.json();
}

export async function fetchTemplateSchema(platform: string = 'powerbi') {
  const res = await fetch(`${BASE_URL}/templates/schema?platform=${encodeURIComponent(platform)}`, { cache: 'no-store' });
  if (!res.ok) throw new Error('Failed to fetch template schema');
  return res.json();
}

export function getTemplateDownloadUrl(platform: string = 'powerbi', samples: boolean = true) {
  return `${BASE_URL}/templates/download?platform=${encodeURIComponent(platform)}&samples=${samples}`;
}

export function getExcelExportUrl() {
  return `${BASE_URL}/rationalization/export/excel`;
}

export async function askAdvisor(message: string, history?: any[]) {
  const res = await fetch(`${BASE_URL}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, conversation_history: history || [] }),
  });
  if (!res.ok) throw new Error('Failed to communicate with AI advisor');
  return res.json();
}


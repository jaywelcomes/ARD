"""
Unit Tests for Standalone Rationalization Scoring Engine
"""

import os
import shutil
import unittest
import pandas as pd
import numpy as np
from engine.core_scorer import (
    load_configuration,
    evaluate_dataset_rationalization,
    run_scoring_pipeline
)

class TestRationalizationEngine(unittest.TestCase):
    def setUp(self):
        self.test_dir = os.path.join("tests", "temp_rationalization_test")
        os.makedirs(self.test_dir, exist_ok=True)
        self.cfg = load_configuration()

    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_default_config_loading(self):
        cfg = load_configuration("non_existent_file.yaml")
        self.assertIn("weights", cfg)
        self.assertEqual(cfg["weights"]["business_value"], 0.25)
        self.assertEqual(cfg["weights"]["usage_adoption"], 0.20)

    def test_rationalization_scoring_logic(self):
        mock_data = pd.DataFrame([
            {
                "dataset_id": "ds-test-1",
                "dataset_name": "Executive Sales Model",
                "workspace_id": "ws-1",
                "workspace_name": "Finance Exec",
                "workspace_description": "Board reporting",
                "workspace_type": "Group",
                "workspace_admin_count": 2,
                "workspace_member_count": 10,
                "workspace_is_on_dedicated_capacity": False,
                "workspace_state": "Active",
                "business_domain": "Finance",
                "endorsement": "Certified",
                "is_certified": True,
                "activity_views": 500,
                "monthly_active_users": 120,
                "has_subscriptions": True,
                "last_refresh_time": "2026-09-10T00:00:00Z",
                "table_count": 5,
                "total_column_count": 40,
                "calculated_column_count": 2,
                "measure_count": 20,
                "dataset_size_mb": 250.0,
                "has_incremental_refresh": False,
                "has_high_risk_dax": False,
                "sensitivity_label": "Confidential",
                "has_rls": True,
                "datasource_count": 2,
                "has_gateway": False,
                "storage_mode": "Import",
                "has_directquery": False,
                "relationship_count": 6,
                "downstream_report_count": 4
            },
            {
                "dataset_id": "ds-test-2",
                "dataset_name": "Old Orphan Test",
                "workspace_id": "ws-2",
                "workspace_name": "Unused Personal WS",
                "workspace_description": "",
                "workspace_type": "Personal",
                "workspace_admin_count": 0,
                "workspace_member_count": 1,
                "workspace_is_on_dedicated_capacity": False,
                "workspace_state": "Active",
                "business_domain": "Personal",
                "endorsement": "None",
                "is_certified": False,
                "activity_views": 0,
                "monthly_active_users": 0,
                "has_subscriptions": False,
                "last_refresh_time": "2023-01-01T00:00:00Z",
                "table_count": 1,
                "total_column_count": 120,
                "calculated_column_count": 50,
                "measure_count": 0,
                "dataset_size_mb": 50.0,
                "has_incremental_refresh": False,
                "has_high_risk_dax": True,
                "sensitivity_label": "None",
                "has_rls": False,
                "datasource_count": 8,
                "has_gateway": True,
                "storage_mode": "DirectQuery",
                "has_directquery": True,
                "relationship_count": 0,
                "downstream_report_count": 0
            }
        ])

        df_readiness, df_summary = evaluate_dataset_rationalization(mock_data, self.cfg)

        # Verify high scoring executive dataset
        exec_ds = df_readiness[df_readiness["Artifact"] == "Executive Sales Model"].iloc[0]
        self.assertGreaterEqual(exec_ds["ReadinessScore"], 80)
        self.assertEqual(exec_ds["OutcomeDecision"], "Migrate As-Is")
        self.assertEqual(exec_ds["ProposedDisposition"], "Select for migration")
        self.assertEqual(exec_ds["ReviewStatus"], "Ready")
        self.assertEqual(exec_ds["SimilarityFlag"], "Unique")
        self.assertEqual(exec_ds["ExecutionWave"], "Wave 1: Migrate As-Is")
        self.assertEqual(exec_ds["IsGoldenDataset"], "Yes")
        self.assertEqual(exec_ds["DirectLakeCandidate"], "Yes")
        self.assertEqual(exec_ds["AssetId"], "ds-test-1")
        self.assertEqual(exec_ds["WorkspaceName"], "Finance Exec")

        # Verify low scoring orphan dataset
        orphan_ds = df_readiness[df_readiness["Artifact"] == "Old Orphan Test"].iloc[0]
        self.assertLess(orphan_ds["ReadinessScore"], 40)
        self.assertEqual(orphan_ds["OutcomeDecision"], "Retire")
        self.assertEqual(orphan_ds["ProposedDisposition"], "Retire candidate")
        self.assertEqual(orphan_ds["ReviewStatus"], "Ready")
        self.assertEqual(orphan_ds["ExecutionWave"], "Wave 4: Retire & Archive")
        self.assertEqual(orphan_ds["IsGoldenDataset"], "No")
        self.assertEqual(orphan_ds["DirectLakeCandidate"], "No")

    def test_datasource_count_in_complexity_score(self):
        from engine.core_scorer import compute_complexity_score
        # Row with datasource_count = 5 (score = 60.0)
        row1 = pd.Series({
            "table_count": 5, "total_column_count": 20, "calculated_column_count": 2,
            "measure_count": 10, "dataset_size_mb": 50, "has_incremental_refresh": False,
            "has_high_risk_dax": False, "datasource_count": 5, "relationship_count": 4,
            "downstream_report_count": 2, "has_gateway": False, "storage_mode": "Import"
        })
        score1 = compute_complexity_score(row1, self.cfg)

        # Row with datasource_count = 1 (score = 100.0)
        row2 = pd.Series({
            "table_count": 5, "total_column_count": 20, "calculated_column_count": 2,
            "measure_count": 10, "dataset_size_mb": 50, "has_incremental_refresh": False,
            "has_high_risk_dax": False, "datasource_count": 1, "relationship_count": 4,
            "downstream_report_count": 2, "has_gateway": False, "storage_mode": "Import"
        })
        score2 = compute_complexity_score(row2, self.cfg)

        self.assertGreater(score2, score1)

    def test_validate_and_normalize_inventory(self):
        from engine.core_scorer import validate_and_normalize_inventory
        raw_df = pd.DataFrame([{
            "dataset_name": "Test DS",
            "workspace_name": "Test WS",
            "table_count": "15",
            "monthly_active_users": "250",
            "activity_views": "1500",
            "datasource_count": "3"
        }])
        norm_df, errors = validate_and_normalize_inventory(raw_df, self.cfg)
        self.assertTrue(isinstance(norm_df["table_count"].iloc[0], (int, float, np.integer, np.floating)))
        self.assertEqual(norm_df["table_count"].iloc[0], 15)
        self.assertEqual(norm_df["monthly_active_users"].iloc[0], 250)

    def test_schema_validation(self):
        from engine.templates_generator import validate_uploaded_dataframe

        # Valid Power BI dataframe
        valid_df = pd.DataFrame([{
            "dataset_name": "Sales",
            "workspace_name": "Finance",
            "table_count": 5,
            "monthly_active_users": 100,
            "activity_views": 500,
            "data_source_count": 2
        }])
        valid, missing_m, missing_o, stats = validate_uploaded_dataframe(valid_df, "powerbi")
        self.assertTrue(valid)
        self.assertEqual(len(missing_m), 0)

        # Invalid Power BI dataframe (missing table_count)
        invalid_df = pd.DataFrame([{
            "dataset_name": "Sales",
            "workspace_name": "Finance",
            "monthly_active_users": 100,
            "activity_views": 500,
            "data_source_count": 2
        }])
        valid, missing_m, missing_o, stats = validate_uploaded_dataframe(invalid_df, "powerbi")
        self.assertFalse(valid)
        self.assertIn("table_count", missing_m)

    def test_dynamic_wave_assignment(self):
        from engine.core_scorer import assign_dynamic_wave

        # Test 2 Waves
        w1_name, _, _ = assign_dynamic_wave(85.0, 2)
        self.assertIn("Wave 1", w1_name)
        w2_name, _, _ = assign_dynamic_wave(30.0, 2)
        self.assertIn("Wave 2", w2_name)

        # Test 5 Waves
        w1_5w, _, _ = assign_dynamic_wave(90.0, 5)
        self.assertIn("Wave 1", w1_5w)
        w5_5w, _, _ = assign_dynamic_wave(20.0, 5)
        self.assertIn("Wave 5", w5_5w)

    def test_cross_platform_column_normalization(self):
        # Test Tableau metadata mapping
        tableau_df = pd.DataFrame([{
            "artifact_name": "Tableau Sales Workbook",
            "project_name": "Commercial Ops",
            "table_count": 6,
            "monthly_active_users": 150,
            "view_count_total": 2400,
            "data_source_count": 2,
            "is_certified": True
        }])

        df_readiness, _ = evaluate_dataset_rationalization(tableau_df, self.cfg)
        self.assertEqual(len(df_readiness), 1)
        row = df_readiness.iloc[0]
        self.assertEqual(row["Artifact"], "Tableau Sales Workbook")
        self.assertEqual(row["Workspace"], "Commercial Ops")
        self.assertGreaterEqual(row["ReadinessScore"], 70)

    def test_excel_export_generation_and_all_columns_preserved(self):
        """Verify that Excel export generates valid bytes and preserves all input & score columns."""
        from engine.excel_exporter import generate_rationalization_excel

        test_data = pd.DataFrame([{
            "custom_input_col_1": "Test Metadata A",
            "custom_input_col_2": 999,
            "artifact_name": "Test Excel WB",
            "project_name": "Finance",
            "table_count": 4,
            "monthly_active_users": 100,
            "activity_views": 450,
            "data_source_count": 2,
            "is_certified": True
        }])

        df_readiness, df_summary = evaluate_dataset_rationalization(test_data, self.cfg)
        
        # Verify custom input columns are preserved in df_readiness
        self.assertIn("custom_input_col_1", df_readiness.columns)
        self.assertIn("custom_input_col_2", df_readiness.columns)
        self.assertIn("ProposedDisposition", df_readiness.columns)
        self.assertIn("ReadinessScore", df_readiness.columns)
        self.assertIn("BusinessValueScore", df_readiness.columns)
        self.assertIn("UsageScore", df_readiness.columns)

        # Generate Excel bytes
        excel_bytes = generate_rationalization_excel(df_readiness, df_summary, self.cfg)
        self.assertIsInstance(excel_bytes, bytes)
        self.assertGreater(len(excel_bytes), 5000)


if __name__ == "__main__":
    unittest.main()


"""
Comprehensive Automated Test Suite for Tableau ARD Lift & Shift Scoring Engine
Tests all mathematical bounds, edge cases, deduplication, and rationale generation.
"""

import unittest
import os
import sys
import pandas as pd
import numpy as np

# Add project root to sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from engine.ard_scorer import (
    compute_ard_criticality_score,
    compute_ard_complexity_score,
    compute_dataset_fingerprint_sha256,
    compute_report_canvas_hash,
    calculate_workbook_canonical_rank,
    calculate_datasource_canonical_rank,
    evaluate_tableau_ard_rationalization
)
from engine.core_scorer import load_configuration


class TestTableauARDEngine(unittest.TestCase):

    def setUp(self):
        self.cfg = {
            "strategy_mode": "tableau_ard_lift_and_shift",
            "ard_settings": {
                "usage_lookback_days": 180,
                "criticality_threshold": 250.0,
                "duplicate_detection": True,
                "complexity_low_limit": 400.0,
                "complexity_medium_limit": 700.0
            }
        }

    # -------------------------------------------------------------
    # 1. CRITICALITY SCORING TESTS
    # -------------------------------------------------------------
    def test_dead_asset_criticality_floor(self):
        """Dead asset with 0 users, 0 views, >365d staleness must score 0.0."""
        row = pd.Series({
            "distinct_users_180d": 0,
            "view_count_180d": 0,
            "bu_reach_count": 0,
            "days_since_last_access": 450,
            "is_certified": "False"
        })
        score, breakdown, _ = compute_ard_criticality_score(row, self.cfg)
        self.assertEqual(score, 0.0)
        self.assertEqual(breakdown["UsersPoints"], 0.0)
        self.assertEqual(breakdown["ViewsPoints"], 0.0)
        self.assertEqual(breakdown["BUPoints"], 0.0)
        self.assertEqual(breakdown["AccessPoints"], 0.0)

    def test_maximum_criticality(self):
        """Top executive workbook must achieve maximum 400.0 points."""
        row = pd.Series({
            "distinct_users_180d": 500,  # >= 500 -> 100
            "view_count_180d": 10000,    # >= 10000 -> 100
            "bu_reach_count": 10,        # >= 10 -> 100
            "days_since_last_access": 2, # <= 30 -> 100
            "is_certified": "True"
        })
        score, _, _ = compute_ard_criticality_score(row, self.cfg)
        self.assertEqual(score, 400.0)

    def test_criticality_boundary_below_and_above_threshold(self):
        """Test exact cutoff boundary at 250 threshold."""
        # Row 1: 40 + 40 + 40 + 40 = 160 pts (Low / Below 250 -> Retire)
        row_low = pd.Series({
            "distinct_users_180d": 15,    # 1-199 -> 40
            "view_count_180d": 45,        # 1-2499 -> 40
            "bu_reach_count": 1,          # 1-4 -> 40
            "days_since_last_access": 200 # 181-365 -> 40
        })
        score_low, _, _ = compute_ard_criticality_score(row_low, self.cfg)
        self.assertEqual(score_low, 160.0)

        # Row 2: 70 + 70 + 70 + 70 = 280 pts (Medium / >= 250 -> Migrate)
        row_mid = pd.Series({
            "distinct_users_180d": 250,   # 200-499 -> 70
            "view_count_180d": 3000,      # 2500-9999 -> 70
            "bu_reach_count": 6,          # 5-9 -> 70
            "days_since_last_access": 45  # 31-180 -> 70
        })
        score_mid, _, _ = compute_ard_criticality_score(row_mid, self.cfg)
        self.assertEqual(score_mid, 280.0)

    # -------------------------------------------------------------
    # 2. COMPLEXITY SCORING TESTS
    # -------------------------------------------------------------
    def test_minimum_complexity_low_tier(self):
        """Clean basic workbook must score minimum 90.0 points."""
        row = pd.Series({
            "data_connection_count": 1,     # <= 1 -> 10
            "custom_sql_count": 0,          # 0 -> 10
            "join_relationship_count": 0,   # <= 1 -> 10
            "data_blending_count": 0,
            "calculation_count": 2,         # < 5 -> 10
            "lod_calc_count": 0,
            "parameter_count": 0,           # < 3 -> 10
            "filter_count": 2,              # < 5 -> 10
            "sheet_count": 4,               # < 10 -> 10
            "dashboard_count": 1,           # <= 2 -> 10
            "story_count": 0,
            "action_count": 0,              # 0 -> 10
            "has_rls": "False"
        })
        score, _ = compute_ard_complexity_score(row, self.cfg)
        self.assertEqual(score, 90.0)

    def test_maximum_complexity_high_tier(self):
        """Massive complex workbook with Custom SQL, LODs, Blends & Dynamic RLS must score 900.0."""
        row = pd.Series({
            "data_connection_count": 5,     # 4+ -> 100
            "custom_sql_count": 4,          # 3+ -> 100
            "join_relationship_count": 12,  # 10+ -> 100
            "data_blending_count": 2,
            "calculation_count": 40,
            "lod_calc_count": 20,           # > 15 -> 100
            "parameter_count": 8,           # > 5 -> 100
            "filter_count": 15,             # > 10 -> 100
            "sheet_count": 25,              # 20+ -> 100
            "dashboard_count": 8,           # 7+ -> 100
            "story_count": 2,
            "action_count": 8,              # > 5 -> 100
            "has_rls": "True",
            "rls_type": "Dynamic Entitlement RLS" # -> 100
        })
        score, _ = compute_ard_complexity_score(row, self.cfg)
        self.assertEqual(score, 900.0)

    # -------------------------------------------------------------
    # 3. END-TO-END PIPELINE & DEDUPLICATION TESTS
    # -------------------------------------------------------------
    def test_synthetic_end_to_end_pipeline(self):
        """Tests full portfolio evaluation including duplicate detection, zombie detection & wave mapping."""
        synthetic_data = [
            # 1. High Criticality + Low Complexity -> Wave 1
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "FastTrack Master",
                "artifact_type": "Workbook", "owner_name": "Alice", "is_orphan": "False", "bu_sector": "Finance",
                "bu_reach_count": 4, "distinct_users_180d": 400, "view_count_180d": 2000,
                "last_access_date": "2026-09-15", "is_certified": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 1,
                "data_blending_count": 0, "calculation_count": 3, "lod_calc_count": 1,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 4, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 50
            },
            # 2. Structural Match of FastTrack Master (Same data + same canvas) -> Flagged for Business Review, NOT auto-retired
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "FastTrack Master (Copy)",
                "artifact_type": "Workbook", "owner_name": "Alice", "is_orphan": "False", "bu_sector": "Finance",
                "bu_reach_count": 4, "distinct_users_180d": 400, "view_count_180d": 2000,
                "last_access_date": "2026-09-15", "is_certified": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 1,
                "data_blending_count": 0, "calculation_count": 3, "lod_calc_count": 1,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 4, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 50
            },
            # 3. High Criticality + High Complexity -> Wave 3
            {
                "site_name": "Site B", "project_name": "Logistics", "workbook_name": "Supply Chain Monster",
                "artifact_type": "Workbook", "owner_name": "Bob", "is_orphan": "False", "bu_sector": "Supply Chain",
                "bu_reach_count": 3, "distinct_users_180d": 200, "view_count_180d": 1500,
                "last_access_date": "2026-09-10", "is_certified": "True",
                "data_connection_count": 4, "custom_sql_count": 3, "join_relationship_count": 12,
                "data_blending_count": 1, "calculation_count": 30, "lod_calc_count": 18,
                "parameter_count": 6, "filter_count": 12, "sheet_count": 22, "dashboard_count": 6,
                "story_count": 1, "action_count": 6, "has_rls": "True", "rls_type": "Dynamic Entitlement RLS", "extract_size_mb": 1200
            },
            # 4. Zombie Asset (Departed owner, daily refresh, 0 users) -> Wave 4 Retire
            {
                "site_name": "Site C", "project_name": "Sandbox", "workbook_name": "Zombie Hourly Extract",
                "artifact_type": "Workbook", "owner_name": "Ex-Employee", "is_orphan": "True", "bu_sector": "Sales",
                "bu_reach_count": 1, "distinct_users_180d": 0, "view_count_180d": 0,
                "last_access_date": "2025-05-01", "is_certified": "False", "refresh_frequency": "hourly",
                "data_connection_count": 2, "custom_sql_count": 1, "join_relationship_count": 4,
                "data_blending_count": 0, "calculation_count": 8, "lod_calc_count": 4,
                "parameter_count": 2, "filter_count": 4, "sheet_count": 6, "dashboard_count": 2,
                "story_count": 0, "action_count": 1, "has_rls": "False", "rls_type": "None", "extract_size_mb": 400
            }
        ]

        df_synthetic = pd.DataFrame(synthetic_data)
        df_readiness, df_summary = evaluate_tableau_ard_rationalization(df_synthetic, self.cfg)

        # Assertions
        self.assertEqual(len(df_readiness), 4)

        # 1. FastTrack Master -> Select for migration in Wave 1, Business review required (Group member)
        fast_row = df_readiness[df_readiness["Artifact"] == "FastTrack Master"].iloc[0]
        self.assertEqual(fast_row["ProposedDisposition"], "Select for migration")
        self.assertEqual(fast_row["ReviewStatus"], "Business review required")
        self.assertEqual(fast_row["SimilarityFlag"], "Potential structural duplicate")
        self.assertEqual(fast_row["ExecutionWave"], "Wave 1: Fast-Track Migrate")
        self.assertIn("Suggested Retained Copy", fast_row["RecommendationReason"])

        # 2. FastTrack Master (Copy) -> High criticality independent disposition (Select for migration), Business review required
        copy_row = df_readiness[df_readiness["Artifact"] == "FastTrack Master (Copy)"].iloc[0]
        self.assertEqual(copy_row["ProposedDisposition"], "Select for migration")
        self.assertEqual(copy_row["ReviewStatus"], "Business review required")
        self.assertEqual(copy_row["SimilarityFlag"], "Potential structural duplicate")
        self.assertEqual(copy_row["SuggestedRetainedAssetName"], "FastTrack Master")
        self.assertIn("FastTrack Master", copy_row["RecommendationReason"])

        # 3. Supply Chain Monster -> Select for migration in Wave 3 (Complex), Ready
        monster_row = df_readiness[df_readiness["Artifact"] == "Supply Chain Monster"].iloc[0]
        self.assertEqual(monster_row["ProposedDisposition"], "Select for migration")
        self.assertEqual(monster_row["ReviewStatus"], "Ready")
        self.assertEqual(monster_row["SimilarityFlag"], "Unique")
        self.assertEqual(monster_row["ExecutionWave"], "Wave 3: Complex Migrate")
        self.assertIn("Wave 3 / Complex", monster_row["RecommendationReason"])

        # 4. Zombie Asset -> Retire candidate, Ready
        zombie_row = df_readiness[df_readiness["Artifact"] == "Zombie Hourly Extract"].iloc[0]
        self.assertEqual(zombie_row["ProposedDisposition"], "Retire candidate")
        self.assertEqual(zombie_row["ReviewStatus"], "Ready")
        self.assertIn("Zombie Refresh", zombie_row["RecommendationReason"])


    # -------------------------------------------------------------
    # 4. GOLDEN DATASET & HUB-AND-SPOKE CLUSTER TESTS
    # -------------------------------------------------------------
    def test_golden_dataset_and_hub_spoke_cluster(self):
        """Tests that a central Published Data Source and its downstream spokes cluster correctly."""
        cluster_data = [
            # 1. Central Published Data Source (Golden Model)
            {
                "site_name": "Data Platform Site", "project_name": "Certified Models",
                "workbook_name": "Enterprise Commercial Gold Semantic Model", "artifact_type": "Published Data Source",
                "owner_name": "Data Governance", "is_orphan": "False", "bu_sector": "BI CoE",
                "bu_reach_count": 10, "distinct_users_180d": 650, "view_count_180d": 12000,
                "last_access_date": "2026-09-18", "is_certified": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 8,
                "data_blending_count": 0, "calculation_count": 55, "lod_calc_count": 8,
                "parameter_count": 0, "filter_count": 0, "sheet_count": 1, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "True", "rls_type": "Dynamic Entitlement RLS", "extract_size_mb": 620
            },
            # 2. Downstream Spoke 1 (Americas View)
            {
                "site_name": "Americas Site", "project_name": "Sales",
                "workbook_name": "Commercial Gold - Americas Executive View", "artifact_type": "Workbook",
                "owner_name": "Elena", "is_orphan": "False", "bu_sector": "Sales",
                "bu_reach_count": 5, "distinct_users_180d": 250, "view_count_180d": 3000,
                "last_access_date": "2026-09-15", "is_certified": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 8,
                "data_blending_count": 0, "calculation_count": 12, "lod_calc_count": 2,
                "parameter_count": 2, "filter_count": 5, "sheet_count": 8, "dashboard_count": 2,
                "story_count": 0, "action_count": 2, "has_rls": "True", "rls_type": "Dynamic Entitlement RLS", "extract_size_mb": 620
            },
            # 3. Downstream Spoke 2 (EMEA View)
            {
                "site_name": "EMEA Site", "project_name": "Sales",
                "workbook_name": "Commercial Gold - EMEA Executive View", "artifact_type": "Workbook",
                "owner_name": "Jean", "is_orphan": "False", "bu_sector": "Sales",
                "bu_reach_count": 5, "distinct_users_180d": 250, "view_count_180d": 3000,
                "last_access_date": "2026-09-14", "is_certified": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 8,
                "data_blending_count": 0, "calculation_count": 14, "lod_calc_count": 2,
                "parameter_count": 2, "filter_count": 5, "sheet_count": 8, "dashboard_count": 2,
                "story_count": 0, "action_count": 2, "has_rls": "True", "rls_type": "Dynamic Entitlement RLS", "extract_size_mb": 620
            }
        ]

        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(cluster_data), self.cfg)

        # 1. Verify SHA-256 Fingerprint matches across all 3
        hashes = df_readiness["DatasourceFingerprint"].unique()
        self.assertEqual(len(hashes), 1, "All 3 records must share the exact same datasource hash")

        # 2. Verify Shared Count is 3
        self.assertTrue((df_readiness["SharedDatasetCount"] == 3).all())

        # 3. Verify None are flagged as exact duplicates (different visual canvases)
        for _, r in df_readiness.iterrows():
            self.assertEqual(r["ProposedDisposition"], "Select for migration")
            self.assertIn("Shared Model Cluster (3 Reports)", r["DuplicateStatus"])

        # 4. Verify Golden Model attributes
        pds_row = df_readiness[df_readiness["Type"] == "Published Data Source"].iloc[0]
        self.assertEqual(pds_row["IsGoldenDataset"], "Yes")
        self.assertEqual(pds_row["DirectLakeCandidate"], "Yes")

    # -------------------------------------------------------------
    # 5. DATA QUALITY, NULLS & MALFORMED TELEMETRY ROBUSTNESS
    # -------------------------------------------------------------
    def test_missing_and_null_telemetry_fields(self):
        """Engine must handle None, NaN, missing dates and strings gracefully without crashing and flag Undecided."""
        malformed_row = pd.Series({
            "workbook_name": "Incomplete Telemetry Asset",
            "project_name": "Edge Project",
            "distinct_users_180d": None,
            "view_count_180d": np.nan,
            "bu_reach_count": None,
            "last_access_date": None,
            "days_since_last_access": np.nan,
            "is_certified": None,
            "data_connection_count": None,
            "custom_sql_count": np.nan,
            "join_relationship_count": None,
            "extract_size_mb": None,
            "has_rls": None
        })

        crit_score, crit_breakdown, evidence_gaps = compute_ard_criticality_score(malformed_row, self.cfg)
        comp_score, comp_breakdown = compute_ard_complexity_score(malformed_row, self.cfg)

        # Missing telemetry produces None for criticality and evidence gaps
        self.assertIsNone(crit_score)
        self.assertIn("missing_telemetry", evidence_gaps)
        self.assertIsInstance(comp_score, float)

        # Full pipeline evaluation should produce Undecided disposition and Insufficient evidence review status
        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame([malformed_row.to_dict()]), self.cfg)
        self.assertEqual(len(df_readiness), 1)
        res_row = df_readiness.iloc[0]
        self.assertEqual(res_row["ProposedDisposition"], "Undecided")
        self.assertEqual(res_row["ReviewStatus"], "Insufficient evidence")
        self.assertEqual(res_row["ExecutionWave"], "Unassigned")
        self.assertIn("Insufficient Evidence", res_row["RecommendationReason"])

    # -------------------------------------------------------------
    # 6. WORKSPACE ROLLUP & GOVERNANCE SAFEGUARD TESTS
    # -------------------------------------------------------------
    def test_workspace_golden_override_safeguard(self):
        """A container with low usage but containing a Golden dataset must apply GoldenOverrideApplied."""
        ws_data = [
            # Certified golden model with high criticality
            {
                "site_name": "Central Site", "project_name": "Hub Project",
                "workbook_name": "Central Golden Model", "artifact_type": "Published Data Source",
                "bu_reach_count": 10, "distinct_users_180d": 600, "view_count_180d": 12000,
                "last_access_date": "2026-09-18", "is_certified": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 2,
                "data_blending_count": 0, "calculation_count": 10, "lod_calc_count": 2,
                "parameter_count": 0, "filter_count": 0, "sheet_count": 1, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 100
            }
        ]
        _, df_summary = evaluate_tableau_ard_rationalization(pd.DataFrame(ws_data), self.cfg)
        self.assertEqual(len(df_summary), 1)
        ws_row = df_summary.iloc[0]
        self.assertGreaterEqual(ws_row["GoldenCount"], 1)

    # -------------------------------------------------------------
    # 7. CONFIGURABLE LOOKBACK WINDOW TEST
    # -------------------------------------------------------------
    def test_configurable_lookback_window(self):
        """Verifies that changing the lookback days dynamically affects criticality."""
        row = pd.Series({
            "distinct_users_180d": 100,
            "view_count_180d": 500,
            "bu_reach_count": 2,
            "days_since_last_access": 50
        })

        cfg_30d = {
            "strategy_mode": "tableau_ard_lift_and_shift",
            "ard_settings": {"usage_lookback_days": 30, "criticality_threshold": 250.0}
        }
        cfg_365d = {
            "strategy_mode": "tableau_ard_lift_and_shift",
            "ard_settings": {"usage_lookback_days": 365, "criticality_threshold": 250.0}
        }

        score_30, _, _ = compute_ard_criticality_score(row, cfg_30d)
        score_365, _, _ = compute_ard_criticality_score(row, cfg_365d)

        self.assertIsInstance(score_30, float)
        self.assertIsInstance(score_365, float)

    # -------------------------------------------------------------
    # 8. NEGATIVE INVARIANT: GOVERNANCE RANK CANNOT OVERRIDE EVIDENCE
    # -------------------------------------------------------------
    def test_higher_governance_rank_cannot_override_non_exact_evidence(self):
        """
        CRITICAL ARCHITECTURAL INVARIANT:
        Even if Workbook A has huge governance authority (Production, 500 users, 10,000 views)
        and identical sheet/dashboard layout to Workbook B, if Workbook B has differing data
        connections or Custom SQL, Workbook B CANNOT be retired as an exact duplicate.
        Step 1 evidence must classify it as STRUCTURAL_CLONE_REVIEW, requiring human review.
        """
        records = [
            # High Governance Production Workbook A
            {
                "site_name": "Finance Site", "project_name": "Production Finance",
                "workbook_name": "Corp P&L Standard", "artifact_type": "Workbook",
                "container_type": "Project", "governance_tier": "Production",
                "bu_sector": "Finance", "bu_reach_count": 5,
                "distinct_users_180d": 500, "view_count_180d": 10000,
                "last_access_date": "2026-09-18", "is_certified": "False", "uses_certified_datasource": "True",
                # Data Model A: Standard connection, 0 Custom SQL
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 2,
                "data_blending_count": 0, "calculation_count": 15, "lod_calc_count": 2,
                "parameter_count": 3, "filter_count": 4, "sheet_count": 10, "dashboard_count": 3,
                "story_count": 0, "action_count": 2, "has_rls": "False", "rls_type": "None", "extract_size_mb": 150
            },
            # Departmental Workbook B: Identical canvas (10 sheets, 3 dashboards, 3 params, 4 filters, 2 actions)
            # BUT differing data model (3 connections, 2 custom SQLs)
            {
                "site_name": "Regional Site", "project_name": "Departmental Reports",
                "workbook_name": "Corp P&L Custom Adjustments", "artifact_type": "Workbook",
                "container_type": "Project", "governance_tier": "Departmental",
                "bu_sector": "Finance", "bu_reach_count": 2,
                "distinct_users_180d": 80, "view_count_180d": 600,
                "last_access_date": "2026-09-18", "is_certified": "False", "uses_certified_datasource": "False",
                # Data Model B: 3 connections, 2 Custom SQL
                "data_connection_count": 3, "custom_sql_count": 2, "join_relationship_count": 6,
                "data_blending_count": 0, "calculation_count": 15, "lod_calc_count": 2,
                "parameter_count": 3, "filter_count": 4, "sheet_count": 10, "dashboard_count": 3,
                "story_count": 0, "action_count": 2, "has_rls": "False", "rls_type": "None", "extract_size_mb": 250
            }
        ]

        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(records), self.cfg)

        row_a = df_readiness[df_readiness["Artifact"] == "Corp P&L Standard"].iloc[0]
        row_b = df_readiness[df_readiness["Artifact"] == "Corp P&L Custom Adjustments"].iloc[0]

        # Both must have identical report canvas hash
        self.assertEqual(row_a["ReportCanvasHash"], row_b["ReportCanvasHash"])
        # But different data fingerprints
        self.assertNotEqual(row_a["DatasourceFingerprint"], row_b["DatasourceFingerprint"])

        # Invariant: Workbook B MUST NOT be "Retire Candidate" or "EXACT_DUPLICATE_CONFIRMED"
        self.assertEqual(row_b["ReviewStatus"], "Business review required")
        self.assertEqual(row_b["SimilarityFlag"], "Potential structural clone (different data model)")

    # -------------------------------------------------------------
    # 9. PERSONAL SPACE CANONICAL PENALTY TEST
    # -------------------------------------------------------------
    def test_personal_space_canonical_penalty(self):
        """
        Verifies that between two matching workbooks, the Production copy is suggested as the
        retained copy, while the Personal Space copy receives an independent disposition with review flag.
        """
        records = [
            # 1. Personal Space copy (low criticality)
            {
                "site_name": "Sales Site", "project_name": "Personal Space",
                "workbook_name": "Executive Sales Deck (My Draft)", "artifact_type": "Workbook",
                "container_type": "Personal Space", "governance_tier": "Personal", "is_personal_space": "True",
                "bu_sector": "Sales", "bu_reach_count": 1,
                "distinct_users_180d": 10, "view_count_180d": 20,
                "last_access_date": "2026-09-18", "is_certified": "False", "uses_certified_datasource": "False",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 2,
                "data_blending_count": 0, "calculation_count": 5, "lod_calc_count": 0,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 5, "dashboard_count": 2,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 80
            },
            # 2. Production Project copy (Identical data & canvas)
            {
                "site_name": "Sales Site", "project_name": "Enterprise Production",
                "workbook_name": "Executive Sales Deck", "artifact_type": "Workbook",
                "container_type": "Project", "governance_tier": "Production", "is_personal_space": "False",
                "bu_sector": "Sales", "bu_reach_count": 4,
                "distinct_users_180d": 350, "view_count_180d": 1800,
                "last_access_date": "2026-09-18", "is_certified": "False", "uses_certified_datasource": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 2,
                "data_blending_count": 0, "calculation_count": 5, "lod_calc_count": 0,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 5, "dashboard_count": 2,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 80
            }
        ]

        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(records), self.cfg)

        prod_row = df_readiness[df_readiness["Artifact"] == "Executive Sales Deck"].iloc[0]
        pers_row = df_readiness[df_readiness["Artifact"] == "Executive Sales Deck (My Draft)"].iloc[0]

        # Production is Canonical Master / Suggested Retained Copy
        self.assertEqual(prod_row["ProposedDisposition"], "Select for migration")
        self.assertEqual(prod_row["ReviewStatus"], "Business review required")
        self.assertEqual(prod_row["SuggestedRetainedAssetName"], "Executive Sales Deck")

        # Personal Space has independent low disposition (Retire candidate) + Business review required + Suggested Retained pointer
        self.assertEqual(pers_row["ProposedDisposition"], "Retire candidate")
        self.assertEqual(pers_row["ReviewStatus"], "Business review required")
        self.assertEqual(pers_row["SuggestedRetainedAssetName"], "Executive Sales Deck")

    # -------------------------------------------------------------
    # 10. SEGREGATED CANONICAL RANKING FUNCTIONS
    # -------------------------------------------------------------
    def test_segregated_canonical_ranking_functions(self):
        """Verifies mathematical ranking calculation for workbooks and published data sources."""
        wb_prod = pd.Series({
            "container_type": "Project", "governance_tier": "Production",
            "uses_certified_datasource": "True", "is_orphan": "False",
            "subscription_count": 10, "distinct_users_180d": 100, "view_count_180d": 500
        })
        wb_personal = pd.Series({
            "container_type": "Personal Space", "governance_tier": "Personal",
            "uses_certified_datasource": "False", "is_orphan": "False",
            "subscription_count": 0, "distinct_users_180d": 10, "view_count_180d": 50
        })

        rank_prod = calculate_workbook_canonical_rank(wb_prod, self.cfg)
        rank_pers = calculate_workbook_canonical_rank(wb_personal, self.cfg)

        self.assertGreater(rank_prod, 1500.0)
        self.assertLess(rank_pers, 0.0)  # -800 penalty

        pds_cert = pd.Series({
            "governance_tier": "Production", "is_certified": "True",
            "is_orphan": "False", "subscription_count": 5, "distinct_users_180d": 80
        })
        pds_uncert = pd.Series({
            "governance_tier": "Departmental", "is_certified": "False",
            "is_orphan": "False", "subscription_count": 0, "distinct_users_180d": 10
        })

        pds_cert_rank = calculate_datasource_canonical_rank(pds_cert, self.cfg)
        pds_uncert_rank = calculate_datasource_canonical_rank(pds_uncert, self.cfg)

        self.assertGreater(pds_cert_rank, 2500.0)
        self.assertLess(pds_uncert_rank, 1000.0)

    # -------------------------------------------------------------
    # 11. INSUFFICIENT EVIDENCE PRECEDENCE OVER SIMILARITY
    # -------------------------------------------------------------
    def test_insufficient_evidence_precedence_over_similarity(self):
        """
        An asset with missing telemetry AND a matching structural clone MUST receive
        review_status = 'Insufficient evidence' and proposed_disposition = 'Undecided'.
        Group similarity processing must NEVER overwrite Insufficient evidence.
        """
        records = [
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "Known Asset",
                "artifact_type": "Workbook", "distinct_users_180d": 300, "view_count_180d": 1200,
                "bu_reach_count": 3, "last_access_date": "2026-09-15", "is_certified": "True",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 1,
                "data_blending_count": 0, "calculation_count": 5, "lod_calc_count": 1,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 4, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 50
            },
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "Unobserved Asset",
                "artifact_type": "Workbook", "distinct_users_180d": None, "view_count_180d": None,
                "bu_reach_count": None, "last_access_date": None, "is_certified": "False",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 1,
                "data_blending_count": 0, "calculation_count": 5, "lod_calc_count": 1,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 4, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 50
            }
        ]

        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(records), self.cfg)
        unobs_row = df_readiness[df_readiness["Artifact"] == "Unobserved Asset"].iloc[0]

        # Insufficient evidence takes strict precedence
        self.assertEqual(unobs_row["ReviewStatus"], "Insufficient evidence")
        self.assertEqual(unobs_row["ProposedDisposition"], "Undecided")
        self.assertEqual(unobs_row["ExecutionWave"], "Unassigned")
        self.assertEqual(unobs_row["SimilarityFlag"], "Potential structural duplicate")

    # -------------------------------------------------------------
    # 12. MINIMUM METADATA GATING FOR SIMILARITY SCREENING
    # -------------------------------------------------------------
    def test_minimum_metadata_gating_for_similarity(self):
        """
        Assets lacking minimum structural metadata (sheets, calcs, connections) must not be grouped
        by empty keys. They must be tagged 'Similarity not assessed — insufficient metadata'.
        """
        records = [
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "Empty Metadata WB 1",
                "artifact_type": "Workbook", "distinct_users_180d": 100, "view_count_180d": 500,
                "bu_reach_count": 2, "last_access_date": "2026-09-15", "is_certified": "False",
                "data_connection_count": None, "custom_sql_count": None, "join_relationship_count": None,
                "sheet_count": None, "calculation_count": None
            },
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "Empty Metadata WB 2",
                "artifact_type": "Workbook", "distinct_users_180d": 150, "view_count_180d": 600,
                "bu_reach_count": 2, "last_access_date": "2026-09-15", "is_certified": "False",
                "data_connection_count": None, "custom_sql_count": None, "join_relationship_count": None,
                "sheet_count": None, "calculation_count": None
            }
        ]

        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(records), self.cfg)
        wb1 = df_readiness[df_readiness["Artifact"] == "Empty Metadata WB 1"].iloc[0]
        wb2 = df_readiness[df_readiness["Artifact"] == "Empty Metadata WB 2"].iloc[0]

        self.assertEqual(wb1["SimilarityFlag"], "Similarity not assessed — insufficient metadata")
        self.assertEqual(wb2["SimilarityFlag"], "Similarity not assessed — insufficient metadata")

    # -------------------------------------------------------------
    # 13. DYNAMIC THRESHOLD PROPAGATION IN RATIONALE
    # -------------------------------------------------------------
    def test_dynamic_threshold_in_recommendation_reason(self):
        """Rationale text must faithfully reflect the configured threshold, not a hardcoded 250."""
        custom_cfg = {
            "strategy_mode": "tableau_ard_lift_and_shift",
            "ard_settings": {
                "criticality_threshold": 180.0,
                "complexity_low_limit": 350.0,
                "complexity_medium_limit": 650.0,
                "duplicate_detection": True
            }
        }
        records = [{
            "site_name": "Site A", "project_name": "Finance", "workbook_name": "Borderline Asset",
            "artifact_type": "Workbook", "distinct_users_180d": 15, "view_count_180d": 45,
            "bu_reach_count": 1, "days_since_last_access": 200, "is_certified": "False",
            "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 1,
            "data_blending_count": 0, "calculation_count": 3, "lod_calc_count": 1,
            "parameter_count": 1, "filter_count": 2, "sheet_count": 4, "dashboard_count": 1,
            "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 50
        }]

        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(records), custom_cfg)
        reason = df_readiness.iloc[0]["RecommendationReason"]
        self.assertIn("180 threshold", reason)
        self.assertNotIn("250", reason)

    # -------------------------------------------------------------
    # 14. TARGETED VERIFICATION: CONTRADICTORY EXPLANATIONS FOR LOW CRITICALITY RETAINED COPIES
    # -------------------------------------------------------------
    def test_low_criticality_suggested_retained_copy_explanation(self):
        """A suggested retained copy with low criticality (< threshold) must receive 'Retire candidate' and a consistent rationale."""
        records = [
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "LowCrit Clone Master",
                "artifact_type": "Workbook", "distinct_users_180d": 2, "view_count_180d": 10,
                "bu_reach_count": 1, "days_since_last_access": 200, "is_certified": "False",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 1,
                "data_blending_count": 0, "calculation_count": 3, "lod_calc_count": 1,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 4, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 50
            },
            {
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "LowCrit Clone Duplicate",
                "artifact_type": "Workbook", "distinct_users_180d": 1, "view_count_180d": 5,
                "bu_reach_count": 1, "days_since_last_access": 250, "is_certified": "False",
                "data_connection_count": 1, "custom_sql_count": 0, "join_relationship_count": 1,
                "data_blending_count": 0, "calculation_count": 3, "lod_calc_count": 1,
                "parameter_count": 1, "filter_count": 2, "sheet_count": 4, "dashboard_count": 1,
                "story_count": 0, "action_count": 0, "has_rls": "False", "rls_type": "None", "extract_size_mb": 50
            }
        ]
        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(records), self.cfg)
        master_row = df_readiness[df_readiness["Artifact"] == "LowCrit Clone Master"].iloc[0]

        self.assertEqual(master_row["ProposedDisposition"], "Retire candidate")
        self.assertNotIn("Select for migration", master_row["RecommendationReason"])
        self.assertIn("Retire Candidate", master_row["RecommendationReason"])

    # -------------------------------------------------------------
    # 15. TARGETED VERIFICATION: PARTIAL METADATA GATING
    # -------------------------------------------------------------
    def test_partial_metadata_does_not_match_observed_zero(self):
        """An asset with partially missing metadata (e.g. csql=None) must NOT hash-match an observed zero-count asset."""
        row_partial = pd.Series({
            "data_connection_count": 1,
            "custom_sql_count": None,  # unobserved
            "join_relationship_count": 0
        })
        row_observed = pd.Series({
            "data_connection_count": 1,
            "custom_sql_count": 0,     # observed 0
            "join_relationship_count": 0
        })

        fp_partial = compute_dataset_fingerprint_sha256(row_partial)
        fp_observed = compute_dataset_fingerprint_sha256(row_observed)

        self.assertEqual(fp_partial, "", "Partial metadata must yield empty fingerprint")
        self.assertNotEqual(fp_observed, "")
        self.assertNotEqual(fp_partial, fp_observed)

    # -------------------------------------------------------------
    # 16. TARGETED VERIFICATION: MISSING/NONE ASSET IDS DO NOT COLLIDE
    # -------------------------------------------------------------
    def test_missing_asset_ids_do_not_collide_to_literal_none(self):
        """Missing or None/NaN asset IDs must generate distinct fallback IDs and never literal 'None'."""
        records = [
            {
                "asset_id": None,
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "WB Alpha",
                "artifact_type": "Workbook", "distinct_users_180d": 100, "view_count_180d": 500,
                "bu_reach_count": 2, "last_access_date": "2026-09-15"
            },
            {
                "asset_id": np.nan,
                "site_name": "Site A", "project_name": "Finance", "workbook_name": "WB Beta",
                "artifact_type": "Workbook", "distinct_users_180d": 120, "view_count_180d": 600,
                "bu_reach_count": 2, "last_access_date": "2026-09-15"
            }
        ]
        df_readiness, _ = evaluate_tableau_ard_rationalization(pd.DataFrame(records), self.cfg)
        id1 = df_readiness.iloc[0]["AssetId"]
        id2 = df_readiness.iloc[1]["AssetId"]

        self.assertNotEqual(id1.strip().lower(), "none")
        self.assertNotEqual(id1.strip().lower(), "nan")
        self.assertNotEqual(id2.strip().lower(), "none")
        self.assertNotEqual(id2.strip().lower(), "nan")
        self.assertNotEqual(id1, id2, "Fallback IDs must be unique across assets")


if __name__ == "__main__":
    unittest.main()


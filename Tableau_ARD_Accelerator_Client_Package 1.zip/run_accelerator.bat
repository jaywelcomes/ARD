@echo off
SETLOCAL EnableDelayedExpansion
TITLE "BI Rationalization & Migration Planning Accelerator"
echo ================================================================
echo       BI Rationalization ^& Migration Planning Accelerator        
echo ================================================================
echo.

:: 1. Check Python
echo [1/5] Checking Python environment...
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python 3.9+ from Software Center or python.org.
    pause
    exit /b 1
)

:: 2. Install Python Dependencies
echo [2/5] Ensuring Python requirements are installed...
python -m pip install -r "%~dp0requirements.txt" --quiet
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] Pip install had issues. Attempting verbose install...
    python -m pip install -r "%~dp0requirements.txt"
)

:: 3. Check Node.js and Install Frontend Dependencies
echo [3/4] Checking Node.js and Frontend dependencies...
node --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please install Node.js 18+ from Software Center or nodejs.org.
    pause
    exit /b 1
)

if not exist "%~dp0frontend\node_modules" (
    echo [INFO] First-time setup detected: Installing frontend packages...
    cd /d "%~dp0frontend"
    call npm install
    cd /d "%~dp0"
)

:: 4. Launch Backend & Frontend Servers
echo [4/4] Launching FastAPI Backend (Port 8000) and Next.js UI (Port 3000)...
start "Rationalization API Backend" cmd /k "cd /d ""%~dp0"" && python server.py"
start "Rationalization Next.js UI" cmd /k "cd /d ""%~dp0frontend"" && npm run dev"

echo.
echo ================================================================
echo  All Services Successfully Launched!
echo  - Web Application:   http://localhost:3000
echo  - API Documentation: http://127.0.0.1:8000/docs
echo ================================================================
echo.
pause

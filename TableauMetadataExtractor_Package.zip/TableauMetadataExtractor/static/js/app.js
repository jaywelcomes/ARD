// ==================== State Management ====================
const state = {
    content: [],
    filteredContent: [],
    originalContent: [], // Store original unfiltered content
    projects: [],
    deepData: {
        custom_sql: [],
        calculations: [],
        lineage: [],
        connections: [],
        tables: [],
        actions: [],
        columns: [],
        custom_visuals: [],
        object_tables_summary: [],
        lineage_summary: [],
        lineage_workbooks: [],
        lineage_datasources: [],
        lineage_flows: [],
        lineage_custom_sql: [],
        lineage_table_matrix: [],
        lineage_impact: []
    },
    originalDeepData: { // Store original unfiltered deep data
        custom_sql: [],
        calculations: [],
        lineage: [],
        connections: [],
        tables: [],
        actions: [],
        columns: [],
        custom_visuals: [],
        object_tables_summary: [],
        lineage_summary: [],
        lineage_workbooks: [],
        lineage_datasources: [],
        lineage_flows: [],
        lineage_custom_sql: [],
        lineage_table_matrix: [],
        lineage_impact: []
    },
    currentDeepView: 'sql',
    lineageDataset: 'lineage_summary',
    deepCounts: null,
    lineageRun: false,
    currentAdminView: 'users',
    currentAdminData: [],
    currentJobId: null,
    currentProjectName: 'All Projects',
    savedFiles: [],
    pagination: {
        content: { page: 1, perPage: 10 },
        admin: { page: 1, perPage: 10 },
        deep: { page: 1, perPage: 10 },
        analytics: { page: 1, perPage: 9999 }
    },
    // Usage & Criticality Analytics
    analytics: {
        jobId: null,
        data: null,
        currentTab: 'workbooks',
        filteredData: [],
        sort: {
            column: null,
            direction: 'asc'
        },
        kpiFilter: null,  // For KPI card filtering (active_7d, active_30d, dormant, total_views)
        userFilter: null, // For Users tab filtering
        repositoryConfig: null,  // For Tableau Server repository connection
        usageDataSource: 'rest'  // 'rest', 'repository', or 'admin_insights'
    },
    // Metadata GraphQL
    graphql: {
        results: {},           // Stores results keyed by query type: { published_datasources: [...], workbooks: [...] }
        currentView: null,     // Currently selected query type to display
        filteredData: [],      // Filtered data for current view
        page: 1,
        perPage: 10,
        sortColumn: null,
        sortDirection: 'asc',
        projects: []           // List of projects for filter dropdown
    }
};

// ==================== Initialization ====================
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuth();
    initializeEventListeners();
    initializeFilterSystem();
    loadSavedFiles();

    // Load dashboard data sequentially to avoid race conditions
    try {
        await loadProjects();
        await loadDashboardStats();
        await loadContent();
    } catch (error) {
        console.error('Dashboard initialization error:', error);
    }
});

async function checkAuth() {
    const config = sessionStorage.getItem('tableauConfig');
    if (!config) {
        window.location.href = '/';
        return;
    }
    const configData = JSON.parse(config);
    const siteName = configData.site_name || 'Default';

    // Update footer with connection info
    updateFooterInfo(configData);

    // Fetch system username
    try {
        const result = await apiCall('system_user');
        if (result.success) {
            document.getElementById('userAvatar').textContent = result.initials;
            document.getElementById('userName').textContent = result.username;
            document.getElementById('welcomeName').textContent = result.username;
        } else {
            document.getElementById('userAvatar').textContent = siteName.substring(0, 2).toUpperCase();
            document.getElementById('userName').textContent = siteName;
            document.getElementById('welcomeName').textContent = siteName;
        }
    } catch (error) {
        document.getElementById('userAvatar').textContent = siteName.substring(0, 2).toUpperCase();
        document.getElementById('userName').textContent = siteName;
        document.getElementById('welcomeName').textContent = siteName;
    }
}

function updateFooterInfo(config) {
    // Update server URL
    const serverUrlEl = document.getElementById('footerServerUrl');
    if (serverUrlEl && config.server_url) {
        // Extract hostname from URL
        try {
            const url = new URL(config.server_url);
            serverUrlEl.textContent = url.hostname;
            serverUrlEl.title = config.server_url;
        } catch {
            serverUrlEl.textContent = config.server_url;
        }
    }

    // Update site name
    const siteNameEl = document.getElementById('footerSiteName');
    if (siteNameEl) {
        siteNameEl.textContent = config.site_name || 'Default';
    }

    // Update last login time
    const lastLoginEl = document.getElementById('footerLastLogin');
    if (lastLoginEl) {
        const now = new Date();
        const timeStr = now.toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        lastLoginEl.textContent = timeStr;
    }
}

// ==================== Event Listeners ====================
function initializeEventListeners() {
    // Navigation
    document.querySelectorAll('.navbar-menu a[data-section]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            showSection(e.target.dataset.section);
        });
    });

    // Deep Analysis dropdown
    document.querySelectorAll('.dropdown-menu a[data-view]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const view = link.dataset.view;
            console.log('Dropdown clicked, view:', view);
            const deepViews = ['sql', 'calculations', 'lineage', 'connections', 'tables', 'object_tables', 'lineage_info', 'actions', 'columns', 'custom_visuals'];
            const adminViews = ['users', 'groups', 'schedules', 'jobs'];

            if (view === 'single_workbook') {
                showSection('singleworkbook');
            } else if (deepViews.includes(view)) {
                showSection('deep');
                showDeepView(view);
            } else if (adminViews.includes(view)) {
                showSection('administration');
                loadAdminView(view);
            }
        });
    });

    // Analytics link in dropdown
    document.querySelectorAll('.dropdown-menu a[data-section="analytics"]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            showSection('analytics');
        });
    });

    // Deep Analysis tabs - use event delegation for reliability
    const tabsContainer = document.querySelector('#deepSection .tabs');
    if (tabsContainer) {
        tabsContainer.addEventListener('click', function(e) {
            const btn = e.target.closest('.tab-btn');
            if (btn) {
                e.preventDefault();
                e.stopPropagation();
                const tab = btn.dataset.tab;
                console.log('Tab clicked:', tab);
                showDeepView(tab);
            }
        });
    }

    // Also add direct onclick handlers as backup
    document.querySelectorAll('#deepSection .tab-btn').forEach(btn => {
        btn.onclick = function(e) {
            e.preventDefault();
            const tab = this.dataset.tab;
            console.log('Tab onclick:', tab);
            showDeepView(tab);
        };
    });

    // Quick actions
    document.getElementById('btnDeepExtract').addEventListener('click', startDeepExtraction);
    document.getElementById('btnExportDeep').addEventListener('click', exportDeepResults);
    document.getElementById('btnRefreshStats').addEventListener('click', loadDashboardStats);
    document.getElementById('btnSaveResults').addEventListener('click', saveExtractionResults);
    document.getElementById('btnLoadResults').addEventListener('click', () => document.getElementById('fileInput').click());
    document.getElementById('fileInput').addEventListener('change', handleFileUpload);

    // Content
    document.getElementById('contentSearch').addEventListener('input', debounce(filterContent, 300));
    document.getElementById('contentTypeFilter').addEventListener('change', filterContent);
    document.getElementById('contentPerPage').addEventListener('change', (e) => {
        state.pagination.content.perPage = parseInt(e.target.value);
        state.pagination.content.page = 1;
        renderContentTable();
    });
    document.getElementById('btnExportContent').addEventListener('click', () => exportToExcel(state.filteredContent, 'content'));

    // Content Type Chips
    document.querySelectorAll('.type-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            // Update active state
            document.querySelectorAll('.type-chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            // Update dropdown to match
            const type = chip.dataset.type;
            document.getElementById('contentTypeFilter').value = type;
            // Filter content
            filterContent();
        });
    });

    // Admin
    document.getElementById('adminSearch').addEventListener('input', debounce(renderAdminTable, 300));
    document.getElementById('adminPerPage').addEventListener('change', (e) => {
        state.pagination.admin.perPage = parseInt(e.target.value);
        state.pagination.admin.page = 1;
        renderAdminTable();
    });
    document.getElementById('btnExportAdmin').addEventListener('click', () => exportToExcel(state.currentAdminData, state.currentAdminView));

    // Deep
    document.getElementById('deepSearch').addEventListener('input', debounce(renderDeepTable, 300));
    document.getElementById('deepPerPage').addEventListener('change', (e) => {
        state.pagination.deep.perPage = parseInt(e.target.value);
        state.pagination.deep.page = 1;
        renderDeepTable();
    });
    document.getElementById('btnExportDeepData').addEventListener('click', () => {
        const data = getDeepViewData();
        exportToExcel(data, state.currentDeepView);
    });
}

// ==================== Navigation ====================
function showSection(section) {
    document.querySelectorAll('.navbar-menu a').forEach(a => a.classList.remove('active'));
    document.querySelector(`.navbar-menu a[data-section="${section === 'singleworkbook' ? 'deep' : section}"]`)?.classList.add('active');
    document.querySelectorAll('.section-content').forEach(s => s.classList.add('hidden'));
    document.getElementById(`${section}Section`)?.classList.remove('hidden');

    // Auto-restore analytics data when navigating to analytics section
    if (section === 'analytics' && !state.analytics.data) {
        restoreAnalyticsFromStorage();
    }

    // Load projects for GraphQL filter when navigating to graphql section
    if (section === 'graphql' && state.graphql.projects.length === 0) {
        loadGraphqlProjects();
    }
}

function showDeepView(view) {
    console.log('showDeepView called with:', view);
    state.currentDeepView = view;

    // Update tab styling
    document.querySelectorAll('#deepSection .tab-btn').forEach(b => {
        b.classList.remove('active');
        if (b.dataset.tab === view) {
            b.classList.add('active');
        }
    });

    // Update title and icon based on view
    const titles = {
        'sql': 'Custom SQL',
        'calculations': 'Calculations',
        'lineage': 'Lineage',
        'connections': 'Connections',
        'tables': 'Tables',
        'object_tables': 'Tables Used',
        'lineage_info': 'Lineage Info',
        'actions': 'Actions',
        'columns': 'Columns',
        'custom_visuals': 'Custom Visuals'
    };

    const icons = {
        'sql': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/>',
        'calculations': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>',
        'lineage': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>',
        'connections': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>',
        'tables': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>',
        'lineage_info': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>',
        'object_tables': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>',
        'actions': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"/>',
        'columns': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2"/>',
        'custom_visuals': '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"/>'
    };

    const titleEl = document.querySelector('#deepTableTitle span');
    const iconEl = document.querySelector('#deepTableTitle svg');

    if (titleEl) {
        titleEl.textContent = titles[view] || view;
    }
    if (iconEl) {
        iconEl.innerHTML = icons[view] || icons['sql'];
    }

    updateLineageToolbar(view);
    state.pagination.deep.page = 1;
    renderDeepTable();
}

// ==================== Loading ====================
function showLoading(message = 'Loading...') {
    document.getElementById('loadingText').textContent = message;
    document.getElementById('loadingOverlay').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.add('hidden');
}

// ==================== API Calls ====================
async function apiCall(endpoint, method = 'GET', data = null, retries = 2) {
    const options = {
        method,
        headers: { 'Content-Type': 'application/json' }
    };
    if (data) options.body = JSON.stringify(data);

    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const response = await fetch(`/api/${endpoint}`, options);
            if (!response.ok && attempt < retries) {
                console.warn(`API call to ${endpoint} failed (attempt ${attempt + 1}), retrying...`);
                await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
                continue;
            }
            return response.json();
        } catch (error) {
            if (attempt < retries) {
                console.warn(`API call to ${endpoint} error (attempt ${attempt + 1}), retrying...`, error);
                await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
                continue;
            }
            throw error;
        }
    }
}

async function loadDashboardStats() {
    showLoading('Loading statistics...');
    try {
        const result = await apiCall('dashboard_stats');
        if (result.success) {
            const stats = result.data;
            // Main stats
            document.getElementById('statWorkbooks').textContent = stats.workbooks || 0;
            document.getElementById('statDatasources').textContent = stats.datasources || 0;
            document.getElementById('statViews').textContent = stats.views || 0;
            document.getElementById('statUsers').textContent = stats.users || 0;
            document.getElementById('statProjects').textContent = stats.projects || 0;
            document.getElementById('statFlows').textContent = stats.flows || 0;
            document.getElementById('statGroups').textContent = stats.groups || 0;
            document.getElementById('statSchedules').textContent = stats.schedules || 0;

            // Deep analysis stats - show 0 if extraction was run but empty, otherwise show indicator
            const customSql = stats.custom_sql_count;
            const calculations = stats.calculations_count;
            const lineage = stats.lineage_edges;

            document.getElementById('statCustomSQL').textContent = customSql > 0 ? customSql : '0';
            document.getElementById('statCalculations').textContent = calculations > 0 ? calculations : '0';
            document.getElementById('statLineage').textContent = lineage > 0 ? lineage : '0';
            document.getElementById('statConnections').textContent = '0';

            // Update extraction preview counts
            updateExtractionPreview(stats);
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
    hideLoading();
}

// Update extraction preview counts
function updateExtractionPreview(stats) {
    const previewWorkbooks = document.getElementById('previewWorkbooks');
    const previewDatasources = document.getElementById('previewDatasources');
    const previewFlows = document.getElementById('previewFlows');
    const previewViews = document.getElementById('previewViews');

    if (previewWorkbooks) previewWorkbooks.textContent = stats.workbooks || 0;
    if (previewDatasources) previewDatasources.textContent = stats.datasources || 0;
    if (previewFlows) previewFlows.textContent = stats.flows || 0;
    if (previewViews) previewViews.textContent = stats.views || 0;
}

async function refreshDashboardStats() {
    const btn = document.getElementById('btnRefreshStats');
    const originalText = btn.innerHTML;
    btn.innerHTML = `<svg class="icon-svg spinning" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width: 16px; height: 16px;">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
    </svg> Refreshing...`;
    btn.disabled = true;

    try {
        await loadDashboardStats();
        await loadContent();
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

async function loadContent() {
    showLoading('Fetching metadata...');
    try {
        const result = await apiCall('fetch_metadata');
        if (result.success) {
            state.originalContent = result.data; // Store original unfiltered
            state.content = result.data;
            state.filteredContent = [...state.content];
            state.pagination.content.page = 1;
            renderContentTable();
            updateContentTypeChipCounts();
        }
    } catch (error) {
        console.error('Error loading content:', error);
    }
    hideLoading();
}

function updateContentTypeChipCounts() {
    // Use globally filtered content for chip counts
    let baseContent = state.originalContent.length > 0 ? state.originalContent : state.content;

    // Apply global filter context to get accurate counts
    const filterCtx = window.currentFilterContext || {};
    const globalSearchTerms = filterCtx.search_terms || [];
    const projectIds = filterCtx.project_ids || [];
    const contentTypes = filterCtx.content_types || [];
    const objectIds = filterCtx.object_ids || [];

    // Apply project filter
    if (projectIds.length > 0 && state.projects.length > 0) {
        const projectNames = new Set();
        projectIds.forEach(pid => {
            const proj = state.projects.find(p => p.id === pid);
            if (proj) projectNames.add(proj.name);
        });
        baseContent = baseContent.filter(item =>
            item.Type === 'Site' ||
            (item.Type === 'Project' && projectNames.has(item.Name)) ||
            projectNames.has(item.Parent)
        );
    }

    // Apply global content type filter (for chip counts, don't filter by this)
    // We want to show counts for all types within the project/search filter

    // Apply object ID filter
    if (objectIds.length > 0) {
        baseContent = baseContent.filter(item => objectIds.includes(item.ID));
    }

    // Apply global search terms
    if (globalSearchTerms.length > 0) {
        baseContent = filterBySearchTerms(baseContent, globalSearchTerms, ['Name', 'Parent']);
    }

    const counts = {
        all: baseContent.length,
        Project: 0,
        Workbook: 0,
        'Data Source': 0,
        Flow: 0,
        View: 0
    };

    baseContent.forEach(item => {
        if (counts.hasOwnProperty(item.Type)) {
            counts[item.Type]++;
        }
    });

    // Update chip count displays
    const chipAll = document.getElementById('chipCountAll');
    const chipProjects = document.getElementById('chipCountProjects');
    const chipWorkbooks = document.getElementById('chipCountWorkbooks');
    const chipDatasources = document.getElementById('chipCountDatasources');
    const chipFlows = document.getElementById('chipCountFlows');
    const chipViews = document.getElementById('chipCountViews');

    if (chipAll) chipAll.textContent = counts.all;
    if (chipProjects) chipProjects.textContent = counts.Project;
    if (chipWorkbooks) chipWorkbooks.textContent = counts.Workbook;
    if (chipDatasources) chipDatasources.textContent = counts['Data Source'];
    if (chipFlows) chipFlows.textContent = counts.Flow;
    if (chipViews) chipViews.textContent = counts.View;
}

// ==================== Projects ====================
async function loadProjects() {
    try {
        const result = await apiCall('projects');
        if (result.success) {
            state.projects = result.data || [];
            const select = document.getElementById('projectFilter');
            select.innerHTML = '<option value="all">All Projects</option>';
            state.projects.forEach(p => {
                const option = document.createElement('option');
                option.value = p.id;
                option.textContent = p.name;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading projects:', error);
    }
}

// ==================== Saved Files ====================
async function loadSavedFiles() {
    try {
        const result = await apiCall('list_extractions');
        if (result.success) {
            state.savedFiles = result.files || [];
            renderSavedFiles();
        }
    } catch (error) {
        console.error('Error loading saved files:', error);
    }
}

function renderSavedFiles() {
    const container = document.getElementById('savedFilesContainer');
    const listDiv = document.getElementById('savedFilesList');

    if (state.savedFiles.length === 0) {
        listDiv.style.display = 'none';
        return;
    }

    listDiv.style.display = 'block';
    container.innerHTML = state.savedFiles.slice(0, 5).map(f => `
        <div class="saved-file-chip" style="display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.5rem 1rem; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 0.875rem;">
            <span style="cursor: pointer;" onclick="loadSavedFile('${f.filename}')">${f.filename}</span>
            <button onclick="deleteSavedFile('${f.filename}')" style="background: none; border: none; color: var(--accent-red); cursor: pointer; font-size: 1rem;">&times;</button>
        </div>
    `).join('');
}

async function loadSavedFile(filename) {
    showLoading('Loading saved extraction...');
    try {
        const result = await apiCall('load_extraction', 'POST', { filename });
        if (result.success) {
            state.currentJobId = result.job_id;
            loadJobResultsFromData(result.data);
            document.getElementById('btnExportDeep').disabled = false;
            document.getElementById('btnSaveResults').disabled = false;
            alert('Extraction loaded successfully from: ' + filename);
        } else {
            alert('Failed to load: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error loading file: ' + error.message);
    }
    hideLoading();
}

async function deleteSavedFile(filename) {
    if (!confirm('Delete saved extraction: ' + filename + '?')) return;

    try {
        const result = await fetch(`/api/delete_extraction/${filename}`, { method: 'DELETE' });
        const data = await result.json();
        if (data.success) {
            loadSavedFiles();
        } else {
            alert('Failed to delete: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error deleting file: ' + error.message);
    }
}

async function saveExtractionResults() {
    if (!state.currentJobId) {
        alert('No extraction results to save. Run deep extraction first.');
        return;
    }

    // Get project name from global filter or use 'All Projects'
    let projectName = 'All Projects';
    const selectedProjects = multiSelectState.projectMultiSelect?.selected || [];
    if (selectedProjects.length > 0) {
        const options = multiSelectState.projectMultiSelect?.options || [];
        const projectLabels = selectedProjects.map(id => {
            const opt = options.find(o => o.id === id);
            return opt ? opt.name : id;
        });
        projectName = projectLabels.length > 0 ? projectLabels.join(', ') : 'All Projects';
    }

    showLoading('Saving extraction results...');
    try {
        const result = await apiCall('save_extraction', 'POST', {
            job_id: state.currentJobId,
            project_name: projectName
        });
        if (result.success) {
            alert('Saved to: ' + result.filename);
            loadSavedFiles();
        } else {
            alert('Failed to save: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error saving: ' + error.message);
    }
    hideLoading();
}

async function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    showLoading('Loading extraction file...');
    try {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch('/api/load_extraction', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (result.success) {
            state.currentJobId = result.job_id;
            loadJobResultsFromData(result.data);
            document.getElementById('btnExportDeep').disabled = false;
            document.getElementById('btnSaveResults').disabled = false;
            alert('Extraction loaded successfully!');
        } else {
            alert('Failed to load: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Error loading file: ' + error.message);
    }
    hideLoading();
    event.target.value = ''; // Reset file input
}

function loadJobResultsFromData(data) {
    // Store original unfiltered deep data
    state.originalDeepData.custom_sql = data.custom_sql || [];
    state.originalDeepData.calculations = data.calculations || [];
    state.originalDeepData.lineage = data.lineage || [];
    state.originalDeepData.connections = data.connections || [];
    state.originalDeepData.tables = data.tables || [];
    state.originalDeepData.actions = data.actions || [];
    state.originalDeepData.columns = data.columns || [];
    state.originalDeepData.custom_visuals = data.custom_visuals || [];
    state.originalDeepData.object_tables_summary = data.object_tables_summary || [];
    state.originalDeepData.lineage_summary = data.lineage_summary || [];
    state.originalDeepData.lineage_workbooks = data.lineage_workbooks || [];
    state.originalDeepData.lineage_datasources = data.lineage_datasources || [];
    state.originalDeepData.lineage_flows = data.lineage_flows || [];
    state.originalDeepData.lineage_custom_sql = data.lineage_custom_sql || [];
    state.originalDeepData.lineage_table_matrix = data.lineage_table_matrix || [];
    state.originalDeepData.lineage_impact = data.lineage_impact || [];

    // Copy to working deep data
    state.deepData.custom_sql = data.custom_sql || [];
    state.deepData.calculations = data.calculations || [];
    state.deepData.lineage = data.lineage || [];
    state.deepData.connections = data.connections || [];
    state.deepData.tables = data.tables || [];
    state.deepData.actions = data.actions || [];
    state.deepData.columns = data.columns || [];
    state.deepData.custom_visuals = data.custom_visuals || [];
    state.deepData.object_tables_summary = data.object_tables_summary || [];
    state.deepData.lineage_summary = data.lineage_summary || [];
    state.deepData.lineage_workbooks = data.lineage_workbooks || [];
    state.deepData.lineage_datasources = data.lineage_datasources || [];
    state.deepData.lineage_flows = data.lineage_flows || [];
    state.deepData.lineage_custom_sql = data.lineage_custom_sql || [];
    state.deepData.lineage_table_matrix = data.lineage_table_matrix || [];
    state.deepData.lineage_impact = data.lineage_impact || [];

    // Update stats
    document.getElementById('statCustomSQL').textContent = state.deepData.custom_sql.length;
    document.getElementById('statCalculations').textContent = state.deepData.calculations.length;
    document.getElementById('statLineage').textContent = state.deepData.lineage.length;
    document.getElementById('statConnections').textContent = state.deepData.connections.length;

    renderDeepTable();
}

// ==================== Deep Extraction ====================
async function startDeepExtraction(options) {
    const lineageOnly = !!(options && options.lineageOnly === true);
    // Get filter context from global filters
    const projectIds = multiSelectState.projectMultiSelect?.selected || [];
    const contentTypes = multiSelectState.contentTypeMultiSelect?.selected || [];
    const objectIds = multiSelectState.objectMultiSelect?.selected || [];

    // Build description of what we're extracting
    let scopeDescription = 'All Content';
    let filterSummary = [];

    if (projectIds.length > 0) {
        const projectOptions = multiSelectState.projectMultiSelect?.options || [];
        const projectNames = projectIds.map(id => {
            const proj = projectOptions.find(p => p.id === id);
            return proj ? proj.name : id;
        });
        scopeDescription = projectNames.length <= 2 ? projectNames.join(', ') : `${projectNames.length} Projects`;
        filterSummary.push(`<span class="filter-tag project">${projectNames.length} Project${projectNames.length > 1 ? 's' : ''}</span>`);
    }

    if (contentTypes.length > 0) {
        filterSummary.push(`<span class="filter-tag type">${contentTypes.join(', ')}</span>`);
    }

    if (objectIds.length > 0) {
        scopeDescription = `${objectIds.length} Selected Objects`;
        filterSummary.push(`<span class="filter-tag object">${objectIds.length} Object${objectIds.length > 1 ? 's' : ''}</span>`);
    }

    state.currentProjectName = scopeDescription;

    document.getElementById('btnDeepExtract').disabled = true;
    document.getElementById('jobStatusContainer').classList.remove('hidden');
    document.getElementById('jobProgress').style.width = '0%';
    document.getElementById('jobMessage').textContent = `Starting extraction...`;

    // Show applied filters in progress section
    const filterDisplay = document.getElementById('appliedFiltersDisplay');
    if (filterDisplay) {
        if (filterSummary.length > 0) {
            filterDisplay.innerHTML = `<strong>Filters:</strong> ${filterSummary.join(' ')}`;
            filterDisplay.style.display = 'block';
        } else {
            filterDisplay.innerHTML = '<strong>Scope:</strong> <span class="filter-tag">All Content</span>';
            filterDisplay.style.display = 'block';
        }
    }

    try {
        // Get config from sessionStorage to send with request
        const configStr = sessionStorage.getItem('tableauConfig');
        const config = configStr ? JSON.parse(configStr) : null;

        // Pass global filter context to extraction along with config
        const result = await apiCall('extract_deep_metadata', 'POST', {
            config: config,
            project_id: projectIds.length === 1 ? projectIds[0] : (projectIds.length > 0 ? projectIds.join(',') : 'all'),
            project_ids: projectIds,
            project_name: scopeDescription,
            content_types: contentTypes,
            object_ids: objectIds,
            lineage_only: lineageOnly
        });
        if (result.success) {
            state.currentJobId = result.job_id;
            pollJobStatus(result.job_id);
        } else {
            alert('Failed to start extraction: ' + (result.error || 'Unknown error'));
            document.getElementById('btnDeepExtract').disabled = false;
            document.getElementById('jobStatusContainer').classList.add('hidden');
        }
    } catch (error) {
        console.error('Error starting extraction:', error);
        alert('Error: ' + error.message);
        document.getElementById('btnDeepExtract').disabled = false;
        document.getElementById('jobStatusContainer').classList.add('hidden');
    }
}

async function pollJobStatus(jobId) {
    try {
        const result = await apiCall(`job_status/${jobId}`);
        if (result.success) {
            const status = result.status;
            document.getElementById('jobProgress').style.width = `${status.progress}%`;
            document.getElementById('jobMessage').textContent = status.message;

            if (status.status === 'completed') {
                document.getElementById('btnDeepExtract').disabled = false;
                document.getElementById('btnExportDeep').disabled = false;
                await loadJobResults(jobId);
                if (state.lineageRun) {
                    state.lineageRun = false;
                    showSection('deep');
                    showDeepView('lineage_info');
                }
            } else if (status.status === 'failed') {
                state.lineageRun = false;
                alert('Extraction failed: ' + status.message);
                document.getElementById('btnDeepExtract').disabled = false;
                document.getElementById('jobStatusContainer').classList.add('hidden');
            } else {
                setTimeout(() => pollJobStatus(jobId), 2000);
            }
        }
    } catch (error) {
        console.error('Error polling job status:', error);
        setTimeout(() => pollJobStatus(jobId), 3000);
    }
}

async function loadJobResults(jobId) {
    try {
        const result = await apiCall(`job_result/${jobId}`);
        if (result.success) {
            const data = result.data;

            // Store original unfiltered deep data
            state.originalDeepData.custom_sql = data.custom_sql || [];
            state.originalDeepData.calculations = data.calculations || [];
            state.originalDeepData.lineage = data.lineage || [];
            state.originalDeepData.connections = data.connections || [];
            state.originalDeepData.tables = data.tables || [];
            state.originalDeepData.actions = data.actions || [];
            state.originalDeepData.columns = data.columns || [];
            state.originalDeepData.custom_visuals = data.custom_visuals || [];
            state.originalDeepData.object_tables_summary = data.object_tables_summary || [];
            state.originalDeepData.lineage_summary = data.lineage_summary || [];
            state.originalDeepData.lineage_workbooks = data.lineage_workbooks || [];
            state.originalDeepData.lineage_datasources = data.lineage_datasources || [];
            state.originalDeepData.lineage_flows = data.lineage_flows || [];
            state.originalDeepData.lineage_custom_sql = data.lineage_custom_sql || [];
            state.originalDeepData.lineage_table_matrix = data.lineage_table_matrix || [];
            state.originalDeepData.lineage_impact = data.lineage_impact || [];

            // Copy to working deep data
            state.deepData.custom_sql = data.custom_sql || [];
            state.deepData.calculations = data.calculations || [];
            state.deepData.lineage = data.lineage || [];
            state.deepData.connections = data.connections || [];
            state.deepData.tables = data.tables || [];
            state.deepData.actions = data.actions || [];
            state.deepData.columns = data.columns || [];
            state.deepData.custom_visuals = data.custom_visuals || [];
            state.deepData.object_tables_summary = data.object_tables_summary || [];
            state.deepData.lineage_summary = data.lineage_summary || [];
            state.deepData.lineage_workbooks = data.lineage_workbooks || [];
            state.deepData.lineage_datasources = data.lineage_datasources || [];
            state.deepData.lineage_flows = data.lineage_flows || [];
            state.deepData.lineage_custom_sql = data.lineage_custom_sql || [];
            state.deepData.lineage_table_matrix = data.lineage_table_matrix || [];
            state.deepData.lineage_impact = data.lineage_impact || [];

            // Update stats - use the server's true totals: for a huge site the browser only receives a
            // preview (first rows) of each dataset, the complete data is in the export download.
            state.deepCounts = data.counts || null;
            const totals = data.counts || {};
            const total = (key) => (totals[key] !== undefined ? totals[key] : (state.deepData[key] || []).length);
            document.getElementById('statCustomSQL').textContent = total('custom_sql').toLocaleString();
            document.getElementById('statCalculations').textContent = total('calculations').toLocaleString();
            document.getElementById('statLineage').textContent = total('lineage').toLocaleString();
            document.getElementById('statConnections').textContent = total('connections').toLocaleString();

            const jobMessage = document.getElementById('jobMessage');
            if (jobMessage) {
                const notes = [];
                if (data.truncated) {
                    notes.push(`Showing the first ${(data.preview_limit || 0).toLocaleString()} rows of each large dataset on screen - Export downloads everything.`);
                }
                if ((data.warnings || []).length > 0) {
                    notes.push(`${data.warnings.length} warning(s) recorded - see the Warnings sheet in the export.`);
                }
                if (notes.length > 0) {
                    jobMessage.textContent = notes.join(' ');
                }
            }

            // Enable save button
            document.getElementById('btnSaveResults').disabled = false;

            renderDeepTable();
        }
    } catch (error) {
        console.error('Error loading job results:', error);
    }
}

const LINEAGE_DATASET_LABELS = {
    lineage_summary: 'Lineage Summary', lineage_workbooks: 'Workbook Lineage', lineage_datasources: 'Datasource Lineage',
    lineage_flows: 'Flow Lineage', lineage_custom_sql: 'Custom SQL Analysis', lineage_table_matrix: 'Table Usage Matrix',
    lineage_impact: 'Impact Analysis'
};

function updateLineageToolbar(view) {
    const bar = document.getElementById('lineageToolbar');
    if (!bar) return;
    bar.classList.toggle('hidden', view !== 'lineage_info');
    if (view === 'lineage_info') {
        const titleEl = document.querySelector('#deepTableTitle span');
        if (titleEl) titleEl.textContent = 'Lineage Info - ' + (LINEAGE_DATASET_LABELS[state.lineageDataset] || '');
        const sel = document.getElementById('lineageDataset');
        if (sel) sel.value = state.lineageDataset;
        const counts = document.getElementById('lineageCounts');
        if (counts) {
            const src = state.originalDeepData.custom_sql.length > 0 ? state.originalDeepData : state.deepData;
            counts.textContent = Object.keys(LINEAGE_DATASET_LABELS)
                .map(k => {
                    const total = (state.deepCounts && state.deepCounts[k] !== undefined) ? state.deepCounts[k] : (src[k] || []).length;
                    return `${LINEAGE_DATASET_LABELS[k]}: ${total.toLocaleString()}`;
                }).join('  |  ');
        }
    }
}

function changeLineageDataset(value) {
    state.lineageDataset = value;
    state.pagination.deep.page = 1;
    updateLineageToolbar('lineage_info');
    renderDeepTable();
}

function startLineageExtraction() {
    // Fast run: Metadata API lineage only (no workbook downloads, permissions or admin data).
    // Progress is shown on the Home page; we come back to this tab when it finishes.
    state.lineageRun = true;
    showSection('home');
    startDeepExtraction({ lineageOnly: true });
}

async function exportLineage() {
    if (!state.currentJobId) {
        alert('No lineage available. Run Deep Extraction (or "Extract Lineage Only") first.');
        return;
    }
    try {
        const check = await fetch(`/api/export_lineage/${state.currentJobId}?check=1`);
        const info = await check.json();
        if (!info.success) {
            alert('Export failed: ' + (info.error || 'result not available. Please run the extraction again.'));
            return;
        }
    } catch (error) {
        alert('Export failed: ' + error.message);
        return;
    }
    window.location.href = `/api/export_lineage/${state.currentJobId}`;
}

async function exportObjectTables() {
    if (!state.currentJobId) {
        alert('No extraction results available. Run deep extraction first.');
        return;
    }
    try {
        const check = await fetch(`/api/export_object_tables/${state.currentJobId}?check=1`);
        const info = await check.json();
        if (!info.success) {
            alert('Export failed: ' + (info.error || 'result not available. Please run the extraction again.'));
            return;
        }
    } catch (error) {
        alert('Export failed: ' + error.message);
        return;
    }
    window.location.href = `/api/export_object_tables/${state.currentJobId}`;
}

async function exportDeepResults() {
    if (!state.currentJobId) {
        alert('No extraction results available. Run deep extraction first.');
        return;
    }
    // Check the result still exists first, so a failure shows a message instead of navigating away.
    // Large extractions are delivered as a .zip of several Excel files (Excel's row limit is ~1M).
    try {
        const check = await fetch(`/api/export_job_result/${state.currentJobId}?check=1`);
        const info = await check.json();
        if (!info.success) {
            alert('Export failed: ' + (info.error || 'result not available. Please run the extraction again.'));
            return;
        }
    } catch (error) {
        alert('Export failed: ' + error.message);
        return;
    }
    window.location.href = `/api/export_job_result/${state.currentJobId}`;
}

// ==================== Deep Table Rendering ====================
function getDeepViewData() {
    // Use originalDeepData if available, otherwise fall back to deepData
    const source = state.originalDeepData.custom_sql.length > 0 ? state.originalDeepData : state.deepData;
    const map = {
        'sql': source.custom_sql,
        'calculations': source.calculations,
        'lineage': source.lineage,
        'connections': source.connections,
        'tables': source.tables,
        'object_tables': source.object_tables_summary,
        'lineage_info': source[state.lineageDataset] || [],
        'actions': source.actions,
        'columns': source.columns,
        'custom_visuals': source.custom_visuals
    };
    return map[state.currentDeepView] || [];
}

function getDeepViewHeaders() {
    if (state.currentDeepView === 'lineage_info') {
        // Lineage datasets carry their own (human readable) column names
        const rows = getDeepViewData();
        return rows.length > 0 ? Object.keys(rows[0]) : ['No data - run Deep Extraction or "Extract Lineage Only"'];
    }
    const headers = {
        'sql': ['Project', 'Workbook/Datasource', 'Datasource', 'SQL Name', 'SQL Text'],
        'calculations': ['Project', 'Workbook/Datasource', 'Datasource', 'Field Name', 'Caption', 'Formula', 'Hidden'],
        'lineage': ['Project', 'Upstream Object', 'Type', 'Database', 'Connection', 'Downstream Object', 'Type'],
        'connections': ['Project', 'Workbook/Datasource', 'Datasource', 'Connector Type', 'Server', 'Database', 'Schema'],
        'tables': ['Project', 'Workbook/Datasource', 'Datasource', 'Table Name', 'Table Type', 'Columns'],
        'object_tables': ['Project', 'ID', 'Workbook/Datasource', 'Type', 'Connection Type', 'Server', 'Database', '# Tables', 'Tables Used'],
        'actions': ['Project', 'Workbook', 'Action Name', 'Type', 'Activation', 'Source Sheets', 'Target Sheets', 'URL Target'],
        'columns': ['Project', 'Workbook/Datasource', 'Datasource', 'Field Name', 'Type', 'Role', 'Hidden', 'Description'],
        'custom_visuals': ['Project', 'Workbook', 'Worksheet', 'All Marks', 'Standard Marks', 'Custom Marks', 'Has Custom']
    };
    return headers[state.currentDeepView] || [];
}

function getDeepSearchFields(view, includeDeepFields = false) {
    const baseFields = {
        'sql': ['object_name', 'datasource_name', 'sql_name', 'project_name'],
        'calculations': ['object_name', 'field_name', 'field_caption', 'caption', 'project_name'],
        'lineage': ['upstream_object', 'downstream_object', 'upstream_database', 'project_name'],
        'connections': ['object_name', 'datasource_name', 'server', 'dbname', 'project_name'],
        'tables': ['object_name', 'datasource_name', 'table_name', 'project_name'],
        'object_tables': ['object_id', 'object_name', 'connection_type', 'connection_server', 'database', 'tables_used', 'project_name'],
        'lineage_info': ['Content ID', 'Content Name', 'Workbook Name', 'Datasource Name', 'Project Name', 'Owner Name', 'Table Name',
                         'Fully Qualified Table Name', 'Referenced Table', 'Object Name', 'Flow Name', 'Asset Name', 'Server Name', 'Database Name'],
        'actions': ['object_name', 'action_name', 'action_caption', 'project_name'],
        'columns': ['object_name', 'field_name', 'datasource_name', 'datasource_caption', 'project_name'],
        'custom_visuals': ['object_name', 'worksheet_name', 'project_name']
    };

    const deepFields = {
        'sql': ['sql_text'],
        'calculations': ['formula_text']
    };

    let fields = baseFields[view] || ['object_name'];
    if (includeDeepFields && deepFields[view]) {
        fields = [...fields, ...deepFields[view]];
    }
    return fields;
}

// Helper function to get project name for an object
function getProjectForObject(objectName) {
    if (!objectName) return '-';

    // First check if it's directly in the data
    const content = state.originalContent.length > 0 ? state.originalContent : state.content;
    const item = content.find(c => c.Name === objectName);

    if (item) {
        return item.Parent || '-';
    }
    return '-';
}

function renderDeepTable() {
    let data = getDeepViewData();
    const headers = getDeepViewHeaders();
    const searchTerm = document.getElementById('deepSearch').value.toLowerCase();

    // Apply global filter context
    const filterCtx = window.currentFilterContext || {};
    const globalSearchTerms = filterCtx.search_terms || [];
    const deepSearch = filterCtx.deep_search || false;
    const projectIds = filterCtx.project_ids || [];
    const contentTypes = filterCtx.content_types || [];
    const objectIds = filterCtx.object_ids || [];

    // Apply project filter - filter by object_name matching project content
    const isLineageView = state.currentDeepView === 'lineage_info';
    if (!isLineageView && projectIds.length > 0 && state.projects.length > 0) {
        const projectNames = new Set();
        projectIds.forEach(pid => {
            const proj = state.projects.find(p => p.id === pid);
            if (proj) projectNames.add(proj.name);
        });

        // Get content items that belong to selected projects
        const projectContent = state.originalContent.filter(item =>
            projectNames.has(item.Parent) || (item.Type === 'Project' && projectNames.has(item.Name))
        );
        const validObjectNames = new Set(projectContent.map(item => item.Name));

        // Filter deep data by object names belonging to selected projects
        data = data.filter(item => {
            const objName = item.object_name || item.upstream_object || item.downstream_object || '';
            return validObjectNames.has(objName) || projectNames.has(objName);
        });
    }

    // Apply content type filter
    if (!isLineageView && contentTypes.length > 0) {
        // Get content items that match selected types
        const typeContent = state.originalContent.filter(item => contentTypes.includes(item.Type));
        const validObjectNames = new Set(typeContent.map(item => item.Name));

        data = data.filter(item => {
            const objName = item.object_name || item.upstream_object || item.downstream_object || '';
            return validObjectNames.has(objName);
        });
    }

    // Apply object ID filter
    if (!isLineageView && objectIds.length > 0) {
        const objectContent = state.originalContent.filter(item => objectIds.includes(item.ID));
        const validObjectNames = new Set(objectContent.map(item => item.Name));

        data = data.filter(item => {
            const objName = item.object_name || item.upstream_object || item.downstream_object || '';
            return validObjectNames.has(objName);
        });
    }

    // Apply global search terms
    if (globalSearchTerms.length > 0) {
        const searchFields = getDeepSearchFields(state.currentDeepView, deepSearch);
        data = filterBySearchTerms(data, globalSearchTerms, searchFields);
    }

    // Filter by local search term
    let filtered = data;
    if (searchTerm) {
        filtered = data.filter(item =>
            Object.values(item).some(v => String(v).toLowerCase().includes(searchTerm))
        );
    }

    // Render headers
    const thead = document.getElementById('deepTableHead');
    thead.innerHTML = `<tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;

    // Paginate
    const { page, perPage } = state.pagination.deep;
    const start = (page - 1) * perPage;
    const pageData = filtered.slice(start, start + perPage);

    // Render body
    const tbody = document.getElementById('deepTableBody');

    if (pageData.length === 0) {
        tbody.innerHTML = `<tr><td colspan="${headers.length}" class="text-center"><div class="empty-state"><p>No data available. Run deep extraction first.</p></div></td></tr>`;
    } else {
        tbody.innerHTML = pageData.map(item => {
            // Get project name - first try from item data, then look up from content
            const projectName = item.project_name || getProjectForObject(item.object_name || item.downstream_object) || '-';

            if (state.currentDeepView === 'sql') {
                const sqlPreview = (item.sql_text || '').substring(0, 100) + ((item.sql_text || '').length > 100 ? '...' : '');
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.object_name || '-'}</td>
                    <td>${item.datasource_name || '-'}</td>
                    <td>${item.sql_name || '-'}</td>
                    <td><div class="sql-preview">${escapeHtml(sqlPreview)}</div></td>
                </tr>`;
            } else if (state.currentDeepView === 'calculations') {
                const formulaPreview = (item.formula_text || '').substring(0, 80) + ((item.formula_text || '').length > 80 ? '...' : '');
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.object_name || '-'}</td>
                    <td>${item.datasource_name || '-'}</td>
                    <td>${item.field_name || '-'}</td>
                    <td>${item.field_caption || item.caption || '-'}</td>
                    <td><span class="formula-text">${escapeHtml(formulaPreview)}</span></td>
                    <td>${item.is_hidden === 'true' ? '<span class="badge badge-red">Yes</span>' : 'No'}</td>
                </tr>`;
            } else if (state.currentDeepView === 'lineage') {
                const connType = item.connection_type || '-';
                const connBadgeClass = connType.toLowerCase().includes('oracle') ? 'badge-red' :
                                       connType.toLowerCase().includes('sql') ? 'badge-blue' :
                                       connType.toLowerCase().includes('postgres') ? 'badge-green' :
                                       connType.toLowerCase().includes('snowflake') ? 'badge-purple' :
                                       connType.toLowerCase().includes('hyper') ? 'badge-orange' :
                                       'badge-gray';
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.upstream_object || '-'}</td>
                    <td><span class="badge badge-blue">${item.upstream_type || '-'}</span></td>
                    <td>${item.upstream_database || '-'}</td>
                    <td><span class="badge ${connBadgeClass}">${connType}</span></td>
                    <td>${item.downstream_object || '-'}</td>
                    <td><span class="badge badge-purple">${item.downstream_type || '-'}</span></td>
                </tr>`;
            } else if (state.currentDeepView === 'connections') {
                const connType = item.connection_class || item.connector_type || '-';
                const connBadgeClass = connType.toLowerCase().includes('oracle') ? 'badge-red' :
                                       connType.toLowerCase().includes('sql') ? 'badge-blue' :
                                       connType.toLowerCase().includes('postgres') ? 'badge-green' :
                                       connType.toLowerCase().includes('snowflake') ? 'badge-purple' :
                                       'badge-orange';
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.object_name || '-'}</td>
                    <td>${item.datasource_name || '-'}</td>
                    <td><span class="badge ${connBadgeClass}">${connType}</span></td>
                    <td>${item.server || '-'}</td>
                    <td>${item.dbname || '-'}</td>
                    <td>${item.schema || '-'}</td>
                </tr>`;
            } else if (state.currentDeepView === 'tables') {
                const colsPreview = (item.columns || '').substring(0, 60) + ((item.columns || '').length > 60 ? '...' : '');
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.object_name || '-'}</td>
                    <td>${item.datasource_name || '-'}</td>
                    <td>${item.table_name || '-'}</td>
                    <td><span class="badge badge-blue">${item.table_type || '-'}</span></td>
                    <td><div class="sql-preview">${escapeHtml(colsPreview)}</div></td>
                </tr>`;
            } else if (state.currentDeepView === 'lineage_info') {
                const cells = headers.map(k => {
                    const v = item[k];
                    const s = (v === undefined || v === null || v === '') ? '-' : String(v);
                    const short = s.length > 110 ? s.substring(0, 110) + '\u2026' : s;
                    return `<td title="${escapeHtml(s)}">${escapeHtml(short)}</td>`;
                }).join('');
                return `<tr>${cells}</tr>`;
            } else if (state.currentDeepView === 'object_tables') {
                const ct = item.connection_type || '-';
                const ctClass = ct.toLowerCase().includes('oracle') ? 'badge-red' :
                                ct.toLowerCase().includes('sql') ? 'badge-blue' :
                                ct.toLowerCase().includes('postgres') ? 'badge-green' :
                                ct.toLowerCase().includes('snowflake') ? 'badge-purple' :
                                ct.toLowerCase().includes('published') ? 'badge-orange' :
                                'badge-gray';
                return `<tr>
                    <td>${projectName}</td>
                    <td>${escapeHtml(item.object_id || '-')}</td>
                    <td>${escapeHtml(item.object_name || '-')}</td>
                    <td><span class="badge badge-purple">${escapeHtml(item.object_type || '-')}</span></td>
                    <td><span class="badge ${ctClass}">${escapeHtml(ct)}</span></td>
                    <td>${escapeHtml(item.connection_server || '-')}</td>
                    <td>${escapeHtml(item.database || '-')}</td>
                    <td>${item.table_count ?? '-'}</td>
                    <td><div class="sql-preview" title="${escapeHtml(item.tables_used || '')}">${escapeHtml(item.tables_used || '-')}</div></td>
                </tr>`;
            } else if (state.currentDeepView === 'actions') {
                const actionTypeClass = item.action_type === 'URL' ? 'badge-orange' : 'badge-blue';
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.object_name || '-'}</td>
                    <td>${item.action_name || item.action_caption || '-'}</td>
                    <td><span class="badge ${actionTypeClass}">${item.action_type || '-'}</span></td>
                    <td><span class="badge badge-green">${item.activation_type || '-'}</span></td>
                    <td>${item.source_sheets || '-'}</td>
                    <td>${item.target_sheets || '-'}</td>
                    <td>${item.url_target || '-'}</td>
                </tr>`;
            } else if (state.currentDeepView === 'columns') {
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.object_name || '-'}</td>
                    <td>${item.datasource_caption || item.datasource_name || '-'}</td>
                    <td>${item.field_name || '-'}</td>
                    <td>${item.field_type || '-'}</td>
                    <td>${item.measure_or_attribute || '-'}</td>
                    <td>${item.hidden === 'true' ? '<span class="badge badge-red">Yes</span>' : 'No'}</td>
                    <td>${item.description || '-'}</td>
                </tr>`;
            } else if (state.currentDeepView === 'custom_visuals') {
                const hasCustomClass = item.has_custom_visuals === 'Yes' ? 'badge-red' : 'badge-green';
                return `<tr>
                    <td>${projectName}</td>
                    <td>${item.object_name || '-'}</td>
                    <td>${item.worksheet_name || '-'}</td>
                    <td>${item.all_mark_types || item.custom_mark_types || '-'}</td>
                    <td>${item.standard_marks || '-'}</td>
                    <td>${item.custom_marks || '-'}</td>
                    <td><span class="badge ${hasCustomClass}">${item.has_custom_visuals || 'No'}</span></td>
                </tr>`;
            }
            return '';
        }).join('');
    }

    renderPagination('deep', filtered.length);
}

// ==================== Content Table ====================
function filterContent() {
    const searchTerm = document.getElementById('contentSearch').value.toLowerCase();
    const typeFilter = document.getElementById('contentTypeFilter').value;

    // Start with original content and apply global filter context
    let baseContent = state.originalContent.length > 0 ? state.originalContent : state.content;

    // Apply global filter context
    const filterCtx = window.currentFilterContext || {};
    const globalSearchTerms = filterCtx.search_terms || [];
    const projectIds = filterCtx.project_ids || [];
    const contentTypes = filterCtx.content_types || [];
    const objectIds = filterCtx.object_ids || [];

    // Apply project filter
    if (projectIds.length > 0 && state.projects.length > 0) {
        const projectNames = new Set();
        projectIds.forEach(pid => {
            const proj = state.projects.find(p => p.id === pid);
            if (proj) projectNames.add(proj.name);
        });
        baseContent = baseContent.filter(item =>
            item.Type === 'Site' ||
            (item.Type === 'Project' && projectNames.has(item.Name)) ||
            projectNames.has(item.Parent)
        );
    }

    // Apply global content type filter
    if (contentTypes.length > 0) {
        baseContent = baseContent.filter(item => contentTypes.includes(item.Type));
    }

    // Apply object ID filter
    if (objectIds.length > 0) {
        baseContent = baseContent.filter(item => objectIds.includes(item.ID));
    }

    // Apply global search terms
    if (globalSearchTerms.length > 0) {
        baseContent = filterBySearchTerms(baseContent, globalSearchTerms, ['Name', 'Parent']);
    }

    // Now apply local page filters (search box and type dropdown on Content page)
    state.filteredContent = baseContent.filter(item => {
        const matchesSearch = !searchTerm ||
            (item.Name || '').toLowerCase().includes(searchTerm) ||
            (item.Parent || '').toLowerCase().includes(searchTerm);
        const matchesType = !typeFilter || item.Type === typeFilter;
        return matchesSearch && matchesType;
    });

    state.pagination.content.page = 1;
    renderContentTable();
}

function renderContentTable() {
    const { page, perPage } = state.pagination.content;
    const start = (page - 1) * perPage;
    const pageData = state.filteredContent.slice(start, start + perPage);

    const tbody = document.getElementById('contentTableBody');

    if (pageData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center"><div class="empty-state"><p>No content found</p></div></td></tr>';
    } else {
        tbody.innerHTML = pageData.map(item => `
            <tr>
                <td><span class="badge badge-${getTypeBadge(item.Type)}">${item.Type}</span></td>
                <td>${item.URL ? `<a href="${item.URL}" target="_blank">${item.Name}</a>` : item.Name}</td>
                <td>${item.Parent || '-'}</td>
                <td>${item.URL ? `<a href="${item.URL}" target="_blank">Open</a>` : '-'}</td>
            </tr>
        `).join('');
    }

    renderPagination('content', state.filteredContent.length);
}

function getTypeBadge(type) {
    const badges = { 'Site': 'blue', 'Project': 'purple', 'Workbook': 'green', 'Data Source': 'orange', 'Flow': 'blue' };
    return badges[type] || 'blue';
}

// ==================== Admin Views ====================
async function loadAdminView(view) {
    state.currentAdminView = view;
    showLoading(`Loading ${view}...`);

    const titles = { 'users': 'Users', 'groups': 'Groups', 'schedules': 'Schedules', 'jobs': 'Jobs' };
    document.querySelector('#adminTableTitle span').textContent = titles[view] || view;

    try {
        const result = await apiCall(view);
        if (result.success) {
            state.currentAdminData = result.data;
            state.pagination.admin.page = 1;
            setupAdminTableHeaders(view);
            renderAdminTable();
        }
    } catch (error) {
        console.error(`Error loading ${view}:`, error);
    }
    hideLoading();
}

function setupAdminTableHeaders(view) {
    const headers = {
        'users': ['Name', 'Full Name', 'Email', 'Site Role', 'Status', 'Days Inactive', 'Last Login'],
        'groups': ['Name', 'Domain', 'License Mode'],
        'schedules': ['Name', 'Type', 'State', 'Frequency'],
        'jobs': ['ID', 'Type', 'Status', 'Progress']
    };
    document.getElementById('adminTableHead').innerHTML = `<tr>${(headers[view] || []).map(h => `<th>${h}</th>`).join('')}</tr>`;
}

function renderAdminTable() {
    const searchTerm = document.getElementById('adminSearch').value.toLowerCase();
    let filtered = state.currentAdminData;

    if (searchTerm) {
        filtered = state.currentAdminData.filter(item =>
            Object.values(item).some(v => String(v).toLowerCase().includes(searchTerm))
        );
    }

    const { page, perPage } = state.pagination.admin;
    const start = (page - 1) * perPage;
    const pageData = filtered.slice(start, start + perPage);

    const fieldMap = {
        'users': ['name', 'fullname', 'email', 'site_role', 'activity_status', 'days_since_login', 'last_login'],
        'groups': ['name', 'domain_name', 'license_mode'],
        'schedules': ['name', 'schedule_type', 'state', 'frequency'],
        'jobs': ['id', 'job_type', 'status', 'progress']
    };

    const fields = fieldMap[state.currentAdminView] || Object.keys(pageData[0] || {});
    const tbody = document.getElementById('adminTableBody');

    if (pageData.length === 0) {
        tbody.innerHTML = `<tr><td colspan="${fields.length}" class="text-center"><div class="empty-state"><p>No data found</p></div></td></tr>`;
    } else if (state.currentAdminView === 'users') {
        // Custom rendering for users with status badges
        tbody.innerHTML = pageData.map(item => {
            const statusClass = {
                'Active': 'badge-green',
                'Recent': 'badge-blue',
                'Inactive': 'badge-orange',
                'Dormant': 'badge-red',
                'Never': 'badge-gray'
            }[item.activity_status] || 'badge-gray';

            const daysInactive = item.days_since_login !== null && item.days_since_login !== undefined
                ? item.days_since_login
                : '-';

            return `<tr>
                <td>${item.name || '-'}</td>
                <td>${item.fullname || '-'}</td>
                <td>${item.email || '-'}</td>
                <td>${item.site_role || '-'}</td>
                <td><span class="badge ${statusClass}">${item.activity_status || 'Unknown'}</span></td>
                <td>${daysInactive}</td>
                <td>${formatValue(item.last_login)}</td>
            </tr>`;
        }).join('');
    } else {
        tbody.innerHTML = pageData.map(item =>
            `<tr>${fields.map(f => `<td>${formatValue(item[f])}</td>`).join('')}</tr>`
        ).join('');
    }

    renderPagination('admin', filtered.length);
}

// ==================== Pagination ====================
function renderPagination(type, totalItems) {
    const { page, perPage } = state.pagination[type];
    const totalPages = Math.ceil(totalItems / perPage);
    const start = (page - 1) * perPage + 1;
    const end = Math.min(page * perPage, totalItems);

    document.getElementById(`${type}PaginationInfo`).textContent =
        totalItems > 0 ? `Showing ${start} to ${end} of ${totalItems} items` : 'No items';

    const container = document.getElementById(`${type}Pagination`);
    container.innerHTML = '';

    if (totalPages <= 1) return;

    container.innerHTML = `
        <button class="pagination-btn" onclick="goToPage('${type}', 1)" ${page === 1 ? 'disabled' : ''}>First</button>
        <button class="pagination-btn" onclick="goToPage('${type}', ${page - 1})" ${page === 1 ? 'disabled' : ''}>&lt;</button>
        ${Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
            if (p > totalPages) return '';
            return `<button class="pagination-btn ${p === page ? 'active' : ''}" onclick="goToPage('${type}', ${p})">${p}</button>`;
        }).join('')}
        <button class="pagination-btn" onclick="goToPage('${type}', ${page + 1})" ${page === totalPages ? 'disabled' : ''}>&gt;</button>
        <button class="pagination-btn" onclick="goToPage('${type}', ${totalPages})" ${page === totalPages ? 'disabled' : ''}>Last</button>
    `;
}

function goToPage(type, page) {
    state.pagination[type].page = page;
    if (type === 'content') renderContentTable();
    else if (type === 'admin') renderAdminTable();
    else if (type === 'deep') renderDeepTable();
}

// ==================== Export ====================
async function exportToExcel(data, type) {
    if (!data || data.length === 0) {
        alert('No data to export');
        return;
    }

    showLoading('Exporting...');
    try {
        const response = await fetch('/api/export_excel', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data, type })
        });

        if (response.ok) {
            const blob = await response.blob();
            const defaultFilename = `${type}_${new Date().toISOString().slice(0, 10)}.xlsx`;

            // Use File System Access API if available (allows user to choose save location)
            if ('showSaveFilePicker' in window) {
                try {
                    const handle = await window.showSaveFilePicker({
                        suggestedName: defaultFilename,
                        types: [{
                            description: 'Excel Files',
                            accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] }
                        }]
                    });
                    const writable = await handle.createWritable();
                    await writable.write(blob);
                    await writable.close();
                    hideLoading();
                    return;
                } catch (err) {
                    // User cancelled the save dialog or API failed - fall back to regular download
                    if (err.name === 'AbortError') {
                        hideLoading();
                        return;
                    }
                }
            }

            // Fallback: regular download for browsers without File System Access API
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = defaultFilename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
        } else {
            const error = await response.json();
            alert(error.error || 'Export failed');
        }
    } catch (error) {
        alert('Export failed: ' + error.message);
    }
    hideLoading();
}

// ==================== Metadata GraphQL Functions ====================

// Query type display names
const QUERY_TYPE_LABELS = {
    'published_datasources': 'Published Datasources',
    'workbooks': 'Workbooks',
    'workbook_dependency': 'Workbook Dependency Backbone',
    'workbook_field_lineage': 'Workbook Field Lineage',
    'datasource_impact': 'Published Datasource Impact',
    'database_servers': 'Database Servers',
    'virtual_connections': 'Virtual Connections'
};

// Toggle all query checkboxes
function toggleAllQueries(checked) {
    document.querySelectorAll('input[name="queryType"]').forEach(cb => {
        cb.checked = checked;
    });
}

// Load projects for filter dropdown
async function loadGraphqlProjects() {
    const projectSelect = document.getElementById('graphqlProjectFilter');
    if (!projectSelect) return;

    try {
        const response = await fetch('/api/metadata/projects');
        const result = await response.json();

        if (result.success && result.projects) {
            state.graphql.projects = result.projects;

            // Clear and rebuild options
            projectSelect.innerHTML = '<option value="all">All Projects</option>';
            result.projects.forEach(project => {
                const option = document.createElement('option');
                option.value = project.name;
                option.textContent = project.name;
                projectSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to load projects:', error);
    }
}

// Run metadata fetch for selected queries
async function runMetadataFetch() {
    const loadingEl = document.getElementById('graphqlLoading');
    const loadingDetailEl = document.getElementById('graphqlLoadingDetail');
    const emptyState = document.getElementById('graphqlEmptyState');
    const tableContainer = document.getElementById('graphqlTableContainer');
    const messageEl = document.getElementById('graphqlMessage');
    const messageTextEl = document.getElementById('graphqlMessageText');
    const exportBtn = document.getElementById('btnExportGraphqlData');
    const runBtn = document.getElementById('btnRunMetadataFetch');
    const resultSelector = document.getElementById('graphqlResultSelector');
    const resultCount = document.getElementById('graphqlResultCount');
    const paginationWrapper = document.getElementById('graphqlPaginationWrapper');

    // Get selected queries
    const selectedQueries = Array.from(document.querySelectorAll('input[name="queryType"]:checked'))
        .map(cb => cb.value);

    if (selectedQueries.length === 0) {
        messageEl.classList.remove('hidden');
        messageEl.className = 'alert alert-error';
        messageTextEl.textContent = 'Please select at least one query to run.';
        setTimeout(() => messageEl.classList.add('hidden'), 3000);
        return;
    }

    // Get filter values
    const projectFilter = document.getElementById('graphqlProjectFilter').value;
    const nameFilter = document.getElementById('graphqlNameFilter').value.trim();

    // Reset state
    state.graphql.results = {};
    state.graphql.currentView = null;
    state.graphql.filteredData = [];
    state.graphql.page = 1;

    // Show loading
    emptyState.style.display = 'none';
    tableContainer.classList.add('hidden');
    paginationWrapper.style.display = 'none';
    loadingEl.classList.remove('hidden');
    messageEl.classList.add('hidden');
    exportBtn.disabled = true;

    runBtn.disabled = true;
    runBtn.innerHTML = `
        <div class="stat-loading" style="width: 14px; height: 14px; border-width: 2px; margin-right: 6px;"></div>
        Fetching...
    `;

    let successCount = 0;
    let errorMessages = [];

    try {
        for (let i = 0; i < selectedQueries.length; i++) {
            const queryType = selectedQueries[i];
            loadingDetailEl.textContent = `Fetching ${QUERY_TYPE_LABELS[queryType]} (${i + 1}/${selectedQueries.length})...`;

            try {
                const response = await fetch('/api/metadata/query', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        query_type: queryType,
                        project_filter: projectFilter === 'all' ? null : projectFilter,
                        name_filter: nameFilter || null
                    })
                });

                const result = await response.json();

                if (result.success) {
                    state.graphql.results[queryType] = result.data || [];
                    successCount++;
                } else {
                    errorMessages.push(`${QUERY_TYPE_LABELS[queryType]}: ${result.error}`);
                    state.graphql.results[queryType] = [];
                }
            } catch (err) {
                errorMessages.push(`${QUERY_TYPE_LABELS[queryType]}: ${err.message}`);
                state.graphql.results[queryType] = [];
            }
        }

        // Hide loading
        loadingEl.classList.add('hidden');

        // Populate result selector
        resultSelector.innerHTML = '<option value="">-- Select a result --</option>';
        let firstResultWithData = null;

        for (const queryType of selectedQueries) {
            const data = state.graphql.results[queryType] || [];
            const option = document.createElement('option');
            option.value = queryType;
            option.textContent = `${QUERY_TYPE_LABELS[queryType]} (${data.length} rows)`;
            resultSelector.appendChild(option);

            if (!firstResultWithData && data.length > 0) {
                firstResultWithData = queryType;
            }
        }

        // Show results
        if (successCount > 0) {
            // Auto-select first result with data
            if (firstResultWithData) {
                resultSelector.value = firstResultWithData;
                switchGraphqlResultView();
            }

            exportBtn.disabled = false;

            // Show success/warning message
            if (errorMessages.length > 0) {
                messageEl.classList.remove('hidden');
                messageEl.className = 'alert alert-warning';
                messageTextEl.textContent = `Fetched ${successCount}/${selectedQueries.length} queries. Errors: ${errorMessages.join('; ')}`;
            } else {
                messageEl.classList.remove('hidden');
                messageEl.className = 'alert alert-success';
                const totalRows = Object.values(state.graphql.results).reduce((sum, arr) => sum + arr.length, 0);
                messageTextEl.textContent = `Successfully fetched ${successCount} queries with ${totalRows} total rows.`;
                setTimeout(() => messageEl.classList.add('hidden'), 3000);
            }
        } else {
            // All queries failed
            emptyState.style.display = 'block';
            messageEl.classList.remove('hidden');
            messageEl.className = 'alert alert-error';
            messageTextEl.textContent = 'All queries failed: ' + errorMessages.join('; ');
        }

    } catch (error) {
        loadingEl.classList.add('hidden');
        emptyState.style.display = 'block';
        messageEl.classList.remove('hidden');
        messageEl.className = 'alert alert-error';
        messageTextEl.textContent = 'Error: ' + error.message;
    }

    // Reset button
    runBtn.disabled = false;
    runBtn.innerHTML = `
        <svg style="width: 18px; height: 18px;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
        </svg>
        Run Metadata Fetch
    `;
}

// Switch between result views
function switchGraphqlResultView() {
    const resultSelector = document.getElementById('graphqlResultSelector');
    const resultCount = document.getElementById('graphqlResultCount');
    const emptyState = document.getElementById('graphqlEmptyState');
    const tableContainer = document.getElementById('graphqlTableContainer');
    const paginationWrapper = document.getElementById('graphqlPaginationWrapper');

    const selectedType = resultSelector.value;

    if (!selectedType || !state.graphql.results[selectedType]) {
        emptyState.style.display = 'block';
        tableContainer.classList.add('hidden');
        paginationWrapper.style.display = 'none';
        resultCount.textContent = '';
        return;
    }

    const data = state.graphql.results[selectedType];
    state.graphql.currentView = selectedType;
    state.graphql.filteredData = [...data];
    state.graphql.page = 1;
    state.graphql.sortColumn = null;

    if (data.length === 0) {
        emptyState.style.display = 'block';
        emptyState.querySelector('p').textContent = 'No data returned for this query.';
        tableContainer.classList.add('hidden');
        paginationWrapper.style.display = 'none';
        resultCount.textContent = '(0 rows)';
    } else {
        emptyState.style.display = 'none';
        tableContainer.classList.remove('hidden');
        paginationWrapper.style.display = 'flex';
        resultCount.textContent = '';
        renderGraphqlTable();
    }
}

// Render table with dynamic columns
function renderGraphqlTable() {
    const thead = document.getElementById('graphqlTableHead');
    const tbody = document.getElementById('graphqlTableBody');
    const paginationInfo = document.getElementById('graphqlPaginationInfo');
    const pagination = document.getElementById('graphqlPagination');

    const { filteredData, page, perPage, currentView } = state.graphql;

    if (!currentView || filteredData.length === 0) {
        thead.innerHTML = '';
        tbody.innerHTML = `<tr><td colspan="10" style="text-align: center; padding: 2rem; color: var(--text-muted);">No data available.</td></tr>`;
        paginationInfo.textContent = 'Showing 0 items';
        pagination.innerHTML = '';
        return;
    }

    // Get columns from first row
    const columns = Object.keys(filteredData[0]);

    // Helper to check if column is an ID column
    const isIdColumn = (col) => col.toLowerCase().includes(' id') || col.toLowerCase().endsWith('id') || col.toLowerCase() === 'luid';

    // Render header
    thead.innerHTML = `<tr>${columns.map(col => {
        const isId = isIdColumn(col);
        const style = isId ? 'cursor: pointer; white-space: nowrap; max-width: 120px;' : 'cursor: pointer; white-space: nowrap;';
        return `<th onclick="sortGraphqlTable('${escapeHtml(col)}')" style="${style}">${escapeHtml(col)} ↕</th>`;
    }).join('')}</tr>`;

    // Pagination
    const start = (page - 1) * perPage;
    const end = start + perPage;
    const pageData = filteredData.slice(start, end);
    const totalPages = Math.ceil(filteredData.length / perPage);

    // Render body
    tbody.innerHTML = pageData.map(row => `
        <tr>
            ${columns.map(col => {
                const val = row[col];
                const strVal = val === null || val === undefined ? '-' : String(val);
                const isId = isIdColumn(col);

                // Truncate IDs to first 8 chars, other long values to 40 chars
                let displayVal;
                if (isId && strVal.length > 12) {
                    displayVal = strVal.substring(0, 8) + '...';
                } else if (strVal.length > 40) {
                    displayVal = strVal.substring(0, 40) + '...';
                } else {
                    displayVal = strVal;
                }

                const tdStyle = isId ? 'font-family: monospace; font-size: 0.8rem; color: var(--text-muted);' : '';
                return `<td title="${escapeHtml(strVal)}" style="${tdStyle}">${escapeHtml(displayVal)}</td>`;
            }).join('')}
        </tr>
    `).join('');

    // Pagination info
    const showing = filteredData.length > 0 ? `${start + 1}-${Math.min(end, filteredData.length)}` : '0';
    paginationInfo.textContent = `Showing ${showing} of ${filteredData.length} items`;

    // Pagination controls
    if (totalPages <= 1) {
        pagination.innerHTML = '';
    } else {
        let paginationHtml = '';
        if (page > 1) {
            paginationHtml += `<button class="pagination-btn" onclick="goToGraphqlPage(${page - 1})">Prev</button>`;
        }
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= page - 1 && i <= page + 1)) {
                paginationHtml += `<button class="pagination-btn ${i === page ? 'active' : ''}" onclick="goToGraphqlPage(${i})">${i}</button>`;
            } else if (i === page - 2 || i === page + 2) {
                paginationHtml += `<span class="pagination-ellipsis">...</span>`;
            }
        }
        if (page < totalPages) {
            paginationHtml += `<button class="pagination-btn" onclick="goToGraphqlPage(${page + 1})">Next</button>`;
        }
        pagination.innerHTML = paginationHtml;
    }
}

function goToGraphqlPage(page) {
    state.graphql.page = page;
    renderGraphqlTable();
}

function changeGraphqlPerPage() {
    state.graphql.perPage = parseInt(document.getElementById('graphqlPerPage').value);
    state.graphql.page = 1;
    renderGraphqlTable();
}

function filterGraphqlTable() {
    const searchTerm = document.getElementById('graphqlSearch').value.toLowerCase();
    const currentView = state.graphql.currentView;

    if (!currentView || !state.graphql.results[currentView]) {
        return;
    }

    const sourceData = state.graphql.results[currentView];

    if (!searchTerm) {
        state.graphql.filteredData = [...sourceData];
    } else {
        state.graphql.filteredData = sourceData.filter(row => {
            return Object.values(row).some(val =>
                String(val || '').toLowerCase().includes(searchTerm)
            );
        });
    }

    state.graphql.page = 1;
    renderGraphqlTable();
}

function sortGraphqlTable(column) {
    const { sortColumn, sortDirection } = state.graphql;

    // Toggle direction if same column, otherwise default to asc
    if (sortColumn === column) {
        state.graphql.sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        state.graphql.sortColumn = column;
        state.graphql.sortDirection = 'asc';
    }

    state.graphql.filteredData.sort((a, b) => {
        const aVal = (a[column] || '').toString().toLowerCase();
        const bVal = (b[column] || '').toString().toLowerCase();

        if (aVal < bVal) return state.graphql.sortDirection === 'asc' ? -1 : 1;
        if (aVal > bVal) return state.graphql.sortDirection === 'asc' ? 1 : -1;
        return 0;
    });

    state.graphql.page = 1;
    renderGraphqlTable();
}

// Export all results to multi-sheet Excel
async function exportAllMetadataResults() {
    const results = state.graphql.results;
    const hasData = Object.values(results).some(arr => arr && arr.length > 0);

    if (!hasData) {
        alert('No data to export. Run queries first.');
        return;
    }

    showLoading('Exporting to Excel...');

    try {
        const response = await fetch('/api/metadata/export', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ results: results })
        });

        if (response.ok) {
            const blob = await response.blob();
            const defaultFilename = `tableau_metadata_${new Date().toISOString().slice(0, 10)}.xlsx`;

            // Use File System Access API if available
            if ('showSaveFilePicker' in window) {
                try {
                    const handle = await window.showSaveFilePicker({
                        suggestedName: defaultFilename,
                        types: [{
                            description: 'Excel Files',
                            accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] }
                        }]
                    });
                    const writable = await handle.createWritable();
                    await writable.write(blob);
                    await writable.close();
                    hideLoading();
                    return;
                } catch (err) {
                    if (err.name === 'AbortError') {
                        hideLoading();
                        return;
                    }
                }
            }

            // Fallback: regular download
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = defaultFilename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
        } else {
            const error = await response.json();
            alert(error.error || 'Export failed');
        }
    } catch (error) {
        alert('Export failed: ' + error.message);
    }
    hideLoading();
}

// Make functions globally available
window.toggleAllQueries = toggleAllQueries;
window.loadGraphqlProjects = loadGraphqlProjects;
window.runMetadataFetch = runMetadataFetch;
window.switchGraphqlResultView = switchGraphqlResultView;
window.filterGraphqlTable = filterGraphqlTable;
window.sortGraphqlTable = sortGraphqlTable;
window.exportAllMetadataResults = exportAllMetadataResults;
window.goToGraphqlPage = goToGraphqlPage;
window.changeGraphqlPerPage = changeGraphqlPerPage;

// ==================== Utilities ====================
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func(...args), wait);
    };
}

function formatValue(value) {
    if (value === null || value === undefined || value === '') return '-';
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    if (typeof value === 'string' && value.match(/^\d{4}-\d{2}-\d{2}/)) {
        try {
            return new Date(value).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
        } catch { return value; }
    }
    return value;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Global function for deep view navigation (called from stat cards on home page)
window.navigateToDeepView = function(view) {
    showSection('deep');
    switchDeepTab(view);
};

// Make showDeepView available globally for onclick handlers
function switchDeepTab(view) {
    console.log('switchDeepTab called with:', view);
    state.currentDeepView = view;

    // Update tab styling
    document.querySelectorAll('#deepSection .tab-btn').forEach(b => {
        b.classList.remove('active');
        if (b.dataset.tab === view) {
            b.classList.add('active');
        }
    });

    // Update title and icon based on view
    const titles = {
        'sql': 'Custom SQL',
        'calculations': 'Calculations',
        'lineage': 'Lineage',
        'connections': 'Connections',
        'tables': 'Tables',
        'object_tables': 'Tables Used',
        'lineage_info': 'Lineage Info',
        'actions': 'Actions',
        'columns': 'Columns',
        'custom_visuals': 'Custom Visuals'
    };

    const titleEl = document.querySelector('#deepTableTitle span');
    if (titleEl) {
        titleEl.textContent = titles[view] || view;
    }

    updateLineageToolbar(view);
    state.pagination.deep.page = 1;
    renderDeepTable();
}

window.showDeepView = switchDeepTab;

// Navigation functions for KPI cards
window.navigateToContent = function(filterType) {
    showSection('content');
    // Set the filter if specified
    if (filterType) {
        document.getElementById('contentTypeFilter').value = filterType;
    } else {
        document.getElementById('contentTypeFilter').value = '';
    }
    filterContent();
};

window.navigateToAdmin = function(view) {
    showSection('administration');
    loadAdminView(view);
};

window.navigateToDeep = function(view) {
    showSection('deep');
    switchDeepTab(view);
};

// ==================== Global Filter System ====================

const multiSelectState = {
    projectMultiSelect: { selected: [], options: [] },
    contentTypeMultiSelect: { selected: [], options: [] },
    objectMultiSelect: { selected: [], options: [] }
};

// All content cache for search autocomplete
let allContentCache = [];

// Search tags state
let searchTags = [];

// Initialize multi-select dropdowns
function initializeMultiSelects() {
    document.querySelectorAll('.multi-select-container').forEach(container => {
        const id = container.id;
        const trigger = container.querySelector('.multi-select-trigger');
        const dropdown = container.querySelector('.multi-select-dropdown');
        const searchInput = container.querySelector('.multi-select-search input');

        // Toggle dropdown on click
        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            closeAllMultiSelects();
            dropdown.classList.toggle('show');
            trigger.classList.toggle('active');
            if (dropdown.classList.contains('show') && searchInput) {
                searchInput.focus();
            }
        });

        // Search functionality
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const term = e.target.value.toLowerCase();
                container.querySelectorAll('.multi-select-option').forEach(opt => {
                    const text = opt.textContent.toLowerCase();
                    opt.style.display = text.includes(term) ? 'flex' : 'none';
                });
            });
            searchInput.addEventListener('click', (e) => e.stopPropagation());
        }
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => closeAllMultiSelects());
}

function closeAllMultiSelects() {
    document.querySelectorAll('.multi-select-dropdown').forEach(d => d.classList.remove('show'));
    document.querySelectorAll('.multi-select-trigger').forEach(t => t.classList.remove('active'));
}

function populateMultiSelect(containerId, options, labelKey = 'name', valueKey = 'id') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const optionsContainer = container.querySelector('.multi-select-options');
    multiSelectState[containerId] = { selected: [], options: options };

    optionsContainer.innerHTML = options.map(opt => `
        <label class="multi-select-option" data-value="${opt[valueKey]}">
            <input type="checkbox" value="${opt[valueKey]}">
            <span>${opt[labelKey]}</span>
        </label>
    `).join('');

    // Add change listeners
    optionsContainer.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        cb.addEventListener('change', () => {
            updateMultiSelectState(containerId);
            updateMultiSelectDisplay(containerId);
        });
    });

    updateMultiSelectDisplay(containerId);
}

function updateMultiSelectState(containerId) {
    const container = document.getElementById(containerId);
    const checkboxes = container.querySelectorAll('.multi-select-options input[type="checkbox"]:checked');
    multiSelectState[containerId].selected = Array.from(checkboxes).map(cb => cb.value);
}

function updateMultiSelectDisplay(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const trigger = container.querySelector('.multi-select-trigger');
    const selected = multiSelectState[containerId]?.selected || [];
    const options = multiSelectState[containerId]?.options || [];

    // Find selected option labels
    const selectedLabels = selected.map(val => {
        const opt = options.find(o => o.id === val || o.value === val);
        return opt ? (opt.name || opt.label) : val;
    });

    // Determine placeholder based on container
    let placeholder = 'All';
    if (containerId === 'projectMultiSelect') placeholder = 'All Projects';
    else if (containerId === 'contentTypeMultiSelect') placeholder = 'All Types';
    else if (containerId === 'objectMultiSelect') placeholder = 'All Objects';

    if (selected.length === 0) {
        trigger.innerHTML = `
            <span class="multi-select-placeholder">${placeholder}</span>
            <svg class="multi-select-arrow" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
            </svg>
        `;
    } else if (selected.length <= 2) {
        trigger.innerHTML = `
            <div class="multi-select-tags">
                ${selectedLabels.slice(0, 2).map(label => `
                    <span class="multi-select-tag" title="${label}">${label.length > 15 ? label.substring(0, 15) + '...' : label}</span>
                `).join('')}
            </div>
            <svg class="multi-select-arrow" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
            </svg>
        `;
    } else {
        trigger.innerHTML = `
            <div class="multi-select-tags">
                <span class="multi-select-count">${selected.length} selected</span>
            </div>
            <svg class="multi-select-arrow" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
            </svg>
        `;
    }

    // Update option styling
    container.querySelectorAll('.multi-select-option').forEach(opt => {
        const value = opt.dataset.value;
        opt.classList.toggle('selected', selected.includes(value));
    });
}

window.multiSelectAll = function(containerId) {
    const container = document.getElementById(containerId);
    container.querySelectorAll('.multi-select-options input[type="checkbox"]').forEach(cb => {
        if (cb.closest('.multi-select-option').style.display !== 'none') {
            cb.checked = true;
        }
    });
    updateMultiSelectState(containerId);
    updateMultiSelectDisplay(containerId);
};

window.multiSelectClear = function(containerId) {
    const container = document.getElementById(containerId);
    container.querySelectorAll('.multi-select-options input[type="checkbox"]').forEach(cb => {
        cb.checked = false;
    });
    updateMultiSelectState(containerId);
    updateMultiSelectDisplay(containerId);
};

// Load projects into multi-select
async function loadProjectsForFilter() {
    try {
        const result = await apiCall('projects');
        if (result.success && result.data) {
            populateMultiSelect('projectMultiSelect', result.data, 'name', 'id');
        }
    } catch (error) {
        console.error('Error loading projects for filter:', error);
    }
}

// Initialize content type multi-select
function initializeContentTypeMultiSelect() {
    const contentTypes = [
        { id: 'Workbook', name: 'Workbooks', label: 'Workbooks' },
        { id: 'Data Source', name: 'Data Sources', label: 'Data Sources' },
        { id: 'Flow', name: 'Flows', label: 'Flows' },
        { id: 'View', name: 'Views', label: 'Views' }
    ];
    populateMultiSelect('contentTypeMultiSelect', contentTypes, 'name', 'id');
}

// Load objects based on content type and project selection
async function loadObjectsForFilter() {
    const contentTypes = multiSelectState.contentTypeMultiSelect?.selected || [];
    const projectIds = multiSelectState.projectMultiSelect?.selected || [];

    try {
        // If no content types selected, load all
        let url = 'content_by_type?';
        if (contentTypes.length === 1) {
            url += `type=${encodeURIComponent(contentTypes[0])}`;
        }
        if (projectIds.length > 0) {
            url += (contentTypes.length === 1 ? '&' : '') + projectIds.map(id => `project_ids=${encodeURIComponent(id)}`).join('&');
        }

        const result = await apiCall(url);
        if (result.success && result.data) {
            // Filter by content types if multiple selected
            let filteredData = result.data;
            if (contentTypes.length > 1) {
                filteredData = result.data.filter(item => contentTypes.includes(item.type));
            }

            // Add type badge info to each option
            const optionsWithType = filteredData.map(item => ({
                ...item,
                displayName: item.name,
                typeClass: getTypeBadgeClass(item.type)
            }));

            populateMultiSelectWithTypes('objectMultiSelect', optionsWithType);

            // Also update content cache for search
            allContentCache = result.data;
        }
    } catch (error) {
        console.error('Error loading objects for filter:', error);
    }
}

// Populate multi-select with type badges
function populateMultiSelectWithTypes(containerId, options) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const optionsContainer = container.querySelector('.multi-select-options');
    multiSelectState[containerId] = { selected: [], options: options };

    optionsContainer.innerHTML = options.map(opt => `
        <label class="multi-select-option" data-value="${opt.id}">
            <input type="checkbox" value="${opt.id}">
            <span style="flex: 1;">${opt.name}</span>
            <span class="type-badge ${opt.typeClass}">${opt.type}</span>
        </label>
    `).join('');

    // Add change listeners
    optionsContainer.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        cb.addEventListener('change', () => {
            updateMultiSelectState(containerId);
            updateMultiSelectDisplay(containerId);
        });
    });

    updateMultiSelectDisplay(containerId);
}

function getTypeBadgeClass(type) {
    const classes = {
        'Project': 'project',
        'Workbook': 'workbook',
        'Data Source': 'datasource',
        'Flow': 'flow',
        'View': 'view'
    };
    return classes[type] || 'workbook';
}

// Search autocomplete with multi-tag support
function initializeSearchAutocomplete() {
    const searchInput = document.getElementById('globalSearchInput');
    const dropdown = document.getElementById('searchAutocomplete');
    const tagsContainer = document.getElementById('searchTags');
    const searchContainer = document.getElementById('searchTagsContainer');

    if (!searchInput || !dropdown) return;

    // Focus input when clicking container
    if (searchContainer) {
        searchContainer.addEventListener('click', () => searchInput.focus());
    }

    // Handle comma and enter to add tags
    searchInput.addEventListener('keydown', (e) => {
        if (e.key === ',' || e.key === 'Enter') {
            e.preventDefault();
            const term = searchInput.value.trim().replace(/,/g, '');
            if (term.length >= 2) {
                addSearchTag(term);
                searchInput.value = '';
                dropdown.classList.remove('show');
            }
        } else if (e.key === 'Backspace' && searchInput.value === '' && searchTags.length > 0) {
            // Remove last tag on backspace when input is empty
            removeSearchTag(searchTags.length - 1);
        } else if (e.key === 'Escape') {
            dropdown.classList.remove('show');
        }
    });

    searchInput.addEventListener('input', debounce(async (e) => {
        const term = e.target.value.trim().replace(/,/g, '');

        if (term.length < 2) {
            dropdown.classList.remove('show');
            return;
        }

        // Search in cached content
        let suggestions = allContentCache.filter(item =>
            item.name.toLowerCase().includes(term.toLowerCase())
        ).slice(0, 10);

        // If cache is empty, fetch from server
        if (suggestions.length === 0 && allContentCache.length === 0) {
            try {
                const result = await apiCall('content_by_type');
                if (result.success && result.data) {
                    allContentCache = result.data;
                    suggestions = allContentCache.filter(item =>
                        item.name.toLowerCase().includes(term.toLowerCase())
                    ).slice(0, 10);
                }
            } catch (error) {
                console.error('Error fetching suggestions:', error);
            }
        }

        if (suggestions.length === 0) {
            dropdown.innerHTML = '<div class="search-no-results">No results found. Press comma or Enter to add as search term.</div>';
        } else {
            dropdown.innerHTML = suggestions.map(item => {
                const highlightedName = item.name.replace(
                    new RegExp(`(${escapeRegex(term)})`, 'gi'),
                    '<span class="search-suggestion-highlight">$1</span>'
                );
                return `
                    <div class="search-suggestion" data-id="${item.id}" data-name="${item.name}">
                        <span class="search-suggestion-name">${highlightedName}</span>
                        <span class="type-badge ${getTypeBadgeClass(item.type)}">${item.type}</span>
                    </div>
                `;
            }).join('');

            // Add click handlers to add as tag
            dropdown.querySelectorAll('.search-suggestion').forEach(el => {
                el.addEventListener('click', () => {
                    addSearchTag(el.dataset.name);
                    searchInput.value = '';
                    dropdown.classList.remove('show');
                });
            });
        }

        dropdown.classList.add('show');
    }, 300));

    // Close on click outside
    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !dropdown.contains(e.target) &&
            !searchContainer?.contains(e.target)) {
            dropdown.classList.remove('show');
        }
    });
}

// Escape regex special characters
function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Add search tag
function addSearchTag(term) {
    if (!term || searchTags.includes(term)) return;

    searchTags.push(term);
    renderSearchTags();
}

// Remove search tag
function removeSearchTag(index) {
    searchTags.splice(index, 1);
    renderSearchTags();
}

// Render search tags
function renderSearchTags() {
    const container = document.getElementById('searchTags');
    if (!container) return;

    container.innerHTML = searchTags.map((tag, index) => `
        <span class="search-tag">
            ${escapeHtml(tag)}
            <span class="search-tag-remove" onclick="removeSearchTag(${index})">&times;</span>
        </span>
    `).join('');
}

// Get all search terms (tags + input)
function getAllSearchTerms() {
    const input = document.getElementById('globalSearchInput');
    const inputValue = input ? input.value.trim() : '';
    const terms = [...searchTags];
    if (inputValue.length >= 2) {
        terms.push(inputValue);
    }
    return terms;
}

// Make removeSearchTag globally available
window.removeSearchTag = removeSearchTag;

// Apply global filters
window.applyGlobalFilters = async function() {
    const projectIds = multiSelectState.projectMultiSelect?.selected || [];
    const contentTypes = multiSelectState.contentTypeMultiSelect?.selected || [];
    const objectIds = multiSelectState.objectMultiSelect?.selected || [];
    const searchTerms = getAllSearchTerms();
    const deepSearch = document.getElementById('deepSearchToggle').checked;

    const filterData = {
        project_ids: projectIds,
        content_types: contentTypes,
        content_type: contentTypes.length === 1 ? contentTypes[0] : '',
        object_ids: objectIds,
        search_terms: searchTerms,
        search_term: searchTerms.join(' '), // For backward compatibility
        deep_search: deepSearch
    };

    // Store filter context locally for immediate use
    window.currentFilterContext = filterData;

    try {
        const result = await apiCall('set_filter_context', 'POST', filterData);
        if (result.success) {
            // Update filter badge
            const badge = document.getElementById('filterActiveBadge');
            const hasFilters = projectIds.length > 0 || contentTypes.length > 0 ||
                             objectIds.length > 0 || searchTerms.length > 0;
            if (hasFilters) {
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }

            // Reload data with filters applied
            await refreshFilteredData();
        }
    } catch (error) {
        console.error('Error applying filters:', error);
        alert('Error applying filters: ' + error.message);
    }
};

// Clear global filters
window.clearGlobalFilters = async function() {
    // Clear UI
    multiSelectClear('projectMultiSelect');
    multiSelectClear('contentTypeMultiSelect');
    multiSelectClear('objectMultiSelect');
    document.getElementById('globalSearchInput').value = '';
    document.getElementById('deepSearchToggle').checked = false;

    // Clear search tags
    searchTags = [];
    renderSearchTags();

    // Clear local filter context
    window.currentFilterContext = null;

    // Hide autocomplete
    document.getElementById('searchAutocomplete').classList.remove('show');

    try {
        await apiCall('clear_filter_context', 'POST');

        // Hide filter badge
        document.getElementById('filterActiveBadge').classList.add('hidden');

        // Reload unfiltered data
        await refreshFilteredData();
    } catch (error) {
        console.error('Error clearing filters:', error);
    }
};

// Refresh data with current filter context
async function refreshFilteredData() {
    const filterCtx = window.currentFilterContext || {};
    const searchTerms = filterCtx.search_terms || [];
    const deepSearch = filterCtx.deep_search || false;
    const projectIds = filterCtx.project_ids || [];
    const contentTypes = filterCtx.content_types || [];
    const objectIds = filterCtx.object_ids || [];

    // Use original content as base
    let baseContent = state.originalContent.length > 0 ? state.originalContent : state.content;

    // Apply project filter
    if (projectIds.length > 0 && state.projects.length > 0) {
        const projectNames = new Set();
        projectIds.forEach(pid => {
            const proj = state.projects.find(p => p.id === pid);
            if (proj) projectNames.add(proj.name);
        });
        baseContent = baseContent.filter(item =>
            item.Type === 'Site' ||
            (item.Type === 'Project' && projectNames.has(item.Name)) ||
            projectNames.has(item.Parent)
        );
    }

    // Apply content type filter
    if (contentTypes.length > 0) {
        baseContent = baseContent.filter(item => contentTypes.includes(item.Type));
    }

    // Apply object ID filter
    if (objectIds.length > 0) {
        baseContent = baseContent.filter(item => objectIds.includes(item.ID));
    }

    // Apply search terms filter
    if (searchTerms.length > 0) {
        baseContent = filterBySearchTerms(baseContent, searchTerms, ['Name', 'Parent']);
    }

    // Calculate stats from filtered content
    const stats = {
        workbooks: baseContent.filter(i => i.Type === 'Workbook').length,
        datasources: baseContent.filter(i => i.Type === 'Data Source').length,
        views: baseContent.filter(i => i.Type === 'View').length,
        projects: baseContent.filter(i => i.Type === 'Project').length,
        flows: baseContent.filter(i => i.Type === 'Flow').length
    };

    // Update all KPI stats
    document.getElementById('statWorkbooks').textContent = stats.workbooks || 0;
    document.getElementById('statDatasources').textContent = stats.datasources || 0;
    document.getElementById('statViews').textContent = stats.views || 0;
    document.getElementById('statProjects').textContent = stats.projects || 0;
    document.getElementById('statFlows').textContent = stats.flows || 0;

    // Update extraction preview counts
    updateExtractionPreview(stats);

    // Trigger content table re-filter (uses filterContent which applies global filter)
    filterContent();
    updateContentTypeChipCounts();

    // Update deep analysis stats based on filtered data
    if (state.originalDeepData.custom_sql.length > 0 || state.originalDeepData.calculations.length > 0) {
        // Get valid object names from filtered content
        const validObjectNames = new Set(baseContent.map(item => item.Name));

        // Filter deep data
        let filteredSQL = state.originalDeepData.custom_sql;
        let filteredCalcs = state.originalDeepData.calculations;
        let filteredLineage = state.originalDeepData.lineage;
        let filteredConnections = state.originalDeepData.connections;

        // Apply project/content type filter to deep data
        if (projectIds.length > 0 || contentTypes.length > 0 || objectIds.length > 0) {
            filteredSQL = filteredSQL.filter(item => validObjectNames.has(item.object_name));
            filteredCalcs = filteredCalcs.filter(item => validObjectNames.has(item.object_name));
            filteredLineage = filteredLineage.filter(item =>
                validObjectNames.has(item.upstream_object) || validObjectNames.has(item.downstream_object));
            filteredConnections = filteredConnections.filter(item => validObjectNames.has(item.object_name));
        }

        // Apply search terms to deep data
        if (searchTerms.length > 0) {
            filteredSQL = filterBySearchTerms(filteredSQL, searchTerms,
                getDeepSearchFields('sql', deepSearch));
            filteredCalcs = filterBySearchTerms(filteredCalcs, searchTerms,
                getDeepSearchFields('calculations', deepSearch));
            filteredLineage = filterBySearchTerms(filteredLineage, searchTerms,
                getDeepSearchFields('lineage', deepSearch));
            filteredConnections = filterBySearchTerms(filteredConnections, searchTerms,
                getDeepSearchFields('connections', deepSearch));
        }

        // Update deep stats
        document.getElementById('statCustomSQL').textContent = filteredSQL.length;
        document.getElementById('statCalculations').textContent = filteredCalcs.length;
        document.getElementById('statLineage').textContent = filteredLineage.length;
        document.getElementById('statConnections').textContent = filteredConnections.length;

        // Re-render deep table if currently viewing
        renderDeepTable();
    }
}

// Helper function to filter data by multiple search terms
function filterBySearchTerms(data, searchTerms, fields) {
    if (!data || !Array.isArray(data) || searchTerms.length === 0) return data;

    return data.filter(item => {
        // Item matches if ANY search term matches ANY field
        return searchTerms.some(term => {
            const lowerTerm = term.toLowerCase();
            return fields.some(field => {
                const value = item[field];
                return value && String(value).toLowerCase().includes(lowerTerm);
            });
        });
    });
}

// Initialize filter system
function initializeFilterSystem() {
    initializeMultiSelects();
    initializeContentTypeMultiSelect();
    loadProjectsForFilter();
    loadObjectsForFilter();
    initializeSearchAutocomplete();

    // Content type change handler - reload objects when type changes
    const contentTypeContainer = document.getElementById('contentTypeMultiSelect');
    if (contentTypeContainer) {
        contentTypeContainer.addEventListener('change', () => {
            loadObjectsForFilter();
        });
    }

    // Project selection change handler - reload objects when projects change
    const projectContainer = document.getElementById('projectMultiSelect');
    if (projectContainer) {
        projectContainer.addEventListener('change', () => {
            loadObjectsForFilter();
        });
    }

    // Enter key to apply filters
    document.getElementById('globalSearchInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('searchAutocomplete').classList.remove('show');
            applyGlobalFilters();
        }
    });
}

// ==================== Usage & Criticality Analytics ====================

async function runUsageAnalytics() {
    const btn = document.getElementById('btnRunAnalytics');
    const statusText = document.getElementById('analyticsStatusText');

    btn.disabled = true;
    statusText.textContent = 'Starting analysis...';

    try {
        // Get config from session storage
        const configStr = sessionStorage.getItem('tableauConfig');
        const config = configStr ? JSON.parse(configStr) : null;

        // Build request body
        const requestBody = { config };

        // Check if Tableau Cloud - automatically use Admin Insights
        if (config && config.is_cloud) {
            requestBody.use_admin_insights = true;
            statusText.textContent = 'Starting analysis with Admin Insights (Tableau Cloud)...';
        } else if (state.analytics.repositoryConfig) {
            // Tableau Server with repository config
            requestBody.repository_config = state.analytics.repositoryConfig;
            statusText.textContent = 'Starting analysis with Repository data...';
        }

        const response = await apiCall('run_usage_analytics', 'POST', requestBody);
        if (response.success) {
            state.analytics.jobId = response.job_id;
            pollAnalyticsStatus(response.job_id);
        } else {
            statusText.textContent = 'Error: ' + (response.error || 'Unknown error');
            btn.disabled = false;
        }
    } catch (error) {
        statusText.textContent = 'Error: ' + error.message;
        btn.disabled = false;
    }
}

async function runWithAdminInsightsAuto() {
    const statusText = document.getElementById('analyticsStatusText');

    // Close the modal
    closeUsageSourceModal();

    statusText.textContent = 'Starting analysis with Admin Insights (Auto-Fetch)...';

    try {
        // Get config from session storage
        const configStr = sessionStorage.getItem('tableauConfig');
        const config = configStr ? JSON.parse(configStr) : null;

        if (!config) {
            statusText.textContent = 'Error: No Tableau connection configured';
            return;
        }

        // Request with use_admin_insights flag
        const requestBody = {
            config,
            use_admin_insights: true
        };

        const response = await apiCall('run_usage_analytics', 'POST', requestBody);
        if (response.success) {
            state.analytics.jobId = response.job_id;
            pollAnalyticsStatus(response.job_id);
        } else {
            statusText.textContent = 'Error: ' + (response.error || 'Unknown error');
        }
    } catch (error) {
        statusText.textContent = 'Error: ' + error.message;
    }
}

async function pollAnalyticsStatus(jobId) {
    const statusText = document.getElementById('analyticsStatusText');
    const btn = document.getElementById('btnRunAnalytics');

    try {
        const response = await apiCall(`analytics_status/${jobId}`);
        if (response.success) {
            statusText.textContent = `${response.message} (${response.progress}%)`;

            if (response.status === 'completed') {
                await loadAnalyticsResult(jobId);
                btn.disabled = false;
            } else if (response.status === 'failed') {
                statusText.textContent = 'Analysis failed: ' + response.message;
                btn.disabled = false;
            } else {
                setTimeout(() => pollAnalyticsStatus(jobId), 1500);
            }
        }
    } catch (error) {
        statusText.textContent = 'Error polling status';
        btn.disabled = false;
    }
}

async function loadAnalyticsResult(jobId) {
    try {
        const response = await apiCall(`analytics_result/${jobId}`);
        if (response.success) {
            // Debug logging
            console.log('Analytics result received:', response.data);
            console.log('Workbook analytics count:', response.data.workbook_analytics?.length || 0);
            console.log('View analytics count:', response.data.view_analytics?.length || 0);
            console.log('Lineage impact count:', response.data.lineage_impact?.length || 0);
            console.log('KPI summary:', response.data.kpi_summary);
            console.log('Errors:', response.data.errors);

            state.analytics.data = response.data;
            state.analytics.jobId = jobId;

            // Save to sessionStorage for persistence. Browsers cap storage at ~5MB, so a large site's
            // result does not fit - that must never break rendering, just skip persistence.
            try {
                sessionStorage.setItem('analyticsData', JSON.stringify(response.data));
            } catch (storageError) {
                console.warn('Analytics result too large for sessionStorage - not persisted', storageError);
                try { sessionStorage.removeItem('analyticsData'); } catch (e) { /* ignore */ }
            }

            updateAnalyticsKPIs(response.data.kpi_summary);
            updateAnalyticsTabCounts();
            showAnalyticsTab('workbooks');
            updateDataSourceIndicator(response.data.data_sources);
            updateUsageSourceBadge(response.data.usage_data_source);

            // Check for errors and display warnings
            if (response.data.errors && response.data.errors.length > 0) {
                const statusText = document.getElementById('analyticsStatusText');
                const adminInsightsError = response.data.errors.find(e => e.includes('Admin Insights'));
                if (adminInsightsError) {
                    statusText.innerHTML = `<span style="color: #f59e0b;">Analysis complete (Admin Insights not available)</span>`;
                    // Show alert for Admin Insights
                    showAnalyticsWarning(adminInsightsError);
                } else {
                    statusText.textContent = 'Analysis complete!';
                }
            } else {
                document.getElementById('analyticsStatusText').textContent = 'Analysis complete!';
            }
        }
    } catch (error) {
        console.error('Error loading analytics result:', error);
    }
}

function restoreAnalyticsFromStorage() {
    // Try to restore analytics data from sessionStorage
    const savedData = sessionStorage.getItem('analyticsData');
    if (savedData) {
        try {
            const data = JSON.parse(savedData);
            state.analytics.data = data;
            updateAnalyticsKPIs(data.kpi_summary || {});
            updateAnalyticsTabCounts();
            showAnalyticsTab('workbooks');
            if (data.data_sources) {
                updateDataSourceIndicator(data.data_sources);
            }
            document.getElementById('analyticsStatusText').textContent = 'Loaded from previous analysis';
            return true;
        } catch (e) {
            console.error('Error restoring analytics:', e);
        }
    }
    return false;
}

// ==================== Usage Source Configuration ====================

function showUsageSourceConfig() {
    const modal = document.getElementById('usageSourceModal');
    modal.classList.remove('hidden');

    // Check if Tableau Cloud
    const configStr = sessionStorage.getItem('tableauConfig');
    const config = configStr ? JSON.parse(configStr) : null;
    const isCloud = config && config.is_cloud;

    // Get tab elements
    const repoTabBtn = document.querySelector('[data-source-tab="repository"]');
    const noteBox = document.querySelector('#usageSourceModal .modal-body > div:first-child p');
    const cloudAutoMsg = document.getElementById('cloudAutoDetectMsg');

    if (isCloud) {
        // Hide Server Repository tab for Cloud
        if (repoTabBtn) repoTabBtn.style.display = 'none';
        // Show auto-detect message
        if (cloudAutoMsg) cloudAutoMsg.style.display = 'block';
        // Update note for Cloud
        if (noteBox) {
            noteBox.innerHTML = '<strong>Tableau Cloud Detected:</strong> Admin Insights will automatically fetch actual "Last Viewed" dates using your PAT credentials.';
        }
        // Default to Admin Insights tab
        showUsageSourceTab('insights');
    } else {
        // Show all tabs for Server
        if (repoTabBtn) repoTabBtn.style.display = '';
        // Hide auto-detect message
        if (cloudAutoMsg) cloudAutoMsg.style.display = 'none';
        // Reset note for Server
        if (noteBox) {
            noteBox.innerHTML = '<strong>Note:</strong> By default, usage metrics are estimated from REST API data (total views, modified dates). For accurate access data, connect to the Tableau Server Repository.';
        }
        // Default to REST tab
        showUsageSourceTab('rest');
    }
}

function closeUsageSourceModal() {
    document.getElementById('usageSourceModal').classList.add('hidden');
}

function showUsageSourceTab(tab) {
    // Update tab buttons
    document.querySelectorAll('[data-source-tab]').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.sourceTab === tab);
    });

    // Show/hide content
    document.getElementById('usageSourceRestTab').classList.toggle('hidden', tab !== 'rest');
    document.getElementById('usageSourceRepoTab').classList.toggle('hidden', tab !== 'repository');
    document.getElementById('usageSourceInsightsTab').classList.toggle('hidden', tab !== 'insights');
}

async function testRepositoryConnection() {
    const statusEl = document.getElementById('repoConnectionStatus');
    statusEl.innerHTML = '<span style="color: var(--primary-color);">Testing connection...</span>';

    const config = {
        host: document.getElementById('repoHost').value,
        port: parseInt(document.getElementById('repoPort').value) || 8060,
        database: document.getElementById('repoDatabase').value || 'workgroup',
        user: document.getElementById('repoUser').value || 'readonly',
        password: document.getElementById('repoPassword').value
    };

    if (!config.host) {
        statusEl.innerHTML = '<span style="color: #dc2626;">Host is required</span>';
        return;
    }

    try {
        const response = await apiCall('test_repository_connection', 'POST', config);
        if (response.success) {
            statusEl.innerHTML = `<span style="color: #16a34a;">${response.message}</span>`;
        } else {
            statusEl.innerHTML = `<span style="color: #dc2626;">${response.error}</span>`;
        }
    } catch (error) {
        statusEl.innerHTML = `<span style="color: #dc2626;">Connection failed: ${error.message}</span>`;
    }
}

function saveRepositoryConfig() {
    const config = {
        host: document.getElementById('repoHost').value,
        port: parseInt(document.getElementById('repoPort').value) || 8060,
        database: document.getElementById('repoDatabase').value || 'workgroup',
        user: document.getElementById('repoUser').value || 'readonly',
        password: document.getElementById('repoPassword').value
    };

    if (!config.host) {
        alert('Host is required');
        return;
    }

    state.analytics.repositoryConfig = config;
    state.analytics.usageDataSource = 'repository';

    // Update badge
    const badge = document.getElementById('usageSourceBadge');
    const label = document.getElementById('usageSourceLabel');
    badge.style.display = 'inline-flex';
    badge.className = 'badge badge-green';
    label.textContent = 'Repository (Configured)';

    closeUsageSourceModal();

    // Show confirmation
    document.getElementById('analyticsStatusText').textContent = 'Repository configured. Click "Run Usage Analysis" to use.';
}

async function handleAdminInsightsUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const statusEl = document.getElementById('insightsUploadStatus');
    statusEl.innerHTML = '<span style="color: var(--primary-color);">Uploading...</span>';

    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/api/upload_admin_insights', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            statusEl.innerHTML = `
                <div style="padding: 0.75rem; background: #dcfce7; border-radius: 6px; margin-top: 0.5rem;">
                    <strong style="color: #166534;">${result.message}</strong>
                    <p style="margin: 0.5rem 0 0; font-size: 0.8rem; color: #166534;">
                        Columns: ${result.preview.columns.join(', ')}
                    </p>
                </div>
            `;
            document.getElementById('btnUseInsights').classList.remove('hidden');
            state.analytics.usageDataSource = 'admin_insights';
        } else {
            statusEl.innerHTML = `<span style="color: #dc2626;">${result.error}</span>`;
        }
    } catch (error) {
        statusEl.innerHTML = `<span style="color: #dc2626;">Upload failed: ${error.message}</span>`;
    }
}

async function useAdminInsights() {
    const btn = document.getElementById('btnRunAnalytics');
    const statusText = document.getElementById('analyticsStatusText');

    btn.disabled = true;
    statusText.textContent = 'Starting analysis with Admin Insights...';
    closeUsageSourceModal();

    try {
        const configStr = sessionStorage.getItem('tableauConfig');
        const config = configStr ? JSON.parse(configStr) : null;

        const response = await apiCall('run_usage_analytics_with_insights', 'POST', { config });
        if (response.success) {
            state.analytics.jobId = response.job_id;
            pollAnalyticsStatus(response.job_id);
        } else {
            statusText.textContent = 'Error: ' + (response.error || 'Unknown error');
            btn.disabled = false;
        }
    } catch (error) {
        statusText.textContent = 'Error: ' + error.message;
        btn.disabled = false;
    }
}

function updateUsageSourceBadge(source) {
    const badge = document.getElementById('usageSourceBadge');
    const label = document.getElementById('usageSourceLabel');

    if (!badge || !label) return;

    badge.style.display = 'inline-flex';

    if (source === 'Repository') {
        badge.className = 'badge badge-green';
        label.textContent = 'Repository';
        state.analytics.usageDataSource = 'repository';
    } else if (source === 'Admin Insights') {
        badge.className = 'badge badge-blue';
        label.textContent = 'Admin Insights';
        state.analytics.usageDataSource = 'admin_insights';
    } else {
        badge.className = 'badge badge-orange';
        label.textContent = 'REST API (Estimated)';
        state.analytics.usageDataSource = 'rest';
    }
}

function showAnalyticsWarning(message) {
    // Create a warning banner above the analytics table
    const existingWarning = document.getElementById('analyticsWarningBanner');
    if (existingWarning) existingWarning.remove();

    const warningDiv = document.createElement('div');
    warningDiv.id = 'analyticsWarningBanner';
    warningDiv.style.cssText = 'padding: 0.75rem 1rem; background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;';
    warningDiv.innerHTML = `
        <svg width="20" height="20" fill="none" stroke="#d97706" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
        </svg>
        <span style="color: #92400e; font-size: 0.875rem;">${message}</span>
        <button onclick="this.parentElement.remove()" style="margin-left: auto; background: none; border: none; cursor: pointer; color: #92400e;">&times;</button>
    `;

    const analyticsSection = document.getElementById('analyticsContent');
    if (analyticsSection) {
        analyticsSection.insertBefore(warningDiv, analyticsSection.firstChild);
    }
}

function updateAnalyticsKPIs(kpi) {
    // Usage metrics - support Admin Insights and legacy format field names
    document.getElementById('analyticsStatViews').textContent = formatNumber(
        kpi.total_views_30d || kpi.total_views || kpi.total_views_all_time || kpi.total_workbooks || 0
    );
    document.getElementById('analyticsStatActive7d').textContent =
        kpi.active_7d || kpi.active_workbooks_7d || Math.round((kpi.active_workbooks_30d || 0) * 0.3) || 0;
    document.getElementById('analyticsStatActive').textContent =
        kpi.active_30d || kpi.active_workbooks_30d || 0;
    document.getElementById('analyticsStatDormant').textContent =
        kpi.dormant_90d || kpi.dormant_workbooks_90d || 0;

    // Governance metrics
    document.getElementById('analyticsStatSunset').textContent = kpi.sunset_candidates || 0;
    document.getElementById('analyticsStatHighRisk').textContent =
        kpi.high_risk || kpi.high_governance_risk || kpi.high_risk_count || 0;

    // Tier counts - support both formats
    document.getElementById('tier1Count').textContent = kpi.tier1_count || kpi.tier_1_count || 0;
    document.getElementById('tier2Count').textContent = kpi.tier2_count || kpi.tier_2_count || 0;
    document.getElementById('tier3Count').textContent = kpi.tier3_count || kpi.tier_3_count || 0;

    // Users KPIs
    updateUsersKPIs(kpi);
}

function updateUsersKPIs(kpi) {
    // Update users KPI cards
    const el = (id) => document.getElementById(id);

    if (el('usersStatTotal')) el('usersStatTotal').textContent = kpi.total_users || 0;
    if (el('usersStatActive')) el('usersStatActive').textContent = kpi.active_users || 0;
    if (el('usersStatAtRisk')) el('usersStatAtRisk').textContent = kpi.at_risk_users || 0;
    if (el('usersStatInactive')) el('usersStatInactive').textContent = kpi.inactive_users || 0;
    if (el('usersStatNeverUsed')) el('usersStatNeverUsed').textContent = kpi.never_used_users || 0;
    if (el('usersStatLicenseWaste')) el('usersStatLicenseWaste').textContent = kpi.license_waste_users || 0;
    if (el('usersStatAdminRisk')) el('usersStatAdminRisk').textContent = kpi.admin_risk_users || 0;
    if (el('usersStatCreators')) el('usersStatCreators').textContent = kpi.creators || 0;
    if (el('usersStatExplorers')) el('usersStatExplorers').textContent = kpi.explorers || 0;
    if (el('usersStatViewers')) el('usersStatViewers').textContent = kpi.viewers || 0;
    if (el('usersStatUnlicensed')) el('usersStatUnlicensed').textContent = kpi.unlicensed || 0;

    // User tier counts
    if (el('userTier1Count')) el('userTier1Count').textContent = kpi.user_tier_1 || 0;
    if (el('userTier2Count')) el('userTier2Count').textContent = kpi.user_tier_2 || 0;
    if (el('userTier3Count')) el('userTier3Count').textContent = kpi.user_tier_3 || 0;
    if (el('userTier4Count')) el('userTier4Count').textContent = kpi.user_tier_4 || 0;

    // License utilization
    if (el('licenseAllowed')) el('licenseAllowed').textContent = kpi.total_allowed_licenses || '-';
    if (el('licenseOccupied')) el('licenseOccupied').textContent = kpi.total_occupied_licenses || '-';
    if (el('licenseRemaining')) el('licenseRemaining').textContent = kpi.total_remaining_licenses || '-';
    if (el('licenseCreatorPct')) el('licenseCreatorPct').textContent = kpi.creator_usage_pct ? kpi.creator_usage_pct + '%' : '-';
    if (el('licenseExplorerPct')) el('licenseExplorerPct').textContent = kpi.explorer_usage_pct ? kpi.explorer_usage_pct + '%' : '-';
    if (el('licenseViewerPct')) el('licenseViewerPct').textContent = kpi.viewer_usage_pct ? kpi.viewer_usage_pct + '%' : '-';
}

function updateAnalyticsTabCounts() {
    const data = state.analytics.data || {};

    // Get counts for each tab
    const workbooksCount = (data.workbook_analytics || []).length;
    const datasourcesCount = (data.datasource_analytics || []).length;
    const flowsCount = (data.flow_analytics || []).length;
    const usersCount = (data.user_analytics || []).length;

    // Update tab labels with counts
    const setCount = (id, count) => {
        const el = document.getElementById(id);
        if (el) el.textContent = count > 0 ? `(${count})` : '';
    };

    setCount('tabCountWorkbooks', workbooksCount);
    setCount('tabCountDatasources', datasourcesCount);
    setCount('tabCountFlows', flowsCount);
    setCount('tabCountUsers', usersCount);
}

function updateDataSourceIndicator(dataSources) {
    const sources = [];
    if (dataSources.rest && dataSources.rest.length > 0) {
        sources.push('REST API (' + dataSources.rest.join(', ') + ')');
    }
    if (dataSources.metadata_api && dataSources.metadata_api.length > 0) {
        sources.push('Metadata API (' + dataSources.metadata_api.join(', ') + ')');
    }
    if (dataSources.calculated && dataSources.calculated.length > 0) {
        sources.push('Calculated (' + dataSources.calculated.join(', ') + ')');
    }
    document.getElementById('dataSourceList').textContent = sources.join(' | ') || '-';
}

function showAnalyticsTab(tab) {
    state.analytics.currentTab = tab;
    state.pagination.analytics.page = 1;

    // Update tab styling
    document.querySelectorAll('[data-analytics-tab]').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.analyticsTab === tab);
    });

    // Get references to containers
    const dataCard = document.querySelector('#analyticsSection .data-card');
    const scoringContent = document.getElementById('scoringModelContent');
    const dataSourceIndicator = document.getElementById('analyticsDataSource');

    // Handle scoring model tab specially
    if (tab === 'scoring') {
        // Hide data card, show scoring content
        if (dataCard) dataCard.classList.add('hidden');
        if (scoringContent) scoringContent.classList.remove('hidden');
        if (dataSourceIndicator) dataSourceIndicator.classList.add('hidden');
        return; // Don't render table for scoring tab
    } else {
        // Show data card, hide scoring content
        if (dataCard) dataCard.classList.remove('hidden');
        if (scoringContent) scoringContent.classList.add('hidden');
        if (dataSourceIndicator) dataSourceIndicator.classList.remove('hidden');
    }

    // Reset sort state when switching tabs
    state.analytics.sort = { column: null, direction: 'asc' };

    // Update table headers and title
    const titleSpan = document.querySelector('#analyticsTableTitle span');
    const thead = document.getElementById('analyticsTableHead');

    // Helper to create sortable header
    const sortableHeader = (label, column) => {
        const sortIcon = state.analytics.sort.column === column
            ? (state.analytics.sort.direction === 'asc' ? ' ▲' : ' ▼')
            : ' ⇅';
        return `<th class="sortable" data-sort="${column}" onclick="sortAnalyticsTable('${column}')">${label}<span class="sort-icon">${sortIcon}</span></th>`;
    };

    if (tab === 'workbooks') {
        titleSpan.textContent = 'Workbook Governance Analytics';
        thead.innerHTML = `<tr>
            ${sortableHeader('Workbook', 'workbook_name')}
            ${sortableHeader('Project', 'project')}
            ${sortableHeader('Owner', 'owner')}
            ${sortableHeader('Views (30d)', 'views_30d')}
            ${sortableHeader('Users', 'unique_users_30d')}
            ${sortableHeader('Last Accessed', 'last_accessed')}
            ${sortableHeader('Size (MB)', 'size_mb')}
            ${sortableHeader('Criticality', 'criticality_score')}
            ${sortableHeader('Sunset', 'is_sunset_candidate')}
            ${sortableHeader('Tier', 'tier')}
        </tr>`;
    } else if (tab === 'retirement') {
        titleSpan.textContent = 'Sunset Candidates';
        thead.innerHTML = `<tr>
            ${sortableHeader('Workbook', 'workbook_name')}
            ${sortableHeader('Project', 'project_name')}
            ${sortableHeader('Owner', 'owner_name')}
            ${sortableHeader('Days Inactive', 'days_since_access')}
            ${sortableHeader('Sunset Score', 'sunset_score')}
            ${sortableHeader('Criticality', 'criticality_score')}
            ${sortableHeader('Recommendation', 'sunset_recommendation')}
            <th>Reasons</th>
        </tr>`;
    } else if (tab === 'lineage') {
        titleSpan.textContent = 'Lineage Impact';
        thead.innerHTML = `<tr>
            ${sortableHeader('Table', 'table_name')}
            ${sortableHeader('Schema', 'schema')}
            ${sortableHeader('Database', 'database')}
            ${sortableHeader('Connection', 'connection_type')}
            ${sortableHeader('Downstream Workbooks', 'downstream_workbook_count')}
            ${sortableHeader('Downstream Datasources', 'downstream_datasource_count')}
        </tr>`;
    } else if (tab === 'datasources') {
        titleSpan.textContent = 'Datasource Governance';
        thead.innerHTML = `<tr>
            ${sortableHeader('Datasource', 'datasource_name')}
            ${sortableHeader('Project', 'project')}
            ${sortableHeader('Owner', 'owner')}
            ${sortableHeader('Type', 'connection_type')}
            ${sortableHeader('Uses (30d)', 'use_count_30d')}
            ${sortableHeader('Last Accessed', 'last_accessed')}
            ${sortableHeader('Last Modified', 'last_modified')}
            ${sortableHeader('Subscribers', 'subscriber_count')}
            ${sortableHeader('Criticality', 'criticality_score')}
            ${sortableHeader('Sunset', 'is_sunset_candidate')}
            ${sortableHeader('Tier', 'tier')}
        </tr>`;
    } else if (tab === 'flows') {
        titleSpan.textContent = 'Flow Governance';
        thead.innerHTML = `<tr>
            ${sortableHeader('Flow', 'flow_name')}
            ${sortableHeader('Project', 'project')}
            ${sortableHeader('Owner', 'owner')}
            ${sortableHeader('Runs (30d)', 'runs_30d')}
            ${sortableHeader('Users', 'users')}
            ${sortableHeader('Last Run', 'last_run')}
            ${sortableHeader('Last Modified', 'last_modified')}
            ${sortableHeader('Failures', 'failures')}
            ${sortableHeader('Subscribers', 'subscribers')}
            ${sortableHeader('Criticality', 'criticality_score')}
            ${sortableHeader('Sunset', 'is_sunset_candidate')}
            ${sortableHeader('Tier', 'tier')}
        </tr>`;
    } else if (tab === 'users') {
        titleSpan.textContent = 'Users Governance';
        thead.innerHTML = `<tr>
            ${sortableHeader('User', 'user_name')}
            ${sortableHeader('Email', 'email')}
            ${sortableHeader('License', 'license_type')}
            ${sortableHeader('Site Role', 'site_role')}
            ${sortableHeader('Projects', 'projects')}
            ${sortableHeader('Workbooks', 'workbooks')}
            ${sortableHeader('Datasources', 'data_sources')}
            ${sortableHeader('Views', 'views')}
            ${sortableHeader('Last Login', 'last_login')}
            ${sortableHeader('Days Inactive', 'days_since_login')}
            ${sortableHeader('Contribution', 'contribution_score')}
            ${sortableHeader('Tier', 'user_tier')}
            ${sortableHeader('Status', 'user_status')}
            ${sortableHeader('License Waste', 'license_waste_flag')}
            ${sortableHeader('Admin Risk', 'admin_risk_flag')}
        </tr>`;
    }

    // Show/hide appropriate KPI sections based on tab
    const usersKpiSection = document.getElementById('usersKpiSection');
    const contentTierSummary = document.getElementById('contentTierSummary');
    const analyticsKPIs = document.getElementById('analyticsKPIs');

    if (tab === 'users') {
        if (usersKpiSection) usersKpiSection.style.display = 'block';
        if (contentTierSummary) contentTierSummary.style.display = 'none';
        if (analyticsKPIs) analyticsKPIs.style.display = 'none';
    } else {
        if (usersKpiSection) usersKpiSection.style.display = 'none';
        if (contentTierSummary) contentTierSummary.style.display = 'flex';
        if (analyticsKPIs) analyticsKPIs.style.display = 'grid';
    }

    // Update tier counts based on current tab data
    updateTierCountsForTab(tab);

    renderAnalyticsTable();
}

// Update tier counts based on current tab's data
function updateTierCountsForTab(tab) {
    const data = state.analytics.data;
    if (!data) return;

    let items = [];
    if (tab === 'workbooks') {
        items = data.workbook_analytics || [];
    } else if (tab === 'datasources') {
        items = data.datasource_analytics || [];
    } else if (tab === 'flows') {
        items = data.flow_analytics || [];
    } else if (tab === 'users') {
        // Update users tier counts
        items = data.user_analytics || [];
        let tier1 = 0, tier2 = 0, tier3 = 0, tier4 = 0;
        items.forEach(item => {
            const tier = item.user_tier || 'Tier 4';
            if (tier.includes('Tier 1')) tier1++;
            else if (tier.includes('Tier 2')) tier2++;
            else if (tier.includes('Tier 3')) tier3++;
            else tier4++;
        });
        document.getElementById('userTier1Count').textContent = tier1;
        document.getElementById('userTier2Count').textContent = tier2;
        document.getElementById('userTier3Count').textContent = tier3;
        document.getElementById('userTier4Count').textContent = tier4;
        return;
    } else {
        return; // Don't update for other tabs
    }

    // Count tiers for content tabs
    let tier1 = 0, tier2 = 0, tier3 = 0;
    items.forEach(item => {
        const tier = item.Tier || item.tier || 'Tier 3';
        if (tier.includes('Tier 1')) tier1++;
        else if (tier.includes('Tier 2')) tier2++;
        else tier3++;
    });

    document.getElementById('tier1Count').textContent = tier1;
    document.getElementById('tier2Count').textContent = tier2;
    document.getElementById('tier3Count').textContent = tier3;
}

// Scoring Model threshold functions (placeholder for future implementation)
function resetThresholds() {
    // Reset all threshold inputs to default values
    document.getElementById('configWeightUsage').value = 30;
    document.getElementById('configWeightUsers').value = 20;
    document.getElementById('configWeightLineage').value = 20;
    document.getElementById('configWeightOperational').value = 15;
    document.getElementById('configWeightComplexity').value = 15;
    document.getElementById('configTier1').value = 70;
    document.getElementById('configTier2').value = 40;
    document.getElementById('configSunset').value = 70;
    document.getElementById('configReview').value = 50;
}

function saveThresholds() {
    // Placeholder for saving thresholds
    alert('Threshold configuration will be available in a future release.');
}

function sortAnalyticsTable(column) {
    const currentSort = state.analytics.sort;

    // Toggle direction if same column, otherwise default to ascending
    if (currentSort.column === column) {
        currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
    } else {
        currentSort.column = column;
        currentSort.direction = 'asc';
    }

    // Update header icons
    updateSortIcons();

    // Reset to page 1 and re-render
    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

function updateSortIcons() {
    const thead = document.getElementById('analyticsTableHead');
    const headers = thead.querySelectorAll('th.sortable');

    headers.forEach(th => {
        const column = th.dataset.sort;
        const iconSpan = th.querySelector('.sort-icon');
        if (iconSpan) {
            if (state.analytics.sort.column === column) {
                iconSpan.textContent = state.analytics.sort.direction === 'asc' ? ' ▲' : ' ▼';
            } else {
                iconSpan.textContent = ' ⇅';
            }
        }
    });
}

function applySorting(items) {
    const { column, direction } = state.analytics.sort;
    if (!column) return items;

    return [...items].sort((a, b) => {
        let valA = a[column];
        let valB = b[column];

        // Handle null/undefined
        if (valA == null) valA = '';
        if (valB == null) valB = '';

        // Handle booleans
        if (typeof valA === 'boolean') valA = valA ? 1 : 0;
        if (typeof valB === 'boolean') valB = valB ? 1 : 0;

        // Handle dates
        if (column.includes('date') || column.includes('accessed') || column === 'last_accessed' || column === 'updated_at' || column === 'created_at') {
            valA = valA ? new Date(valA).getTime() : 0;
            valB = valB ? new Date(valB).getTime() : 0;
        }

        // Handle numbers
        if (typeof valA === 'number' && typeof valB === 'number') {
            return direction === 'asc' ? valA - valB : valB - valA;
        }

        // Handle strings (case-insensitive)
        valA = String(valA).toLowerCase();
        valB = String(valB).toLowerCase();

        if (valA < valB) return direction === 'asc' ? -1 : 1;
        if (valA > valB) return direction === 'asc' ? 1 : -1;
        return 0;
    });
}

function renderAnalyticsTable() {
    const data = state.analytics.data;
    if (!data) return;

    const tab = state.analytics.currentTab;
    const searchTerm = (document.getElementById('analyticsSearch').value || '').toLowerCase();

    // Get filter values
    const tierFilter = document.getElementById('analyticsTierFilter')?.value || '';
    const sunsetFilter = document.getElementById('analyticsSunsetFilter')?.value || '';
    const riskFilter = document.getElementById('analyticsRiskFilter')?.value || '';

    let items = [];
    if (tab === 'workbooks') items = data.workbook_analytics || [];
    else if (tab === 'views') items = data.view_analytics || [];
    else if (tab === 'retirement') {
        // Use sunset candidates from workbook_analytics for retirement tab
        items = (data.workbook_analytics || []).filter(wb => wb.is_sunset_candidate || wb.sunset_recommendation === 'Review');
    }
    else if (tab === 'lineage') items = data.lineage_impact || [];
    else if (tab === 'datasources') items = data.datasource_analytics || [];
    else if (tab === 'flows') items = data.flow_analytics || [];
    else if (tab === 'users') items = data.user_analytics || [];

    // Apply filters for workbooks, datasources, flows, and retirement tabs
    if (tab === 'workbooks' || tab === 'datasources' || tab === 'flows' || tab === 'retirement') {
        // Tier filter
        if (tierFilter) {
            const tier = (item) => item.Tier || item.tier || '';
            items = items.filter(item => tier(item).includes(tierFilter));
        }
        // Sunset filter
        if (sunsetFilter) {
            if (sunsetFilter === 'sunset') {
                const isSunset = (item) => item.is_sunset_candidate || item['Is Sunset Candidate'] || item['Sunset Candidate'] || false;
                items = items.filter(item => isSunset(item) === true || isSunset(item) === 'True' || isSunset(item) === 'true');
            } else if (sunsetFilter === 'review') {
                items = items.filter(item => item.sunset_recommendation === 'Review');
            } else if (sunsetFilter === 'keep') {
                items = items.filter(item => item.sunset_recommendation === 'Keep');
            }
        }
        // Risk filter
        if (riskFilter) {
            items = items.filter(item => item.governance_risk === riskFilter);
        }
    }

    // Filter by search
    if (searchTerm) {
        items = items.filter(item =>
            Object.values(item).some(v => String(v).toLowerCase().includes(searchTerm))
        );
    }

    // Apply KPI-based filters (active_7d, active_30d, dormant, total_views)
    const kpiFilter = state.analytics.kpiFilter;
    if (kpiFilter) {
        const now = new Date();
        items = items.filter(item => {
            // Get last accessed date
            const lastAccessed = item['Last Accessed'] || item.last_accessed || item.last_accessed_at ||
                                item['Last Run'] || item.last_run;
            let lastAccessedDate = null;
            if (lastAccessed) {
                lastAccessedDate = new Date(lastAccessed);
            }

            switch (kpiFilter.type) {
                case 'active_7d':
                    if (!lastAccessedDate) return false;
                    const daysSince7 = Math.floor((now - lastAccessedDate) / (1000 * 60 * 60 * 24));
                    return daysSince7 <= 7;
                case 'active_30d':
                    if (!lastAccessedDate) return false;
                    const daysSince30 = Math.floor((now - lastAccessedDate) / (1000 * 60 * 60 * 24));
                    return daysSince30 <= 30;
                case 'dormant':
                    if (!lastAccessedDate) return true; // No access date = dormant
                    const daysSince90 = Math.floor((now - lastAccessedDate) / (1000 * 60 * 60 * 24));
                    return daysSince90 > 90;
                case 'total_views':
                    // No filter, just show all (sorting will handle order)
                    return true;
                default:
                    return true;
            }
        });

        // Sort by views if total_views filter is active
        if (kpiFilter.type === 'total_views') {
            items.sort((a, b) => {
                const viewsA = a['Views (30d)'] || a.views_30d || a['Runs (30d)'] || a.runs_30d || 0;
                const viewsB = b['Views (30d)'] || b.views_30d || b['Runs (30d)'] || b.runs_30d || 0;
                return viewsB - viewsA;
            });
        }
    }

    // Apply user-specific filters (for Users tab)
    const userFilter = state.analytics.userFilter;
    if (userFilter && tab === 'users') {
        items = items.filter(item => {
            const status = item.user_status || 'Unknown';
            const licenseWaste = item.license_waste_flag || 'No';
            const adminRisk = item.admin_risk_flag || 'No';
            const licenseType = (item.license_type || '').toLowerCase();
            const userTier = item.user_tier || 'Tier 4';

            switch (userFilter) {
                case 'total':
                    return true;
                case 'active':
                    return status === 'Active';
                case 'at_risk':
                    return status === 'At Risk';
                case 'inactive':
                    return status === 'Inactive';
                case 'never_used':
                    return status === 'Never Used';
                case 'license_waste':
                    return licenseWaste === 'Yes';
                case 'admin_risk':
                    return adminRisk === 'Yes';
                case 'creators':
                    return licenseType.includes('creator');
                case 'explorers':
                    return licenseType.includes('explorer');
                case 'viewers':
                    return licenseType.includes('viewer');
                case 'unlicensed':
                    return licenseType.includes('unlicensed');
                case 'user_tier1':
                    return userTier.includes('Tier 1');
                case 'user_tier2':
                    return userTier.includes('Tier 2');
                case 'user_tier3':
                    return userTier.includes('Tier 3');
                case 'user_tier4':
                    return userTier.includes('Tier 4');
                default:
                    return true;
            }
        });
    }

    // Apply sorting (unless already sorted by KPI filter)
    if (!kpiFilter || kpiFilter.type !== 'total_views') {
        items = applySorting(items);
    }

    state.analytics.filteredData = items;

    // Paginate
    const { page, perPage } = state.pagination.analytics;
    const start = (page - 1) * perPage;
    const pageData = items.slice(start, start + perPage);

    const tbody = document.getElementById('analyticsTableBody');

    if (pageData.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" class="text-center"><div class="empty-state"><p>No data available. Upload Admin Insights CSV to get started.</p></div></td></tr>`;
    } else if (tab === 'workbooks') {
        tbody.innerHTML = pageData.map(item => {
            // Support both Admin Insights format (capitalized keys) and legacy format
            const tier = item.Tier || item.tier || 'Tier 3';
            const tierClass = tier.includes('Tier 1') ? 'badge-green' :
                              tier.includes('Tier 2') ? 'badge-orange' : 'badge-red';

            // Get workbook name
            const workbookName = item.Workbook || item.workbook_name || '-';

            // Get values - check both capitalized and lowercase keys
            const views30d = item['Views (30d)'] || item.views_30d || item.total_views_all_time || 0;
            const uniqueUsers = item['Unique Users'] || item.unique_users_30d || 0;
            const sizeMb = item['Size (MB)'] || item.size_mb || 0;
            const criticalityScore = item['Criticality Score'] || item.criticality_score || 0;
            const owner = item.Owner || item.owner || item.owner_name || '-';
            const project = item.Project || item.project || item.project_name || '-';

            // Format dates
            let lastAccessedDisplay = '-';
            const lastAccessed = item['Last Accessed'] || item.last_accessed;
            if (lastAccessed) {
                lastAccessedDisplay = formatDateShort(lastAccessed);
            }

            // Sunset Yes/No
            const isSunset = item['Is Sunset Candidate'] || item.is_sunset_candidate || item['Sunset Candidate'] || item.sunset_candidate || false;
            const sunsetText = isSunset === true || isSunset === 'True' || isSunset === 'true' ? 'Yes' : 'No';
            const sunsetClass = sunsetText === 'Yes' ? 'badge-red' : 'badge-green';

            // Criticality badge
            const critClass = criticalityScore >= 70 ? 'badge-green' :
                             criticalityScore >= 40 ? 'badge-orange' : 'badge-red';

            return `<tr>
                <td title="${workbookName}">${truncateText(workbookName, 25)}</td>
                <td title="${project}">${truncateText(project, 15)}</td>
                <td>${truncateText(owner, 15)}</td>
                <td>${formatNumber(views30d)}</td>
                <td>${uniqueUsers}</td>
                <td>${lastAccessedDisplay}</td>
                <td>${sizeMb > 0 ? parseFloat(sizeMb).toFixed(1) : '-'}</td>
                <td><span class="badge ${critClass}">${Math.round(criticalityScore)}</span></td>
                <td><span class="badge ${sunsetClass}">${sunsetText}</span></td>
                <td><span class="badge ${tierClass}">${tier}</span></td>
            </tr>`;
        }).join('');
    } else if (tab === 'views') {
        tbody.innerHTML = pageData.map(item => `<tr>
            <td>${item.rank}</td>
            <td>${item.view_name}</td>
            <td>${item.workbook_name || '-'}</td>
            <td>${item.project_name || '-'}</td>
            <td>${formatNumber(item.total_views)}</td>
        </tr>`).join('');
    } else if (tab === 'retirement') {
        tbody.innerHTML = pageData.map(item => {
            const recClass = item.sunset_recommendation === 'Sunset' ? 'badge-red' :
                             item.sunset_recommendation === 'Review' ? 'badge-orange' : 'badge-green';
            return `<tr>
                <td title="${item.workbook_name}">${truncateText(item.workbook_name, 25)}</td>
                <td>${item.project_name || '-'}</td>
                <td>${item.owner_name || '-'}</td>
                <td>${item.days_since_access}</td>
                <td><span class="score-badge" style="background: ${getScoreColor(100 - item.sunset_score)}">${item.sunset_score}</span></td>
                <td><span class="score-badge" style="background: ${getScoreColor(item.criticality_score)}">${item.criticality_score}</span></td>
                <td><span class="badge ${recClass}">${item.sunset_recommendation}</span></td>
                <td title="${(item.sunset_reasons || []).join('; ')}"><span class="reasons-list">${truncateText((item.sunset_reasons || []).join('; '), 30)}</span></td>
            </tr>`;
        }).join('');
    } else if (tab === 'lineage') {
        tbody.innerHTML = pageData.map(item => `<tr>
            <td>${item.table_name}</td>
            <td>${item.schema || '-'}</td>
            <td>${item.database || '-'}</td>
            <td><span class="badge badge-blue">${item.connection_type || '-'}</span></td>
            <td>${item.downstream_workbook_count}</td>
            <td>${item.downstream_datasource_count}</td>
        </tr>`).join('');
    } else if (tab === 'datasources') {
        tbody.innerHTML = pageData.map(item => {
            // Support both Admin Insights format (capitalized keys) and legacy format
            const tier = item.Tier || item.tier || 'Tier 3';
            const tierClass = tier.includes('Tier 1') ? 'badge-green' :
                              tier.includes('Tier 2') ? 'badge-orange' : 'badge-red';

            // Get datasource name
            const dsName = item.Datasource || item.datasource_name || item.content_name || '-';

            // Get values
            const lastAccessed = item['Last Accessed'] || item.last_accessed_at || item.last_used;
            const lastAccessedFmt = lastAccessed ? formatDateShort(lastAccessed) : '-';
            const lastModified = item['Last Modified'] || item.last_modified || item.last_published_at || item.extracts_refreshed_at;
            const lastModifiedFmt = lastModified ? formatDateShort(lastModified) : '-';
            const useCount = item['Uses (30d)'] || item.use_count_30d || item.views_30d || 0;
            const owner = item.Owner || item.owner || item.owner_email || item.owner_name || '-';
            const project = item.Project || item.project || item.project_name || '-';
            const subscribers = item.Subscribers || item.subscriber_count || 0;
            const criticalityScore = item['Criticality'] || item['Health Score'] || item.criticality_score || item.health_score || 0;

            // Connection type (Live vs Extract)
            const isExtract = item['Is Extract'] || item.is_data_extract || item.is_extract;
            const connType = isExtract === true || isExtract === 'true' || isExtract === 'True' ? 'Extract' : 'Live';
            const connClass = connType === 'Extract' ? 'badge-blue' : 'badge-purple';

            // Sunset - Yes/No
            const isSunset = item['Is Sunset Candidate'] || item.is_sunset_candidate || false;
            const sunsetText = isSunset === true || isSunset === 'True' || isSunset === 'true' ? 'Yes' : 'No';
            const sunsetClass = sunsetText === 'Yes' ? 'badge-red' : 'badge-green';
            const sunsetReasons = item['Sunset Reasons'] || item.sunset_reasons || [];
            const reasonsTooltip = Array.isArray(sunsetReasons) ? sunsetReasons.join(', ') : sunsetReasons;

            // Criticality color
            const critClass = criticalityScore >= 70 ? 'badge-green' :
                             criticalityScore >= 40 ? 'badge-orange' : 'badge-red';

            return `<tr>
                <td title="${dsName}">${truncateText(dsName, 25)}</td>
                <td title="${project}">${truncateText(project, 15)}</td>
                <td>${truncateText(owner, 20)}</td>
                <td><span class="badge ${connClass}">${connType}</span></td>
                <td>${useCount}</td>
                <td>${lastAccessedFmt}</td>
                <td>${lastModifiedFmt}</td>
                <td>${subscribers}</td>
                <td><span class="badge ${critClass}">${Math.round(criticalityScore)}</span></td>
                <td title="${reasonsTooltip}"><span class="badge ${sunsetClass}">${sunsetText}</span></td>
                <td><span class="badge ${tierClass}">${tier}</span></td>
            </tr>`;
        }).join('');
    } else if (tab === 'flows') {
        tbody.innerHTML = pageData.map(item => {
            const tier = item.Tier || item.tier || 'Tier 3';
            const tierClass = tier.includes('Tier 1') ? 'badge-green' :
                              tier.includes('Tier 2') ? 'badge-orange' : 'badge-red';

            const flowName = item.Flow || item.flow_name || item.content_name || '-';
            const project = item.Project || item.project || item.project_name || '-';
            const owner = item.Owner || item.owner || item.owner_email || '-';
            const runs = item['Runs (30d)'] || item.runs_30d || item.views_30d || 0;
            const users = item.Users || item.users || item.unique_users_30d || 0;
            const lastRun = item['Last Run'] || item.last_run || item.last_accessed_at;
            const lastRunFmt = lastRun ? formatDateShort(lastRun) : 'Never';
            const lastModified = item['Last Modified'] || item.last_modified || item.last_published_at;
            const lastModifiedFmt = lastModified ? formatDateShort(lastModified) : '-';
            const failures = item.Failures || item.failures || item.refresh_failures || 0;
            const subscribers = item.Subscribers || item.subscribers || item.subscriber_count || 0;
            const criticalityScore = item['Criticality'] || item.criticality_score || 0;

            // Sunset - Yes/No with tooltip
            const isSunset = item.Sunset === true || item.Sunset === 'True' || item.Sunset === 'true' ||
                            item.is_sunset_candidate === true || item['Is Sunset Candidate'] === true;
            const sunsetText = isSunset ? 'Yes' : 'No';
            const sunsetClass = isSunset ? 'badge-red' : 'badge-green';
            const sunsetReasons = item['Sunset Reasons'] || item.sunset_reasons || [];
            const reasonsTooltip = Array.isArray(sunsetReasons) ? sunsetReasons.join(', ') : sunsetReasons;

            const critClass = criticalityScore >= 70 ? 'badge-green' :
                             criticalityScore >= 40 ? 'badge-orange' : 'badge-red';

            return `<tr>
                <td title="${flowName}">${truncateText(flowName, 30)}</td>
                <td title="${project}">${truncateText(project, 20)}</td>
                <td>${truncateText(owner, 25)}</td>
                <td>${runs}</td>
                <td>${users}</td>
                <td>${lastRunFmt}</td>
                <td>${lastModifiedFmt}</td>
                <td>${failures}</td>
                <td>${subscribers}</td>
                <td><span class="badge ${critClass}">${Math.round(criticalityScore)}</span></td>
                <td title="${reasonsTooltip}"><span class="badge ${sunsetClass}">${sunsetText}</span></td>
                <td><span class="badge ${tierClass}">${tier}</span></td>
            </tr>`;
        }).join('');
    } else if (tab === 'users') {
        tbody.innerHTML = pageData.map(item => {
            const userName = item.user_name || item.User || 'Unknown User';
            const email = item.email || item.Email || '-';
            const licenseType = item.license_type || item['License Type'] || '-';
            const siteRole = item.site_role || item['Site Role'] || '-';
            const projects = item.projects || item.Projects || 0;
            const workbooks = item.workbooks || item.Workbooks || 0;
            const dataSources = item.data_sources || item['Data Sources'] || 0;
            const views = item.views || item.Views || 0;
            const lastLogin = item.last_login || item['Last Login'];
            const lastLoginFmt = lastLogin ? formatDateShort(lastLogin) : 'Never';
            const daysInactive = item.days_since_login || item['Days Since Login'] || 0;
            const contributionScore = item.contribution_score || item['Contribution Score'] || 0;
            const userTier = item.user_tier || item['User Tier'] || 'Tier 4';
            const userStatus = item.user_status || item['User Status'] || 'Unknown';
            const licenseWaste = item.license_waste_flag || item['License Waste'] || 'No';
            const adminRisk = item.admin_risk_flag || item['Admin Risk'] || 'No';

            // Tier badge colors
            const tierClass = userTier.includes('Tier 1') ? 'badge-green' :
                              userTier.includes('Tier 2') ? 'badge-orange' :
                              userTier.includes('Tier 3') ? 'badge-blue' : 'badge-red';

            // Status badge colors
            const statusClass = userStatus === 'Active' ? 'badge-green' :
                               userStatus === 'At Risk' ? 'badge-orange' :
                               userStatus === 'Inactive' ? 'badge-red' : 'badge-gray';

            // License waste badge
            const wasteClass = licenseWaste === 'Yes' ? 'badge-red' : 'badge-green';

            // Admin risk badge
            const riskClass = adminRisk === 'Yes' ? 'badge-orange' : 'badge-green';

            // Contribution score badge
            const contribClass = contributionScore >= 60 ? 'badge-green' :
                                contributionScore >= 20 ? 'badge-orange' : 'badge-gray';

            // License type badge
            const licenseClass = licenseType.toLowerCase().includes('creator') ? 'badge-purple' :
                                licenseType.toLowerCase().includes('explorer') ? 'badge-blue' :
                                licenseType.toLowerCase().includes('viewer') ? 'badge-cyan' : 'badge-gray';

            return `<tr>
                <td title="${userName}">${truncateText(userName, 20)}</td>
                <td title="${email}">${truncateText(email, 25)}</td>
                <td><span class="badge ${licenseClass}">${licenseType}</span></td>
                <td>${truncateText(siteRole, 15)}</td>
                <td>${projects}</td>
                <td>${workbooks}</td>
                <td>${dataSources}</td>
                <td>${views}</td>
                <td>${lastLoginFmt}</td>
                <td>${daysInactive}</td>
                <td><span class="badge ${contribClass}">${Math.round(contributionScore)}</span></td>
                <td><span class="badge ${tierClass}">${userTier}</span></td>
                <td><span class="badge ${statusClass}">${userStatus}</span></td>
                <td><span class="badge ${wasteClass}">${licenseWaste}</span></td>
                <td><span class="badge ${riskClass}">${adminRisk}</span></td>
            </tr>`;
        }).join('');
    }

    // Update info and pagination
    const totalItems = items.length;
    document.getElementById('analyticsTableInfo').textContent =
        totalItems > 0 ? `Showing ${start + 1} to ${Math.min(start + perPage, totalItems)} of ${totalItems} items` : 'No items';

    renderAnalyticsPagination(totalItems);
}

// Helper function for score color gradient
function getScoreColor(score) {
    if (score >= 70) return '#22c55e'; // green
    if (score >= 40) return '#f59e0b'; // amber
    return '#ef4444'; // red
}

// Helper function to truncate text
function truncateText(text, maxLength) {
    if (!text) return '-';
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
}

function renderAnalyticsPagination(total) {
    const { page, perPage } = state.pagination.analytics;
    const totalPages = Math.ceil(total / perPage);
    const container = document.getElementById('analyticsPagination');

    if (totalPages <= 1) {
        container.innerHTML = '';
        return;
    }

    let html = '';
    if (page > 1) {
        html += `<button class="page-btn" onclick="goToAnalyticsPage(${page - 1})">Prev</button>`;
    }

    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= page - 2 && i <= page + 2)) {
            html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="goToAnalyticsPage(${i})">${i}</button>`;
        } else if (i === page - 3 || i === page + 3) {
            html += '<span>...</span>';
        }
    }

    if (page < totalPages) {
        html += `<button class="page-btn" onclick="goToAnalyticsPage(${page + 1})">Next</button>`;
    }

    container.innerHTML = html;
}

function goToAnalyticsPage(page) {
    state.pagination.analytics.page = page;
    renderAnalyticsTable();
}

function changeAnalyticsPerPage() {
    const select = document.getElementById('analyticsPerPage');
    state.pagination.analytics.perPage = parseInt(select.value);
    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

function filterAnalyticsTable() {
    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

function filterByTier(tier) {
    const tierFilter = document.getElementById('analyticsTierFilter');
    if (tierFilter) {
        tierFilter.value = tier;
    }
    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

// Track active KPI filter
let activeKpiFilter = null;

function toggleKpiFilter(filterType) {
    // Get all clickable KPI elements
    const allKpis = document.querySelectorAll('.clickable-kpi');

    // If clicking the same filter, clear it (toggle off)
    if (activeKpiFilter === filterType) {
        activeKpiFilter = null;
        allKpis.forEach(el => el.classList.remove('active'));
        clearAnalyticsFilters();
        return;
    }

    // Set new active filter
    activeKpiFilter = filterType;

    // Update active styling
    allKpis.forEach(el => {
        if (el.dataset.kpiFilter === filterType) {
            el.classList.add('active');
        } else {
            el.classList.remove('active');
        }
    });

    // Clear existing filters first
    document.getElementById('analyticsTierFilter').value = '';
    document.getElementById('analyticsSunsetFilter').value = '';
    document.getElementById('analyticsRiskFilter').value = '';
    document.getElementById('analyticsSearch').value = '';

    // Apply the appropriate filter based on type
    switch (filterType) {
        case 'tier1':
            document.getElementById('analyticsTierFilter').value = 'Tier 1';
            break;
        case 'tier2':
            document.getElementById('analyticsTierFilter').value = 'Tier 2';
            break;
        case 'tier3':
            document.getElementById('analyticsTierFilter').value = 'Tier 3';
            break;
        case 'sunset':
            document.getElementById('analyticsSunsetFilter').value = 'sunset';
            break;
        case 'high_risk':
            document.getElementById('analyticsRiskFilter').value = 'High';
            break;
        case 'active_7d':
            // Filter items accessed within 7 days
            state.analytics.kpiFilter = { type: 'active_7d', days: 7 };
            break;
        case 'active_30d':
            // Filter items accessed within 30 days
            state.analytics.kpiFilter = { type: 'active_30d', days: 30 };
            break;
        case 'dormant':
            // Filter items not accessed in 90+ days
            state.analytics.kpiFilter = { type: 'dormant', days: 90 };
            break;
        case 'total_views':
            // Sort by views descending (show most viewed)
            state.analytics.kpiFilter = { type: 'total_views' };
            break;
        default:
            state.analytics.kpiFilter = null;
    }

    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

function clearKpiFilterState() {
    activeKpiFilter = null;
    activeUserFilter = null;
    state.analytics.kpiFilter = null;
    state.analytics.userFilter = null;
    document.querySelectorAll('.clickable-kpi').forEach(el => el.classList.remove('active'));
}

// Track active User filter
let activeUserFilter = null;

function toggleUserFilter(filterType) {
    // Get all clickable KPI elements in users section
    const allKpis = document.querySelectorAll('#usersKpiSection .clickable-kpi');

    // If clicking the same filter, clear it (toggle off)
    if (activeUserFilter === filterType) {
        activeUserFilter = null;
        state.analytics.userFilter = null;
        allKpis.forEach(el => el.classList.remove('active'));
        document.getElementById('analyticsSearch').value = '';
        state.pagination.analytics.page = 1;
        renderAnalyticsTable();
        return;
    }

    // Set new active filter
    activeUserFilter = filterType;
    state.analytics.userFilter = filterType;

    // Update active styling
    allKpis.forEach(el => {
        if (el.dataset.userFilter === filterType) {
            el.classList.add('active');
        } else {
            el.classList.remove('active');
        }
    });

    // Clear search
    document.getElementById('analyticsSearch').value = '';

    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

function applyAnalyticsFilters() {
    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

function clearAnalyticsFilters() {
    document.getElementById('analyticsTierFilter').value = '';
    document.getElementById('analyticsSunsetFilter').value = '';
    document.getElementById('analyticsRiskFilter').value = '';
    document.getElementById('analyticsSearch').value = '';
    clearKpiFilterState();
    state.pagination.analytics.page = 1;
    renderAnalyticsTable();
}

function showWorkbookDetails(workbookId) {
    const data = state.analytics.data;
    if (!data) return;

    const workbook = data.workbook_analytics.find(w => w.workbook_id === workbookId);
    if (!workbook) return;

    document.getElementById('modalWorkbookName').textContent = workbook.workbook_name;

    const tierClass = workbook.tier.includes('Tier 1') ? 'tier-1-bg' :
                      workbook.tier.includes('Tier 2') ? 'tier-2-bg' : 'tier-3-bg';
    const riskClass = workbook.governance_risk === 'High' ? 'badge-red' :
                      workbook.governance_risk === 'Medium' ? 'badge-orange' : 'badge-green';
    const sunsetClass = workbook.is_sunset_candidate ? 'badge-red' :
                        workbook.sunset_recommendation === 'Review' ? 'badge-orange' : 'badge-green';

    const content = `
        <div class="workbook-details">
            <!-- Status Badges Row -->
            <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                <div style="padding: 0.75rem 1.25rem; background: linear-gradient(135deg, ${workbook.tier.includes('Tier 1') ? '#dcfce7' : workbook.tier.includes('Tier 2') ? '#fef3c7' : '#fee2e2'} 0%, ${workbook.tier.includes('Tier 1') ? '#bbf7d0' : workbook.tier.includes('Tier 2') ? '#fde68a' : '#fecaca'} 100%); border-radius: 8px; text-align: center;">
                    <div style="font-size: 1.5rem; font-weight: 700;">${workbook.criticality_score}</div>
                    <div style="font-size: 0.75rem; text-transform: uppercase; font-weight: 500;">Criticality</div>
                </div>
                <div style="padding: 0.75rem 1.25rem; background: linear-gradient(135deg, ${workbook.sunset_score >= 70 ? '#fee2e2' : workbook.sunset_score >= 40 ? '#fef3c7' : '#dcfce7'} 0%, ${workbook.sunset_score >= 70 ? '#fecaca' : workbook.sunset_score >= 40 ? '#fde68a' : '#bbf7d0'} 100%); border-radius: 8px; text-align: center;">
                    <div style="font-size: 1.5rem; font-weight: 700;">${workbook.sunset_score}</div>
                    <div style="font-size: 0.75rem; text-transform: uppercase; font-weight: 500;">Sunset Score</div>
                </div>
                <div style="padding: 0.75rem 1.25rem; background: #f1f5f9; border-radius: 8px; flex: 1;">
                    <div style="font-size: 0.875rem; font-weight: 600; margin-bottom: 0.25rem;">Recommendation: <span class="badge ${sunsetClass}">${workbook.sunset_recommendation}</span></div>
                    <div style="font-size: 0.875rem;">Risk Level: <span class="badge ${riskClass}">${workbook.governance_risk}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Overview</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Project:</label> <span>${workbook.project_name || '-'}</span></div>
                    <div class="detail-item"><label>Owner:</label> <span>${workbook.owner_name || '-'} ${workbook.owner_active ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-orange">Inactive</span>'}</span></div>
                    <div class="detail-item"><label>Created:</label> <span>${formatValue(workbook.created_at)}</span></div>
                    <div class="detail-item"><label>${state.analytics.usageDataSource === 'admin_insights' || state.analytics.usageDataSource === 'repository' ? 'Last Viewed:' : 'Last Modified:'}</label> <span>${formatValue(workbook.last_viewed || workbook.updated_at)} (${workbook.days_since_access} days ago)</span></div>
                    <div class="detail-item"><label>Usage Trend:</label> <span class="badge ${workbook.usage_trend === 'active' ? 'badge-green' : workbook.usage_trend === 'stable' ? 'badge-blue' : workbook.usage_trend === 'declining' ? 'badge-orange' : 'badge-red'}">${workbook.usage_trend || '-'}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Usage & Engagement</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Total Views:</label> <span>${formatNumber(workbook.total_views_all_time || 0)}</span></div>
                    <div class="detail-item"><label>Dashboards:</label> <span>${workbook.dashboard_count || 0}</span></div>
                    <div class="detail-item"><label>Subscribers:</label> <span>${workbook.subscriber_count || 0}</span></div>
                    <div class="detail-item"><label>Top View:</label> <span>${workbook.top_view_name || '-'} (${workbook.top_view_views} views)</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Operational Health</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Has Refresh Schedule:</label> <span>${workbook.has_refresh_schedule ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-orange">No</span>'}</span></div>
                    <div class="detail-item"><label>Refresh Tasks:</label> <span>${workbook.refresh_task_count || 0}</span></div>
                    <div class="detail-item"><label>Subscriptions:</label> <span>${workbook.has_subscriptions ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-orange">No</span>'}</span></div>
                    <div class="detail-item"><label>Job Failures (30d):</label> <span>${workbook.job_failures_30d || 0}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Governance Status</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Has Description:</label> <span>${workbook.has_description ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-orange">No</span>'}</span></div>
                    <div class="detail-item"><label>Tags:</label> <span>${workbook.tag_count || 0}</span></div>
                    <div class="detail-item"><label>Governance Issues:</label> <span>${(workbook.governance_issues || []).length > 0 ? (workbook.governance_issues || []).join(', ') : 'None'}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Lineage & Complexity</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Upstream Tables:</label> <span>${workbook.upstream_tables || 0}</span></div>
                    <div class="detail-item"><label>Upstream Databases:</label> <span>${workbook.upstream_databases || 0}</span></div>
                    <div class="detail-item"><label>Calculated Fields:</label> <span>${workbook.calculated_field_count || 0}</span></div>
                    <div class="detail-item"><label>Custom SQL:</label> <span>${workbook.custom_sql_count || 0}</span></div>
                </div>
            </div>

            ${workbook.sunset_reasons && workbook.sunset_reasons.length > 0 ? `
            <div class="detail-section" style="background: #fef2f2; border-radius: 8px; padding: 1rem;">
                <h4 style="color: #dc2626; margin-bottom: 0.5rem;">Sunset Reasons</h4>
                <ul style="margin: 0; padding-left: 1.25rem; color: #991b1b;">
                    ${workbook.sunset_reasons.map(r => `<li>${r}</li>`).join('')}
                </ul>
            </div>
            ` : ''}

            <div class="detail-section">
                <h4>Criticality Score Breakdown</h4>
                <div class="scores-grid">
                    <div class="score-item">
                        <label>Usage (30%)</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${workbook.usage_score}%; background: ${getScoreColor(workbook.usage_score)}"></div></div>
                        <span>${workbook.usage_score}</span>
                    </div>
                    <div class="score-item">
                        <label>Unique Users (20%)</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${workbook.unique_users_score || 0}%; background: ${getScoreColor(workbook.unique_users_score || 0)}"></div></div>
                        <span>${workbook.unique_users_score || 0}</span>
                    </div>
                    <div class="score-item">
                        <label>Lineage Impact (20%)</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${workbook.impact_score}%; background: ${getScoreColor(workbook.impact_score)}"></div></div>
                        <span>${workbook.impact_score}</span>
                    </div>
                    <div class="score-item">
                        <label>Operational (15%)</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${workbook.operational_score}%; background: ${getScoreColor(workbook.operational_score)}"></div></div>
                        <span>${workbook.operational_score}</span>
                    </div>
                    <div class="score-item">
                        <label>Complexity (15%)</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${workbook.complexity_score || 0}%; background: ${getScoreColor(workbook.complexity_score || 0)}"></div></div>
                        <span>${workbook.complexity_score || 0}</span>
                    </div>
                </div>
                <div class="total-score ${tierClass}">
                    <span class="score-label">Criticality Score</span>
                    <span class="score-value">${workbook.criticality_score}</span>
                    <span class="tier-label">${workbook.tier}</span>
                </div>
            </div>
        </div>
    `;

    document.getElementById('modalWorkbookContent').innerHTML = content;
    document.getElementById('workbookDetailsModal').classList.remove('hidden');
}

function closeWorkbookModal() {
    document.getElementById('workbookDetailsModal').classList.add('hidden');
}

function showDatasourceDetails(datasourceId) {
    const data = state.analytics.data;
    if (!data || !data.datasource_analytics) return;

    const datasource = data.datasource_analytics.find(d => d.datasource_id === datasourceId);
    if (!datasource) return;

    const riskClass = datasource.risk_level === 'High' ? 'badge-red' :
                      datasource.risk_level === 'Medium' ? 'badge-orange' : 'badge-green';
    const healthBg = datasource.health_score >= 70 ? '#dcfce7' : datasource.health_score >= 40 ? '#fef3c7' : '#fee2e2';
    const healthBgEnd = datasource.health_score >= 70 ? '#bbf7d0' : datasource.health_score >= 40 ? '#fde68a' : '#fecaca';

    const content = `
        <div class="workbook-details">
            <!-- Status Badges Row -->
            <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                <div style="padding: 0.75rem 1.25rem; background: linear-gradient(135deg, ${healthBg} 0%, ${healthBgEnd} 100%); border-radius: 8px; text-align: center;">
                    <div style="font-size: 1.5rem; font-weight: 700;">${datasource.health_score}</div>
                    <div style="font-size: 0.75rem; text-transform: uppercase; font-weight: 500;">Health Score</div>
                </div>
                <div style="padding: 0.75rem 1.25rem; background: #f1f5f9; border-radius: 8px; flex: 1;">
                    <div style="font-size: 0.875rem; font-weight: 600; margin-bottom: 0.25rem;">Risk Level: <span class="badge ${riskClass}">${datasource.risk_level}</span></div>
                    <div style="font-size: 0.875rem;">Sunset Candidate: <span class="badge ${datasource.is_sunset_candidate ? 'badge-red' : 'badge-green'}">${datasource.is_sunset_candidate ? 'Yes' : 'No'}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Overview</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Project:</label> <span>${datasource.project_name || '-'}</span></div>
                    <div class="detail-item"><label>Owner:</label> <span>${datasource.owner_name || '-'} ${datasource.owner_active ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-orange">Inactive</span>'}</span></div>
                    <div class="detail-item"><label>Content Type:</label> <span>${datasource.content_type || '-'}</span></div>
                    <div class="detail-item"><label>Has Extract:</label> <span>${datasource.has_extract ? 'Yes' : 'No'}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Usage Metrics</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Total Workbooks Using:</label> <span>${datasource.workbook_count || 0}</span></div>
                    <div class="detail-item"><label>Active Workbooks (7d):</label> <span>${datasource.active_workbook_count_7d || 0}</span></div>
                    <div class="detail-item"><label>Active Workbooks (30d):</label> <span>${datasource.active_workbook_count_30d || 0}</span></div>
                    <div class="detail-item"><label>Active Workbooks (90d):</label> <span>${datasource.active_workbook_count_90d || 0}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Operational Metrics</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Last Refresh:</label> <span>${datasource.last_refresh_date ? formatDateShort(datasource.last_refresh_date) : '-'}</span></div>
                    <div class="detail-item"><label>Has Refresh Schedule:</label> <span>${datasource.has_refresh_schedule ? 'Yes' : 'No'}</span></div>
                    <div class="detail-item"><label>Refresh Failures (30d):</label> <span class="${datasource.refresh_failures_30d > 0 ? 'badge badge-red' : ''}">${datasource.refresh_failures_30d || 0}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Governance</h4>
                <div class="detail-grid">
                    <div class="detail-item"><label>Has Description:</label> <span>${datasource.has_description ? 'Yes' : 'No'}</span></div>
                    <div class="detail-item"><label>Certified:</label> <span>${datasource.is_certified ? 'Yes' : 'No'}</span></div>
                </div>
            </div>

            <div class="detail-section">
                <h4>Health Score Breakdown</h4>
                <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;">Each component contributes up to 20 points to the total health score (max 100).</p>
                <div class="scores-grid">
                    <div class="score-item">
                        <label>Active Workbooks (>5)</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${(datasource.active_workbook_count_90d || 0) > 5 ? 100 : 0}%; background: ${(datasource.active_workbook_count_90d || 0) > 5 ? '#22c55e' : '#ef4444'}"></div></div>
                        <span>${(datasource.active_workbook_count_90d || 0) > 5 ? '+20' : '0'}</span>
                    </div>
                    <div class="score-item">
                        <label>Has Refresh Schedule</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${datasource.has_refresh_schedule ? 100 : 0}%; background: ${datasource.has_refresh_schedule ? '#22c55e' : '#ef4444'}"></div></div>
                        <span>${datasource.has_refresh_schedule ? '+20' : '0'}</span>
                    </div>
                    <div class="score-item">
                        <label>No Refresh Failures</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${(datasource.refresh_failures_30d || 0) === 0 ? 100 : 0}%; background: ${(datasource.refresh_failures_30d || 0) === 0 ? '#22c55e' : '#ef4444'}"></div></div>
                        <span>${(datasource.refresh_failures_30d || 0) === 0 ? '+20' : '0'}</span>
                    </div>
                    <div class="score-item">
                        <label>Active Owner</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${datasource.owner_active ? 100 : 0}%; background: ${datasource.owner_active ? '#22c55e' : '#ef4444'}"></div></div>
                        <span>${datasource.owner_active ? '+20' : '0'}</span>
                    </div>
                    <div class="score-item">
                        <label>Has Description</label>
                        <div class="score-bar-large"><div class="score-fill" style="width: ${datasource.has_description ? 100 : 0}%; background: ${datasource.has_description ? '#22c55e' : '#ef4444'}"></div></div>
                        <span>${datasource.has_description ? '+20' : '0'}</span>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('modalWorkbookName').textContent = datasource.datasource_name;
    document.getElementById('modalWorkbookContent').innerHTML = content;
    document.getElementById('workbookDetailsModal').classList.remove('hidden');
}

async function exportAnalytics() {
    if (!state.analytics.data) {
        alert('No analytics data to export. Run analysis first.');
        return;
    }

    try {
        // Preferred: the full result is still on the server - stream it straight to a download.
        // (Posting the whole analytics result back from the browser fails on very large sites, and a
        //  huge result is split into several files automatically, delivered as a .zip.)
        if (state.analytics.jobId) {
            try {
                const check = await fetch(`/api/export_analytics/${state.analytics.jobId}?check=1`);
                const info = await check.json();
                if (info && info.success) {
                    window.location.href = `/api/export_analytics/${state.analytics.jobId}`;
                    return;
                }
            } catch (e) {
                console.warn('Server-side analytics export unavailable, falling back to browser data', e);
            }
        }

        const response = await fetch('/api/export_analytics', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: state.analytics.data })
        });

        if (response.ok) {
            const blob = await response.blob();
            const isZip = (response.headers.get('Content-Type') || '').includes('zip');
            const defaultFilename = `usage_analytics_${new Date().toISOString().slice(0, 10)}.${isZip ? 'zip' : 'xlsx'}`;

            // Use File System Access API if available (allows user to choose save location)
            if ('showSaveFilePicker' in window) {
                try {
                    const handle = await window.showSaveFilePicker({
                        suggestedName: defaultFilename,
                        types: [isZip ? {
                            description: 'Zip Archive',
                            accept: { 'application/zip': ['.zip'] }
                        } : {
                            description: 'Excel Files',
                            accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] }
                        }]
                    });
                    const writable = await handle.createWritable();
                    await writable.write(blob);
                    await writable.close();
                    return;
                } catch (err) {
                    if (err.name === 'AbortError') return;
                }
            }

            // Fallback: regular download
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = defaultFilename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
        } else {
            alert('Export failed');
        }
    } catch (error) {
        alert('Export error: ' + error.message);
    }
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num;
}

function formatDateShort(dateStr) {
    if (!dateStr) return '-';
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return '-';
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
        return '-';
    }
}


// ==================== Admin Insights CSV Upload ====================

// Track Admin Insights upload state
const adminInsightsState = {
    site_content: null,
    ts_events: null,
    ts_users: null,
    subscriptions: null,
    permissions: null,
    groups: null,
    viz_load_times: null,
    job_performance: null,
    analysisComplete: false
};

// Element ID mappings for each CSV type
const csvElementIds = {
    'site_content': 'SiteContent',
    'ts_events': 'TsEvents',
    'ts_users': 'TsUsers',
    'subscriptions': 'Subscriptions',
    'permissions': 'Permissions',
    'groups': 'Groups',
    'viz_load_times': 'VizLoad',
    'job_performance': 'JobPerf'
};

async function handleAdminInsightsUpload(csvType, event) {
    const file = event.target.files[0];
    if (!file) return;

    const elementId = csvElementIds[csvType];
    const statusEl = document.getElementById(`csvStatus${elementId}`);
    const cardEl = document.getElementById(`csvCard${elementId}`);

    // Show uploading state
    statusEl.innerHTML = '<span style="color: #6366f1;">Uploading...</span>';

    try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('csv_type', csvType);

        const response = await fetch('/api/admin-insights/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.ok) {
            adminInsightsState[csvType] = {
                filename: file.name,
                rows: result.rows,
                columns: result.columns
            };

            // Update UI to show success
            cardEl.style.borderColor = '#10b981';
            cardEl.style.background = '#f0fdf4';
            statusEl.innerHTML = `<span style="color: #10b981;">✓ ${result.rows.toLocaleString()} rows</span>`;

            updateAdminInsightsUploadSummary();
        } else {
            throw new Error(result.error || 'Upload failed');
        }
    } catch (error) {
        statusEl.innerHTML = `<span style="color: #ef4444;">✗ ${error.message}</span>`;
        cardEl.style.borderColor = '#ef4444';
        cardEl.style.background = '#fef2f2';
    }
}

// File name patterns for auto-detection (case-insensitive)
const fileNamePatterns = {
    'site_content': ['site_content.csv', 'sitecontent.csv', 'site-content.csv'],
    'ts_events': ['ts_events.csv', 'tsevents.csv', 'ts-events.csv'],
    'ts_users': ['ts_users.csv', 'tsusers.csv', 'ts-users.csv'],
    'subscriptions': ['subscriptions.csv', 'subscription.csv', 'subcriptions.csv'],
    'permissions': ['permissions.csv', 'permission.csv'],
    'groups': ['groups.csv', 'group.csv'],
    'viz_load_times': ['viz_load_times.csv', 'vizloadtimes.csv', 'viz-load-times.csv'],
    'job_performance': ['job_performance.csv', 'jobperformance.csv', 'job-performance.csv']
};

// Status element IDs for folder upload UI
const statusElementIds = {
    'site_content': 'statusSiteContent',
    'ts_events': 'statusTsEvents',
    'ts_users': 'statusTsUsers',
    'subscriptions': 'statusSubscriptions',
    'permissions': 'statusPermissions',
    'groups': 'statusGroups',
    'viz_load_times': 'statusVizLoad',
    'job_performance': 'statusJobPerf'
};

async function handleFolderSelect(event) {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    // Show progress
    const progressDiv = document.getElementById('folderUploadProgress');
    const progressBar = document.getElementById('folderUploadProgressBar');
    progressDiv.style.display = 'block';
    progressBar.style.width = '0%';

    // Reset all status icons
    for (const statusId of Object.values(statusElementIds)) {
        const el = document.getElementById(statusId);
        if (el) {
            el.querySelector('.status-icon').textContent = '○';
            el.querySelector('.status-icon').style.color = '#94a3b8';
            el.style.background = '#f1f5f9';
        }
    }

    // Match files to expected types
    const matchedFiles = {};
    for (const file of files) {
        const fileName = file.name.toLowerCase();
        for (const [csvType, patterns] of Object.entries(fileNamePatterns)) {
            if (patterns.some(p => fileName === p || fileName.endsWith(p))) {
                matchedFiles[csvType] = file;
                break;
            }
        }
    }

    const totalMatched = Object.keys(matchedFiles).length;
    let uploaded = 0;

    // Upload each matched file
    for (const [csvType, file] of Object.entries(matchedFiles)) {
        const statusEl = document.getElementById(statusElementIds[csvType]);

        // Show uploading
        if (statusEl) {
            statusEl.querySelector('.status-icon').textContent = '⟳';
            statusEl.querySelector('.status-icon').style.color = '#6366f1';
        }

        try {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('csv_type', csvType);

            const response = await fetch('/api/admin-insights/upload', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.ok) {
                adminInsightsState[csvType] = {
                    filename: file.name,
                    rows: result.rows,
                    columns: result.columns
                };

                // Update status to success
                if (statusEl) {
                    statusEl.querySelector('.status-icon').textContent = '✓';
                    statusEl.querySelector('.status-icon').style.color = '#10b981';
                    statusEl.style.background = '#f0fdf4';
                }
            } else {
                throw new Error(result.error || 'Upload failed');
            }
        } catch (error) {
            // Update status to error
            if (statusEl) {
                statusEl.querySelector('.status-icon').textContent = '✗';
                statusEl.querySelector('.status-icon').style.color = '#ef4444';
                statusEl.style.background = '#fef2f2';
            }
        }

        uploaded++;
        progressBar.style.width = `${(uploaded / totalMatched) * 100}%`;
    }

    // Hide progress after a short delay
    setTimeout(() => {
        progressDiv.style.display = 'none';
    }, 1000);

    updateAdminInsightsUploadSummary();
}

function updateAdminInsightsUploadSummary() {
    const countEl = document.getElementById('adminInsightsUploadCount');
    const runBtn = document.getElementById('btnRunAdminInsightsAnalysis');

    let uploadedCount = 0;
    const requiredUploaded = adminInsightsState.site_content !== null;

    for (const type of Object.keys(csvElementIds)) {
        if (adminInsightsState[type]) uploadedCount++;
    }

    countEl.textContent = `${uploadedCount} of 8 files detected`;

    // Enable run button only if Site_Content is uploaded
    runBtn.disabled = !requiredUploaded;
}

async function clearAdminInsightsUploads() {
    try {
        await fetch('/api/admin-insights/clear', { method: 'POST' });

        // Reset state
        for (const type of Object.keys(csvElementIds)) {
            adminInsightsState[type] = null;
        }
        adminInsightsState.analysisComplete = false;

        // Reset folder upload status grid
        for (const [csvType, statusId] of Object.entries(statusElementIds)) {
            const el = document.getElementById(statusId);
            if (el) {
                el.querySelector('.status-icon').textContent = '○';
                el.querySelector('.status-icon').style.color = '#94a3b8';
                el.style.background = '#f1f5f9';
            }
        }

        // Reset old card-based UI (for backward compatibility)
        for (const [csvType, elementId] of Object.entries(csvElementIds)) {
            const cardEl = document.getElementById(`csvCard${elementId}`);
            const statusEl = document.getElementById(`csvStatus${elementId}`);
            const fileInput = document.getElementById(`csvFile${elementId}`);

            if (cardEl) {
                if (csvType === 'site_content') {
                    cardEl.style.borderColor = '#6366f1';
                    cardEl.style.background = '#f5f3ff';
                } else {
                    cardEl.style.borderColor = 'var(--border-color)';
                    cardEl.style.background = 'white';
                }
            }
            if (statusEl) statusEl.innerHTML = '';
            if (fileInput) fileInput.value = '';
        }

        // Reset folder input
        const folderInput = document.getElementById('csvFolderInput');
        if (folderInput) folderInput.value = '';

        updateAdminInsightsUploadSummary();

    } catch (error) {
        console.error('Clear error:', error);
    }
}

async function runAdminInsightsAnalysis() {
    const runBtn = document.getElementById('btnRunAdminInsightsAnalysis');
    const statusSection = document.getElementById('adminInsightsAnalysisStatus');
    const statusText = document.getElementById('adminInsightsStatusText');

    runBtn.disabled = true;
    runBtn.innerHTML = `
        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right: 4px; animation: spin 1s linear infinite;">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
        </svg>
        Analyzing...
    `;

    statusSection.style.display = 'block';
    statusText.textContent = 'Starting governance analysis...';

    try {
        const response = await fetch('/api/admin-insights/run', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const result = await response.json();

        if (result.success && result.job_id) {
            await pollAdminInsightsJob(result.job_id, statusText, runBtn);
        } else {
            throw new Error(result.error || 'Analysis failed to start');
        }
    } catch (error) {
        statusText.textContent = 'Error: ' + error.message;
        statusSection.querySelector('div').style.background = '#fef2f2';
        statusSection.querySelector('div').style.borderColor = '#fca5a5';
        statusSection.querySelector('svg').setAttribute('stroke', '#ef4444');

        runBtn.disabled = false;
        runBtn.innerHTML = `
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right: 4px;">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
            Run Governance Analysis
        `;
    }
}

async function pollAdminInsightsJob(jobId, statusText, runBtn) {
    const poll = async () => {
        try {
            const statusRes = await fetch(`/api/job_status/${jobId}`);
            const statusData = await statusRes.json();

            if (statusData.success && statusData.status) {
                const { status, progress, message } = statusData.status;
                statusText.textContent = message || `Processing... ${progress}%`;

                if (status === 'completed') {
                    // Fetch results
                    const resultRes = await fetch(`/api/job_result/${jobId}`);
                    const resultData = await resultRes.json();

                    if (resultData.success && resultData.data && resultData.data.success) {
                        const data = resultData.data;
                        adminInsightsState.analysisComplete = true;
                        state.analytics.jobId = jobId;

                        // Load results into analytics state
                        state.analytics.data = {
                            workbook_analytics: data.workbook_analytics || [],
                            datasource_analytics: data.datasource_analytics || [],
                            flow_analytics: data.flow_analytics || [],
                            user_analytics: data.user_analytics || [],
                            view_analytics: data.view_analytics || [],
                            lineage_impact: data.lineage_impact || [],
                            retirement_candidates: data.retirement_candidates || [],
                            kpi_summary: data.kpi_summary || {},
                            users_kpi: data.users_kpi || {},
                            license_summary: data.license_summary || {}
                        };

                        console.log('Flow analytics loaded:', data.flow_analytics?.length || 0, 'items');
                        console.log('User analytics loaded:', data.user_analytics?.length || 0, 'items');

                        // Update KPIs
                        const kpi = data.kpi_summary || {};
                        updateAnalyticsKPIs(kpi);
                        updateAnalyticsTabCounts();

                        // Update tier counts
                        document.getElementById('tier1Count').textContent = kpi.tier_1_count || 0;
                        document.getElementById('tier2Count').textContent = kpi.tier_2_count || 0;
                        document.getElementById('tier3Count').textContent = kpi.tier_3_count || 0;

                        // Show data source info
                        const csvInfoEl = document.getElementById('csvDataSourceInfo');
                        if (csvInfoEl) {
                            csvInfoEl.style.display = 'block';
                            document.getElementById('csvDataSourceText').textContent =
                                `Admin Insights CSV (${kpi.total_workbooks || 0} workbooks, ${kpi.total_datasources || 0} datasources, ${kpi.total_flows || 0} flows, ${kpi.total_users || 0} users)`;
                        }

                        // Close modal
                        closeUsageSourceModal();

                        // Render the analytics table
                        renderAnalyticsTable();

                        statusText.textContent = 'Analysis complete!';
                    } else {
                        throw new Error(resultData.data?.error || 'Analysis returned no data');
                    }
                } else if (status === 'error') {
                    throw new Error(message || 'Analysis failed');
                } else {
                    // Still running, poll again
                    setTimeout(poll, 1000);
                    return;
                }
            } else {
                throw new Error('Failed to get job status');
            }
        } catch (error) {
            statusText.textContent = 'Error: ' + error.message;
        }

        // Reset button
        runBtn.disabled = false;
        runBtn.innerHTML = `
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right: 4px;">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
            Run Governance Analysis
        `;
    };

    poll();
}

async function exportAdminInsightsAnalysis() {
    try {
        const response = await fetch('/api/admin-insights/export');

        if (response.ok) {
            const blob = await response.blob();
            const defaultFilename = `Admin_Insights_Governance_${new Date().toISOString().slice(0, 10)}.xlsx`;

            // Use File System Access API if available (allows user to choose save location)
            if ('showSaveFilePicker' in window) {
                try {
                    const handle = await window.showSaveFilePicker({
                        suggestedName: defaultFilename,
                        types: [{
                            description: 'Excel Files',
                            accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] }
                        }]
                    });
                    const writable = await handle.createWritable();
                    await writable.write(blob);
                    await writable.close();
                    return;
                } catch (err) {
                    if (err.name === 'AbortError') return;
                }
            }

            // Fallback: regular download
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = defaultFilename;
            a.click();
            window.URL.revokeObjectURL(url);
        } else {
            const error = await response.json();
            alert('Export failed: ' + (error.error || 'Unknown error'));
        }
    } catch (error) {
        alert('Export error: ' + error.message);
    }
}

// Legacy function aliases for backward compatibility
async function handleCSVUpload(type, event) {
    const typeMap = {
        'views': 'ts_events',
        'datasources': 'ts_events',
        'space': 'site_content'
    };
    return handleAdminInsightsUpload(typeMap[type] || type, event);
}

async function runCSVAnalysis() {
    return runAdminInsightsAnalysis();
}

async function clearCSVUploads() {
    return clearAdminInsightsUploads();
}

async function exportCSVAnalysis() {
    return exportAdminInsightsAnalysis();
}


// ==================== AI Assistant Integration ====================

const aiState = {
    isOpen: false,
    isOnline: false,
    conversationId: null,
    isTyping: false,
    currentModel: 'llama3.2'
};

// Initialize AI on page load
document.addEventListener('DOMContentLoaded', function() {
    checkAIStatus();
    // Check AI status periodically
    setInterval(checkAIStatus, 30000);
});

async function checkAIStatus() {
    try {
        const response = await fetch('/api/ai/status');
        const data = await response.json();

        aiState.isOnline = data.available;
        aiState.currentModel = data.config?.model || 'llama3.2';

        const badge = document.getElementById('aiBadge');
        const modelBadge = document.getElementById('aiModelBadge');

        if (data.available) {
            badge.textContent = 'AI';
            badge.classList.remove('offline');
            if (modelBadge) modelBadge.textContent = aiState.currentModel;
        } else {
            badge.textContent = 'OFF';
            badge.classList.add('offline');
        }
    } catch (error) {
        console.error('AI status check failed:', error);
        aiState.isOnline = false;
        const badge = document.getElementById('aiBadge');
        badge.textContent = 'OFF';
        badge.classList.add('offline');
    }
}

function toggleAIChat() {
    const panel = document.getElementById('aiChatPanel');
    const fab = document.getElementById('aiChatFab');

    aiState.isOpen = !aiState.isOpen;

    if (aiState.isOpen) {
        panel.classList.add('open');
        fab.style.display = 'none';
        document.getElementById('aiChatInput').focus();

        // Check status when opening
        if (!aiState.isOnline) {
            checkAIStatus();
        }
    } else {
        panel.classList.remove('open');
        fab.style.display = 'flex';
    }
}

function handleAIChatKeydown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendAIMessage();
    }
}

async function sendAIMessage() {
    const input = document.getElementById('aiChatInput');
    const message = input.value.trim();

    if (!message || aiState.isTyping) return;

    if (!aiState.isOnline) {
        addAIMessage('error', 'AI is offline. Make sure Ollama is running (ollama serve).');
        return;
    }

    // Add user message to chat
    addAIMessage('user', message);
    input.value = '';
    input.style.height = 'auto';

    // Show typing indicator
    showAITyping(true);

    try {
        const response = await fetch('/api/ai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: message,
                conversation_id: aiState.conversationId
            })
        });

        const data = await response.json();
        showAITyping(false);

        if (data.success) {
            aiState.conversationId = data.conversation_id;
            addAIMessage('assistant', data.response);
        } else {
            addAIMessage('error', data.error || 'Failed to get response');
        }
    } catch (error) {
        showAITyping(false);
        addAIMessage('error', 'Failed to connect to AI: ' + error.message);
    }
}

function sendQuickAIMessage(message) {
    document.getElementById('aiChatInput').value = message;
    sendAIMessage();
}

function addAIMessage(type, content) {
    const messagesContainer = document.getElementById('aiChatMessages');

    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-message ${type}`;

    // Format markdown-like content for assistant messages
    if (type === 'assistant') {
        content = formatAIResponse(content);
        messageDiv.innerHTML = content;
    } else {
        messageDiv.textContent = content;
    }

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function formatAIResponse(text) {
    // Convert markdown-style formatting to HTML
    let html = text
        // Code blocks
        .replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre><code>$2</code></pre>')
        // Inline code
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        // Bold
        .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
        // Italic
        .replace(/\*([^*]+)\*/g, '<em>$1</em>')
        // Line breaks
        .replace(/\n/g, '<br>')
        // Lists
        .replace(/^- (.+)$/gm, '• $1')
        .replace(/^\d+\. (.+)$/gm, '→ $1');

    return html;
}

function showAITyping(show) {
    aiState.isTyping = show;
    const messagesContainer = document.getElementById('aiChatMessages');

    // Remove existing typing indicator
    const existing = messagesContainer.querySelector('.ai-typing');
    if (existing) existing.remove();

    if (show) {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'ai-typing';
        typingDiv.innerHTML = '<span></span><span></span><span></span>';
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    document.getElementById('aiSendBtn').disabled = show;
}

async function clearAIChat() {
    if (aiState.conversationId) {
        try {
            await fetch('/api/ai/chat/clear', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ conversation_id: aiState.conversationId })
            });
        } catch (error) {
            console.error('Failed to clear conversation:', error);
        }
    }

    aiState.conversationId = null;
    const messagesContainer = document.getElementById('aiChatMessages');
    messagesContainer.innerHTML = `
        <div class="ai-message system">
            Chat cleared. Ask me about your Tableau metadata, governance, or usage patterns.
        </div>
    `;
}

// AI Insights Functions
async function getAIInsights(type = 'general') {
    if (!aiState.isOnline) {
        alert('AI is offline. Make sure Ollama is running.');
        return null;
    }

    showLoading('Generating AI insights...');

    try {
        const response = await fetch('/api/ai/insights', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: type })
        });

        const data = await response.json();
        hideLoading();

        if (data.success) {
            return data.insights;
        } else {
            alert(data.error || 'Failed to generate insights');
            return null;
        }
    } catch (error) {
        hideLoading();
        alert('Failed to get AI insights: ' + error.message);
        return null;
    }
}

// Natural Language Search
async function aiNaturalLanguageSearch(query) {
    if (!aiState.isOnline) {
        return { success: false, error: 'AI is offline' };
    }

    try {
        const response = await fetch('/api/ai/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query })
        });

        return await response.json();
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// Apply AI-generated filters to the UI
function applyAIFilters(filters) {
    if (!filters) return;

    // Apply content type filter
    if (filters.content_type) {
        const typeChips = document.querySelectorAll('.type-chip');
        typeChips.forEach(chip => {
            if (chip.dataset.type === filters.content_type) {
                chip.click();
            }
        });
    }

    // Apply search text
    if (filters.search_text) {
        const searchInput = document.getElementById('globalSearchInput');
        if (searchInput) {
            searchInput.value = filters.search_text;
            searchInput.dispatchEvent(new Event('input'));
        }
    }

    // Apply owner filter
    if (filters.owner) {
        // Try to find and select the owner in dropdown
        console.log('AI filter - owner:', filters.owner);
    }

    // Apply project filter
    if (filters.project) {
        console.log('AI filter - project:', filters.project);
    }
}

// Get AI explanation for specific content
async function explainContent(contentType, contentData) {
    if (!aiState.isOnline) {
        return { success: false, error: 'AI is offline' };
    }

    try {
        const response = await fetch('/api/ai/explain', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                type: contentType,
                data: contentData
            })
        });

        return await response.json();
    } catch (error) {
        return { success: false, error: error.message };
    }
}


// ==================== Single Workbook Analysis (TWB / TWBX) ====================
const sw = {
    job: null, workbooks: [], datasets: [], selected: '', dataset: 'workbook_summary',
    offset: 0, limit: 50, total: 0, q: '', columns: [], tree: null, wbShown: 100, busy: false
};

function swInit() {
    const $ = (id) => document.getElementById(id);
    if (!$('swAnalyzeBtn')) return;

    $('swBrowseFile').addEventListener('click', () => swBrowse('file'));
    $('swBrowseFolder').addEventListener('click', () => swBrowse('folder'));
    $('swPickFiles').addEventListener('click', () => $('swFileInput').click());
    $('swFileInput').addEventListener('change', (e) => {
        const files = Array.from(e.target.files || []);
        e.target.value = '';
        if (files.length) swUploadAndAnalyze(files);
    });
    $('swAnalyzeBtn').addEventListener('click', () => swStartAnalysis({ path: $('swPath').value.trim() }));
    $('swPath').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('swAnalyzeBtn').click(); });

    const drop = $('swDrop');
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('sw-drag'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('sw-drag'); }));
    drop.addEventListener('drop', async (e) => {
        // collect synchronously: the DataTransfer is only valid until the first await
        const entries = Array.from(e.dataTransfer.items || []).map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
        const plain = Array.from(e.dataTransfer.files || []);
        const files = entries.length ? await swWalkEntries(entries) : plain;
        if (files.length) swUploadAndAnalyze(files);
    });

    $('swDataset').addEventListener('change', (e) => { sw.dataset = e.target.value; sw.offset = 0; swLoadRows(); });
    $('swPerPage').addEventListener('change', (e) => { sw.limit = parseInt(e.target.value); sw.offset = 0; swLoadRows(); });
    $('swPrev').addEventListener('click', () => { sw.offset = Math.max(0, sw.offset - sw.limit); swLoadRows(); });
    $('swNext').addEventListener('click', () => { if (sw.offset + sw.limit < sw.total) { sw.offset += sw.limit; swLoadRows(); } });
    let t1, t2, t3;
    $('swSearch').addEventListener('input', (e) => { clearTimeout(t1); t1 = setTimeout(() => { sw.q = e.target.value.trim(); sw.offset = 0; swLoadRows(); }, 300); });
    $('swWbSearch').addEventListener('input', () => { clearTimeout(t2); t2 = setTimeout(() => { sw.wbShown = 100; swRenderWbList(); }, 200); });
    $('swTreeSearch').addEventListener('input', () => { clearTimeout(t3); t3 = setTimeout(swRenderTree, 200); });
    $('swBody').addEventListener('click', (e) => {          // click a cell to expand / collapse its full text
        const td = e.target.closest('td');
        if (!td || !td.dataset.full) return;
        const open = td.classList.toggle('sw-expanded');
        td.textContent = open ? td.dataset.full : td.dataset.short;
    });
}

async function swWalkEntries(entries) {
    const files = [];
    const walk = async (entry) => {
        if (entry.isFile) {
            await new Promise(res => entry.file(f => { files.push(f); res(); }, res));
        } else if (entry.isDirectory) {
            const reader = entry.createReader();
            let batch;
            do {
                batch = await new Promise(res => reader.readEntries(res, () => res([])));
                for (const e of batch) await walk(e);
            } while (batch.length);
        }
    };
    for (const e of entries) await walk(e);
    return files;
}

function swProgress(pct, text) {
    document.getElementById('swProgress').classList.remove('hidden');
    document.getElementById('swBarFill').style.width = Math.max(0, Math.min(100, pct)) + '%';
    document.getElementById('swProgText').textContent = text || '';
}

async function swBrowse(kind) {
    try {
        const r = await fetch('/api/single_workbook/browse', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind })
        });
        const j = await r.json();
        if (!j.success) { alert(j.error || 'Could not open the file chooser.'); return; }
        if (j.path) {
            document.getElementById('swPath').value = j.path;
            swStartAnalysis({ path: j.path });
        }
    } catch (e) {
        alert('Browse failed: ' + e.message);
    }
}

async function swUploadAndAnalyze(files) {
    const wanted = files.filter(f => /\.(twb|twbx|tds|tdsx|tfl|tflx)$/i.test(f.name));
    if (!wanted.length) { alert('No Tableau files (.twb .twbx .tds .tdsx .tfl .tflx) found in the selection.'); return; }
    try {
        let uploadId = null, batch = [], size = 0, sent = 0;
        const flush = async () => {
            if (!batch.length) return;
            const fd = new FormData();
            if (uploadId) fd.append('upload_id', uploadId);
            batch.forEach(f => fd.append('files', f, f.name));
            const r = await fetch('/api/single_workbook/upload', { method: 'POST', body: fd });
            const j = await r.json();
            if (!j.success) throw new Error(j.error || 'upload failed');
            uploadId = j.upload_id;
            sent += batch.length;
            swProgress(Math.round(100 * sent / wanted.length), `Uploading ${sent}/${wanted.length} file(s)...`);
            batch = []; size = 0;
        };
        swProgress(0, `Uploading ${wanted.length} file(s)...`);
        for (const f of wanted) {
            batch.push(f); size += f.size;
            if (batch.length >= 20 || size > 150 * 1024 * 1024) await flush();
        }
        await flush();
        await swStartAnalysis({ upload_id: uploadId });
    } catch (e) {
        swProgress(0, 'Upload failed: ' + e.message);
        alert('Upload failed: ' + e.message);
    }
}

async function swStartAnalysis(payload) {
    if (sw.busy) return;
    if (!payload.upload_id && !payload.path) { alert('Choose a file or folder, or paste a path first.'); return; }
    payload.recursive = document.getElementById('swRecursive').checked;
    try {
        sw.busy = true;
        document.getElementById('swAnalyzeBtn').disabled = true;
        swProgress(0, 'Starting...');
        const r = await fetch('/api/single_workbook/analyze', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
        });
        const j = await r.json();
        if (!j.success) throw new Error(j.error || 'Could not start the analysis');
        sw.job = j.job_id;
        swProgress(1, `Analysing ${j.files} workbook(s)...`);
        await swPoll(j.job_id);
    } catch (e) {
        swProgress(0, 'Failed: ' + e.message);
        alert(e.message);
    } finally {
        sw.busy = false;
        document.getElementById('swAnalyzeBtn').disabled = false;
    }
}

async function swPoll(job) {
    for (;;) {
        const r = await fetch(`/api/job_status/${job}`);
        const j = await r.json();
        const s = j.status || {};
        swProgress(s.progress || 0, s.message || '');
        if (s.status === 'completed') break;
        if (s.status === 'failed') throw new Error(s.message || 'Analysis failed');
        await new Promise(res => setTimeout(res, 600));
    }
    await swLoad(job);
}

async function swLoad(job) {
    const r = await fetch(`/api/single_workbook/summary/${job}`);
    const j = await r.json();
    if (!j.success) throw new Error(j.error || 'Could not load results');
    sw.workbooks = j.workbooks || [];
    // the Flow Steps sheet only exists when the selection contains Prep flows
    sw.datasets = (j.datasets || []).filter(d => !(d.key === 'flow_steps' && d.count === 0));
    sw.selected = '';
    sw.offset = 0;
    sw.q = '';
    document.getElementById('swSearch').value = '';
    document.getElementById('swWbSearch').value = '';
    document.getElementById('swResults').classList.remove('hidden');

    const count = (k) => (sw.datasets.find(d => d.key === k) || {}).count || 0;
    const failed = j.stats.failed || 0;
    document.getElementById('swStats').innerHTML = [
        [swKindLabel(), j.stats.workbooks], ['Datasources', sw.workbooks.reduce((a, w) => a + (Number(w.Datasources) || 0), 0)],
        ['Tables', sw.workbooks.reduce((a, w) => a + (Number(w.Tables) || 0), 0)],
        ['Custom SQL', sw.workbooks.reduce((a, w) => a + (Number(w['Custom SQL']) || 0), 0)], ['Calculated fields', count('calculated_fields')],
        ['Worksheets', count('worksheets')], ['Dashboards', count('dashboards')], ['Findings', count('data_quality')]
    ].map(([k, v]) => `<span class="sw-chip"><b>${Number(v).toLocaleString()}</b>${k}</span>`).join('')
        + (failed ? `<span class="sw-chip sw-bad"><b>${failed}</b>failed to parse</span>` : '')
        + `<span class="sw-chip">${j.stats.seconds}s</span>`;

    const sel = document.getElementById('swDataset');
    sel.innerHTML = sw.datasets.map(d => `<option value="${d.key}">${escapeHtml(d.sheet)} (${d.count.toLocaleString()})</option>`).join('');
    sw.dataset = sw.datasets.some(d => d.key === sw.dataset) ? sw.dataset : 'workbook_summary';
    sel.value = sw.dataset;

    swRenderWbList();
    swSelect('');
}

function swKindLabel() {
    // "7 Files" when the selection mixes workbooks / datasources / flows, otherwise the specific kind
    const kinds = {};
    sw.workbooks.forEach(w => { kinds[w['Content Type'] || 'Workbook'] = (kinds[w['Content Type'] || 'Workbook'] || 0) + 1; });
    const names = Object.keys(kinds);
    return names.length === 1 ? (names[0] === 'Datasource' ? 'Datasources files' : names[0] + 's') : 'Files';
}

function swRenderWbList() {
    const q = document.getElementById('swWbSearch').value.trim().toLowerCase();
    const list = sw.workbooks.filter(w => !q || (w.Workbook + ' ' + w['File Path']).toLowerCase().includes(q));
    const shown = list.slice(0, sw.wbShown);
    const all = `<div class="sw-wb ${sw.selected === '' ? 'sw-active' : ''}" data-wb=""><div class="sw-wb-name">All workbooks</div>
        <div class="sw-wb-meta">${sw.workbooks.length.toLocaleString()} workbook(s)</div></div>`;
    const items = shown.map(w => {
        const failed = String(w.Status || '').startsWith('FAILED');
        return `<div class="sw-wb ${sw.selected === w.Workbook ? 'sw-active' : ''}" data-wb="${escapeHtml(w.Workbook)}" title="${escapeHtml(w['File Path'])}">
            <div class="sw-wb-name">${escapeHtml(w.Workbook)}${failed ? '<span class="sw-badge sw-fail">failed</span>'
            : (w.Findings ? `<span class="sw-badge">${w.Findings}</span>` : '')}</div>
            <div class="sw-wb-meta">${escapeHtml(w['File Type'])} &middot; ${escapeHtml(w['Content Type'] || 'Workbook')} &middot; ${w['Content Type'] === 'Flow'
                ? `${w.Datasources || 0} steps in/out &middot; ${w.Tables || 0} tables &middot; ${w.Joins || 0} joins`
                : `${w.Worksheets || 0} sheets &middot; ${w.Dashboards || 0} dashboards &middot; ${w.Tables || 0} tables`}</div></div>`;
    }).join('');
    const more = list.length > shown.length ? `<div class="sw-more" data-more="1">Show more (${list.length - shown.length} left)</div>` : '';
    const box = document.getElementById('swWbList');
    box.innerHTML = all + items + more;
    box.onclick = (e) => {
        if (e.target.closest('[data-more]')) { sw.wbShown += 200; swRenderWbList(); return; }
        const el = e.target.closest('.sw-wb');
        if (el) swSelect(el.dataset.wb);
    };
}

async function swSelect(name) {
    sw.selected = name;
    sw.offset = 0;
    document.querySelectorAll('#swWbList .sw-wb').forEach(el => el.classList.toggle('sw-active', el.dataset.wb === name));
    document.getElementById('swExportSel').classList.toggle('hidden', !name);
    document.getElementById('swScope').textContent = name ? `Workbook: ${name}` : 'All workbooks';
    const card = document.getElementById('swTreeCard');
    if (name) {
        try {
            const r = await fetch(`/api/single_workbook/tree/${sw.job}?workbook=${encodeURIComponent(name)}`);
            const j = await r.json();
            if (j.success) {
                sw.tree = j.tree;
                document.getElementById('swTreeTitle').textContent = 'Workbook tree - ' + name;
                document.getElementById('swTreeSearch').value = '';
                card.classList.remove('hidden');
                swRenderTree();
            }
        } catch (e) { console.warn('tree failed', e); }
    } else {
        sw.tree = null;
        card.classList.add('hidden');
    }
    swLoadRows();
}

function swTreeHtml(n, q, depth) {
    const label = escapeHtml(n.label || '');
    const detail = n.detail ? escapeHtml(n.detail.length > 140 ? n.detail.substring(0, 140) + '\u2026' : n.detail) : '';
    const match = !q || (n.label || '').toLowerCase().includes(q) || (n.detail || '').toLowerCase().includes(q);
    const kids = (n.children || []).map(c => swTreeHtml(c, q, depth + 1)).join('');
    if (q && !match && !kids) return '';
    if ((n.children || []).length) {
        const open = q || depth <= 1 ? 'open' : '';
        return `<details ${open} class="sw-t sw-t-${n.type}"><summary>${label}${detail ? `<span class="sw-detail">${detail}</span>` : ''}</summary>${kids}</details>`;
    }
    return `<div class="sw-leaf sw-t-${n.type}" title="${escapeHtml(n.detail || '')}">${label}${detail ? `<span class="sw-detail">${detail}</span>` : ''}</div>`;
}

function swRenderTree() {
    const q = document.getElementById('swTreeSearch').value.trim().toLowerCase();
    document.getElementById('swTree').innerHTML = sw.tree ? swTreeHtml(sw.tree, q, 0) || '<div class="sw-leaf">No matches</div>' : '';
}

async function swLoadRows() {
    if (!sw.job) return;
    const params = new URLSearchParams({ dataset: sw.dataset, offset: sw.offset, limit: sw.limit, q: sw.q, workbook: sw.selected });
    const r = await fetch(`/api/single_workbook/rows/${sw.job}?${params}`);
    const j = await r.json();
    if (!j.success) { document.getElementById('swPageInfo').textContent = j.error || 'Error'; return; }
    sw.total = j.total;
    sw.columns = j.columns;
    const meta = sw.datasets.find(d => d.key === sw.dataset);
    document.getElementById('swGridTitle').textContent = meta ? meta.sheet : sw.dataset;
    document.getElementById('swHead').innerHTML = `<tr>${j.columns.map(c => `<th>${escapeHtml(c)}</th>`).join('')}</tr>`;
    const body = document.getElementById('swBody');
    if (!j.rows.length) {
        body.innerHTML = `<tr><td colspan="${j.columns.length}" class="text-center"><div class="empty-state"><p>No rows.</p></div></td></tr>`;
    } else {
        body.innerHTML = j.rows.map(row => `<tr>${j.columns.map(c => {
            const v = row[c];
            const s = (v === undefined || v === null || v === '') ? '' : String(v);
            const short = s.length > 90 ? s.substring(0, 90) + '\u2026' : s;
            return `<td ${s.length > 90 ? `data-full="${escapeHtml(s)}" data-short="${escapeHtml(short)}"` : ''} title="${escapeHtml(s.substring(0, 300))}">${escapeHtml(short)}</td>`;
        }).join('')}</tr>`).join('');
    }
    const from = j.total ? sw.offset + 1 : 0;
    const to = Math.min(sw.offset + sw.limit, j.total);
    document.getElementById('swPageInfo').textContent = `Showing ${from.toLocaleString()}-${to.toLocaleString()} of ${j.total.toLocaleString()}`;
    document.getElementById('swPrev').disabled = sw.offset === 0;
    document.getElementById('swNext').disabled = sw.offset + sw.limit >= j.total;
}

async function swExport(fmt, selectedOnly) {
    if (!sw.job) return;
    const wb = selectedOnly ? sw.selected : '';
    const qs = `format=${fmt}` + (wb ? `&workbook=${encodeURIComponent(wb)}` : '');
    try {
        const check = await fetch(`/api/single_workbook/export/${sw.job}?check=1`);
        const info = await check.json();
        if (!info.success) { alert('Export failed: ' + (info.error || 'result not available')); return; }
    } catch (e) { alert('Export failed: ' + e.message); return; }
    // Large results are delivered as a .zip of several Excel files (Excel's row limit is ~1M rows per sheet)
    window.location.href = `/api/single_workbook/export/${sw.job}?${qs}`;
}

if (document.readyState !== 'loading') { swInit(); } else { document.addEventListener('DOMContentLoaded', swInit); }
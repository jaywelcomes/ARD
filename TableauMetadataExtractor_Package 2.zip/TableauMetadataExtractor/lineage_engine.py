"""
Lineage Info engine - end-to-end lineage for every Tableau content type.

Pipeline
    1. fetch_lineage_data()  - Metadata API (GraphQL), cursor-paginated, seven collections fetched in parallel,
                               each with a list of field-set "variants" so a server that lacks an optional field
                               degrades gracefully instead of failing.
    2. build_lineage()       - builds an in-memory dependency graph
                                   Database -> Table -> [Flow ->] Datasource (published / embedded) -> Workbook
                               (+ Virtual Connections), enriches it with connection details from the workbook /
                               datasource XML, parses Custom SQL, and produces the seven output datasets:
                                   lineage_summary, lineage_workbooks, lineage_datasources, lineage_flows,
                                   lineage_custom_sql, lineage_table_matrix, lineage_impact
    3. SqlTableParser        - tokenizer based SQL reference extractor (aliases, CTEs, nested subqueries,
                               FROM / JOIN / MERGE / UPDATE / INSERT / DELETE), used for Custom SQL analysis.

Design notes
    * Only the *upstream* direction is queried (consumer -> upstream ids). Downstream sets are derived from the
      graph, which keeps every GraphQL page small (fewer "node limit" rejections) and guarantees the two
      directions always agree.
    * Lists inside queries only ask for ids/names - tables are fetched once as their own collection and joined
      client-side ("dedupe + cache": each object is stored exactly once, traversals are memoised).
"""

import hashlib
import logging
import re
from collections import OrderedDict, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------------------
# Labels
# --------------------------------------------------------------------------------------

CONNECTION_LABELS = {
    'sqlserver': 'SQL Server', 'azure_sql_dw': 'Azure Synapse', 'postgres': 'PostgreSQL',
    'oracle': 'Oracle', 'mysql': 'MySQL', 'snowflake': 'Snowflake', 'redshift': 'Amazon Redshift',
    'bigquery': 'Google BigQuery', 'teradata': 'Teradata', 'databricks': 'Databricks',
    'spark': 'Spark SQL', 'hive': 'Hive', 'impala': 'Impala', 'vertica': 'Vertica', 'db2': 'IBM DB2',
    'sapbw': 'SAP BW', 'saphana': 'SAP HANA', 'genericodbc': 'ODBC', 'odbc': 'ODBC',
    'excel-direct': 'Microsoft Excel', 'textscan': 'Text File (CSV)', 'google-sheets': 'Google Sheets',
    'salesforce': 'Salesforce', 'hyper': 'Hyper Extract', 'dataengine': 'Extract (TDE)',
    'sqlproxy': 'Published Data Source', 'msaccess': 'Microsoft Access', 'sharepoint': 'SharePoint',
    'awsathena': 'Amazon Athena', 'presto': 'Presto', 'trino': 'Trino', 'mongodb': 'MongoDB',
    'denodo': 'Denodo', 'datavirtuality': 'Data Virtuality', 'pdf': 'PDF', 'json': 'JSON',
}

AUTH_LABELS = {
    'sspi': 'Integrated Windows (SSPI)', 'username-password': 'Username / Password',
    'username': 'Username', 'oauth': 'OAuth', 'kerberos': 'Kerberos', 'saml': 'SAML',
    'prompt': 'Prompt user', 'server-run-as': 'Server run-as', 'anonymous': 'Anonymous',
    'azure-ad': 'Azure AD', 'oauth-native': 'OAuth', 'pat': 'Personal access token',
}


def friendly_connection(cls):
    cls = cls or ''
    return CONNECTION_LABELS.get(cls.lower(), cls)


def auth_label(xml_auth='', embed_password=None):
    """Best available description of how the connection authenticates."""
    a = (xml_auth or '').strip()
    low = a.lower()
    if 'oauth' in low:
        return 'OAuth'
    if 'kerberos' in low:
        return 'Kerberos'
    label = AUTH_LABELS.get(low, a)
    if embed_password is True or str(embed_password).lower() == 'true':
        return f'Embedded credentials ({label})' if label else 'Embedded credentials'
    return label


def _s(v):
    return '' if v is None else str(v)


def _join(values, limit=None, sep=', '):
    """Distinct, order preserving, non-empty join with an optional '(+N more)' cap."""
    seen, out = set(), []
    for v in values:
        v = _s(v).strip()
        if v and v not in seen:
            seen.add(v)
            out.append(v)
    if limit and len(out) > limit:
        return sep.join(out[:limit]) + f'{sep}(+{len(out) - limit} more)'
    return sep.join(out)


# --------------------------------------------------------------------------------------
# GraphQL definitions
# --------------------------------------------------------------------------------------
# Each collection: (root field, [field-set variants richest -> minimal]).
# The first variant the server accepts is used; a variant is only abandoned on a *schema* error
# (unknown field), never on a size/timeout error (those shrink the page size instead).

_OWNER = 'owner { luid username name }'
_TBL = 'upstreamTables { id name schema }'
_REF = '{ id luid name }'

LINEAGE_COLLECTIONS = OrderedDict([
    ('databases', ('databases', [
        'id name connectionType isEmbedded hostName port service',
        'id name connectionType isEmbedded',
        'id name connectionType',
    ])),
    ('tables', ('databaseTables', [
        'id name schema fullName isEmbedded tableType database { id name connectionType isEmbedded hostName port }',
        'id name schema fullName isEmbedded database { id name connectionType isEmbedded hostName port }',
        'id name schema fullName isEmbedded database { id name connectionType isEmbedded }',
        'id name schema fullName database { id name connectionType }',
    ])),
    ('custom_sql', ('customSQLTables', [
        'id name query isEmbedded database { id name connectionType } '
        'downstreamDatasources ' + _REF + ' downstreamWorkbooks ' + _REF,
        'id name query isEmbedded database { id name connectionType }',
        'id name query',
    ])),
    ('workbooks', ('workbooks', [
        'id luid name projectName createdAt updatedAt uri site { name } ' + _OWNER + ' '
        'upstreamDatasources ' + _REF + ' upstreamFlows ' + _REF + ' ' + _TBL + ' '
        'embeddedDatasources { id name hasExtracts ' + _TBL + ' upstreamDatasources ' + _REF + ' }',
        'id luid name projectName updatedAt site { name } ' + _OWNER + ' '
        'upstreamDatasources ' + _REF + ' ' + _TBL + ' '
        'embeddedDatasources { id name hasExtracts ' + _TBL + ' }',
        'id luid name projectName updatedAt site { name } ' + _OWNER + ' '
        'upstreamDatasources ' + _REF + ' ' + _TBL,
        'id luid name projectName updatedAt owner { name username } upstreamDatasources ' + _REF,
    ])),
    ('datasources', ('publishedDatasources', [
        'id luid name projectName createdAt updatedAt uri hasExtracts site { name } ' + _OWNER + ' '
        + _TBL + ' upstreamFlows ' + _REF + ' upstreamDatasources ' + _REF,
        'id luid name projectName updatedAt hasExtracts site { name } ' + _OWNER + ' ' + _TBL + ' '
        'upstreamFlows ' + _REF,
        'id luid name projectName updatedAt site { name } ' + _OWNER + ' ' + _TBL,
        'id luid name projectName updatedAt owner { name username } ' + _TBL,
    ])),
    ('flows', ('flows', [
        'id luid name projectName createdAt updatedAt uri site { name } ' + _OWNER + ' '
        + _TBL + ' upstreamDatasources ' + _REF + ' upstreamFlows ' + _REF + ' '
        'downstreamDatasources ' + _REF + ' downstreamWorkbooks ' + _REF + ' downstreamFlows ' + _REF,
        'id luid name projectName updatedAt site { name } ' + _OWNER + ' ' + _TBL + ' '
        'upstreamDatasources ' + _REF + ' downstreamDatasources ' + _REF + ' downstreamWorkbooks ' + _REF,
        'id luid name projectName updatedAt site { name } ' + _OWNER + ' ' + _TBL + ' upstreamDatasources ' + _REF,
        'id luid name projectName updatedAt owner { name username } ' + _TBL,
        'id luid name projectName',
    ])),
    ('virtual_connections', ('virtualConnections', [
        'id luid name description projectName createdAt updatedAt isCertified ' + _OWNER + ' '
        'tables { id name } upstreamDatabases { id name connectionType } '
        'upstreamTables { id name schema fullName } downstreamDatasources ' + _REF + ' downstreamWorkbooks ' + _REF,
        'id luid name projectName updatedAt owner { name username } '
        'upstreamTables { id name schema } downstreamDatasources ' + _REF + ' downstreamWorkbooks ' + _REF,
        'id luid name projectName updatedAt',
    ])),
])


def fetch_lineage_data(client, progress=None, max_workers=4, collections=None):
    """
    Fetch every lineage collection from the Metadata API in parallel.

    client      : MetadataAPIClient (must provide fetch_collection(root, variants))
    progress    : optional callback(done, total, name)
    returns     : {'databases': [...], 'tables': [...], ..., 'errors': [str], 'variants': {name: index}}
    """
    names = list(collections or LINEAGE_COLLECTIONS.keys())
    raw = {n: [] for n in LINEAGE_COLLECTIONS}
    raw['errors'] = []
    raw['variants'] = {}

    def work(name):
        root, variants = LINEAGE_COLLECTIONS[name]
        return name, client.fetch_collection(root, variants)

    done = 0
    with ThreadPoolExecutor(max_workers=max(1, max_workers)) as pool:
        futures = [pool.submit(work, n) for n in names]
        for fut in as_completed(futures):
            try:
                name, (nodes, variant, err) = fut.result()
            except Exception as e:  # never let one collection kill the whole lineage run
                raw['errors'].append(f'lineage fetch failed: {e}')
                done += 1
                continue
            done += 1
            if nodes is None:
                raw['errors'].append(f'{name}: not available ({err})')
            else:
                raw[name] = nodes
                raw['variants'][name] = variant
                if variant > 0:
                    raw['errors'].append(
                        f'{name}: this server does not expose all lineage fields - used reduced field set #{variant}')
            if progress:
                progress(done, len(names), name)
    return raw


# --------------------------------------------------------------------------------------
# SQL parsing
# --------------------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"""
    (?P<ws>\s+)
  | (?P<comment>--[^\n]*|/\*.*?\*/)
  | (?P<string>'(?:[^']|'')*')
  | (?P<qident>\[[^\]]*\]|"(?:[^"]|"")*"|`[^`]*`)
  | (?P<word>[#@$]*[^\W\d][\w#@$]*|\$\d+)
  | (?P<number>\d+(?:\.\d+)?)
  | (?P<sym>.)
""", re.VERBOSE | re.DOTALL)

_TABLEAU_PARAM = re.compile(r"<\s*\[?Parameters\]?\s*\.[^>]*>", re.IGNORECASE)


class SqlTableParser:
    """
    Extracts the physical tables a SQL text depends on.

    Handles: FROM (comma lists), JOIN, INSERT INTO, MERGE INTO / USING, UPDATE, DELETE FROM, SELECT INTO,
    aliases (incl. UPDATE <alias> ... FROM <table> <alias>), CTEs (WITH ... AS (...), RECURSIVE, column lists),
    nested / derived-table subqueries, comments, string literals, Tableau <Parameters.x> placeholders,
    bracket / double-quote / back-tick quoting, 1-4 part names (db..table too), EXTRACT(x FROM y) style FROMs,
    table-valued functions, temp tables (#t) and table variables (@t) (both excluded).
    """

    END_FROM = {'WHERE', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'INTERSECT', 'EXCEPT', 'MINUS', 'LIMIT',
                'WINDOW', 'QUALIFY', 'SELECT', 'SET', 'VALUES', 'FETCH', 'OFFSET', 'FOR', 'RETURNING'}
    ALIAS_STOP = {'ON', 'USING', 'WHERE', 'GROUP', 'ORDER', 'HAVING', 'JOIN', 'INNER', 'LEFT', 'RIGHT', 'FULL',
                  'CROSS', 'OUTER', 'NATURAL', 'UNION', 'INTERSECT', 'EXCEPT', 'MINUS', 'SET', 'LIMIT', 'WINDOW',
                  'QUALIFY', 'FETCH', 'OFFSET', 'FOR', 'WITH', 'PIVOT', 'UNPIVOT', 'TABLESAMPLE', 'WHEN', 'THEN',
                  'LATERAL', 'OPTION', 'FROM', 'SELECT', 'VALUES', 'RETURNING', 'AS', 'STRAIGHT_JOIN', 'APPLY'}
    NOT_TABLES = {'SELECT', 'WITH', 'VALUES', 'TABLE', 'DUAL', 'UNNEST', 'LATERAL', 'FLATTEN', 'GENERATE_SERIES'}
    FUNC_FROM_OPENERS = {'EXTRACT', 'SUBSTRING', 'TRIM', 'OVERLAY', 'POSITION', 'DATE_PART'}

    @classmethod
    def _tokenize(cls, sql):
        sql = _TABLEAU_PARAM.sub("'?'", sql or '')
        tokens = []
        for m in _TOKEN_RE.finditer(sql):
            kind = m.lastgroup
            if kind in ('ws', 'comment'):
                continue
            text = m.group()
            if kind == 'string':
                tokens.append(('string', "''"))
            elif kind == 'qident':
                inner = text[1:-1].replace('""', '"')
                tokens.append(('qident', inner))
            else:
                tokens.append((kind, text))
        return tokens

    @classmethod
    def _read_item(cls, toks, j, allow_paren):
        """Read one table expression starting at toks[j]. Returns (ref|None, next_index)."""
        n = len(toks)
        while j < n and toks[j][0] == 'word' and toks[j][1].upper() in ('ONLY', 'LATERAL'):
            j += 1
        if j >= n:
            return None, j
        if toks[j] == ('sym', '('):
            return None, j                      # derived table / parenthesised join: scanned by the main loop
        if toks[j][0] not in ('word', 'qident'):
            return None, j

        parts, quoted = [], []
        while j < n:
            k, t = toks[j]
            if k not in ('word', 'qident'):
                break
            parts.append(t)
            quoted.append(k == 'qident')
            j += 1
            if j < n and toks[j] == ('sym', '.'):
                j += 1
                if j < n and toks[j] == ('sym', '.'):      # db..table
                    parts.append('')
                    quoted.append(False)
                    j += 1
                if j < n and toks[j][0] in ('word', 'qident'):
                    continue
            break

        if not parts:
            return None, j
        first = parts[0].upper()
        if len(parts) == 1 and not quoted[0] and first in cls.NOT_TABLES:
            return None, j
        if j < n and toks[j] == ('sym', '(') and not allow_paren:
            return None, j                      # table-valued function, e.g. dbo.fn(x)

        alias = ''
        if j < n:
            k, t = toks[j]
            if k == 'word' and t.upper() == 'AS' and j + 1 < n and toks[j + 1][0] in ('word', 'qident'):
                alias = toks[j + 1][1]
                j += 2
            elif k == 'qident' or (k == 'word' and t.upper() not in cls.ALIAS_STOP):
                alias = t
                j += 1
        return {'parts': parts, 'alias': alias}, j

    @classmethod
    def parse(cls, sql):
        """Returns {'tables': [...], 'ctes': [...], 'aliases': {alias: 'schema.table'}}"""
        toks = cls._tokenize(sql)
        n = len(toks)
        refs, ctes = [], []
        depth, paren_stack, in_from = 0, [], {}
        i = 0
        while i < n:
            kind, text = toks[i]
            if kind == 'sym':
                if text == '(':
                    opener = toks[i - 1][1].upper() if i > 0 and toks[i - 1][0] == 'word' else ''
                    paren_stack.append(opener)
                    depth += 1
                    in_from[depth] = False
                elif text == ')':
                    in_from.pop(depth, None)
                    depth = max(0, depth - 1)
                    if paren_stack:
                        paren_stack.pop()
                elif text == ';':
                    in_from[depth] = False
                elif text == ',' and in_from.get(depth):
                    ref, j = cls._read_item(toks, i + 1, allow_paren=False)
                    if ref:
                        ref['kind'] = 'FROM'
                        refs.append(ref)
                        i = j
                        continue
                i += 1
                continue
            if kind != 'word':
                i += 1
                continue

            u = text.upper()
            prev = toks[i - 1][1].upper() if i > 0 and toks[i - 1][0] == 'word' else ''

            if u == 'AS' and i + 2 < n and toks[i + 1] == ('sym', '('):
                # CTE definition:  [WITH|RECURSIVE|,] name [(cols)] AS ( SELECT|WITH|VALUES|(
                p = i - 1
                if p >= 0 and toks[p] == ('sym', ')'):
                    level = 0
                    while p >= 0:
                        if toks[p] == ('sym', ')'):
                            level += 1
                        elif toks[p] == ('sym', '('):
                            level -= 1
                            if level == 0:
                                break
                        p -= 1
                    p -= 1
                nxt = toks[i + 2]
                if (p >= 1 and toks[p][0] in ('word', 'qident')
                        and (toks[p - 1] == ('sym', ',')
                             or (toks[p - 1][0] == 'word' and toks[p - 1][1].upper() in ('WITH', 'RECURSIVE')))
                        and (nxt == ('sym', '(') or (nxt[0] == 'word' and nxt[1].upper() in ('SELECT', 'WITH', 'VALUES', 'TABLE')))):
                    ctes.append(toks[p][1])
            elif u in cls.END_FROM:
                in_from[depth] = False
            elif u == 'FROM':
                opener = paren_stack[-1] if paren_stack else ''
                if opener in cls.FUNC_FROM_OPENERS or prev == 'DISTINCT':
                    pass                          # EXTRACT(YEAR FROM d), a IS DISTINCT FROM b
                else:
                    in_from[depth] = True
                    ref, j = cls._read_item(toks, i + 1, allow_paren=False)
                    if ref:
                        ref['kind'] = 'FROM'
                        refs.append(ref)
                        i = j
                        continue
            elif u == 'JOIN':
                ref, j = cls._read_item(toks, i + 1, allow_paren=False)
                if ref:
                    ref['kind'] = 'JOIN'
                    refs.append(ref)
                    i = j
                    continue
            elif u == 'INTO':
                kind_name = {'INSERT': 'INSERT INTO', 'MERGE': 'MERGE INTO'}.get(prev, 'SELECT INTO')
                ref, j = cls._read_item(toks, i + 1, allow_paren=True)
                if ref:
                    ref['kind'] = kind_name
                    refs.append(ref)
                    i = j
                    continue
            elif u == 'UPDATE':
                if not (i + 1 < n and toks[i + 1][0] == 'word' and toks[i + 1][1].upper() == 'SET'):
                    ref, j = cls._read_item(toks, i + 1, allow_paren=False)
                    if ref:
                        ref['kind'] = 'UPDATE'
                        refs.append(ref)
                        i = j
                        continue
            elif u == 'USING':
                ref, j = cls._read_item(toks, i + 1, allow_paren=False)
                if ref:
                    ref['kind'] = 'MERGE USING'
                    refs.append(ref)
                    i = j
                    continue
            i += 1

        cte_set = {c.lower() for c in ctes}
        alias_set = {r['alias'].lower() for r in refs if r['alias']}
        tables, index = [], {}
        alias_map = {}
        for r in refs:
            parts = r['parts']
            name = parts[-1]
            if not name or name[0] in '#@$':
                continue                                        # temp table / table variable / stage
            low_parts = tuple(p.lower() for p in parts[-3:])
            if len(parts) == 1 and name.lower() in cte_set:
                continue                                        # CTE reference
            if r['kind'] == 'UPDATE' and len(parts) == 1 and name.lower() in alias_set:
                continue                                        # UPDATE <alias> ... FROM real_table <alias>
            entry = index.get(low_parts)
            if entry is None:
                database = parts[-3] if len(parts) >= 3 else ''
                schema = parts[-2] if len(parts) >= 2 else ''
                entry = {'database': database, 'schema': schema, 'table': name,
                         'fqn': '.'.join(p for p in (database, schema, name) if p),
                         'kinds': [], 'aliases': []}
                index[low_parts] = entry
                tables.append(entry)
            if r['kind'] not in entry['kinds']:
                entry['kinds'].append(r['kind'])
            if r['alias'] and r['alias'] not in entry['aliases']:
                entry['aliases'].append(r['alias'])
            if r['alias']:
                alias_map[r['alias']] = entry['fqn']
        return {'tables': tables, 'ctes': ctes, 'aliases': alias_map}


# --------------------------------------------------------------------------------------
# Graph
# --------------------------------------------------------------------------------------

class LineageGraph:
    """Directed dependency graph (upstream -> downstream) with memoised traversals."""

    MEMO_TYPES = ('ds', 'emb', 'flow', 'vc', 'wb')          # mid-level nodes are cached, tables/dbs are not

    def __init__(self):
        self.nodes = {}
        self.down = defaultdict(set)
        self.up = defaultdict(set)
        self._memo = {'down': {}, 'up': {}}

    def add_node(self, key, **attrs):
        node = self.nodes.get(key)
        if node is None:
            self.nodes[key] = {k: v for k, v in attrs.items()}
        else:
            for k, v in attrs.items():
                if v and not node.get(k):
                    node[k] = v

    def add_edge(self, a, b):
        if a and b and a != b:
            self.down[a].add(b)
            self.up[b].add(a)

    def closure(self, key, direction='down'):
        memo = self._memo[direction]
        if key in memo:
            return memo[key]
        adj = self.down if direction == 'down' else self.up
        seen, stack = set(), [key]
        while stack:
            cur = stack.pop()
            for nxt in adj.get(cur, ()):
                if nxt in seen or nxt == key:
                    continue
                seen.add(nxt)
                cached = memo.get(nxt)
                if cached is not None:
                    seen.update(cached)
                else:
                    stack.append(nxt)
        seen.discard(key)
        result = frozenset(seen)
        if key[0] in self.MEMO_TYPES:
            memo[key] = result
        return result

    def of_type(self, keys, node_type):
        return [k for k in keys if k[0] == node_type]

    def attr(self, key, name, default=''):
        return self.nodes.get(key, {}).get(name, default) or default

    def names(self, keys, node_type, limit=None):
        return _join((self.attr(k, 'name') for k in sorted(self.of_type(keys, node_type), key=lambda x: self.attr(x, 'name'))),
                     limit)


# --------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------

def infer_table_type(name, api_type=''):
    t = (api_type or '').strip().upper()
    if t:
        if 'VIEW' in t:
            return 'View'
        if 'EXTERNAL' in t or 'FOREIGN' in t:
            return 'External Table'
        if 'TABLE' in t:
            return 'Physical'
    n = (name or '').lower()
    if re.match(r'^(v|vw|view)_', n) or n.endswith(('_v', '_vw', '_view')):
        return 'View (inferred)'
    if n.startswith(('ext_', 'external_')) or n.endswith(('_ext', '_external')):
        return 'External Table (inferred)'
    return 'Physical'


def _owner(o):
    o = o or {}
    return o.get('name') or o.get('username') or ''


def _norm_sql(sql):
    return re.sub(r'\s+', ' ', (sql or '').strip()).lower()


def _key(node_type, obj):
    """Graph key from an API object: luid when present (workbooks/datasources/flows), else id."""
    if not obj:
        return None
    ident = obj.get('luid') or obj.get('id')
    return (node_type, ident) if ident else None


class ConnectionIndex:
    """Connection details (server/port/warehouse/auth) gathered from workbook + datasource XML and REST."""

    def __init__(self, object_tables=None, rest_connections=None):
        self.by_object = defaultdict(list)
        self.by_db = {}
        embed = {}
        for r in rest_connections or []:
            embed[(r.get('object_id'), _s(r.get('server_address')).lower())] = (
                r.get('embed_password'), r.get('server_port'), r.get('username'))
        for r in object_tables or []:
            if r.get('source') == 'Metadata API' or not r.get('connection_class'):
                continue
            server = r.get('connection_server', '')
            emb = embed.get((r.get('object_id'), _s(server).lower()), (None, '', ''))
            rec = {
                'class': r.get('connection_class', ''),
                'type': r.get('connection_type', ''),
                'server': server,
                'port': r.get('port') or emb[1] or '',
                'database': r.get('database', ''),
                'schema': r.get('schema', ''),
                'warehouse': r.get('warehouse', ''),
                'catalog': r.get('catalog', ''),
                'auth': auth_label(r.get('authentication', ''), emb[0]),
            }
            self.by_object[r['object_id']].append(rec)
            self.by_db.setdefault(_s(rec['database']).lower(), rec)

    def lookup(self, object_ids, database='', conn_class=''):
        dbl = _s(database).lower()
        for oid in object_ids:
            for rec in self.by_object.get(oid, ()):
                if not dbl or _s(rec['database']).lower() == dbl:
                    return rec
        if dbl and dbl in self.by_db:
            return self.by_db[dbl]
        return {}


# --------------------------------------------------------------------------------------
# Builder
# --------------------------------------------------------------------------------------

def build_lineage(raw, object_tables=None, custom_sql_rows=None, rest_connections=None, scope=None,
                  site_name_hint=''):
    """
    Build the seven lineage datasets from the raw Metadata API collections.

    object_tables    : rows from XMLParser.parse_object_tables (connection details + parsed XML tables)
    custom_sql_rows  : rows from the workbook/datasource XML custom SQL extraction
    rest_connections : REST connection rows (embed_password / server_port)
    scope            : {'workbooks': set|None, 'datasources': set|None, 'flows': set|None}; impact counts are always
                       computed on the full graph, only the emitted rows are limited to the scope.
    """
    scope = scope or {}
    conn_index = ConnectionIndex(object_tables, rest_connections)
    g = LineageGraph()

    def in_scope(kind, ident):
        allowed = scope.get({'wb': 'workbooks', 'ds': 'datasources', 'flow': 'flows'}.get(kind, ''))
        return allowed is None or ident in allowed

    # ------------------------------------------------------------------ databases & tables
    dbs = {}
    for d in raw.get('databases', []):
        if d.get('id'):
            dbs[d['id']] = d
    tables = {}          # id -> info
    table_lite = {}      # id -> {'name','schema'} seen in upstream lists (fallback if the collection is missing)

    def register_table_lite(t):
        if t and t.get('id') and t['id'] not in table_lite:
            table_lite[t['id']] = {'name': t.get('name', ''), 'schema': t.get('schema', '')}

    for t in raw.get('tables', []):
        tid = t.get('id')
        if not tid:
            continue
        db = t.get('database') or {}
        if db.get('id') and db['id'] not in dbs:
            dbs[db['id']] = db
        elif db.get('id'):
            for k, v in db.items():                       # richer fields from the table's database object
                if v and not dbs[db['id']].get(k):
                    dbs[db['id']][k] = v
        tables[tid] = {
            'id': tid, 'name': t.get('name', ''), 'schema': t.get('schema', '') or '',
            'db_id': db.get('id'), 'database': db.get('name', ''), 'connection_class': db.get('connectionType', ''),
            'is_embedded': bool(t.get('isEmbedded')), 'is_custom_sql': False,
            'table_type': infer_table_type(t.get('name', ''), t.get('tableType', '')),
        }
    csql_tables = {}
    for c in raw.get('custom_sql', []):
        cid = c.get('id')
        if not cid:
            continue
        db = c.get('database') or {}
        if db.get('id') and db['id'] not in dbs:
            dbs[db['id']] = db
        tables[cid] = {
            'id': cid, 'name': c.get('name', '') or 'Custom SQL', 'schema': '', 'db_id': db.get('id'),
            'database': db.get('name', ''), 'connection_class': db.get('connectionType', ''),
            'is_embedded': bool(c.get('isEmbedded')), 'is_custom_sql': True, 'table_type': 'Custom SQL',
            'query': c.get('query', ''),
        }
        csql_tables[cid] = c

    def tinfo(tid):
        t = tables.get(tid)
        if t is None:
            lite = table_lite.get(tid, {})
            t = {'id': tid, 'name': lite.get('name', '') or tid, 'schema': lite.get('schema', ''), 'db_id': None,
                 'database': '', 'connection_class': '', 'is_embedded': False, 'is_custom_sql': False,
                 'table_type': infer_table_type(lite.get('name', ''))}
            tables[tid] = t
        return t

    def fqn(t):
        if t['is_custom_sql']:
            return f"(Custom SQL) {t['name']}"
        return '.'.join(x for x in (t['database'], t['schema'], t['name']) if x)

    for d in dbs.values():
        g.add_node(('db', d['id']), name=d.get('name', ''), connection_class=d.get('connectionType', ''),
                   host=d.get('hostName', ''), port=d.get('port', ''))
    for tid, t in tables.items():
        g.add_node(('table', tid), name=t['name'])
        if t['db_id']:
            g.add_edge(('db', t['db_id']), ('table', tid))

    # ------------------------------------------------------------------ content nodes
    def content_attrs(o):
        return dict(name=o.get('name', ''), id=o.get('luid') or o.get('id', ''), project=o.get('projectName', ''),
                    owner=_owner(o.get('owner')), site=(o.get('site') or {}).get('name', '') or site_name_hint,
                    updated=o.get('updatedAt', '') or o.get('createdAt', ''))

    ds_tables = {}        # ds key -> [table ids]
    emb_info = {}         # emb key -> dict
    wb_info = {}          # wb key -> dict(published=[keys], embedded=[keys], tables=[ids])
    flow_direct = {}      # flow key -> [table ids]
    vc_direct = {}

    for f in raw.get('flows', []):
        fk = _key('flow', f)
        if not fk:
            continue
        g.add_node(fk, **content_attrs(f))
        ids = []
        for t in f.get('upstreamTables') or []:
            register_table_lite(t)
            ids.append(t['id'])
            g.add_edge(('table', t['id']), fk)
        flow_direct[fk] = ids
        for u in f.get('upstreamDatasources') or []:
            uk = _key('ds', u)
            g.add_node(uk, name=u.get('name', ''))
            g.add_edge(uk, fk)
        for u in f.get('upstreamFlows') or []:
            uk = _key('flow', u)
            g.add_node(uk, name=u.get('name', ''))
            g.add_edge(uk, fk)
        for dn in f.get('downstreamDatasources') or []:
            dk = _key('ds', dn)
            g.add_node(dk, name=dn.get('name', ''))
            g.add_edge(fk, dk)
        for dn in f.get('downstreamWorkbooks') or []:
            dk = _key('wb', dn)
            g.add_node(dk, name=dn.get('name', ''))
            g.add_edge(fk, dk)
        for dn in f.get('downstreamFlows') or []:
            dk = _key('flow', dn)
            g.add_node(dk, name=dn.get('name', ''))
            g.add_edge(fk, dk)

    for d in raw.get('datasources', []):
        dk = _key('ds', d)
        if not dk:
            continue
        g.add_node(dk, has_extracts=d.get('hasExtracts'), **content_attrs(d))
        ids = []
        for t in d.get('upstreamTables') or []:
            register_table_lite(t)
            ids.append(t['id'])
            g.add_edge(('table', t['id']), dk)
        ds_tables[dk] = ids
        for fl in d.get('upstreamFlows') or []:
            fk = _key('flow', fl)
            g.add_node(fk, name=fl.get('name', ''))
            g.add_edge(fk, dk)
        for u in d.get('upstreamDatasources') or []:
            uk = _key('ds', u)
            g.add_node(uk, name=u.get('name', ''))
            g.add_edge(uk, dk)

    for w in raw.get('workbooks', []):
        wk = _key('wb', w)
        if not wk:
            continue
        g.add_node(wk, **content_attrs(w))
        info = {'published': [], 'embedded': [], 'tables': [], 'leftover': []}
        covered = set()
        for u in w.get('upstreamDatasources') or []:
            uk = _key('ds', u)
            if not uk:
                continue
            g.add_node(uk, name=u.get('name', ''))
            g.add_edge(uk, wk)
            info['published'].append(uk)
            covered.update(ds_tables.get(uk, ()))
        for fl in w.get('upstreamFlows') or []:
            fk = _key('flow', fl)
            g.add_node(fk, name=fl.get('name', ''))
            g.add_edge(fk, wk)
        for e in w.get('embeddedDatasources') or []:
            if not e.get('id'):
                continue
            ek = ('emb', f"{wk[1]}::{e['id']}")
            g.add_node(ek, name=e.get('name', ''), workbook=w.get('name', ''), project=w.get('projectName', ''),
                       owner=_owner(w.get('owner')), site=(w.get('site') or {}).get('name', '') or site_name_hint,
                       updated=w.get('updatedAt', ''), has_extracts=e.get('hasExtracts'), id=e['id'])
            g.add_edge(ek, wk)
            ids = []
            for t in e.get('upstreamTables') or []:
                register_table_lite(t)
                ids.append(t['id'])
                g.add_edge(('table', t['id']), ek)
            covered.update(ids)
            for u in e.get('upstreamDatasources') or []:
                uk = _key('ds', u)
                g.add_node(uk, name=u.get('name', ''))
                g.add_edge(uk, ek)
            emb_info[ek] = {'name': e.get('name', ''), 'tables': ids, 'workbook': wk}
            info['embedded'].append(ek)
        allt = []
        for t in w.get('upstreamTables') or []:
            register_table_lite(t)
            allt.append(t['id'])
        info['leftover'] = [t for t in allt if t not in covered]
        for t in info['leftover']:
            g.add_edge(('table', t), wk)
        info['tables'] = allt
        wb_info[wk] = info

    for v in raw.get('virtual_connections', []):
        vk = _key('vc', v)
        if not vk:
            continue
        g.add_node(vk, **content_attrs(v))
        ids = []
        for t in v.get('upstreamTables') or []:
            register_table_lite(t)
            ids.append(t['id'])
            g.add_edge(('table', t['id']), vk)
        vc_direct[vk] = ids
        for u in v.get('upstreamDatabases') or []:
            if u.get('id'):
                g.add_node(('db', u['id']), name=u.get('name', ''), connection_class=u.get('connectionType', ''))
                g.add_edge(('db', u['id']), vk)
        for dn in v.get('downstreamDatasources') or []:
            dk = _key('ds', dn)
            g.add_node(dk, name=dn.get('name', ''))
            g.add_edge(vk, dk)
        for dn in v.get('downstreamWorkbooks') or []:
            dk = _key('wb', dn)
            g.add_node(dk, name=dn.get('name', ''))
            g.add_edge(vk, dk)
        g.nodes[vk]['tables_names'] = _join(t.get('name', '') for t in (v.get('tables') or []))

    for tid in list(table_lite):
        tinfo(tid)
        g.add_node(('table', tid), name=tables[tid]['name'])

    # ------------------------------------------------------------------ Custom SQL analysis
    csql_rows = []
    seen_sql = set()
    parsed_refs = []      # (owner key, parsed table dict, database hint)

    def add_sql_rows(owner_key, owner_type, owner_id, owner_name, ds_name, sql_name, sql_text, source, conn_class='',
                     database='', server=''):
        norm = _norm_sql(sql_text)
        dedupe = (owner_id, hashlib.md5(norm.encode('utf-8', 'ignore')).hexdigest())
        if dedupe in seen_sql:
            return
        seen_sql.add(dedupe)
        parsed = SqlTableParser.parse(sql_text)
        emit_rows = in_scope(owner_key[0], owner_key[1])
        node = g.nodes.get(owner_key, {})
        common = OrderedDict([
            ('Content ID', owner_id), ('Content Name', owner_name), ('Content Type', owner_type),
            ('Project Name', node.get('project', '')), ('Owner Name', node.get('owner', '')),
            ('Datasource Name', ds_name), ('Custom SQL Name', sql_name),
        ])
        refs = parsed['tables']
        if not refs and emit_rows:
            row = OrderedDict(common)
            row.update([('Referenced Table', ''), ('Referenced Database', ''), ('Referenced Schema', ''),
                        ('Table Name', ''), ('Reference Type', ''), ('Alias', ''),
                        ('CTEs', _join(parsed['ctes'])), ('Connection Type', friendly_connection(conn_class)),
                        ('Server Name', server), ('SQL Text', sql_text), ('Source', source)])
            csql_rows.append(row)
        for r in refs:
            row = OrderedDict(common)
            row.update([('Referenced Table', r['fqn']), ('Referenced Database', r['database']),
                        ('Referenced Schema', r['schema']), ('Table Name', r['table']),
                        ('Reference Type', ', '.join(r['kinds'])), ('Alias', ', '.join(r['aliases'])),
                        ('CTEs', _join(parsed['ctes'])), ('Connection Type', friendly_connection(conn_class)),
                        ('Server Name', server),
                        ('SQL Text', sql_text), ('Source', source)])
            if emit_rows:
                csql_rows.append(row)
            parsed_refs.append((owner_key, r, database))

    obj_type_key = {'Workbook': 'wb', 'Data Source': 'ds'}
    conn_by_obj = {}
    for r in object_tables or []:
        conn_by_obj.setdefault(r.get('object_id'), r)

    for r in custom_sql_rows or []:
        if r.get('source') == 'Metadata API':
            continue
        t = obj_type_key.get(r.get('file_type'))
        oid = r.get('object_id')
        if not t or not oid:
            continue
        c = conn_by_obj.get(oid, {})
        add_sql_rows((t, oid), 'Workbook' if t == 'wb' else 'Datasource', oid, r.get('object_name', ''),
                     r.get('datasource_name', ''), r.get('sql_name', ''), r.get('sql_text', ''), 'XML',
                     c.get('connection_class', ''), c.get('database', ''), c.get('connection_server', ''))

    for cid, c in csql_tables.items():
        sql_text = c.get('query') or ''
        if not sql_text.strip():
            continue
        db = c.get('database') or {}
        for owners, t, label in ((c.get('downstreamWorkbooks') or [], 'wb', 'Workbook'),
                                 (c.get('downstreamDatasources') or [], 'ds', 'Datasource')):
            for o in owners:
                ok = _key(t, o)
                if not ok:
                    continue
                g.add_node(ok, name=o.get('name', ''))
                add_sql_rows(ok, label, ok[1], o.get('name', ''), '', c.get('name', ''), sql_text,
                             'Metadata API', db.get('connectionType', ''), db.get('name', ''), '')

    # parsed SQL references become table nodes (matched to physical tables when they exist)
    physical_index = defaultdict(list)
    for tid, t in list(tables.items()):
        if not t['is_custom_sql']:
            physical_index[(t['schema'].lower(), t['name'].lower())].append(tid)
    parsed_table_ids = {}
    sql_only_by_owner = defaultdict(set)      # owner key -> parsed-only table ids (avoids O(objects x tables) scans)
    via_sql_by_owner = defaultdict(set)       # owner key -> EVERY table id reached via SQL (parsed-only + matched
                                              # to a real table) - used for "own tables" completeness (Lineage
                                              # Summary, Tables Used); sql_only_by_owner stays parsed-only so the
                                              # per-table "Custom SQL (parsed)" detail rows below don't duplicate
                                              # a table already shown via its normal (e.g. Published Datasource) row.
    for owner_key, r, db_hint in parsed_refs:
        match = None
        for tid in physical_index.get((r['schema'].lower(), r['table'].lower()), ()):
            if not r['database'] or tables[tid]['database'].lower() == r['database'].lower():
                match = tid
                break
        if match is None:
            pk = (r['database'].lower(), r['schema'].lower(), r['table'].lower())
            match = parsed_table_ids.get(pk)
            if match is None:
                match = f"parsed:{'.'.join(pk)}"
                parsed_table_ids[pk] = match
                tables[match] = {
                    'id': match, 'name': r['table'], 'schema': r['schema'], 'db_id': None,
                    'database': r['database'] or db_hint, 'connection_class': '', 'is_embedded': False,
                    'is_custom_sql': False, 'table_type': infer_table_type(r['table']),
                    'parsed_only': True,
                }
                g.add_node(('table', match), name=r['table'])
        g.add_edge(('table', match), owner_key)
        tables[match].setdefault('via_sql', set()).add(owner_key)
        via_sql_by_owner[owner_key].add(match)
        if match in parsed_table_ids.values():
            sql_only_by_owner[owner_key].add(match)

    # ------------------------------------------------------------------ helpers for rows
    def conn_for(object_ids, t):
        """Connection details for a table: XML of the owning objects, else Metadata API database info."""
        rec = conn_index.lookup(object_ids, t.get('database', ''), t.get('connection_class', ''))
        db = dbs.get(t.get('db_id') or '', {})
        cls = rec.get('class') or t.get('connection_class') or db.get('connectionType', '')
        return {
            'Connection Type': rec.get('type') or friendly_connection(cls),
            'Connection Class': cls,
            'Server Name': rec.get('server') or db.get('hostName', '') or '',
            'Port': rec.get('port') or db.get('port', '') or '',
            'Warehouse': rec.get('warehouse', ''),
            'Catalog': rec.get('catalog', ''),
            'Schema': rec.get('schema', '') or t.get('schema', ''),
            'Authentication Type': rec.get('auth', ''),
            'Database Name': t.get('database', '') or rec.get('database', ''),
        }

    def table_cols(t):
        return OrderedDict([
            ('Database', t.get('database', '')), ('Schema Name', t.get('schema', '')),
            ('Table Name', t['name']), ('Fully Qualified Table Name', fqn(t)), ('Table Type', t['table_type']),
        ])

    def path_str(t, *chain):
        parts = [t.get('database', ''), t.get('schema', ''), t['name']] if not t['is_custom_sql'] \
            else [t.get('database', ''), fqn(t)]
        return ' > '.join(p for p in list(parts) + list(chain) if p)

    _flow_vc_cache = {}

    def flow_vc(key):
        """(flow keys, flow names, flow ids, vc names) upstream of `key` - computed once per object."""
        hit = _flow_vc_cache.get(key)
        if hit is None:
            ups = g.closure(key, 'up')
            flow_keys = g.of_type(ups, 'flow')
            hit = (flow_keys, g.names(flow_keys, 'flow'), _join(k[1] for k in flow_keys),
                   g.names(g.of_type(ups, 'vc'), 'vc'))
            _flow_vc_cache[key] = hit
        return hit

    def flows_of(key):
        return flow_vc(key)[0]

    def vcs_of(key):
        return g.of_type(g.closure(key, 'up'), 'vc')

    def counts(key):
        down = g.closure(key, 'down')
        up = g.closure(key, 'up')
        return up, down

    # ------------------------------------------------------------------ Workbook lineage rows
    wb_rows = []
    for wk, info in wb_info.items():
        if not in_scope('wb', wk[1]):
            continue
        node = g.nodes[wk]
        base = OrderedDict([
            ('Workbook ID', wk[1]), ('Workbook Name', node.get('name', '')), ('Project Name', node.get('project', '')),
            ('Owner Name', node.get('owner', '')), ('Site Name', node.get('site', '')),
            ('Last Modified', node.get('updated', '')),
        ])
        emitted = 0

        def emit(path_type, pub_key, emb_key, tid, ds_key_for_flows):
            nonlocal emitted
            t = tinfo(tid) if tid else None
            flow_keys, flow_names, flow_ids, vc_names = (
                flow_vc(ds_key_for_flows) if ds_key_for_flows else ([], '', '', ''))
            row = OrderedDict(base)
            row['Path Type'] = path_type
            row['Published Datasource ID'] = pub_key[1] if pub_key else ''
            row['Published Datasource Name'] = g.attr(pub_key, 'name') if pub_key else ''
            row['Embedded Datasource Name'] = emb_info[emb_key]['name'] if emb_key else ''
            row['Flow ID'] = flow_ids
            row['Flow Name'] = flow_names
            row['Virtual Connection Name'] = vc_names
            ids = [wk[1]] + ([pub_key[1]] if pub_key else [])
            if t:
                row.update(conn_for(ids, t))
                row.update(table_cols(t))
                chain = []
                if flow_keys:
                    chain.append('Flow: ' + flow_names)
                if pub_key:
                    chain.append('Published DS: ' + g.attr(pub_key, 'name'))
                elif emb_key:
                    chain.append('Embedded DS: ' + emb_info[emb_key]['name'])
                chain.append('Workbook: ' + node.get('name', ''))
                row['Lineage Path'] = path_str(t, *chain)
            else:
                for c in ('Connection Type', 'Connection Class', 'Server Name', 'Port', 'Warehouse', 'Catalog',
                          'Schema', 'Authentication Type', 'Database Name', 'Database', 'Schema Name', 'Table Name',
                          'Fully Qualified Table Name', 'Table Type'):
                    row[c] = ''
                row['Lineage Path'] = ' > '.join(p for p in (
                    ('Published DS: ' + g.attr(pub_key, 'name')) if pub_key else '',
                    ('Embedded DS: ' + emb_info[emb_key]['name']) if emb_key else '',
                    'Workbook: ' + node.get('name', '')) if p)
            wb_rows.append(row)
            emitted += 1

        for pk in info['published']:
            tids = ds_tables.get(pk, [])
            if tids:
                for tid in tids:
                    emit('Published Datasource', pk, None, tid, pk)
            else:
                emit('Published Datasource (no table lineage)', pk, None, None, pk)
        for ek in info['embedded']:
            tids = emb_info[ek]['tables']
            if tids:
                for tid in tids:
                    emit('Embedded Datasource', None, ek, tid, ek)
            else:
                emit('Embedded Datasource (no table lineage)', None, ek, None, ek)
        for tid in info['leftover']:
            emit('Direct / other', None, None, tid, None)      # no flow/VC attribution: not via a datasource
        if emitted == 0:
            emit('No upstream tables found', None, None, None, None)
        # tables referenced only inside this workbook's custom SQL
        for tid in sorted(sql_only_by_owner.get(wk, ())):
            emit('Custom SQL (parsed)', None, None, tid, None)

    # ------------------------------------------------------------------ Datasource lineage rows
    ds_rows = []
    for dk in [k for k in g.nodes if k[0] == 'ds' and (k in ds_tables)]:
        if not in_scope('ds', dk[1]):
            continue
        node = g.nodes[dk]
        flow_keys, flow_names, flow_ids, vc_names = flow_vc(dk)
        up, down = counts(dk)
        base = OrderedDict([
            ('Datasource ID', dk[1]), ('Datasource Name', node.get('name', '')), ('Datasource Type', 'Published'),
            ('Parent Workbook', ''), ('Project Name', node.get('project', '')), ('Owner Name', node.get('owner', '')),
            ('Site Name', node.get('site', '')), ('Last Modified', node.get('updated', '')),
            ('Has Extract', node.get('has_extracts', '')),
            ('Upstream Flow ID', flow_ids), ('Upstream Flow Name', flow_names),
            ('Virtual Connection Name', vc_names),
            ('Downstream Workbooks', len(g.of_type(down, 'wb'))), ('Downstream Flows', len(g.of_type(down, 'flow'))),
        ])
        tids = ds_tables.get(dk, [])
        extra = sorted(sql_only_by_owner.get(dk, ()))
        for tid in tids + extra:
            t = tinfo(tid)
            row = OrderedDict(base)
            row.update(conn_for([dk[1]], t))
            row.update(table_cols(t))
            row['Custom SQL'] = 'Yes' if t['is_custom_sql'] or tid in extra else ''
            chain = ([f"Flow: {flow_names}"] if flow_keys else []) + [f"Published DS: {node.get('name', '')}"]
            row['Lineage Path'] = path_str(t, *chain)
            ds_rows.append(row)
        if not tids and not extra:
            row = OrderedDict(base)
            for c in ('Connection Type', 'Connection Class', 'Server Name', 'Port', 'Warehouse', 'Catalog', 'Schema',
                      'Authentication Type', 'Database Name', 'Database', 'Schema Name', 'Table Name',
                      'Fully Qualified Table Name', 'Table Type', 'Custom SQL'):
                row[c] = ''
            row['Lineage Path'] = 'No upstream tables found'
            ds_rows.append(row)
    for ek, einfo in emb_info.items():
        wk = einfo['workbook']
        if not in_scope('wb', wk[1]):
            continue
        wnode = g.nodes[wk]
        node = g.nodes[ek]
        flow_keys, flow_names, flow_ids, vc_names = flow_vc(ek)
        base = OrderedDict([
            ('Datasource ID', node.get('id', '')), ('Datasource Name', einfo['name']), ('Datasource Type', 'Embedded'),
            ('Parent Workbook', wnode.get('name', '')), ('Project Name', wnode.get('project', '')),
            ('Owner Name', wnode.get('owner', '')), ('Site Name', wnode.get('site', '')),
            ('Last Modified', wnode.get('updated', '')), ('Has Extract', node.get('has_extracts', '')),
            ('Upstream Flow ID', flow_ids), ('Upstream Flow Name', flow_names),
            ('Virtual Connection Name', vc_names),
            ('Downstream Workbooks', 1), ('Downstream Flows', 0),
        ])
        for tid in einfo['tables']:
            t = tinfo(tid)
            row = OrderedDict(base)
            row.update(conn_for([wk[1]], t))
            row.update(table_cols(t))
            row['Custom SQL'] = 'Yes' if t['is_custom_sql'] else ''
            row['Lineage Path'] = path_str(t, f"Embedded DS: {einfo['name']}", f"Workbook: {wnode.get('name', '')}")
            ds_rows.append(row)

    # ------------------------------------------------------------------ Flow lineage rows
    flow_rows = []
    for fk in [k for k in g.nodes if k[0] == 'flow' and k in flow_direct]:
        if not in_scope('flow', fk[1]):
            continue
        node = g.nodes[fk]
        base = OrderedDict([
            ('Flow ID', fk[1]), ('Flow Name', node.get('name', '')), ('Project Name', node.get('project', '')),
            ('Owner Name', node.get('owner', '')), ('Site Name', node.get('site', '')),
            ('Last Modified', node.get('updated', '')),
        ])

        def frow(direction, asset_type, asset_id, asset_name, t=None, path=''):
            row = OrderedDict(base)
            row['Direction'] = direction
            row['Asset Type'] = asset_type
            row['Asset ID'] = asset_id
            row['Asset Name'] = asset_name
            if t:
                row.update(conn_for([], t))
                row.update(table_cols(t))
            else:
                for c in ('Connection Type', 'Connection Class', 'Server Name', 'Port', 'Warehouse', 'Catalog',
                          'Schema', 'Authentication Type', 'Database Name', 'Database', 'Schema Name', 'Table Name',
                          'Fully Qualified Table Name', 'Table Type'):
                    row[c] = ''
            row['Lineage Path'] = path
            flow_rows.append(row)

        first_row = len(flow_rows)
        ups = g.closure(fk, 'up')
        downs = g.closure(fk, 'down')
        direct_up = g.up.get(fk, set())
        direct_down = g.down.get(fk, set())
        fname = node.get('name', '')
        for tid in flow_direct.get(fk, []):
            t = tinfo(tid)
            frow('Upstream', 'Table', tid, fqn(t), t, path_str(t, f'Flow: {fname}'))
        for k in sorted(g.of_type(direct_up, 'ds'), key=lambda x: g.attr(x, 'name')):
            frow('Upstream', 'Published Datasource', k[1], g.attr(k, 'name'), None,
                 f"Published DS: {g.attr(k, 'name')} > Flow: {fname}")
        for k in sorted(g.of_type(direct_up, 'flow'), key=lambda x: g.attr(x, 'name')):
            frow('Upstream', 'Flow', k[1], g.attr(k, 'name'), None, f"Flow: {g.attr(k, 'name')} > Flow: {fname}")
        for k in sorted(g.of_type(ups, 'db'), key=lambda x: g.attr(x, 'name')):
            frow('Upstream', 'Database', k[1], g.attr(k, 'name'), None, f"Database: {g.attr(k, 'name')} > Flow: {fname}")
        for k in sorted(g.of_type(direct_down, 'ds'), key=lambda x: g.attr(x, 'name')):
            frow('Downstream', 'Published Datasource', k[1], g.attr(k, 'name'), None,
                 f"Flow: {fname} > Published DS: {g.attr(k, 'name')}")
        for k in sorted(g.of_type(direct_down, 'flow'), key=lambda x: g.attr(x, 'name')):
            frow('Downstream', 'Flow', k[1], g.attr(k, 'name'), None, f"Flow: {fname} > Flow: {g.attr(k, 'name')}")
        for k in sorted(g.of_type(downs, 'wb'), key=lambda x: g.attr(x, 'name')):
            via = [d for d in g.of_type(direct_down, 'ds') if k in g.closure(d, 'down')]
            chain = f"Flow: {fname}" + (f" > Published DS: {g.attr(via[0], 'name')}" if via else '') \
                    + f" > Workbook: {g.attr(k, 'name')}"
            frow('Downstream', 'Workbook', k[1], g.attr(k, 'name'), None, chain)
        if len(flow_rows) == first_row:
            frow('', 'No lineage found', '', '', None, '')

    # ------------------------------------------------------------------ Impact analysis
    def down_of(key):
        if key[0] == 'db':                      # a database impacts everything downstream of any of its tables
            acc = set()
            for tk in g.down.get(key, ()):
                acc.add(tk)
                acc |= g.closure(tk, 'down')
            return acc
        return g.closure(key, 'down')

    impact_rows = []

    def add_impact(obj_type, key, name, fq='', project='', owner='', db='', schema=''):
        down = down_of(key)
        wbs = g.of_type(down, 'wb')
        pub = g.of_type(down, 'ds')
        emb = g.of_type(down, 'emb')
        fls = g.of_type(down, 'flow')
        impacted = wbs + pub + fls
        users = {g.attr(k, 'owner') for k in impacted if g.attr(k, 'owner')}
        projects = {g.attr(k, 'project') for k in impacted if g.attr(k, 'project')}
        impact_rows.append(OrderedDict([
            ('Object Type', obj_type), ('Object ID', key[1]), ('Object Name', name),
            ('Fully Qualified Name', fq or name), ('Database', db), ('Schema Name', schema),
            ('Project Name', project), ('Owner Name', owner),
            ('Downstream Workbooks', len(wbs)), ('Downstream Datasources', len(pub)),
            ('Downstream Embedded Datasources', len(emb)), ('Downstream Flows', len(fls)),
            ('Impacted Users', len(users)), ('Impacted Projects', len(projects)),
            ('Impacted Workbook Names', g.names(wbs, 'wb', 25)),
            ('Impacted Datasource Names', g.names(pub, 'ds', 25)),
            ('Impacted Flow Names', g.names(fls, 'flow', 25)),
            ('Impacted Users List', _join(sorted(users), 25)),
        ]))
        return down

    matrix_rows = []
    # scope for table/db rows: tables upstream of in-scope content
    scoped_tables = None
    if any(v is not None for v in scope.values()):
        scoped_tables = set()
        for k in g.nodes:
            if k[0] in ('wb', 'ds', 'flow') and in_scope(k[0], k[1]):
                scoped_tables.update(('table', x[1]) for x in g.closure(k, 'up') if x[0] == 'table')
        for k, e in emb_info.items():
            if in_scope('wb', e['workbook'][1]):
                scoped_tables.update(('table', tid) for tid in e['tables'])

    for tid, t in list(tables.items()):
        tk = ('table', tid)
        if scoped_tables is not None and tk not in scoped_tables:
            continue
        down = add_impact('Custom SQL' if t['is_custom_sql'] else 'Table', tk, t['name'], fqn(t),
                          db=t.get('database', ''), schema=t.get('schema', ''))
        direct = g.down.get(tk, set())
        conn = conn_for([], t)
        sql_owners = t.get('via_sql', set())
        matrix_rows.append(OrderedDict([
            ('Fully Qualified Table Name', fqn(t)), ('Database', t.get('database', '')),
            ('Schema Name', t.get('schema', '')), ('Table Name', t['name']), ('Table Type', t['table_type']),
            ('Connection Type', conn['Connection Type']), ('Server Name', conn['Server Name']),
            ('Published Datasources', len(g.of_type(down, 'ds'))),
            ('Embedded Datasources', len(g.of_type(down, 'emb'))),
            ('Flows', len(g.of_type(down, 'flow'))),
            ('Workbooks', len(g.of_type(down, 'wb'))),
            ('Virtual Connections', len(g.of_type(down, 'vc'))),
            ('Custom SQL References', len(sql_owners)),
            ('Referenced In Custom SQL Only', 'Yes' if t.get('parsed_only') else ''),
            ('Workbook Names', g.names(g.of_type(down, 'wb'), 'wb', 25)),
            ('Published Datasource Names', g.names(g.of_type(down, 'ds'), 'ds', 25)),
            ('Flow Names', g.names(g.of_type(down, 'flow'), 'flow', 25)),
            ('Custom SQL Owners', _join((g.attr(k, 'name') for k in sql_owners), 25)),
        ]))
    for k in [k for k in g.nodes if k[0] == 'db']:
        if scoped_tables is not None and not any(('table', x[1]) in scoped_tables for x in g.down.get(k, ())):
            continue
        nd = g.nodes[k]
        add_impact('Database', k, nd.get('name', ''), nd.get('name', ''), db=nd.get('name', ''))
    for k in [k for k in g.nodes if k[0] == 'ds' and k in ds_tables and in_scope('ds', k[1])]:
        nd = g.nodes[k]
        add_impact('Published Datasource', k, nd.get('name', ''), project=nd.get('project', ''), owner=nd.get('owner', ''))
    for k in [k for k in g.nodes if k[0] == 'flow' and k in flow_direct and in_scope('flow', k[1])]:
        nd = g.nodes[k]
        add_impact('Flow', k, nd.get('name', ''), project=nd.get('project', ''), owner=nd.get('owner', ''))
    for k in [k for k in g.nodes if k[0] == 'vc' and k in vc_direct]:
        nd = g.nodes[k]
        add_impact('Virtual Connection', k, nd.get('name', ''), project=nd.get('project', ''), owner=nd.get('owner', ''))

    # ------------------------------------------------------------------ Lineage summary (one row per content object)
    summary = []
    tables_used = []   # "Tables Used" view - mirrors Deep Analysis's Tables Used tab, one row per content object

    def conn_summary(object_ids, tids, extra_db_ids=()):
        vals = defaultdict(list)
        dbn = []
        for tid in tids:
            t = tinfo(tid)
            c = conn_for(object_ids, t)
            for k2 in ('Connection Type', 'Connection Class', 'Server Name', 'Port', 'Warehouse', 'Catalog', 'Schema',
                       'Authentication Type', 'Database Name'):
                vals[k2].append(c[k2])
            dbn.append(t.get('database', ''))
        for dbid in extra_db_ids:
            dbn.append(g.attr(('db', dbid), 'name'))
            vals['Connection Class'].append(g.attr(('db', dbid), 'connection_class'))
            vals['Connection Type'].append(friendly_connection(g.attr(('db', dbid), 'connection_class')))
        out = OrderedDict((k2, _join(vals[k2], 10)) for k2 in (
            'Connection Type', 'Connection Class', 'Database Name', 'Server Name', 'Port', 'Warehouse', 'Catalog',
            'Schema', 'Authentication Type'))
        return out, _join(dbn, 10)

    def summary_row(ctype, key, name, project, owner, site, updated, own_tables, obj_ids, pub=None, emb_name='',
                    extra_db_ids=()):
        up, down = counts(key)
        conn, lin_db = conn_summary(obj_ids, own_tables, extra_db_ids)
        flow_keys = g.of_type(up, 'flow')
        vc_keys = g.of_type(up, 'vc')
        phys = [tid for tid in own_tables if not tinfo(tid)['is_custom_sql']]
        row = OrderedDict([
            ('Content ID', key[1]), ('Content Name', name), ('Content Type', ctype), ('Project Name', project),
            ('Owner Name', owner), ('Site Name', site), ('Last Modified', updated),
        ])
        row.update(conn)
        row.update(OrderedDict([
            ('Upstream Assets Count', len(up)), ('Downstream Assets Count', len(down)),
            ('Published Datasource Name', _join(g.attr(k, 'name') for k in (pub or []))),
            ('Published Datasource ID', _join(k[1] for k in (pub or []))),
            ('Embedded Datasource Name', emb_name),
            ('Flow Name', g.names(flow_keys, 'flow')), ('Flow ID', _join(k[1] for k in flow_keys)),
            ('Virtual Connection Name', g.names(vc_keys, 'vc')), ('Lineage Database Name', lin_db),
            ('Table Count', len(set(phys))),
            ('Custom SQL Count', len([1 for tid in own_tables if tinfo(tid)['is_custom_sql']])),
            ('Downstream Workbooks', len(g.of_type(down, 'wb'))),
            ('Downstream Datasources', len(g.of_type(down, 'ds')) + len(g.of_type(down, 'emb'))),
            ('Downstream Flows', len(g.of_type(down, 'flow'))),
        ]))
        summary.append(row)

        # Tables Used: every table this object references - resolved published/embedded-datasource tables,
        # direct/leftover tables, AND every table found by parsing its Custom SQL (whether or not that table
        # also exists as a normal Metadata API table) - nothing capped, matching Deep Analysis's Tables Used tab.
        uniq = list(dict.fromkeys(own_tables))
        tables_used.append(OrderedDict([
            ('Content ID', key[1]), ('Content Name', name), ('Content Type', ctype), ('Project Name', project),
            ('Connection Type', conn.get('Connection Type', '')), ('Server Name', conn.get('Server Name', '')),
            ('Database Name', conn.get('Database Name', '') or lin_db),
            ('Table Count', len(uniq)),
            ('Custom SQL Table Count', len([tid for tid in uniq if tid in via_sql_by_owner.get(key, ())])),
            ('Tables Used', _join(fqn(tinfo(tid)) for tid in uniq)),
        ]))

    for wk, info in wb_info.items():
        if not in_scope('wb', wk[1]):
            continue
        nd = g.nodes[wk]
        own = list(dict.fromkeys(
            [t for pk in info['published'] for t in ds_tables.get(pk, [])]
            # ... plus tables that published datasource only reaches through ITS OWN custom SQL
            + [t for pk in info['published'] for t in via_sql_by_owner.get(pk, ())]
            + [t for ek in info['embedded'] for t in emb_info[ek]['tables']] + info['leftover']))
        own += sorted(via_sql_by_owner.get(wk, ()))       # every SQL-referenced table, not just the parsed-only ones
        summary_row('Workbook', wk, nd.get('name', ''), nd.get('project', ''), nd.get('owner', ''), nd.get('site', ''),
                    nd.get('updated', ''), own, [wk[1]] + [k[1] for k in info['published']], info['published'],
                    _join(emb_info[e]['name'] for e in info['embedded']))
    for dk in [k for k in g.nodes if k[0] == 'ds' and k in ds_tables and in_scope('ds', k[1])]:
        nd = g.nodes[dk]
        own = ds_tables.get(dk, []) + sorted(via_sql_by_owner.get(dk, ()))
        summary_row('Datasource', dk, nd.get('name', ''), nd.get('project', ''), nd.get('owner', ''), nd.get('site', ''),
                    nd.get('updated', ''), own, [dk[1]])
    for ek, einfo in emb_info.items():
        wk = einfo['workbook']
        if not in_scope('wb', wk[1]):
            continue
        wn = g.nodes[wk]
        summary_row('Embedded Datasource', ek, einfo['name'], wn.get('project', ''), wn.get('owner', ''),
                    wn.get('site', ''), wn.get('updated', ''), einfo['tables'], [wk[1]], None, einfo['name'])
    for fk in [k for k in g.nodes if k[0] == 'flow' and k in flow_direct and in_scope('flow', k[1])]:
        nd = g.nodes[fk]
        own = flow_direct.get(fk, [])
        summary_row('Flow', fk, nd.get('name', ''), nd.get('project', ''), nd.get('owner', ''), nd.get('site', ''),
                    nd.get('updated', ''), own, [])
    for vk in [k for k in g.nodes if k[0] == 'vc' and k in vc_direct]:
        nd = g.nodes[vk]
        db_ids = [k[1] for k in g.up.get(vk, ()) if k[0] == 'db']
        summary_row('Virtual Connection', vk, nd.get('name', ''), nd.get('project', ''), nd.get('owner', ''),
                    nd.get('site', ''), nd.get('updated', ''), vc_direct.get(vk, []), [], None, '', db_ids)

    stats = {
        'workbooks': len(wb_info), 'published_datasources': len(ds_tables), 'flows': len(flow_direct),
        'virtual_connections': len(vc_direct), 'databases': len(dbs), 'tables': len(tables),
        'edges': sum(len(v) for v in g.down.values()),
    }
    logger.info(f"Lineage graph built: {stats}")
    return {
        'lineage_summary': summary,
        'lineage_tables_used': tables_used,
        'lineage_workbooks': wb_rows,
        'lineage_datasources': ds_rows,
        'lineage_flows': flow_rows,
        'lineage_custom_sql': csql_rows,
        'lineage_table_matrix': matrix_rows,
        'lineage_impact': impact_rows,
        'lineage_stats': stats,
    }

"""
Large-scale export helpers.

Designed so that exporting a huge Tableau site never fails because of Excel limits or memory:

* Rows are streamed to disk (openpyxl write-only mode) instead of building DataFrames/styled cells in RAM.
* A sheet is never larger than Excel's row limit - bigger datasets are split into "Name", "Name_2", ...
* Output is bucketed: everything fits in one .xlsx when small, otherwise a .zip of several .xlsx
  files (each holding at most MAX_ROWS_PER_FILE rows). A CSV zip is available as an alternative.
* Every cell value is sanitised (illegal XML characters removed, >32k characters truncated,
  lists/dicts/NaN converted) so a single odd value cannot abort the whole download.
"""

import csv
import json
import math
import os
import re
import tempfile
import zipfile
from array import array
from datetime import date, datetime
from itertools import islice

from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

# Excel allows 1,048,576 rows per sheet (header included) - stay safely below.
MAX_SHEET_ROWS = 1_000_000
# Rows (all sheets combined) written to a single workbook before a new file is started.
MAX_ROWS_PER_FILE = 1_000_000
# Excel allows 32,767 characters per cell.
MAX_CELL_CHARS = 32_000
# Rows sampled to size columns.
WIDTH_SAMPLE_ROWS = 500
MAX_COL_WIDTH = 50

_ILLEGAL_XML_CHARS = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]')
_INVALID_SHEET_CHARS = re.compile(r'[\[\]:*?/\\]')
_INVALID_FILE_CHARS = re.compile(r'[^A-Za-z0-9._-]+')


def clean_cell(value):
    """Return a value that is always safe to write into an Excel/CSV cell."""
    if value is None:
        return ''
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
            return ''
        return value
    if isinstance(value, (datetime, date)):
        try:
            # openpyxl cannot store timezone-aware datetimes
            if isinstance(value, datetime) and value.tzinfo is not None:
                value = value.replace(tzinfo=None)
            return value
        except Exception:
            return str(value)
    if isinstance(value, (list, tuple, set, frozenset)):
        try:
            if all(isinstance(v, (str, int, float)) or v is None for v in value):
                value = ', '.join('' if v is None else str(v) for v in value)
            else:
                value = json.dumps(list(value), default=str, ensure_ascii=False)
        except Exception:
            value = str(value)
    elif isinstance(value, dict):
        try:
            value = json.dumps(value, default=str, ensure_ascii=False)
        except Exception:
            value = str(value)
    elif not isinstance(value, str):
        try:
            value = str(value)
        except Exception:
            return ''

    value = _ILLEGAL_XML_CHARS.sub('', value)
    if len(value) > MAX_CELL_CHARS:
        value = value[:MAX_CELL_CHARS] + '... [truncated]'
    return value


def clean_sheet_name(name, used=None):
    """Valid, unique (case-insensitive) sheet name of at most 31 characters."""
    base = _INVALID_SHEET_CHARS.sub('_', str(name)).strip("' ") or 'Sheet'
    base = base[:31]
    if used is None:
        return base
    candidate, n = base, 1
    while candidate.lower() in used:
        n += 1
        suffix = f'_{n}'
        candidate = base[:31 - len(suffix)] + suffix
    used.add(candidate.lower())
    return candidate


def _safe_filename(name):
    return _INVALID_FILE_CHARS.sub('_', str(name)).strip('._') or 'export'


def _collect_columns(rows):
    """Ordered union of the keys of all records (records may have different keys)."""
    declared = getattr(rows, 'columns', None)
    if declared:
        return list(declared)
    seen = {}
    for row in rows:
        if isinstance(row, dict):
            for key in row:
                if key not in seen:
                    seen[key] = None
    return list(seen)


def _row_values(row, columns):
    if isinstance(row, dict):
        return [clean_cell(row.get(c)) for c in columns]
    return [clean_cell(row)]


def _column_widths(rows, columns):
    widths = [min(len(str(c)) + 2, MAX_COL_WIDTH) for c in columns]
    for row in rows[:WIDTH_SAMPLE_ROWS]:
        if not isinstance(row, dict):
            continue
        for i, c in enumerate(columns):
            v = row.get(c)
            if v is None:
                continue
            try:
                length = len(v) if isinstance(v, str) else len(str(v))
            except Exception:
                continue
            if length + 2 > widths[i]:
                widths[i] = min(length + 2, MAX_COL_WIDTH)
    return widths


def _write_sheet(wb, title, rows, columns, widths=None):
    ws = wb.create_sheet(title=title)
    ws.freeze_panes = 'A2'
    if widths is None:
        widths = _column_widths(rows, columns)
    for i, w in enumerate(widths):
        ws.column_dimensions[get_column_letter(i + 1)].width = w

    header_fill = PatternFill(start_color='4F81BD', end_color='4F81BD', fill_type='solid')
    header_font = Font(color='FFFFFF', bold=True)
    header = []
    for c in columns or ['Value']:
        cell = WriteOnlyCell(ws, value=clean_cell(c))
        cell.fill = header_fill
        cell.font = header_font
        header.append(cell)
    ws.append(header)

    for row in rows:
        ws.append(_row_values(row, columns) if columns else [clean_cell(row)])
    return ws


class SpooledRows:
    """
    Append-only, disk-backed list of dict rows (one JSON document per line).

    Lets an analysis of thousands of workbooks keep only the current workbook in memory: rows are appended as
    they are produced and later read back lazily - by the UI (paging / search) and by build_export (Excel / CSV /
    JSON) - without ever loading the whole dataset. Supports len(), iteration and slicing (slices are lazy views),
    so it can be passed to build_export() like a list. Rows must be appended from a single thread.
    """

    def __init__(self, path, columns=None):
        self.path = path
        self.columns = list(columns) if columns else None
        self._offsets = array('Q')
        self._pos = 0
        self._fh = open(path, 'wb')

    def append_many(self, rows):
        fh = self._fh
        for row in rows:
            data = (json.dumps(row, ensure_ascii=False, default=str) + '\n').encode('utf-8')
            self._offsets.append(self._pos)
            fh.write(data)
            self._pos += len(data)

    def finalize(self):
        if self._fh is not None:
            self._fh.flush()
            self._fh.close()
            self._fh = None

    def close_and_delete(self):
        self.finalize()
        try:
            os.remove(self.path)
        except OSError:
            pass

    def __len__(self):
        return len(self._offsets)

    def _lines(self, start, stop):
        """Raw text lines [start, stop)."""
        start, stop = max(0, start), min(len(self._offsets), stop)
        if start >= stop:
            return
        if self._fh is not None:
            self._fh.flush()
        with open(self.path, 'rb') as fh:
            fh.seek(self._offsets[start])
            for _ in range(stop - start):
                yield fh.readline().decode('utf-8')

    def _rows(self, start, stop):
        for line in self._lines(start, stop):
            yield json.loads(line)

    def __iter__(self):
        return self._rows(0, len(self))

    def __getitem__(self, item):
        if isinstance(item, slice):
            a, b, step = item.indices(len(self))
            if step != 1:
                raise ValueError('SpooledRows supports contiguous slices only')
            return SpoolView(self, a, b)
        if item < 0:
            item += len(self)
        return next(self._rows(item, item + 1))

    def search(self, query='', start=0, stop=None, offset=0, limit=100):
        """(total matches, rows[offset:offset+limit]) for a case-insensitive substring match over each row."""
        stop = len(self) if stop is None else min(stop, len(self))
        query = (query or '').lower()
        if not query:
            total = max(0, stop - start)
            return total, list(self._rows(start + offset, min(stop, start + offset + limit)))
        total, out = 0, []
        for line in self._lines(start, stop):
            if query in line.lower():                      # cheap pre-filter on the raw line ...
                row = json.loads(line)
                # ... confirmed on the VALUES only (column names such as "Folder" must not match "lod")
                if any(query in str(v).lower() for v in row.values()):
                    if offset <= total < offset + limit:
                        out.append(row)
                    total += 1
        return total, out


class SpoolView:
    """Lazy contiguous slice of a SpooledRows."""

    def __init__(self, spool, start, stop):
        self.spool, self.start, self.stop = spool, start, max(start, stop)
        self.columns = spool.columns

    def __len__(self):
        return self.stop - self.start

    def __iter__(self):
        return self.spool._rows(self.start, self.stop)

    def __getitem__(self, item):
        if isinstance(item, slice):
            a, b, step = item.indices(len(self))
            if step != 1:
                raise ValueError('SpoolView supports contiguous slices only')
            return SpoolView(self.spool, self.start + a, self.start + b)
        if item < 0:
            item += len(self)
        return next(self.spool._rows(self.start + item, self.start + item + 1))


def write_json_export(datasets, prefix='export', out_dir=None):
    """Stream every dataset to one .json file: {"<dataset>": [rows...], ...}. Returns (path, name, mimetype)."""
    out_dir = out_dir or tempfile.gettempdir()
    fd, path = tempfile.mkstemp(suffix='.json', dir=out_dir)
    with os.fdopen(fd, 'w', encoding='utf-8') as fh:
        fh.write('{')
        first_ds = True
        for name, rows in datasets:
            if not first_ds:
                fh.write(',')
            first_ds = False
            fh.write(json.dumps(name, ensure_ascii=False) + ':[')
            first = True
            for row in rows:
                if not first:
                    fh.write(',')
                first = False
                fh.write(json.dumps(row, ensure_ascii=False, default=str))
            fh.write(']')
        fh.write('}')
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    return path, f'{_safe_filename(prefix)}_{stamp}.json', 'application/json'


class _Chunk:
    """One writable unit: a slice (<= MAX_SHEET_ROWS) of one dataset."""

    __slots__ = ('dataset', 'title', 'rows', 'columns', 'widths', 'part', 'parts')

    def __init__(self, dataset, title, rows, columns, widths, part, parts):
        self.dataset = dataset
        self.title = title
        self.rows = rows
        self.columns = columns
        self.widths = widths
        self.part = part
        self.parts = parts


def _plan_chunks(datasets):
    chunks = []
    per_sheet = MAX_SHEET_ROWS - 1  # room for the header row
    for name, rows in datasets:
        if not rows:
            continue
        columns = _collect_columns(rows)
        widths = _column_widths(rows, columns)
        parts = max(1, math.ceil(len(rows) / per_sheet))
        for p in range(parts):
            chunk_rows = rows[p * per_sheet:(p + 1) * per_sheet]
            title = name if p == 0 else f'{name[:27]}_p{p + 1}'
            chunks.append(_Chunk(name, title, chunk_rows, columns, widths, p + 1, parts))
    return chunks


def _pack_chunks(chunks):
    """Greedy bucketing of chunks into files of at most MAX_ROWS_PER_FILE rows."""
    files, current, current_rows = [], [], 0
    for chunk in chunks:
        n = len(chunk.rows)
        if current and current_rows + n > MAX_ROWS_PER_FILE:
            files.append(current)
            current, current_rows = [], 0
        current.append(chunk)
        current_rows += n
    if current:
        files.append(current)
    return files


def _summary_rows(datasets, file_map=None):
    rows = []
    for name, data in datasets:
        row = {'Dataset': name, 'Rows': len(data)}
        if file_map is not None:
            row['Location'] = file_map.get(name, '')
        rows.append(row)
    return rows


def _save_workbook(wb, path):
    wb.save(path)
    wb.close()


def build_export(datasets, prefix='tableau_metadata', fmt='xlsx', extra_summary=None, out_dir=None):
    """
    Build the download for `datasets` and return ``(path, download_name, mimetype)``.

    datasets       : list of (name, list_of_dict_records)
    fmt            : 'xlsx' (default) or 'csv'
    extra_summary  : optional list of {'Dataset':..,'Rows':..} style dicts appended to the Summary
    The caller owns the returned file and should delete it after sending.
    """
    out_dir = out_dir or tempfile.gettempdir()
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    prefix = _safe_filename(prefix)
    datasets = [(n, r) for n, r in datasets if r]

    if fmt == 'csv':
        return _build_csv_zip(datasets, prefix, stamp, out_dir, extra_summary)

    chunks = _plan_chunks(datasets)
    files = _pack_chunks(chunks)
    xlsx_mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

    # ---- single workbook -------------------------------------------------
    if len(files) <= 1:
        fd, path = tempfile.mkstemp(suffix='.xlsx', dir=out_dir)
        os.close(fd)
        wb = Workbook(write_only=True)
        used = set()
        summary = _summary_rows(datasets)
        if extra_summary:
            summary.extend(extra_summary)
        _write_sheet(wb, clean_sheet_name('Summary', used), summary,
                     _collect_columns(summary) or ['Dataset', 'Rows'])
        for chunk in (files[0] if files else []):
            _write_sheet(wb, clean_sheet_name(chunk.title, used), chunk.rows, chunk.columns, chunk.widths)
        _save_workbook(wb, path)
        return path, f'{prefix}_{stamp}.xlsx', xlsx_mime

    # ---- bucketed: several workbooks in a zip -----------------------------
    fd, zip_path = tempfile.mkstemp(suffix='.zip', dir=out_dir)
    os.close(fd)
    file_map = {}
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for idx, bucket in enumerate(files, start=1):
            names = []
            for chunk in bucket:
                if chunk.dataset not in names:
                    names.append(chunk.dataset)
            label = _safe_filename('+'.join(names))[:60]
            arcname = f'{prefix}_part{idx:02d}_{label}.xlsx'
            for n in names:
                file_map.setdefault(n, []).append(arcname)

            fd, tmp = tempfile.mkstemp(suffix='.xlsx', dir=out_dir)
            os.close(fd)
            try:
                wb = Workbook(write_only=True)
                used = set()
                for chunk in bucket:
                    _write_sheet(wb, clean_sheet_name(chunk.title, used), chunk.rows, chunk.columns, chunk.widths)
                _save_workbook(wb, tmp)
                zf.write(tmp, arcname)
            finally:
                try:
                    os.remove(tmp)
                except OSError:
                    pass

        # Summary workbook (index of what is where)
        fd, tmp = tempfile.mkstemp(suffix='.xlsx', dir=out_dir)
        os.close(fd)
        try:
            summary = _summary_rows(datasets, {k: '; '.join(v) for k, v in file_map.items()})
            if extra_summary:
                summary.extend(extra_summary)
            wb = Workbook(write_only=True)
            _write_sheet(wb, 'Summary', summary, _collect_columns(summary))
            _save_workbook(wb, tmp)
            zf.write(tmp, f'{prefix}_00_Summary.xlsx')
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass

    return zip_path, f'{prefix}_{stamp}.zip', 'application/zip'


def _build_csv_zip(datasets, prefix, stamp, out_dir, extra_summary=None):
    fd, zip_path = tempfile.mkstemp(suffix='.zip', dir=out_dir)
    os.close(fd)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        summary = _summary_rows(datasets)
        if extra_summary:
            summary.extend(extra_summary)
        for name, rows in [('Summary', summary)] + list(datasets):
            columns = _collect_columns(rows)
            fd, tmp = tempfile.mkstemp(suffix='.csv', dir=out_dir)
            os.close(fd)
            try:
                with open(tmp, 'w', newline='', encoding='utf-8-sig') as fh:
                    writer = csv.writer(fh)
                    writer.writerow(columns)
                    for row in rows:
                        writer.writerow(_row_values(row, columns))
                zf.write(tmp, f'{_safe_filename(name)}.csv')
            finally:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    return zip_path, f'{prefix}_csv_{stamp}.zip', 'application/zip'

Tableau Metadata Extractor
==========================

A local web app for extracting Tableau Server/Cloud metadata, usage analytics,
lineage and workbook/flow analysis, and exporting it all to Excel.

Nothing here is uploaded anywhere except to your own Tableau Server/Cloud site -
this all runs on your own machine.

>>> First time running this? Read EXECUTION_GUIDE.txt instead of this file -
>>> it walks through install, first run, connecting to Tableau, and fixes for
>>> common problems. This README is just a quick reference.

See VERSION.txt for what's included in this build.


REQUIREMENTS
------------
- Python 3.9 or newer (get it from https://www.python.org/downloads/ - on
  Windows, tick "Add python.exe to PATH" during install)
- Internet access only to reach your own Tableau Server/Cloud


QUICK START
-----------
Windows:
    Double-click  run.bat

macOS / Linux:
    Open a terminal in this folder and run:
        chmod +x run.sh
        ./run.sh

Either script will:
  1. Create a private Python virtual environment in .venv (first run only)
  2. Install the required packages into it
  3. Start the app and open it in your browser at http://127.0.0.1:5001

To stop the app, close the terminal window (or press Ctrl+C in it).

Manual start (any OS), if you'd rather not use the scripts:
    python -m venv .venv
    .venv\Scripts\activate        (Windows)   OR   source .venv/bin/activate   (macOS/Linux)
    pip install -r requirements.txt
    python launcher.py


CONNECTING TO TABLEAU
----------------------
You'll need a Tableau Personal Access Token (PAT):
  Tableau Server/Cloud -> your profile menu -> My Account Settings ->
  Personal Access Tokens -> Create a new token.
Enter your server URL, site name, and the PAT name/secret on the app's home
screen to connect.


WHAT'S IN THIS FOLDER
----------------------
EXECUTION_GUIDE.txt     Full step-by-step run instructions + troubleshooting
VERSION.txt             What's included in this build
run.bat / run.sh        One-click / one-command launcher (Windows / macOS-Linux)
app.py                  Flask app: all routes, extraction, analytics
launcher.py             Starts the app and opens your browser
admin_insights_analyzer.py   Admin Insights (Tableau Cloud usage) analysis
export_utils.py         Streaming/bucketed Excel & CSV export (handles huge sites)
lineage_engine.py       Metadata API lineage graph + SQL parsing
workbook_analyzer.py    Single Workbook Analysis (.twb/.twbx/.tds/.tdsx/.tfl/.tflx)
templates/, static/     Web UI
requirements.txt        Python package list

This is everything needed to run the app - there is nothing else to
download or copy in. The only thing NOT bundled is Python itself
(see REQUIREMENTS above) and, on first run, the small set of Python
packages it installs automatically from the internet into .venv.


NOTES
-----
- On first launch, Windows may ask permission to let Python accept a network
  connection - that's just the local web server (127.0.0.1:5001); allow it.
- Extracted data and saved extractions are stored locally under this folder
  (or, if this is later packaged as an .exe, under your user AppData folder).

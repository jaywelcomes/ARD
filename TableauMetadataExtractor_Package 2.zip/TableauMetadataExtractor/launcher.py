#!/usr/bin/env python3
"""
Launcher for Tableau Metadata Extractor
This script starts the Flask server and opens the browser automatically.
"""

import sys
import os
import threading
import webbrowser
import time

# Add the application directory to path
if getattr(sys, 'frozen', False):
    # Running as compiled executable
    application_path = sys._MEIPASS
    os.chdir(os.path.dirname(sys.executable))
else:
    # Running as script
    application_path = os.path.dirname(os.path.abspath(__file__))

# Set environment for Flask
os.environ['FLASK_ENV'] = 'production'

def open_browser():
    """Open browser after a short delay"""
    time.sleep(2)  # Wait for server to start
    webbrowser.open('http://127.0.0.1:5001')

def main():
    print("="*50)
    print("Tableau Metadata Extractor")
    print("="*50)
    print("\nStarting server...")
    print("The application will open in your browser shortly.")
    print("If it doesn't open automatically, go to: http://127.0.0.1:5001")
    print("\nPress Ctrl+C to stop the server.\n")

    # Start browser opener in background
    browser_thread = threading.Thread(target=open_browser, daemon=True)
    browser_thread.start()

    # Import and run the Flask app
    try:
        from app import app
        app.run(host='127.0.0.1', port=5001, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\nShutting down...")
    except Exception as e:
        print(f"\nError: {e}")
        input("Press Enter to exit...")

if __name__ == '__main__':
    main()

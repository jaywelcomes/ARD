#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found. Install it from https://www.python.org/downloads/ and try again."
    exit 1
fi

if [ ! -f ".venv/bin/python" ]; then
    echo "Setting up a private Python environment - this happens once..."
    python3 -m venv .venv
    ".venv/bin/python" -m pip install --upgrade pip
    ".venv/bin/python" -m pip install -r requirements.txt
fi

echo "Starting Tableau Metadata Extractor..."
".venv/bin/python" launcher.py

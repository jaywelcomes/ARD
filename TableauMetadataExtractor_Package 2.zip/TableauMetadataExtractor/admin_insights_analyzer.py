"""
Admin Insights Analyzer - Comprehensive Tableau Cloud Governance Analytics

This module processes Admin Insights CSV exports from Tableau Cloud and computes
governance metrics, criticality scores, and tier classifications.

Supported CSV Files:
- Site_Content.csv (Central fact table)
- TS_Events.csv (Usage activity)
- TS_Users.csv (User information)
- Subscriptions.csv (Subscription signals)
- Permissions.csv (Access distribution)
- Groups.csv (Group membership)
- Viz_Load_Times.csv (Performance metrics)
- Job_Performance.csv (Extract health)
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from io import BytesIO
import logging
import re

logger = logging.getLogger(__name__)


def sanitize_dataframe_for_excel(df):
    """
    Sanitize a DataFrame for safe Excel export.
    - Replaces NaN with empty string in object/string columns
    - Keeps numeric columns numeric but replaces NaN with empty string for display
    - Handles mixed types safely
    """
    if df is None or df.empty:
        return df

    df = df.copy()

    for col in df.columns:
        # Check if column is numeric (int, float)
        if pd.api.types.is_numeric_dtype(df[col]):
            # For numeric columns, fillna with empty string for display
            df[col] = df[col].apply(lambda x: '' if pd.isna(x) else x)
        elif pd.api.types.is_datetime64_any_dtype(df[col]):
            # For datetime columns, convert NaT to empty string
            df[col] = df[col].apply(lambda x: '' if pd.isna(x) else x)
        else:
            # For object/string columns, replace NaN with empty string
            df[col] = df[col].fillna('')
            # Also handle any remaining float NaN that slipped through
            df[col] = df[col].apply(lambda x: '' if isinstance(x, float) and pd.isna(x) else x)

    return df


class AdminInsightsAnalyzer:
    """
    Analyzes Tableau Cloud Admin Insights CSV exports for comprehensive
    governance metrics and criticality scoring.
    """

    # CSV type constants
    CSV_TYPES = [
        'site_content',
        'ts_events',
        'ts_users',
        'subscriptions',
        'permissions',
        'groups',
        'viz_load_times',
        'job_performance'
    ]

    def __init__(self):
        # DataFrames for each CSV type
        self.site_content_df = None
        self.ts_events_df = None
        self.ts_users_df = None
        self.subscriptions_df = None
        self.permissions_df = None
        self.groups_df = None
        self.viz_load_times_df = None
        self.job_performance_df = None

        # Computed results
        self.content_master = None
        self.workbook_governance = None
        self.datasource_governance = None
        self.flow_governance = None
        self.user_analytics = None
        self.governance_summary = None
        self.users_kpi = {}
        self.license_summary = {}

        # Metadata
        self.date_ranges = {}
        self.parse_info = {}
        self.upload_status = {t: False for t in self.CSV_TYPES}

    def _normalize_column_name(self, col):
        """Normalize column name for matching"""
        if pd.isna(col):
            return ''
        return re.sub(r'[^a-z0-9]', '_', str(col).lower().strip()).strip('_')

    def _normalize_columns(self, df):
        """Normalize all column names in a DataFrame"""
        df.columns = [self._normalize_column_name(c) for c in df.columns]
        return df

    def _find_column(self, df, patterns):
        """Find column matching any of the patterns"""
        cols_normalized = {self._normalize_column_name(c): c for c in df.columns}
        for pattern in patterns:
            pattern_norm = self._normalize_column_name(pattern)
            if pattern_norm in cols_normalized:
                return cols_normalized[pattern_norm]
            for norm, orig in cols_normalized.items():
                if pattern_norm in norm or norm in pattern_norm:
                    return orig
        return None

    def _detect_encoding(self, file_content):
        """Detect file encoding"""
        if file_content[:2] == b'\xff\xfe' or file_content[:2] == b'\xfe\xff':
            return 'utf-16'
        try:
            file_content.decode('utf-8')
            return 'utf-8'
        except:
            return 'latin-1'

    def _read_csv(self, file_content):
        """Read CSV with auto-detection of encoding and delimiter"""
        encoding = self._detect_encoding(file_content)

        # Try comma first, then tab
        try:
            df = pd.read_csv(BytesIO(file_content), encoding=encoding)
            if len(df.columns) < 3:
                df = pd.read_csv(BytesIO(file_content), encoding=encoding, sep='\t')
        except:
            try:
                df = pd.read_csv(BytesIO(file_content), encoding=encoding, sep='\t')
            except:
                df = pd.read_csv(BytesIO(file_content), encoding='latin-1')

        return df

    def _parse_date(self, date_val):
        """Parse various date formats"""
        if pd.isna(date_val) or date_val == '' or date_val is None:
            return pd.NaT
        try:
            return pd.to_datetime(date_val, errors='coerce')
        except:
            return pd.NaT

    # ==================== CSV Loading Methods ====================

    def load_site_content(self, file_content):
        """Load Site_Content.csv - Central fact table"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded Site_Content with {len(df)} rows")

            # Normalize columns
            df = self._normalize_columns(df)

            # Log columns and item types for debugging
            logger.info(f"AdminInsights: Site_Content columns: {list(df.columns)}")

            # Check for item_type/content_type column
            type_col = None
            for col in ['item_type', 'content_type', 'type']:
                if col in df.columns:
                    type_col = col
                    break

            if type_col:
                type_values = df[type_col].value_counts().to_dict()
                logger.info(f"AdminInsights: Site_Content {type_col} values: {type_values}")

            # Store original column mapping for reference
            self.parse_info['site_content'] = {
                'columns': list(df.columns),
                'rows': len(df)
            }

            self.site_content_df = df
            self.upload_status['site_content'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading Site_Content: {str(e)}")
            return False

    def load_ts_events(self, file_content):
        """Load TS_Events.csv - Usage activity events"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded TS_Events with {len(df)} rows")

            df = self._normalize_columns(df)

            # Parse event dates
            date_col = None
            for col in ['event_date', 'event_date_local']:
                if col in df.columns:
                    date_col = col
                    break

            if date_col:
                df['_event_date'] = pd.to_datetime(df[date_col], errors='coerce')
                valid_dates = df['_event_date'].dropna()
                if len(valid_dates) > 0:
                    self.date_ranges['ts_events'] = {
                        'min': valid_dates.min().isoformat(),
                        'max': valid_dates.max().isoformat()
                    }

            self.parse_info['ts_events'] = {
                'columns': list(df.columns),
                'rows': len(df),
                'date_range': self.date_ranges.get('ts_events', {})
            }

            self.ts_events_df = df
            self.upload_status['ts_events'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading TS_Events: {str(e)}")
            return False

    def load_ts_users(self, file_content):
        """Load TS_Users.csv - User information"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded TS_Users with {len(df)} rows")

            df = self._normalize_columns(df)

            self.parse_info['ts_users'] = {
                'columns': list(df.columns),
                'rows': len(df)
            }

            self.ts_users_df = df
            self.upload_status['ts_users'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading TS_Users: {str(e)}")
            return False

    def load_subscriptions(self, file_content):
        """Load Subscriptions.csv"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded Subscriptions with {len(df)} rows")

            df = self._normalize_columns(df)

            self.parse_info['subscriptions'] = {
                'columns': list(df.columns),
                'rows': len(df)
            }

            self.subscriptions_df = df
            self.upload_status['subscriptions'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading Subscriptions: {str(e)}")
            return False

    def load_permissions(self, file_content):
        """Load Permissions.csv"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded Permissions with {len(df)} rows")

            df = self._normalize_columns(df)

            self.parse_info['permissions'] = {
                'columns': list(df.columns),
                'rows': len(df)
            }

            self.permissions_df = df
            self.upload_status['permissions'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading Permissions: {str(e)}")
            return False

    def load_groups(self, file_content):
        """Load Groups.csv"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded Groups with {len(df)} rows")

            df = self._normalize_columns(df)

            self.parse_info['groups'] = {
                'columns': list(df.columns),
                'rows': len(df)
            }

            self.groups_df = df
            self.upload_status['groups'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading Groups: {str(e)}")
            return False

    def load_viz_load_times(self, file_content):
        """Load Viz_Load_Times.csv"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded Viz_Load_Times with {len(df)} rows")

            df = self._normalize_columns(df)

            self.parse_info['viz_load_times'] = {
                'columns': list(df.columns),
                'rows': len(df)
            }

            self.viz_load_times_df = df
            self.upload_status['viz_load_times'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading Viz_Load_Times: {str(e)}")
            return False

    def load_job_performance(self, file_content):
        """Load Job_Performance.csv"""
        try:
            df = self._read_csv(file_content)
            logger.info(f"AdminInsights: Loaded Job_Performance with {len(df)} rows")

            df = self._normalize_columns(df)

            self.parse_info['job_performance'] = {
                'columns': list(df.columns),
                'rows': len(df)
            }

            self.job_performance_df = df
            self.upload_status['job_performance'] = True
            return True

        except Exception as e:
            logger.error(f"Error loading Job_Performance: {str(e)}")
            return False

    # ==================== Data Processing Methods ====================

    def _get_column_safe(self, df, possible_names, default=None):
        """Get column value safely, trying multiple possible column names"""
        for name in possible_names:
            norm_name = self._normalize_column_name(name)
            if norm_name in df.columns:
                return df[norm_name]
        return pd.Series([default] * len(df), index=df.index) if default is not None else None

    def build_content_master(self):
        """Build the master content table with all joined metrics"""
        if self.site_content_df is None:
            raise ValueError("Site_Content.csv is required")

        today = pd.Timestamp.now()
        date_30 = today - pd.Timedelta(days=30)
        date_90 = today - pd.Timedelta(days=90)
        date_120 = today - pd.Timedelta(days=120)

        # Start with site content as base
        df = self.site_content_df.copy()

        # Identify the LUID column
        luid_col = None
        for col in ['item_luid', 'luid', 'item_id']:
            if col in df.columns:
                luid_col = col
                break

        if luid_col is None:
            # Create a synthetic key
            df['content_luid'] = df.index.astype(str)
            luid_col = 'content_luid'
        else:
            df['content_luid'] = df[luid_col].astype(str)

        # Extract item type
        type_col = None
        for col in ['item_type', 'content_type', 'type']:
            if col in df.columns:
                type_col = col
                logger.info(f"AdminInsights: Found type column: '{col}'")
                break

        if type_col:
            df['content_type'] = df[type_col].astype(str)
            # Log unique content types immediately after extraction
            unique_types = df['content_type'].unique().tolist()
            type_counts = df['content_type'].value_counts().to_dict()
            logger.info(f"AdminInsights: Extracted content types: {type_counts}")
            logger.info(f"AdminInsights: Unique content type values: {unique_types}")
        else:
            df['content_type'] = 'Unknown'
            logger.warning(f"AdminInsights: No type column found. Available columns: {list(df.columns)}")

        # Extract item name
        name_col = None
        for col in ['item_name', 'name', 'content_name']:
            if col in df.columns:
                name_col = col
                break

        if name_col:
            df['content_name'] = df[name_col].astype(str)
        else:
            df['content_name'] = 'Unknown'

        # Extract project name
        project_col = None
        for col in ['item_parent_project_name', 'project_name', 'parent_project_name', 'project']:
            if col in df.columns:
                project_col = col
                break

        if project_col:
            df['project_name'] = df[project_col].fillna('Unknown').astype(str)
        else:
            df['project_name'] = 'Unknown'

        # Extract owner
        owner_col = None
        for col in ['owner_email', 'item_owner_email', 'owner']:
            if col in df.columns:
                owner_col = col
                break

        if owner_col:
            df['owner_email'] = df[owner_col].fillna('Unknown').astype(str)
        else:
            df['owner_email'] = 'Unknown'

        # Extract size - handle various normalized column name patterns
        size_col = None
        for col in ['size_mb', 'size__mb', 'size__mb_', 'total_size_mb', 'total_size__mb', 'total_size__mb_']:
            if col in df.columns:
                size_col = col
                break

        if size_col:
            df['size_mb'] = pd.to_numeric(df[size_col], errors='coerce').fillna(0)
        else:
            df['size_mb'] = 0

        # Extract dates
        for date_field, possible_cols in [
            ('created_at', ['created_at', 'created_at_local']),
            ('updated_at', ['updated_at', 'updated_at_local']),
            ('last_accessed_at', ['last_accessed_at', 'last_accessed_at_local']),
            ('last_published_at', ['last_published_at', 'last_published_at_local'])
        ]:
            col_found = None
            for col in possible_cols:
                if col in df.columns:
                    col_found = col
                    break
            if col_found:
                df[date_field] = pd.to_datetime(df[col_found], errors='coerce')
            else:
                df[date_field] = pd.NaT

        # Fallback: If last_accessed_at is empty, use last_published_at or updated_at
        if df['last_accessed_at'].isna().all():
            if 'last_published_at' in df.columns and not df['last_published_at'].isna().all():
                df['last_accessed_at'] = df['last_published_at']
                logger.info("AdminInsights: Using last_published_at as fallback for last_accessed_at")
            elif not df['updated_at'].isna().all():
                df['last_accessed_at'] = df['updated_at']
                logger.info("AdminInsights: Using updated_at as fallback for last_accessed_at")

        # Extract is_data_extract (Live vs Extract)
        extract_col = None
        for col in ['is_data_extract', 'is_extract', 'has_extract']:
            if col in df.columns:
                extract_col = col
                break
        if extract_col:
            df['is_data_extract'] = df[extract_col].fillna(False).astype(str).str.lower().isin(['true', '1', 'yes'])
        else:
            df['is_data_extract'] = False

        # Extract has_refresh_scheduled
        refresh_col = None
        for col in ['has_refresh_scheduled', 'has_refresh_schedule']:
            if col in df.columns:
                refresh_col = col
                break
        if refresh_col:
            df['has_refresh_schedule'] = df[refresh_col].fillna(False).astype(str).str.lower().isin(['true', '1', 'yes'])
        else:
            df['has_refresh_schedule'] = False

        # Extract extracts_refreshed_at for last modified
        refresh_date_col = None
        for col in ['extracts_refreshed_at', 'extracts_refreshed_at__local']:
            if col in df.columns:
                refresh_date_col = col
                break
        if refresh_date_col:
            df['extracts_refreshed_at'] = pd.to_datetime(df[refresh_date_col], errors='coerce')
        else:
            df['extracts_refreshed_at'] = pd.NaT

        # Extract database type
        db_type_col = None
        for col in ['data_source_database_type', 'database_type']:
            if col in df.columns:
                db_type_col = col
                break
        if db_type_col:
            df['database_type'] = df[db_type_col].fillna('Unknown').astype(str)
        else:
            df['database_type'] = 'Unknown'

        # ==================== Join TS_Events for usage metrics ====================
        # Logic:
        # 1. Convert event_date to datetime
        # 2. Filter events within the last 30 days
        # 3. Only include event types: ViewAccessed, WorkbookOpened
        # 4. Group by item_luid
        # 5. Compute: views_30d, unique_users (distinct actor_user_luid), last_accessed (max event_date)
        # 6. Join to Site_Content using TS_Events.item_luid = Site_Content.luid

        if self.ts_events_df is not None and len(self.ts_events_df) > 0:
            events = self.ts_events_df.copy()
            logger.info(f"AdminInsights: Processing {len(events)} total events")

            # Step 1: Convert event_date to datetime
            event_date_col = None
            for col in ['event_date', 'event_date_local', '_event_date']:
                if col in events.columns:
                    event_date_col = col
                    break

            if event_date_col:
                events['event_date_parsed'] = pd.to_datetime(events[event_date_col], errors='coerce')
            else:
                logger.warning("AdminInsights: No event_date column found in TS_Events")
                events['event_date_parsed'] = pd.NaT

            # Step 2: Filter events within the last 30 days
            events_30d = events[events['event_date_parsed'] >= date_30].copy()
            logger.info(f"AdminInsights: Events in last 30 days: {len(events_30d)}")

            # Step 3: Only include event types: ViewAccessed, WorkbookOpened
            event_name_col = None
            for col in ['event_name', 'event_type']:
                if col in events_30d.columns:
                    event_name_col = col
                    break

            if event_name_col:
                # Log available event types
                event_types = events_30d[event_name_col].value_counts().to_dict()
                logger.info(f"AdminInsights: Event types in last 30 days: {event_types}")

                # Filter to ViewAccessed only (case-insensitive)
                # Views (30D) = count(event_type = ViewAccessed)
                events_30d = events_30d[
                    events_30d[event_name_col].str.lower().str.strip().isin([
                        'viewaccessed', 'view accessed', 'access view'
                    ])
                ].copy()
                logger.info(f"AdminInsights: Events after filtering to ViewAccessed: {len(events_30d)}")

            # Step 4: Get item_luid column
            item_luid_col = None
            for col in ['item_luid', 'luid', 'item_id']:
                if col in events_30d.columns:
                    item_luid_col = col
                    break

            # Get actor_user_luid column
            actor_col = None
            for col in ['actor_user_luid', 'actor_user_id', 'user_luid', 'user_id']:
                if col in events_30d.columns:
                    actor_col = col
                    break

            logger.info(f"AdminInsights: Using item_luid column: {item_luid_col}, actor column: {actor_col}")

            if item_luid_col and len(events_30d) > 0:
                # Filter to events with valid item_luid
                events_30d = events_30d[
                    events_30d[item_luid_col].notna() &
                    (events_30d[item_luid_col].astype(str).str.strip() != '')
                ].copy()
                events_30d['_item_luid'] = events_30d[item_luid_col].astype(str).str.strip()
                logger.info(f"AdminInsights: Events with valid item_luid: {len(events_30d)}")

                # Step 5: Group by item_luid and compute metrics
                # views_30d = count of events
                views_agg = events_30d.groupby('_item_luid').size().reset_index(name='views_30d')

                # unique_users = distinct actor_user_luid
                if actor_col:
                    users_agg = events_30d.groupby('_item_luid')[actor_col].nunique().reset_index(name='unique_users_30d')
                else:
                    users_agg = pd.DataFrame({'_item_luid': views_agg['_item_luid'], 'unique_users_30d': 0})

                # last_accessed = max(event_date)
                last_access_agg = events_30d.groupby('_item_luid')['event_date_parsed'].max().reset_index(name='last_accessed_from_events')

                # Merge aggregations
                event_metrics = views_agg.merge(users_agg, on='_item_luid', how='left')
                event_metrics = event_metrics.merge(last_access_agg, on='_item_luid', how='left')

                logger.info(f"AdminInsights: Computed metrics for {len(event_metrics)} unique items")
                logger.info(f"AdminInsights: Total views_30d: {event_metrics['views_30d'].sum()}, Total unique_users: {event_metrics['unique_users_30d'].sum()}")

                # Step 6: Join to Site_Content using TS_Events.item_luid = Site_Content.luid
                # content_luid was extracted earlier from Site_Content.luid
                df = df.merge(event_metrics, left_on='content_luid', right_on='_item_luid', how='left')

                # Fill NaN values with 0
                df['views_30d'] = df['views_30d'].fillna(0).astype(int)
                df['unique_users_30d'] = df['unique_users_30d'].fillna(0).astype(int)

                # Update last_accessed_at from events if available
                if 'last_accessed_from_events' in df.columns:
                    mask = df['last_accessed_at'].isna() & df['last_accessed_from_events'].notna()
                    df.loc[mask, 'last_accessed_at'] = df.loc[mask, 'last_accessed_from_events']
                    # Also update where events have more recent date
                    mask2 = df['last_accessed_from_events'].notna() & (df['last_accessed_from_events'] > df['last_accessed_at'])
                    df.loc[mask2, 'last_accessed_at'] = df.loc[mask2, 'last_accessed_from_events']

                # Log final results
                items_with_views = (df['views_30d'] > 0).sum()
                logger.info(f"AdminInsights: After join - {items_with_views} items have views, total views: {df['views_30d'].sum()}")

                # ==================== Aggregate View metrics to parent Workbooks ====================
                # Access View events have item_luid pointing to Views, not Workbooks
                # We need to aggregate Views' metrics to their parent Workbooks using view_workbook_name

                # Check if we have view_workbook_name column
                view_wb_col = None
                for col in ['view_workbook_name', 'workbook_name']:
                    if col in df.columns:
                        view_wb_col = col
                        break

                if view_wb_col:
                    # Get Views with their metrics
                    views_df = df[df['content_type'].str.lower() == 'view'].copy()
                    views_with_metrics = views_df[views_df['views_30d'] > 0]

                    if len(views_with_metrics) > 0:
                        logger.info(f"AdminInsights: Aggregating metrics from {len(views_with_metrics)} Views to parent Workbooks")

                        # Aggregate views and users by parent workbook name
                        wb_views = views_df.groupby(view_wb_col).agg({
                            'views_30d': 'sum',
                            'unique_users_30d': 'max',  # Use max since same users view same workbook
                            'last_accessed_at': 'max'
                        }).reset_index()
                        wb_views.columns = [view_wb_col, 'wb_views_30d', 'wb_users_30d', 'wb_last_accessed']

                        logger.info(f"AdminInsights: Aggregated to {len(wb_views)} workbooks: {wb_views[[view_wb_col, 'wb_views_30d', 'wb_users_30d']].to_dict('records')}")

                        # Join aggregated metrics to Workbooks by name
                        df = df.merge(wb_views, left_on='content_name', right_on=view_wb_col, how='left', suffixes=('', '_agg'))

                        # For Workbooks, update metrics from aggregated View data
                        workbook_mask = df['content_type'].str.lower() == 'workbook'

                        # Update views_30d for workbooks
                        df.loc[workbook_mask & df['wb_views_30d'].notna(), 'views_30d'] = df.loc[workbook_mask & df['wb_views_30d'].notna(), 'wb_views_30d'].astype(int)

                        # Update unique_users_30d for workbooks
                        df.loc[workbook_mask & df['wb_users_30d'].notna(), 'unique_users_30d'] = df.loc[workbook_mask & df['wb_users_30d'].notna(), 'wb_users_30d'].astype(int)

                        # Update last_accessed_at for workbooks
                        df.loc[workbook_mask & df['wb_last_accessed'].notna(), 'last_accessed_at'] = df.loc[workbook_mask & df['wb_last_accessed'].notna(), 'wb_last_accessed']

                        # Clean up temp columns
                        df = df.drop(columns=[c for c in df.columns if c.startswith('wb_') or c == view_wb_col + '_agg'], errors='ignore')

                        # Log updated workbook metrics
                        workbooks = df[df['content_type'].str.lower() == 'workbook']
                        logger.info(f"AdminInsights: After aggregation - Workbooks with views: {(workbooks['views_30d'] > 0).sum()}, total views: {workbooks['views_30d'].sum()}")
            else:
                logger.warning(f"AdminInsights: No valid item_luid column or no events after filtering")
                df['views_30d'] = 0
                df['unique_users_30d'] = 0
        else:
            df['views_30d'] = 0
            df['unique_users_30d'] = 0

        # Ensure views_90d exists (for backward compatibility)
        if 'views_90d' not in df.columns:
            df['views_90d'] = df['views_30d']

        # ==================== Process Datasource Events ====================
        # Filter events for "Download Data Source" and "Access Data Source"
        if self.ts_events_df is not None and len(self.ts_events_df) > 0:
            ds_events = self.ts_events_df.copy()
            logger.info(f"AdminInsights: Processing datasource events from {len(ds_events)} total events")

            # Convert event_date to datetime
            event_date_col = None
            for col in ['event_date', 'event_date_local', '_event_date']:
                if col in ds_events.columns:
                    event_date_col = col
                    break

            if event_date_col:
                ds_events['event_date_parsed'] = pd.to_datetime(ds_events[event_date_col], errors='coerce')

                # Filter events within the last 30 days
                ds_events_30d = ds_events[ds_events['event_date_parsed'] >= date_30].copy()

                # Find event_name column
                event_name_col = None
                for col in ['event_name', 'event_type']:
                    if col in ds_events_30d.columns:
                        event_name_col = col
                        break

                if event_name_col:
                    # Filter to datasource access events
                    ds_events_30d = ds_events_30d[
                        ds_events_30d[event_name_col].str.lower().str.strip().isin([
                            'download data source', 'access data source',
                            'downloaddatasource', 'accessdatasource'
                        ])
                    ].copy()
                    logger.info(f"AdminInsights: Datasource events (Download/Access) in last 30 days: {len(ds_events_30d)}")

                    if len(ds_events_30d) > 0:
                        # Get item_luid column
                        ds_item_col = None
                        for col in ['item_luid', 'luid', 'item_id']:
                            if col in ds_events_30d.columns:
                                ds_item_col = col
                                break

                        # Get actor column
                        ds_actor_col = None
                        for col in ['actor_user_luid', 'actor_user_id', 'user_luid', 'user_id']:
                            if col in ds_events_30d.columns:
                                ds_actor_col = col
                                break

                        if ds_item_col:
                            # Filter to valid item_luid
                            ds_events_30d = ds_events_30d[
                                ds_events_30d[ds_item_col].notna() &
                                (ds_events_30d[ds_item_col].astype(str).str.strip() != '')
                            ].copy()
                            ds_events_30d['_ds_item_luid'] = ds_events_30d[ds_item_col].astype(str).str.strip()

                            # Aggregate metrics
                            ds_views_agg = ds_events_30d.groupby('_ds_item_luid').size().reset_index(name='ds_views_30d')

                            if ds_actor_col:
                                ds_users_agg = ds_events_30d.groupby('_ds_item_luid')[ds_actor_col].nunique().reset_index(name='ds_unique_users_30d')
                            else:
                                ds_users_agg = pd.DataFrame({'_ds_item_luid': ds_views_agg['_ds_item_luid'], 'ds_unique_users_30d': 0})

                            ds_last_access_agg = ds_events_30d.groupby('_ds_item_luid')['event_date_parsed'].max().reset_index(name='ds_last_accessed')

                            # Merge aggregations
                            ds_event_metrics = ds_views_agg.merge(ds_users_agg, on='_ds_item_luid', how='left')
                            ds_event_metrics = ds_event_metrics.merge(ds_last_access_agg, on='_ds_item_luid', how='left')

                            logger.info(f"AdminInsights: Computed datasource metrics for {len(ds_event_metrics)} unique datasources")

                            # Join to content_master
                            df = df.merge(ds_event_metrics, left_on='content_luid', right_on='_ds_item_luid', how='left')

                            # Update datasource views and last_accessed
                            ds_mask = df['content_type'].str.lower().str.contains('data source|datasource', na=False)
                            df.loc[ds_mask & df['ds_views_30d'].notna(), 'views_30d'] = df.loc[ds_mask & df['ds_views_30d'].notna(), 'ds_views_30d'].astype(int)
                            df.loc[ds_mask & df['ds_unique_users_30d'].notna(), 'unique_users_30d'] = df.loc[ds_mask & df['ds_unique_users_30d'].notna(), 'ds_unique_users_30d'].astype(int)

                            # Update last_accessed_at from events for datasources
                            mask_ds_update = ds_mask & df['ds_last_accessed'].notna()
                            if mask_ds_update.any():
                                df.loc[mask_ds_update, 'last_accessed_at'] = df.loc[mask_ds_update, 'ds_last_accessed']

                            # Log results
                            datasources = df[ds_mask]
                            logger.info(f"AdminInsights: Datasources with views: {(datasources['views_30d'] > 0).sum()}, total views: {datasources['views_30d'].sum()}")

                            # Clean up temp columns
                            df = df.drop(columns=[c for c in df.columns if c.startswith('ds_') or c == '_ds_item_luid'], errors='ignore')

        # ==================== Process Flow Events ====================
        # Filter events for flow-related actions: "Run Flow", "Start Flow Run", etc.
        if self.ts_events_df is not None and len(self.ts_events_df) > 0:
            flow_events = self.ts_events_df.copy()
            logger.info(f"AdminInsights: Processing flow events from {len(flow_events)} total events")

            # Convert event_date to datetime
            event_date_col = None
            for col in ['event_date', 'event_date_local', '_event_date']:
                if col in flow_events.columns:
                    event_date_col = col
                    break

            if event_date_col:
                flow_events['event_date_parsed'] = pd.to_datetime(flow_events[event_date_col], errors='coerce')

                # Filter events within the last 30 days
                flow_events_30d = flow_events[flow_events['event_date_parsed'] >= date_30].copy()

                # Find event_name column
                event_name_col = None
                for col in ['event_name', 'event_type']:
                    if col in flow_events_30d.columns:
                        event_name_col = col
                        break

                if event_name_col:
                    # Log all event types to understand what flow events exist
                    all_events = flow_events_30d[event_name_col].str.lower().value_counts().to_dict()
                    flow_related = {k: v for k, v in all_events.items() if 'flow' in k.lower()}
                    logger.info(f"AdminInsights: Flow-related events found: {flow_related}")

                    # Filter to flow run events
                    flow_events_30d = flow_events_30d[
                        flow_events_30d[event_name_col].str.lower().str.contains('flow', na=False)
                    ].copy()
                    logger.info(f"AdminInsights: Flow events in last 30 days: {len(flow_events_30d)}")

                    if len(flow_events_30d) > 0:
                        # Get item_luid column
                        flow_item_col = None
                        for col in ['item_luid', 'luid', 'item_id']:
                            if col in flow_events_30d.columns:
                                flow_item_col = col
                                break

                        # Get actor column
                        flow_actor_col = None
                        for col in ['actor_user_luid', 'actor_user_id', 'user_luid', 'user_id']:
                            if col in flow_events_30d.columns:
                                flow_actor_col = col
                                break

                        if flow_item_col:
                            # Filter to valid item_luid
                            flow_events_30d = flow_events_30d[
                                flow_events_30d[flow_item_col].notna() &
                                (flow_events_30d[flow_item_col].astype(str).str.strip() != '')
                            ].copy()
                            flow_events_30d['_flow_item_luid'] = flow_events_30d[flow_item_col].astype(str).str.strip()

                            # Aggregate metrics
                            flow_runs_agg = flow_events_30d.groupby('_flow_item_luid').size().reset_index(name='flow_runs_30d')

                            if flow_actor_col:
                                flow_users_agg = flow_events_30d.groupby('_flow_item_luid')[flow_actor_col].nunique().reset_index(name='flow_unique_users_30d')
                            else:
                                flow_users_agg = pd.DataFrame({'_flow_item_luid': flow_runs_agg['_flow_item_luid'], 'flow_unique_users_30d': 0})

                            flow_last_run_agg = flow_events_30d.groupby('_flow_item_luid')['event_date_parsed'].max().reset_index(name='flow_last_run')

                            # Merge aggregations
                            flow_event_metrics = flow_runs_agg.merge(flow_users_agg, on='_flow_item_luid', how='left')
                            flow_event_metrics = flow_event_metrics.merge(flow_last_run_agg, on='_flow_item_luid', how='left')

                            logger.info(f"AdminInsights: Computed flow metrics for {len(flow_event_metrics)} unique flows")

                            # Join to content_master
                            df = df.merge(flow_event_metrics, left_on='content_luid', right_on='_flow_item_luid', how='left')

                            # Update flow views (runs) and last_accessed
                            flow_mask = df['content_type'].str.strip().str.lower() == 'flow'
                            df.loc[flow_mask & df['flow_runs_30d'].notna(), 'views_30d'] = df.loc[flow_mask & df['flow_runs_30d'].notna(), 'flow_runs_30d'].astype(int)
                            df.loc[flow_mask & df['flow_unique_users_30d'].notna(), 'unique_users_30d'] = df.loc[flow_mask & df['flow_unique_users_30d'].notna(), 'flow_unique_users_30d'].astype(int)

                            # Update last_accessed_at from events for flows
                            mask_flow_update = flow_mask & df['flow_last_run'].notna()
                            if mask_flow_update.any():
                                df.loc[mask_flow_update, 'last_accessed_at'] = df.loc[mask_flow_update, 'flow_last_run']

                            # Log results
                            flows_count = df[flow_mask]
                            logger.info(f"AdminInsights: Flows with runs: {(flows_count['views_30d'] > 0).sum()}, total runs: {flows_count['views_30d'].sum()}")

                            # Clean up temp columns
                            df = df.drop(columns=[c for c in df.columns if c.startswith('flow_') or c == '_flow_item_luid'], errors='ignore')

        # ==================== Join Subscriptions ====================
        if self.subscriptions_df is not None and len(self.subscriptions_df) > 0:
            subs = self.subscriptions_df.copy()

            # Find item column
            sub_item_col = None
            for col in ['item_luid', 'content_luid', 'luid']:
                if col in subs.columns:
                    sub_item_col = col
                    break

            if sub_item_col:
                subs['_item_key'] = subs[sub_item_col].astype(str)

                # Count subscriptions
                sub_counts = subs.groupby('_item_key').size().reset_index(name='subscription_count')

                # Count unique subscribers
                sub_user_col = None
                for col in ['subscriber_email', 'subscriber_user_luid', 'subscriber_luid']:
                    if col in subs.columns:
                        sub_user_col = col
                        break

                if sub_user_col:
                    subscriber_counts = subs.groupby('_item_key')[sub_user_col].nunique().reset_index(name='subscriber_count')
                    sub_counts = sub_counts.merge(subscriber_counts, on='_item_key', how='left')
                else:
                    sub_counts['subscriber_count'] = sub_counts['subscription_count']

                df = df.merge(sub_counts, left_on='content_luid', right_on='_item_key', how='left', suffixes=('', '_sub'))
                df['subscription_count'] = df['subscription_count'].fillna(0).astype(int)
                df['subscriber_count'] = df['subscriber_count'].fillna(0).astype(int)
            else:
                df['subscription_count'] = 0
                df['subscriber_count'] = 0
        else:
            df['subscription_count'] = 0
            df['subscriber_count'] = 0

        # ==================== Join Permissions ====================
        if self.permissions_df is not None and len(self.permissions_df) > 0:
            perms = self.permissions_df.copy()

            # Find item column
            perm_item_col = None
            for col in ['item_luid', 'content_luid', 'luid']:
                if col in perms.columns:
                    perm_item_col = col
                    break

            if perm_item_col:
                perms['_item_key'] = perms[perm_item_col].astype(str)

                # Count unique grantees (viewers/editors)
                grantee_col = None
                for col in ['grantee_luid', 'grantee_name', 'user_luid']:
                    if col in perms.columns:
                        grantee_col = col
                        break

                if grantee_col:
                    perm_counts = perms.groupby('_item_key')[grantee_col].nunique().reset_index(name='permission_grantees')
                    df = df.merge(perm_counts, left_on='content_luid', right_on='_item_key', how='left', suffixes=('', '_perm'))
                    df['permission_grantees'] = df['permission_grantees'].fillna(0).astype(int)
                else:
                    df['permission_grantees'] = 0

                # Count by grantee type (groups vs users)
                type_col = None
                for col in ['grantee_type']:
                    if col in perms.columns:
                        type_col = col
                        break

                if type_col and grantee_col:
                    group_perms = perms[perms[type_col].str.lower() == 'group']
                    group_counts = group_perms.groupby('_item_key')[grantee_col].nunique().reset_index(name='group_count')
                    df = df.merge(group_counts, left_on='content_luid', right_on='_item_key', how='left', suffixes=('', '_grp'))
                    df['group_count'] = df['group_count'].fillna(0).astype(int)
                else:
                    df['group_count'] = 0
            else:
                df['permission_grantees'] = 0
                df['group_count'] = 0
        else:
            df['permission_grantees'] = 0
            df['group_count'] = 0

        # ==================== Join Viz Load Times ====================
        if self.viz_load_times_df is not None and len(self.viz_load_times_df) > 0:
            viz = self.viz_load_times_df.copy()

            # Find item column
            viz_item_col = None
            for col in ['item_luid', 'luid', 'item_luid']:
                if col in viz.columns:
                    viz_item_col = col
                    break

            # Find duration column
            duration_col = None
            for col in ['duration', 'load_time', 'response_time']:
                if col in viz.columns:
                    duration_col = col
                    break

            if viz_item_col and duration_col:
                viz['_item_key'] = viz[viz_item_col].astype(str)
                viz['_duration'] = pd.to_numeric(viz[duration_col], errors='coerce')

                # Compute avg and p95 load times
                load_stats = viz.groupby('_item_key')['_duration'].agg(['mean', 'count']).reset_index()
                load_stats.columns = ['_item_key', 'avg_load_time', 'load_time_samples']

                # P95
                p95_stats = viz.groupby('_item_key')['_duration'].quantile(0.95).reset_index(name='p95_load_time')
                load_stats = load_stats.merge(p95_stats, on='_item_key', how='left')

                df = df.merge(load_stats, left_on='content_luid', right_on='_item_key', how='left', suffixes=('', '_viz'))
                df['avg_load_time'] = df['avg_load_time'].fillna(0).round(2)
                df['p95_load_time'] = df['p95_load_time'].fillna(0).round(2)
            else:
                df['avg_load_time'] = 0
                df['p95_load_time'] = 0
        else:
            df['avg_load_time'] = 0
            df['p95_load_time'] = 0

        # ==================== Join Job Performance ====================
        if self.job_performance_df is not None and len(self.job_performance_df) > 0:
            jobs = self.job_performance_df.copy()

            # Find item column
            job_item_col = None
            for col in ['item_luid', 'luid', 'datasource_luid']:
                if col in jobs.columns:
                    job_item_col = col
                    break

            if job_item_col:
                jobs['_item_key'] = jobs[job_item_col].astype(str)

                # Find result column
                result_col = None
                for col in ['job_result', 'final_job_result', 'result']:
                    if col in jobs.columns:
                        result_col = col
                        break

                if result_col:
                    # Count failures
                    jobs['_is_failure'] = jobs[result_col].astype(str).str.lower().str.contains('fail|error', na=False).astype(int)
                    failure_counts = jobs.groupby('_item_key')['_is_failure'].sum().reset_index(name='refresh_failures')
                    df = df.merge(failure_counts, left_on='content_luid', right_on='_item_key', how='left', suffixes=('', '_job'))
                    df['refresh_failures'] = df['refresh_failures'].fillna(0).astype(int)
                else:
                    df['refresh_failures'] = 0

                # Get last refresh date
                completed_col = None
                for col in ['completed_at', 'completed_at_local']:
                    if col in jobs.columns:
                        completed_col = col
                        break

                if completed_col:
                    jobs['_completed'] = pd.to_datetime(jobs[completed_col], errors='coerce')
                    last_refresh = jobs.groupby('_item_key')['_completed'].max().reset_index(name='last_refresh')
                    df = df.merge(last_refresh, left_on='content_luid', right_on='_item_key', how='left', suffixes=('', '_ref'))
                else:
                    df['last_refresh'] = pd.NaT

                # Average refresh duration
                duration_col = None
                for col in ['job_execution_duration', 'job_duration', 'duration']:
                    if col in jobs.columns:
                        duration_col = col
                        break

                if duration_col:
                    jobs['_duration'] = pd.to_numeric(jobs[duration_col], errors='coerce')
                    avg_duration = jobs.groupby('_item_key')['_duration'].mean().reset_index(name='avg_refresh_duration')
                    df = df.merge(avg_duration, left_on='content_luid', right_on='_item_key', how='left', suffixes=('', '_dur'))
                    df['avg_refresh_duration'] = df['avg_refresh_duration'].fillna(0).round(2)
                else:
                    df['avg_refresh_duration'] = 0
            else:
                df['refresh_failures'] = 0
                df['last_refresh'] = pd.NaT
                df['avg_refresh_duration'] = 0
        else:
            df['refresh_failures'] = 0
            df['last_refresh'] = pd.NaT
            df['avg_refresh_duration'] = 0

        # ==================== Compute Derived Metrics ====================

        # Days since last access
        df['days_since_last_access'] = (today - df['last_accessed_at']).dt.days
        df['days_since_last_access'] = df['days_since_last_access'].fillna(999).astype(int)

        # Clean up extra columns from merges
        cols_to_drop = [c for c in df.columns if c.endswith(('_y', '_z', '_w', '_key', '_sub', '_perm', '_grp', '_viz', '_job', '_ref', '_dur'))]
        df = df.drop(columns=cols_to_drop, errors='ignore')

        # Remove duplicates by content_luid
        df = df.drop_duplicates(subset=['content_luid'], keep='first')

        self.content_master = df
        return df

    def compute_governance_scores(self):
        """Compute governance scores for all content"""
        if self.content_master is None:
            self.build_content_master()

        df = self.content_master.copy()
        today = pd.Timestamp.now()

        # ==================== Usage Score ====================
        # usage_score = log1p(views_30d) * 20 + unique_users * 5 + subscription_count * 10
        df['usage_score'] = (
            np.log1p(df['views_30d']) * 20 +
            df['unique_users_30d'] * 5 +
            df['subscription_count'] * 10
        )

        # ==================== Reach Score ====================
        # reach_score = permission_grantees * 2 + group_count * 10
        df['reach_score'] = (
            df['permission_grantees'] * 2 +
            df['group_count'] * 10
        )

        # ==================== Freshness Score ====================
        def calc_freshness(days):
            if pd.isna(days) or days > 999:
                return 0
            elif days <= 7:
                return 30
            elif days <= 30:
                return 20
            elif days <= 90:
                return 10
            else:
                return 0

        df['freshness_score'] = df['days_since_last_access'].apply(calc_freshness)

        # ==================== Performance Penalty ====================
        df['performance_penalty'] = 0
        df.loc[df['avg_load_time'] > 10, 'performance_penalty'] += 10
        df.loc[df['refresh_failures'] > 5, 'performance_penalty'] += 15

        # ==================== Criticality Score ====================
        df['criticality_score'] = (
            df['usage_score'] +
            df['reach_score'] +
            df['freshness_score'] -
            df['performance_penalty']
        )

        # Clamp between 0 and 100
        df['criticality_score'] = df['criticality_score'].clip(0, 100).round(1)

        # ==================== Tier Classification ====================
        def classify_tier(row):
            if row['criticality_score'] >= 70 or row['views_30d'] > 100 or row['subscription_count'] > 10:
                return 'Tier 1'
            elif row['criticality_score'] >= 30:
                return 'Tier 2'
            else:
                return 'Tier 3'

        df['tier'] = df.apply(classify_tier, axis=1)

        # ==================== Sunset Candidate ====================
        df['sunset_candidate'] = (
            (df['days_since_last_access'] > 120) &
            (df['views_30d'] < 5) &
            (df['subscription_count'] == 0)
        )

        # ==================== Risk Level ====================
        def classify_risk(row):
            if row['size_mb'] > 500 and row['days_since_last_access'] > 120:
                return 'High'
            elif row['days_since_last_access'] > 90:
                return 'Medium'
            else:
                return 'Low'

        df['risk_level'] = df.apply(classify_risk, axis=1)

        self.content_master = df
        return df

    def build_workbook_governance(self):
        """Build workbook governance table"""
        if self.content_master is None:
            self.compute_governance_scores()

        df = self.content_master.copy()

        # Log content type distribution (detailed)
        content_types = df['content_type'].value_counts().to_dict()
        logger.info(f"AdminInsights: Content types distribution: {content_types}")
        # Log unique content types for debugging
        unique_types = df['content_type'].unique().tolist()
        logger.info(f"AdminInsights: Unique content types: {unique_types}")

        # Step 7: Filter Site_Content.content_type = 'Workbook'
        # Match 'Workbook' exactly (case-insensitive)
        workbooks = df[df['content_type'].str.strip().str.lower() == 'workbook'].copy()
        logger.info(f"AdminInsights: Filtered to {len(workbooks)} workbooks (content_type = 'Workbook')")

        if len(workbooks) == 0:
            logger.warning("AdminInsights: No items with content_type = 'Workbook' found")
            # Return empty dataframe with correct columns
            self.workbook_governance = pd.DataFrame(columns=[
                'Rank', 'Workbook', 'Project', 'Owner',
                'Views (30d)', 'Unique Users', 'Last Accessed', 'Size (MB)',
                'Subscriptions', 'Criticality Score', 'Tier', 'Risk', 'Sunset Candidate'
            ])
            return self.workbook_governance

        # Rank by views
        workbooks = workbooks.sort_values('views_30d', ascending=False).reset_index(drop=True)
        workbooks['rank'] = range(1, len(workbooks) + 1)

        # Ensure all required columns exist and handle nulls
        if 'subscription_count' not in workbooks.columns:
            workbooks['subscription_count'] = 0
        if 'criticality_score' not in workbooks.columns:
            workbooks['criticality_score'] = 0
        if 'tier' not in workbooks.columns:
            workbooks['tier'] = 'Tier 3'
        if 'risk_level' not in workbooks.columns:
            workbooks['risk_level'] = 'Low'
        if 'sunset_candidate' not in workbooks.columns:
            workbooks['sunset_candidate'] = False

        # Replace null values with appropriate defaults
        workbooks['content_name'] = workbooks['content_name'].fillna('Unknown').replace('None', 'Unknown').replace('nan', 'Unknown')
        workbooks['project_name'] = workbooks['project_name'].fillna('Unknown').replace('None', 'Unknown').replace('nan', 'Unknown')
        workbooks['owner_email'] = workbooks['owner_email'].fillna('Unknown').replace('None', 'Unknown').replace('nan', 'Unknown')
        workbooks['views_30d'] = workbooks['views_30d'].fillna(0).astype(int)
        workbooks['unique_users_30d'] = workbooks['unique_users_30d'].fillna(0).astype(int)
        workbooks['size_mb'] = workbooks['size_mb'].fillna(0).round(2)
        workbooks['subscription_count'] = workbooks['subscription_count'].fillna(0).astype(int)
        workbooks['criticality_score'] = workbooks['criticality_score'].fillna(0).round(1)

        # Select columns for output
        output_cols = [
            'rank', 'content_name', 'project_name', 'owner_email',
            'views_30d', 'unique_users_30d', 'last_accessed_at', 'size_mb',
            'subscription_count', 'criticality_score', 'tier', 'risk_level', 'sunset_candidate'
        ]

        workbooks = workbooks[output_cols].copy()
        workbooks.columns = [
            'Rank', 'Workbook', 'Project', 'Owner',
            'Views (30d)', 'Unique Users', 'Last Accessed', 'Size (MB)',
            'Subscriptions', 'Criticality Score', 'Tier', 'Risk', 'Sunset Candidate'
        ]

        # Final check: ensure no None values in Workbook column
        workbooks['Workbook'] = workbooks['Workbook'].apply(lambda x: 'Unknown' if pd.isna(x) or str(x).lower() in ['none', 'nan', ''] else x)

        logger.info(f"AdminInsights: Workbook governance table has {len(workbooks)} rows, total views: {workbooks['Views (30d)'].sum()}")

        self.workbook_governance = workbooks
        return workbooks

    def build_datasource_governance(self):
        """Build datasource governance table with sunset logic"""
        if self.content_master is None:
            self.compute_governance_scores()

        df = self.content_master.copy()

        # Filter to datasources
        datasources = df[df['content_type'].str.lower().str.contains('data source|datasource', na=False)].copy()

        if len(datasources) == 0:
            self.datasource_governance = pd.DataFrame()
            return self.datasource_governance

        # ==================== Compute Sunset Logic for Datasources ====================
        # Simple rule: If accessed in last 30 days → NOT sunset candidate
        now = pd.Timestamp.now()
        date_30_days_ago = now - pd.Timedelta(days=30)

        def compute_ds_sunset(row):
            """Determine if datasource is a sunset candidate based on recent activity"""
            sunset_reasons = []

            # Check if accessed in last 30 days (views_30d > 0)
            views_30d = 0
            try:
                views_30d = int(float(row.get('views_30d', 0) or 0))
            except:
                pass

            if views_30d > 0:
                # Accessed in last 30 days - NOT a sunset candidate
                return pd.Series({
                    'sunset_score': 0,
                    'sunset_reasons': [],
                    'sunset_recommendation': 'Keep',
                    'is_sunset_candidate': False
                })

            # Check last accessed date
            last_accessed = row.get('last_accessed_at')
            if last_accessed is not None and pd.notna(last_accessed):
                try:
                    last_accessed_dt = pd.to_datetime(last_accessed)
                    if last_accessed_dt >= date_30_days_ago:
                        # Accessed in last 30 days - NOT a sunset candidate
                        return pd.Series({
                            'sunset_score': 0,
                            'sunset_reasons': [],
                            'sunset_recommendation': 'Keep',
                            'is_sunset_candidate': False
                        })
                    else:
                        days_since = (now - last_accessed_dt).days
                        sunset_reasons.append(f'No access in {days_since} days')
                except:
                    pass

            # Check last modified/published date as fallback
            last_modified = row.get('last_published_at')
            if last_modified is not None and pd.notna(last_modified):
                try:
                    last_modified_dt = pd.to_datetime(last_modified)
                    if last_modified_dt >= date_30_days_ago:
                        # Modified in last 30 days - NOT a sunset candidate
                        return pd.Series({
                            'sunset_score': 0,
                            'sunset_reasons': [],
                            'sunset_recommendation': 'Keep',
                            'is_sunset_candidate': False
                        })
                    else:
                        days_since = (now - last_modified_dt).days
                        if not sunset_reasons:
                            sunset_reasons.append(f'No activity in {days_since} days')
                except:
                    pass

            # No recent activity - IS a sunset candidate
            if not sunset_reasons:
                sunset_reasons.append('No recent activity')

            return pd.Series({
                'sunset_score': 100,
                'sunset_reasons': sunset_reasons,
                'sunset_recommendation': 'Sunset',
                'is_sunset_candidate': True
            })

        # Apply sunset scoring
        sunset_data = datasources.apply(compute_ds_sunset, axis=1)
        datasources = pd.concat([datasources, sunset_data], axis=1)

        logger.info(f"AdminInsights: Datasource sunset candidates: {datasources['is_sunset_candidate'].sum()}")

        # Rank by usage
        datasources = datasources.sort_values('views_30d', ascending=False).reset_index(drop=True)
        datasources['rank'] = range(1, len(datasources) + 1)

        # Select columns for output
        output_cols = [
            'content_name', 'project_name', 'owner_email', 'is_data_extract', 'database_type',
            'views_30d', 'last_accessed_at', 'last_published_at', 'extracts_refreshed_at',
            'subscriber_count', 'criticality_score', 'sunset_score', 'sunset_recommendation',
            'tier', 'is_sunset_candidate', 'sunset_reasons'
        ]

        for col in output_cols:
            if col not in datasources.columns:
                datasources[col] = None

        datasources = datasources[output_cols].copy()
        datasources.columns = [
            'Datasource', 'Project', 'Owner', 'Is Extract', 'Database Type',
            'Uses (30d)', 'Last Accessed', 'Last Published', 'Last Refresh',
            'Subscribers', 'Criticality', 'Sunset Score', 'Sunset Recommendation',
            'Tier', 'Is Sunset Candidate', 'Sunset Reasons'
        ]

        # Compute Last Modified as the most recent of Last Published or Last Refresh
        datasources['Last Modified'] = datasources.apply(
            lambda row: row['Last Refresh'] if pd.notna(row['Last Refresh']) else row['Last Published'],
            axis=1
        )

        self.datasource_governance = datasources
        return datasources

    def build_flow_governance(self):
        """Build flow governance table with sunset logic"""
        logger.info("AdminInsights: ========== BUILD_FLOW_GOVERNANCE STARTED ==========")

        if self.content_master is None:
            logger.warning("AdminInsights: content_master is None, calling compute_governance_scores")
            self.compute_governance_scores()

        df = self.content_master.copy()
        logger.info(f"AdminInsights: content_master has {len(df)} total rows")

        # Log content types for debugging
        if 'content_type' in df.columns:
            content_types = df['content_type'].value_counts().to_dict()
            logger.info(f"AdminInsights: Content types in content_master: {content_types}")

            # Log unique raw values
            unique_vals = df['content_type'].unique().tolist()
            logger.info(f"AdminInsights: Unique content_type values: {unique_vals}")

            # Check for 'Flow' specifically
            flow_check = df[df['content_type'].str.contains('flow', case=False, na=False)]
            logger.info(f"AdminInsights: Rows containing 'flow' (case-insensitive): {len(flow_check)}")
        else:
            logger.error("AdminInsights: content_type column NOT FOUND in content_master!")
            logger.info(f"AdminInsights: Available columns: {list(df.columns)}")

        # Filter to flows - match 'Flow' exactly (case-insensitive) or contains 'prep'
        flow_mask = df['content_type'].str.strip().str.lower() == 'flow'
        prep_mask = df['content_type'].str.lower().str.contains('prep', na=False)

        logger.info(f"AdminInsights: flow_mask True count: {flow_mask.sum()}")
        logger.info(f"AdminInsights: prep_mask True count: {prep_mask.sum()}")

        flows = df[flow_mask | prep_mask].copy()

        if len(flows) == 0:
            logger.warning("AdminInsights: No flows found in content data (looked for 'Flow' or 'Prep')")
            self.flow_governance = pd.DataFrame()
            return self.flow_governance

        logger.info(f"AdminInsights: Found {len(flows)} flows for governance analysis")

        # ==================== Compute Sunset Logic for Flows ====================
        # Simple rule: If accessed/modified in last 30 days → NOT sunset candidate
        now = pd.Timestamp.now()
        date_30_days_ago = now - pd.Timedelta(days=30)

        def compute_flow_sunset(row):
            """Determine if flow is a sunset candidate based on recent activity"""
            sunset_reasons = []

            # Check if accessed in last 30 days (views_30d > 0)
            views_30d = 0
            try:
                views_30d = int(float(row.get('views_30d', 0) or 0))
            except:
                pass

            if views_30d > 0:
                # Accessed in last 30 days - NOT a sunset candidate
                return pd.Series({
                    'sunset_reasons': [],
                    'is_sunset_candidate': False
                })

            # Check last accessed date
            last_accessed = row.get('last_accessed_at')
            if last_accessed is not None and pd.notna(last_accessed):
                try:
                    last_accessed_dt = pd.to_datetime(last_accessed)
                    if last_accessed_dt >= date_30_days_ago:
                        # Accessed in last 30 days - NOT a sunset candidate
                        return pd.Series({
                            'sunset_reasons': [],
                            'is_sunset_candidate': False
                        })
                    else:
                        days_since = (now - last_accessed_dt).days
                        sunset_reasons.append(f'No access in {days_since} days')
                except:
                    pass

            # Check last modified date as fallback
            last_modified = row.get('last_published_at')
            if last_modified is not None and pd.notna(last_modified):
                try:
                    last_modified_dt = pd.to_datetime(last_modified)
                    if last_modified_dt >= date_30_days_ago:
                        # Modified in last 30 days - NOT a sunset candidate
                        return pd.Series({
                            'sunset_reasons': [],
                            'is_sunset_candidate': False
                        })
                    else:
                        days_since = (now - last_modified_dt).days
                        if not sunset_reasons:
                            sunset_reasons.append(f'No activity in {days_since} days')
                except:
                    pass

            # No recent activity - IS a sunset candidate
            if not sunset_reasons:
                sunset_reasons.append('No recent activity')

            return pd.Series({
                'sunset_reasons': sunset_reasons,
                'is_sunset_candidate': True
            })

        # Apply sunset computation
        sunset_data = flows.apply(compute_flow_sunset, axis=1)
        flows = pd.concat([flows, sunset_data], axis=1)

        # ==================== Compute Criticality Score for Flows ====================
        def compute_flow_criticality(row):
            """Compute criticality score based on usage and operational metrics"""
            score = 0

            # Usage component (40%)
            runs_30d = 0
            try:
                runs_30d = int(float(row.get('views_30d', 0) or 0))
            except:
                pass
            if runs_30d > 10:
                score += 40
            elif runs_30d > 5:
                score += 30
            elif runs_30d > 0:
                score += 20

            # Has refresh schedule = operational flow (30%)
            has_schedule = row.get('has_refresh_schedule', False)
            if has_schedule == True or str(has_schedule).lower() in ['true', '1', 'yes']:
                score += 30

            # Subscribers (20%)
            subscribers = 0
            try:
                subscribers = int(float(row.get('subscriber_count', 0) or 0))
            except:
                pass
            if subscribers > 5:
                score += 20
            elif subscribers > 0:
                score += 10

            # Recent activity (10%)
            try:
                last_modified = row.get('last_published_at')
                if last_modified is not None and pd.notna(last_modified):
                    days_since = (now - pd.to_datetime(last_modified)).days
                    if days_since <= 30:
                        score += 10
                    elif days_since <= 90:
                        score += 5
            except:
                pass

            return score

        # Apply criticality computation
        flows['criticality_score'] = flows.apply(compute_flow_criticality, axis=1)

        # Determine tier based on criticality score
        def get_tier(crit):
            if crit >= 70:
                return 'Tier 1'
            elif crit >= 40:
                return 'Tier 2'
            return 'Tier 3'

        flows['tier'] = flows['criticality_score'].fillna(0).apply(get_tier)

        # Ensure all required columns exist with proper defaults
        for col, default in [('content_name', 'Unknown'), ('project_name', 'Unknown'),
                             ('owner_email', 'Unknown'), ('views_30d', 0), ('unique_users_30d', 0),
                             ('last_accessed_at', None), ('last_published_at', None),
                             ('refresh_failures', 0), ('avg_refresh_duration', 0),
                             ('criticality_score', 0), ('subscriber_count', 0)]:
            if col not in flows.columns:
                flows[col] = default

        # Debug: Log flow data
        logger.info(f"AdminInsights: Flow content_name values: {flows['content_name'].tolist()}")
        logger.info(f"AdminInsights: Flow project_name values: {flows['project_name'].tolist()}")

        # Select output columns
        output_cols = [
            'content_name', 'project_name', 'owner_email',
            'views_30d', 'unique_users_30d', 'last_accessed_at', 'last_published_at',
            'refresh_failures', 'subscriber_count',
            'criticality_score', 'is_sunset_candidate', 'tier', 'sunset_reasons'
        ]

        # Only include columns that exist
        output_cols = [c for c in output_cols if c in flows.columns]
        flows = flows[output_cols].copy()

        # Rename columns for display
        col_rename = {
            'content_name': 'Flow',
            'project_name': 'Project',
            'owner_email': 'Owner',
            'views_30d': 'Runs (30d)',
            'unique_users_30d': 'Users',
            'last_accessed_at': 'Last Run',
            'last_published_at': 'Last Modified',
            'refresh_failures': 'Failures',
            'subscriber_count': 'Subscribers',
            'criticality_score': 'Criticality',
            'is_sunset_candidate': 'Sunset',
            'tier': 'Tier',
            'sunset_reasons': 'Sunset Reasons'
        }
        flows.columns = [col_rename.get(c, c) for c in flows.columns]

        logger.info(f"AdminInsights: Flow governance table has {len(flows)} rows")
        self.flow_governance = flows
        return flows

    def build_users_governance(self):
        """
        Build comprehensive Users Governance Analytics from TS_Users.
        Implements: activity status, license waste detection, admin risk,
        contribution scoring, tier classification, and license utilization.
        """
        if self.ts_users_df is None:
            logger.warning("AdminInsights: No TS_Users data available for users governance")
            return pd.DataFrame()

        df = self.ts_users_df.copy()
        logger.info(f"AdminInsights: Building users governance for {len(df)} users")
        logger.info(f"AdminInsights: TS_Users columns: {list(df.columns)}")

        # =====================================================
        # STEP 1 — COLUMN MAPPING
        # =====================================================
        col_map = {
            'user_friendly_name': ['user_friendly_name', 'friendly_name', 'user_name'],
            'user_email': ['user_email', 'email'],
            'user_license_type': ['user_license_type', 'license_type'],
            'user_site_role': ['user_site_role', 'site_role'],
            'projects': ['projects'],
            'workbooks': ['workbooks'],
            'data_sources': ['data_sources', 'datasources'],
            'views': ['views'],
            'last_login_date': ['last_login_date', 'last_login'],
            'days_since_last_login': ['days_since_last_login', 'days_since_login'],
            'user_creation_date': ['user_creation_date', 'creation_date'],
            'user_account_age': ['user_account_age', 'account_age'],
            'access_events_data_sources': ['access_events_data_sources', 'access_events___data_sources'],
            'access_events_views': ['access_events_views', 'access_events___views'],
            'publish_events_workbooks': ['publish_events_workbooks', 'publish_events___workbooks'],
            'publish_events_data_sources': ['publish_events_data_sources', 'publish_events___data_sources'],
            'total_traffic_views': ['total_traffic_views', 'total_traffic___views'],
            'total_traffic_data_sources': ['total_traffic_data_sources', 'total_traffic___data_sources'],
            'size_of_workbooks_mb': ['size_of_workbooks_mb', 'size_of_workbooks__mb_'],
            'size_of_data_sources_mb': ['size_of_data_sources_mb', 'size_of_data_sources__mb_'],
            'certified_data_sources': ['certified_data_sources'],
            'total_allowed_licenses': ['total_allowed_licenses'],
            'total_occupied_licenses': ['total_occupied_licenses'],
            'total_remaining_licenses': ['total_remaining_licenses'],
            'allowed_creators': ['allowed_creators'],
            'allowed_explorers': ['allowed_explorers'],
            'allowed_viewers': ['allowed_viewers'],
            'occupied_creator_licenses': ['occupied_creator_licenses'],
            'occupied_explorer_licenses': ['occupied_explorer_licenses'],
            'occupied_viewer_licenses': ['occupied_viewer_licenses'],
        }

        # Find matching columns
        def find_col(patterns):
            for p in patterns:
                if p in df.columns:
                    return p
            return None

        # Build output dataframe
        output = pd.DataFrame()

        for out_col, patterns in col_map.items():
            matched = find_col(patterns)
            if matched:
                output[out_col] = df[matched]
            else:
                output[out_col] = None

        # =====================================================
        # STEP 2 — CLEAN DATA
        # =====================================================
        # Convert date columns
        date_cols = ['last_login_date', 'user_creation_date']
        for col in date_cols:
            if col in output.columns:
                output[col] = pd.to_datetime(output[col], errors='coerce')

        # Convert numeric columns and replace blanks with 0
        numeric_cols = [
            'projects', 'workbooks', 'data_sources', 'views',
            'days_since_last_login', 'user_account_age',
            'access_events_data_sources', 'access_events_views',
            'publish_events_workbooks', 'publish_events_data_sources',
            'total_traffic_views', 'total_traffic_data_sources',
            'size_of_workbooks_mb', 'size_of_data_sources_mb',
            'certified_data_sources',
            'total_allowed_licenses', 'total_occupied_licenses', 'total_remaining_licenses',
            'allowed_creators', 'allowed_explorers', 'allowed_viewers',
            'occupied_creator_licenses', 'occupied_explorer_licenses', 'occupied_viewer_licenses'
        ]

        for col in numeric_cols:
            if col in output.columns:
                output[col] = pd.to_numeric(output[col], errors='coerce').fillna(0).astype(int)

        # Calculate days_since_last_login if not present
        if output['days_since_last_login'].sum() == 0 and output['last_login_date'].notna().any():
            today = pd.Timestamp.now()
            output['days_since_last_login'] = output['last_login_date'].apply(
                lambda x: (today - x).days if pd.notna(x) else 9999
            )

        # Handle null user names
        output['user_friendly_name'] = output['user_friendly_name'].fillna('Unknown User')
        output['user_email'] = output['user_email'].fillna('')

        # =====================================================
        # STEP 3 — USER ACTIVITY STATUS
        # =====================================================
        def get_user_status(row):
            last_login = row.get('last_login_date')
            days = row.get('days_since_last_login', 9999)

            if pd.isna(last_login) or last_login is None:
                return 'Never Used'
            elif days <= 30:
                return 'Active'
            elif days <= 90:
                return 'At Risk'
            else:
                return 'Inactive'

        output['user_status'] = output.apply(get_user_status, axis=1)

        # =====================================================
        # STEP 4 — LICENSE WASTE DETECTION
        # =====================================================
        def detect_license_waste(row):
            license_type = str(row.get('user_license_type', '')).lower()
            access_views = int(row.get('access_events_views', 0) or 0)
            access_ds = int(row.get('access_events_data_sources', 0) or 0)
            days = int(row.get('days_since_last_login', 0) or 0)

            # Exclude Unlicensed users
            if 'unlicensed' in license_type:
                return 'No'

            # Check for Creator or Explorer with no activity
            if ('creator' in license_type or 'explorer' in license_type):
                if access_views == 0 and access_ds == 0 and days > 60:
                    return 'Yes'

            return 'No'

        output['license_waste_flag'] = output.apply(detect_license_waste, axis=1)

        # =====================================================
        # STEP 5 — ADMIN RISK DETECTION
        # =====================================================
        def detect_admin_risk(row):
            site_role = str(row.get('user_site_role', '')).lower()
            days = int(row.get('days_since_last_login', 0) or 0)

            if 'administrator' in site_role and days > 60:
                return 'Yes'
            return 'No'

        output['admin_risk_flag'] = output.apply(detect_admin_risk, axis=1)

        # =====================================================
        # STEP 6 — USER CONTRIBUTION SCORE
        # =====================================================
        def calculate_contribution_score(row):
            workbooks = int(row.get('workbooks', 0) or 0)
            data_sources = int(row.get('data_sources', 0) or 0)
            publish_wb = int(row.get('publish_events_workbooks', 0) or 0)
            publish_ds = int(row.get('publish_events_data_sources', 0) or 0)
            traffic_views = int(row.get('total_traffic_views', 0) or 0)

            raw_score = (
                workbooks * 10 +
                data_sources * 8 +
                publish_wb * 5 +
                publish_ds * 5 +
                traffic_views * 2
            )
            return raw_score

        output['raw_contribution_score'] = output.apply(calculate_contribution_score, axis=1)

        # Normalize score to 0-100
        max_score = output['raw_contribution_score'].max()
        if max_score > 0:
            output['contribution_score'] = (output['raw_contribution_score'] / max_score * 100).round(1)
        else:
            output['contribution_score'] = 0

        # =====================================================
        # STEP 7 — USER TIER CLASSIFICATION
        # =====================================================
        def classify_user_tier(row):
            score = row.get('contribution_score', 0)
            days = int(row.get('days_since_last_login', 0) or 0)
            status = row.get('user_status', '')

            # Tier 4 - Inactive (no login in 90+ days)
            if status == 'Inactive' or status == 'Never Used' or days > 90:
                return 'Tier 4'
            # Tier 1 - Critical Contributor
            elif score >= 60:
                return 'Tier 1'
            # Tier 2 - Contributor
            elif score >= 20:
                return 'Tier 2'
            # Tier 3 - Consumer
            else:
                return 'Tier 3'

        output['user_tier'] = output.apply(classify_user_tier, axis=1)

        # =====================================================
        # STEP 8 — LICENSE UTILIZATION SUMMARY
        # =====================================================
        # Get license info from first row (same for all users in a site)
        if len(output) > 0:
            first_row = output.iloc[0]
            self.license_summary = {
                'total_allowed_licenses': int(first_row.get('total_allowed_licenses', 0) or 0),
                'total_occupied_licenses': int(first_row.get('total_occupied_licenses', 0) or 0),
                'total_remaining_licenses': int(first_row.get('total_remaining_licenses', 0) or 0),
                'allowed_creators': int(first_row.get('allowed_creators', 0) or 0),
                'allowed_explorers': int(first_row.get('allowed_explorers', 0) or 0),
                'allowed_viewers': int(first_row.get('allowed_viewers', 0) or 0),
                'occupied_creators': int(first_row.get('occupied_creator_licenses', 0) or 0),
                'occupied_explorers': int(first_row.get('occupied_explorer_licenses', 0) or 0),
                'occupied_viewers': int(first_row.get('occupied_viewer_licenses', 0) or 0),
            }

            # Calculate usage percentages
            if self.license_summary['allowed_creators'] > 0:
                self.license_summary['creator_usage_pct'] = round(
                    self.license_summary['occupied_creators'] / self.license_summary['allowed_creators'] * 100, 1)
            else:
                self.license_summary['creator_usage_pct'] = 0

            if self.license_summary['allowed_explorers'] > 0:
                self.license_summary['explorer_usage_pct'] = round(
                    self.license_summary['occupied_explorers'] / self.license_summary['allowed_explorers'] * 100, 1)
            else:
                self.license_summary['explorer_usage_pct'] = 0

            if self.license_summary['allowed_viewers'] > 0:
                self.license_summary['viewer_usage_pct'] = round(
                    self.license_summary['occupied_viewers'] / self.license_summary['allowed_viewers'] * 100, 1)
            else:
                self.license_summary['viewer_usage_pct'] = 0
        else:
            self.license_summary = {}

        # =====================================================
        # STEP 9 — COMPUTE KPIs
        # =====================================================
        self.users_kpi = {
            'total_users': len(output),
            'active_users': len(output[output['user_status'] == 'Active']),
            'at_risk_users': len(output[output['user_status'] == 'At Risk']),
            'inactive_users': len(output[output['user_status'] == 'Inactive']),
            'never_used_users': len(output[output['user_status'] == 'Never Used']),
            'license_waste_users': len(output[output['license_waste_flag'] == 'Yes']),
            'admin_risk_users': len(output[output['admin_risk_flag'] == 'Yes']),
            'creators': len(output[output['user_license_type'].str.lower().str.contains('creator', na=False)]),
            'explorers': len(output[output['user_license_type'].str.lower().str.contains('explorer', na=False)]),
            'viewers': len(output[output['user_license_type'].str.lower().str.contains('viewer', na=False)]),
            'unlicensed': len(output[output['user_license_type'].str.lower().str.contains('unlicensed', na=False)]),
            'tier_1_users': len(output[output['user_tier'] == 'Tier 1']),
            'tier_2_users': len(output[output['user_tier'] == 'Tier 2']),
            'tier_3_users': len(output[output['user_tier'] == 'Tier 3']),
            'tier_4_users': len(output[output['user_tier'] == 'Tier 4']),
        }

        # Add license summary to KPIs
        self.users_kpi.update(self.license_summary)

        # =====================================================
        # STEP 10 — PREPARE OUTPUT
        # =====================================================
        # Select and rename columns for final output
        output_columns = [
            'user_friendly_name', 'user_email', 'user_license_type', 'user_site_role',
            'projects', 'workbooks', 'data_sources', 'views',
            'last_login_date', 'days_since_last_login',
            'contribution_score', 'user_tier', 'user_status',
            'license_waste_flag', 'admin_risk_flag',
            'access_events_views', 'access_events_data_sources',
            'publish_events_workbooks', 'publish_events_data_sources',
            'total_traffic_views', 'size_of_workbooks_mb', 'size_of_data_sources_mb'
        ]

        # Only include columns that exist
        final_cols = [c for c in output_columns if c in output.columns]
        output = output[final_cols].copy()

        # Sort by contribution score descending
        output = output.sort_values('contribution_score', ascending=False).reset_index(drop=True)

        # Rename columns for display
        col_rename = {
            'user_friendly_name': 'user_name',
            'user_email': 'email',
            'user_license_type': 'license_type',
            'user_site_role': 'site_role',
            'last_login_date': 'last_login',
            'days_since_last_login': 'days_since_login',
        }
        output = output.rename(columns=col_rename)

        logger.info(f"AdminInsights: Users governance built with {len(output)} users")
        logger.info(f"AdminInsights: Users KPIs: {self.users_kpi}")

        self.user_analytics = output
        return output

    def build_user_analytics(self):
        """Alias for build_users_governance for backward compatibility"""
        return self.build_users_governance()

    def _to_native(self, value):
        """Convert numpy/pandas types to native Python types for JSON serialization"""
        # Handle lists first (like sunset_reasons)
        if isinstance(value, list):
            return value
        # Handle None
        if value is None:
            return None
        # Check for scalar NaN (not arrays/lists)
        try:
            if pd.isna(value):
                return None
        except (ValueError, TypeError):
            # pd.isna fails on arrays/lists, which is fine - just continue
            pass
        if isinstance(value, (np.integer, np.int64, np.int32)):
            return int(value)
        if isinstance(value, (np.floating, np.float64, np.float32)):
            return float(value)
        if isinstance(value, np.bool_):
            return bool(value)
        if isinstance(value, pd.Timestamp):
            try:
                return value.isoformat() if not pd.isna(value) else None
            except:
                return str(value)
        if hasattr(value, 'item'):
            return value.item()
        return value

    def compute_summary(self):
        """Compute summary KPIs"""
        if self.content_master is None:
            self.compute_governance_scores()

        df = self.content_master

        # Log all unique content types for debugging
        unique_content_types = df['content_type'].unique().tolist()
        logger.info(f"AdminInsights: Summary - All content types in data: {unique_content_types}")

        workbooks = df[df['content_type'].str.lower().str.contains('workbook', na=False)]
        datasources = df[df['content_type'].str.lower().str.contains('data source|datasource', na=False)]
        flows = df[df['content_type'].str.strip().str.lower() == 'flow']

        logger.info(f"AdminInsights: Summary counts - Workbooks: {len(workbooks)}, Datasources: {len(datasources)}, Flows: {len(flows)}")

        today = pd.Timestamp.now()

        # Use _to_native for all numeric values to ensure JSON serialization
        avg_load = df['avg_load_time'].mean() if 'avg_load_time' in df.columns else 0
        avg_load = 0 if pd.isna(avg_load) else round(float(avg_load), 2)

        total_size = df['size_mb'].sum()
        total_size = 0 if pd.isna(total_size) else round(float(total_size), 2)

        summary = {
            'total_workbooks': int(len(workbooks)),
            'total_datasources': int(len(datasources)),
            'total_flows': int(len(flows)),
            'total_content': int(len(df)),
            'active_workbooks_30d': int((workbooks['views_30d'] > 0).sum()) if len(workbooks) > 0 else 0,
            'dormant_workbooks_90d': int((workbooks['days_since_last_access'] > 90).sum()) if len(workbooks) > 0 else 0,
            'sunset_candidates': int(df['sunset_candidate'].sum()),
            'total_views_30d': int(df['views_30d'].sum()),
            'total_subscriptions': int(df['subscription_count'].sum()),
            'avg_load_time': avg_load,
            'tier_1_count': int((df['tier'] == 'Tier 1').sum()),
            'tier_2_count': int((df['tier'] == 'Tier 2').sum()),
            'tier_3_count': int((df['tier'] == 'Tier 3').sum()),
            'high_risk_count': int((df['risk_level'] == 'High').sum()),
            'total_size_mb': total_size
        }

        # User stats - use users_kpi if available from build_users_governance
        if self.users_kpi:
            summary['total_users'] = self.users_kpi.get('total_users', 0)
            summary['active_users'] = self.users_kpi.get('active_users', 0)
            summary['at_risk_users'] = self.users_kpi.get('at_risk_users', 0)
            summary['inactive_users'] = self.users_kpi.get('inactive_users', 0)
            summary['never_used_users'] = self.users_kpi.get('never_used_users', 0)
            summary['license_waste_users'] = self.users_kpi.get('license_waste_users', 0)
            summary['admin_risk_users'] = self.users_kpi.get('admin_risk_users', 0)
            summary['creators'] = self.users_kpi.get('creators', 0)
            summary['explorers'] = self.users_kpi.get('explorers', 0)
            summary['viewers'] = self.users_kpi.get('viewers', 0)
            summary['unlicensed'] = self.users_kpi.get('unlicensed', 0)
            summary['user_tier_1'] = self.users_kpi.get('tier_1_users', 0)
            summary['user_tier_2'] = self.users_kpi.get('tier_2_users', 0)
            summary['user_tier_3'] = self.users_kpi.get('tier_3_users', 0)
            summary['user_tier_4'] = self.users_kpi.get('tier_4_users', 0)
            # License utilization
            summary.update(self.license_summary)
        elif self.ts_users_df is not None:
            users = self.ts_users_df
            summary['total_users'] = int(len(users))

            # Count by role
            role_col = None
            for col in ['user_site_role', 'site_role']:
                if col in users.columns:
                    role_col = col
                    break

            if role_col:
                summary['creators'] = int((users[role_col].str.lower().str.contains('creator', na=False)).sum())
                summary['explorers'] = int((users[role_col].str.lower().str.contains('explorer', na=False)).sum())
                summary['viewers'] = int((users[role_col].str.lower().str.contains('viewer', na=False)).sum())
        else:
            summary['total_users'] = 0

        self.governance_summary = summary
        return summary

    def _df_to_json_safe(self, df):
        """Convert DataFrame to JSON-safe list of dicts (handles NaT, NaN, numpy types, etc.)"""
        if df is None or len(df) == 0:
            return []

        # Convert to dict records
        records = df.to_dict('records')

        # Clean each record using _to_native helper
        for record in records:
            for key, value in list(record.items()):
                record[key] = self._to_native(value)

        return records

    def run_full_analysis(self):
        """Run the complete analysis pipeline"""
        logger.info("AdminInsights: Starting full analysis...")

        # Build content master with joins
        logger.info("AdminInsights: Building content master...")
        self.build_content_master()

        # Compute governance scores
        logger.info("AdminInsights: Computing governance scores...")
        self.compute_governance_scores()

        # Build output tables
        logger.info("AdminInsights: Building workbook governance...")
        self.build_workbook_governance()

        logger.info("AdminInsights: Building datasource governance...")
        self.build_datasource_governance()

        logger.info("AdminInsights: Building flow governance...")
        self.build_flow_governance()

        logger.info("AdminInsights: Building user analytics...")
        self.build_user_analytics()

        # Compute summary
        logger.info("AdminInsights: Computing summary...")
        summary = self.compute_summary()

        logger.info("AdminInsights: Analysis complete!")

        # Log what we're returning
        flow_data = self._df_to_json_safe(self.flow_governance)
        logger.info(f"AdminInsights: Returning flow_analytics with {len(flow_data)} items")
        if len(flow_data) > 0:
            logger.info(f"AdminInsights: First flow item keys: {list(flow_data[0].keys()) if flow_data else 'N/A'}")

        return {
            'success': True,
            'workbook_analytics': self._df_to_json_safe(self.workbook_governance),
            'datasource_analytics': self._df_to_json_safe(self.datasource_governance),
            'flow_analytics': flow_data,
            'user_analytics': self._df_to_json_safe(self.user_analytics),
            'users_kpi': self.users_kpi,
            'license_summary': self.license_summary,
            'kpi_summary': summary,
            'content_master_rows': len(self.content_master) if self.content_master is not None else 0
        }

    def export_to_excel(self, include_raw=False):
        """Export analysis results to Excel"""
        output = BytesIO()

        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            # Workbook Governance
            if self.workbook_governance is not None and len(self.workbook_governance) > 0:
                df = sanitize_dataframe_for_excel(self.workbook_governance)
                df.to_excel(writer, sheet_name='Workbook Governance', index=False)

            # Datasource Governance
            if self.datasource_governance is not None and len(self.datasource_governance) > 0:
                df = sanitize_dataframe_for_excel(self.datasource_governance)
                df.to_excel(writer, sheet_name='Datasource Governance', index=False)

            # Flow Governance
            if self.flow_governance is not None and len(self.flow_governance) > 0:
                df = sanitize_dataframe_for_excel(self.flow_governance)
                df.to_excel(writer, sheet_name='Flow Governance', index=False)

            # Sunset Candidates
            if self.content_master is not None:
                sunset = self.content_master[self.content_master['sunset_candidate'] == True]
                if len(sunset) > 0:
                    sunset_out = sunset[['content_name', 'project_name', 'owner_email', 'content_type',
                                        'views_30d', 'days_since_last_access', 'size_mb', 'criticality_score']].copy()
                    sunset_out = sanitize_dataframe_for_excel(sunset_out)
                    sunset_out.to_excel(writer, sheet_name='Sunset Candidates', index=False)

            # User Analytics (Users Governance)
            if self.user_analytics is not None and len(self.user_analytics) > 0:
                user_df = sanitize_dataframe_for_excel(self.user_analytics)
                user_df.to_excel(writer, sheet_name='Users Governance', index=False)

                # License Waste Candidates
                if 'license_waste_flag' in self.user_analytics.columns:
                    waste_users = self.user_analytics[self.user_analytics['license_waste_flag'] == 'Yes']
                    if len(waste_users) > 0:
                        waste_df = sanitize_dataframe_for_excel(waste_users)
                        waste_df.to_excel(writer, sheet_name='License Waste', index=False)

                # Inactive Users (90+ days)
                if 'user_status' in self.user_analytics.columns:
                    inactive_users = self.user_analytics[self.user_analytics['user_status'].isin(['Inactive', 'Never Used'])]
                    if len(inactive_users) > 0:
                        inactive_df = sanitize_dataframe_for_excel(inactive_users)
                        inactive_df.to_excel(writer, sheet_name='Inactive Users', index=False)

                # Admin Risk Users
                if 'admin_risk_flag' in self.user_analytics.columns:
                    admin_risk = self.user_analytics[self.user_analytics['admin_risk_flag'] == 'Yes']
                    if len(admin_risk) > 0:
                        admin_df = sanitize_dataframe_for_excel(admin_risk)
                        admin_df.to_excel(writer, sheet_name='Admin Risk Users', index=False)

            # License Utilization Summary
            if self.license_summary:
                license_df = pd.DataFrame([self.license_summary])
                license_df = sanitize_dataframe_for_excel(license_df)
                license_df.to_excel(writer, sheet_name='License Utilization', index=False)

            # Summary
            if self.governance_summary:
                summary_df = pd.DataFrame([self.governance_summary])
                summary_df = sanitize_dataframe_for_excel(summary_df)
                summary_df.to_excel(writer, sheet_name='Summary', index=False)

            # Raw data if requested
            if include_raw and self.content_master is not None:
                raw_df = sanitize_dataframe_for_excel(self.content_master.head(5000))
                raw_df.to_excel(writer, sheet_name='Raw Content Master', index=False)

        output.seek(0)
        return output

    def get_upload_status(self):
        """Get current upload status for all CSV types"""
        status = {}

        df_map = {
            'site_content': self.site_content_df,
            'ts_events': self.ts_events_df,
            'ts_users': self.ts_users_df,
            'subscriptions': self.subscriptions_df,
            'permissions': self.permissions_df,
            'groups': self.groups_df,
            'viz_load_times': self.viz_load_times_df,
            'job_performance': self.job_performance_df
        }

        for csv_type, df in df_map.items():
            status[csv_type] = {
                'uploaded': df is not None,
                'rows': len(df) if df is not None else 0,
                'columns': list(df.columns) if df is not None else []  # Show all columns
            }
            if csv_type in self.date_ranges:
                status[csv_type]['date_range'] = self.date_ranges[csv_type]

        return status

    def clear_all(self):
        """Clear all loaded data"""
        self.__init__()

"""
Single Workbook Analysis - deep analysis of Tableau files straight from their XML / JSON:
workbooks (.twb / .twbx), published datasources (.tds / .tdsx) and Tableau Prep flows (.tfl / .tflx).

    analyze_file(path)        -> {dataset: [rows]} for ONE workbook (never raises; parse problems become findings)
    BulkAnalysis              -> consolidates many workbooks; rows are spooled to disk (SpooledRows) so thousands of
                                 workbooks never have to sit in memory, and adds the cross-workbook aggregates
    find_workbooks(folder)    -> recursive scan for *.twb *.twbx *.tds *.tdsx *.tfl *.tflx

Object model produced for every workbook (17 datasets, see SCHEMAS): summary, datasources, connections, tables,
joins, relationships (relationships / unions / blends), custom SQL (+ parsed tables), calculated fields (+ dependency
graph), parameters, filters, worksheets, dashboards, stories, field usage matrix, lineage
(database > schema > table > datasource > worksheet > dashboard > workbook), impact analysis and data-quality
findings (unused / duplicate / broken / hidden / deprecated).

Parsing notes
    * A .twbx is a zip: only the inner .twb is streamed out of the archive (nothing is unpacked to disk), package
      contents are listed for the summary.
    * Modern workbooks wrap some elements in `_.fcp.ObjectModelEncapsulateLegacy.*...name` tags; tags are normalised to
      their plain names once, and results are de-duplicated.
    * Owner / project / created date are not stored in workbook XML; site and repository id are, when the workbook was
      downloaded from Tableau Server / Cloud.
"""

import hashlib
import json
import logging
import os
import re
import tempfile
import threading
import zipfile
import xml.etree.ElementTree as ET
from collections import OrderedDict, defaultdict
from datetime import datetime

from export_utils import SpooledRows
from lineage_engine import CONNECTION_LABELS, SqlTableParser, auth_label, friendly_connection

logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------------------
# Output schema  (dataset key -> (Excel sheet name, columns))   order = sheet order
# --------------------------------------------------------------------------------------

SCHEMAS = OrderedDict([
    ('workbook_summary', ('Workbook Summary', [
        'Workbook', 'File Path', 'File Type', 'Content Type', 'File Size (MB)', 'File Modified', 'Workbook Version',
        'Original Version', 'Build', 'Tableau Release', 'Platform', 'Workbook ID', 'Site Name', 'Repository Path',
        'Project Name', 'Owner', 'Created Date', 'Modified Date', 'Description', 'Datasources', 'Connections',
        'Tables', 'Custom SQL', 'Joins', 'Relationships', 'Unions', 'Blends', 'Calculated Fields', 'Parameters',
        'Filters', 'Worksheets', 'Dashboards', 'Stories', 'Hidden Worksheets', 'Hidden Dashboards',
        'Hidden Datasources', 'Hidden Fields', 'Unused Fields', 'Unused Calculations', 'Duplicate Calculations',
        'Broken References', 'Invalid Connections', 'Findings', 'Data Files In Package', 'Status'])),
    ('datasource_inventory', ('Datasource Inventory', [
        'Workbook', 'Datasource', 'Caption', 'Datasource Type', 'Datasource Class', 'Datasource Version',
        'Published Datasource', 'Uses Extract', 'Federated', 'Hidden', 'Connections', 'Tables', 'Custom SQL',
        'Fields', 'Calculated Fields', 'Unused Fields'])),
    ('connection_inventory', ('Connection Inventory', [
        'Workbook', 'Datasource', 'Connection Role', 'Connection Name', 'Connection Type', 'DB Class', 'Server',
        'Port', 'Database', 'Schema', 'Warehouse', 'Catalog', 'Username', 'Authentication Mode', 'SSL Settings',
        'HTTP Path / Service', 'File / Directory', 'Initial SQL', 'Tables'])),
    ('table_inventory', ('Table Inventory', [
        'Workbook', 'Datasource', 'Connection Type', 'Server', 'Database', 'Schema', 'Table Name',
        'Full Table Name', 'Table Alias', 'Logical Table', 'Physical Table', 'Table Kind', 'Source', 'Columns',
        'Worksheets Using', 'Dashboards Using'])),
    ('join_analysis', ('Join Analysis', [
        'Workbook', 'Datasource', 'Join Type', 'Left Table', 'Right Table', 'Left Field', 'Right Field',
        'Join Clause', 'Nesting Level'])),
    ('relationship_analysis', ('Relationship Analysis', [
        'Workbook', 'Datasource', 'Type', 'Name', 'Left Table', 'Right Table', 'Left Field', 'Right Field',
        'Clause', 'Details'])),
    ('custom_sql', ('Custom SQL Analysis', [
        'Workbook', 'Datasource', 'Custom SQL Name', 'Source', 'Connection Type', 'Server', 'Database',
        'Query Length', 'Referenced Table', 'Referenced Database', 'Referenced Schema', 'Table Name',
        'Reference Type', 'CTEs', 'SQL Query'])),
    ('calculated_fields', ('Calculated Fields', [
        'Workbook', 'Datasource', 'Calculation Name', 'Internal Name', 'Formula', 'Data Type', 'Role', 'Folder',
        'Hidden', 'Is LOD', 'Is Table Calc', 'Is Aggregate', 'Formula Length', 'Dependencies',
        'Parameter Dependencies', 'Physical Tables', 'Referenced By Calculations', 'Worksheets Using',
        'Dashboards Using', 'Duplicate Of', 'Used', 'Status'])),
    ('parameters', ('Parameters', [
        'Workbook', 'Parameter Name', 'Internal Name', 'Data Type', 'Current Value', 'Domain Type',
        'Allowed Values', 'Referenced By Calculations', 'Worksheets Using', 'Dashboards Using'])),
    ('filters', ('Filters', [
        'Workbook', 'Scope', 'Worksheet', 'Datasource', 'Filter Name', 'Filter Type', 'Applied Field',
        'Filter Logic', 'Context Filter', 'Dashboards'])),
    ('worksheets', ('Worksheets', [
        'Workbook', 'Worksheet', 'Caption', 'Type', 'Mark Type', 'Hidden', 'Datasources Used', 'Dimensions Used',
        'Measures Used', 'Calculated Fields Used', 'Filters Used', 'Parameters Used', 'Rows Shelf',
        'Columns Shelf', 'Tables Used', 'Dashboards'])),
    ('dashboards', ('Dashboards', [
        'Workbook', 'Dashboard', 'Hidden', 'Size', 'Objects Count', 'Containers Count', 'Worksheets Count',
        'Worksheets Included', 'Filters Included', 'Parameters Included', 'Other Objects', 'Actions Count',
        'Stories'])),
    ('stories', ('Stories', [
        'Workbook', 'Story', 'Hidden', 'Story Point', 'Story Point Caption', 'Referenced Object',
        'Referenced Type'])),
    ('field_usage', ('Field Usage Matrix', [
        'Workbook', 'Datasource', 'Field', 'Internal Name', 'Table', 'Physical Column', 'Role', 'Data Type',
        'Is Calculated', 'Hidden', 'Used In Worksheets', 'Used In Dashboards', 'Referenced By Calculations',
        'Worksheets Count', 'Dashboards Count', 'Calculations Count', 'Used'])),
    ('workbook_lineage', ('Workbook Lineage', [
        'Workbook', 'Connection Type', 'Server', 'Database', 'Schema', 'Table', 'Full Table Name', 'Datasource',
        'Worksheet', 'Dashboard', 'Lineage Path'])),
    ('impact', ('Impact Analysis', [
        'Object Type', 'Workbook', 'Datasource', 'Object Name', 'Table', 'Worksheets Using', 'Dashboards Using',
        'Calculations Referencing', 'Datasources Using', 'Workbooks Using', 'Worksheet Names',
        'Dashboard Names'])),
    ('data_quality', ('Data Quality Findings', [
        'Workbook', 'Finding Type', 'Severity', 'Object Type', 'Object Name', 'Datasource', 'Details'])),
    ('flow_steps', ('Flow Steps', [
        'Workbook', 'Step ID', 'Step Name', 'Step Type', 'Kind', 'Node Type', 'Inputs', 'Outputs', 'Fields', 'Details'])),
])

WORKBOOK_EXTS = ('.twb', '.twbx')
DATASOURCE_EXTS = ('.tds', '.tdsx')
FLOW_EXTS = ('.tfl', '.tflx')
SUPPORTED_EXTS = WORKBOOK_EXTS + DATASOURCE_EXTS + FLOW_EXTS

MAX_LINEAGE_ROWS_PER_WORKBOOK = 50000
LIST_LIMIT = 30

# --------------------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------------------

_BRACKET = re.compile(r'\[([^\]]*)\]')
_AUTO_FIELDS = {'number of records', 'measure names', 'measure values', 'latitude (generated)',
                'longitude (generated)', 'geometry (generated)', 'multiple values'}
_SERVER_CLASSES = {'sqlserver', 'oracle', 'postgres', 'mysql', 'snowflake', 'redshift', 'teradata', 'databricks',
                   'vertica', 'db2', 'saphana', 'sapbw', 'azure_sql_dw', 'spark', 'hive', 'impala', 'presto',
                   'trino', 'awsathena', 'genericodbc', 'odbc', 'mongodb', 'denodo'}
_FILE_CLASSES = {'excel-direct', 'textscan', 'hyper', 'dataengine', 'msaccess', 'pdf', 'json', 'sasfile',
                 'spss', 'rdata'}
_DEPRECATED_CLASSES = {'dataengine': 'Tableau Data Engine (.tde) extract - replaced by Hyper',
                       'webdata-direct': 'Web Data Connector (legacy)', 'wdc': 'Web Data Connector (legacy)',
                       'msaccess': 'Microsoft Access connector (legacy)'}


def _norm_tags(root):
    """Strip XML namespaces and the '_.fcp.<feature>...' prefixes Tableau puts on some tags (one pass, in place)."""
    for el in root.iter():
        t = el.tag
        if not isinstance(t, str):
            continue
        if '...' in t:
            t = t.rsplit('...', 1)[1]
        if t.startswith('{'):
            t = t.split('}', 1)[1]
        el.tag = t


def _strip_br(s):
    s = (s or '').strip()
    return s[1:-1] if s.startswith('[') and s.endswith(']') else s


def _text(el, tag):
    c = el.find(tag)
    return (c.text or '').strip() if c is not None and c.text else ''


def _lst(values, limit=LIST_LIMIT, sep=', '):
    out, seen = [], set()
    for v in values:
        v = '' if v is None else str(v).strip()
        if v and v not in seen:
            seen.add(v)
            out.append(v)
    if limit and len(out) > limit:
        return sep.join(out[:limit]) + f'{sep}(+{len(out) - limit} more)'
    return sep.join(out)


def _bool(v):
    return 'Yes' if str(v).lower() in ('true', '1', 'yes') else ''


def parse_ref(ref):
    """'[fed.x].[none:Region:nk]' -> (datasource, derivation, field, type-suffix); '[Parameters].[P 1]' -> ('Parameters','','P 1','')"""
    parts = _BRACKET.findall(ref or '')
    if not parts:
        return '', '', (ref or '').strip(), ''
    ds = parts[0] if len(parts) >= 2 else ''
    last = parts[-1]
    deriv, name, suffix = '', last, ''
    if ':' in last:
        seg = last.split(':')
        if len(seg) >= 3:
            deriv, suffix, name = seg[0], seg[-1], ':'.join(seg[1:-1])
        elif len(seg) == 2:
            deriv, name = seg[0], seg[1]
    return ds, deriv, name, suffix


def formula_refs(formula):
    """[(qualifier, name)] referenced by a Tableau calculation (comments and string literals ignored)."""
    text = re.sub(r'//[^\n]*', '', formula or '')
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'', '""', text)
    refs = []
    for m in re.finditer(r'\[([^\]]+)\](?:\s*\.\s*\[([^\]]+)\])?', text):
        a, b = m.group(1), m.group(2)
        refs.append((a, b) if b is not None else ('', a))
    return refs


def normalize_formula(formula):
    text = re.sub(r'//[^\n]*', '', formula or '')
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    text = re.sub(r'\[Calculation_\d+\]', '[calc]', text)
    return re.sub(r'\s+', '', text).lower()


def expr_text(expr):
    """Readable text of a <expression> tree (join clauses, relationships)."""
    if expr is None:
        return ''
    op = expr.get('op', '')
    kids = [k for k in expr if k.tag == 'expression']
    if not kids:
        return _strip_br_keep(op)
    if op in ('AND', 'OR') or len(kids) != 2:
        return f' {op} '.join(expr_text(k) for k in kids) if op else ' '.join(expr_text(k) for k in kids)
    return f'{expr_text(kids[0])} {op} {expr_text(kids[1])}'


def _strip_br_keep(s):
    return s


def expr_fields(expr):
    """Leaf field references of an expression, in order."""
    if expr is None:
        return []
    kids = [k for k in expr if k.tag == 'expression']
    if not kids:
        return [expr.get('op', '')]
    out = []
    for k in kids:
        out.extend(expr_fields(k))
    return out


def _field_table(ref):
    """'[Orders].[Customer ID]' -> ('Orders', 'Customer ID')"""
    parts = _BRACKET.findall(ref or '')
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return '', (parts[0] if parts else ref or '')


def release_from(version, build):
    m = re.match(r'\s*(\d{4})\.(\d+)', build or '')
    if m:
        return f'{m.group(1)}.{m.group(2)}'
    m = re.match(r'(\d+)\.(\d+)', version or '')
    if m:
        major, minor = int(m.group(1)), m.group(2)
        return f'20{major}.{minor}' if major >= 18 else f'{major}.{minor}'
    return ''


def _describe_groupfilter(gf):
    fn = gf.get('function', '')
    kids = [k for k in gf if k.tag == 'groupfilter']
    if fn == 'member':
        return (gf.get('member', '') or '').strip('"')
    if fn == 'level-members':
        return '(All values)'
    if fn == 'union':
        parts = [_describe_groupfilter(k) for k in kids]
        return '{' + ', '.join(parts) + '}' if all(k.get('function') == 'member' for k in kids) \
            else '(' + ' OR '.join(parts) + ')'
    if fn == 'except':
        return 'ALL EXCEPT ' + ', '.join(_describe_groupfilter(k) for k in kids[1:]) if len(kids) > 1 else 'ALL EXCEPT ...'
    if fn == 'intersection':
        return '(' + ' AND '.join(_describe_groupfilter(k) for k in kids) + ')'
    if fn == 'order':
        return f"TOP/BOTTOM by {gf.get('expression', '')} ({gf.get('direction', '')})"
    if fn == 'filter':
        return f"WHERE {gf.get('expression', '')}"
    if fn == 'count':
        return f"TOP {gf.get('count', '')}"
    inner = ', '.join(_describe_groupfilter(k) for k in kids)
    attrs = ', '.join(f'{k}={v}' for k, v in gf.attrib.items() if k in ('expression', 'count', 'direction', 'member'))
    return f'{fn}({inner or attrs})'


def describe_filter(f):
    cls = f.get('class', '')
    if cls == 'quantitative':
        lo, hi = _text(f, 'min'), _text(f, 'max')
        inc = f.get('included-values', '')
        return f"range {lo or '-inf'} .. {hi or '+inf'}" + (f' ({inc})' if inc else '')
    if cls == 'relative-date':
        return ', '.join(f'{k}={v}' for k, v in f.attrib.items()
                         if k in ('period-type-v2', 'first-period', 'last-period', 'period-anchor', 'include-future',
                                  'include-null'))
    gfs = [g for g in f if g.tag == 'groupfilter']
    if gfs:
        return ' AND '.join(_describe_groupfilter(g) for g in gfs)
    return ''


# --------------------------------------------------------------------------------------
# Single workbook analysis
# --------------------------------------------------------------------------------------

class WorkbookAnalyzer:
    def __init__(self, root, name, path='', is_twbx=False, file_size=0, modified='', package=None, kind='workbook'):
        _norm_tags(root)
        self.kind = kind
        self.no_consumers = kind == 'datasource'      # a .tds/.tdsx has no worksheets/dashboards that could use its fields
        self.root = root
        self.wb = name
        self.path = path
        self.is_twbx = is_twbx
        self.file_size = file_size
        self.modified = modified
        self.package = package or {}
        self.out = {k: [] for k in SCHEMAS}
        self.findings = []
        self.fields = {}          # ds -> OrderedDict(key -> field)
        self.ds_info = {}         # ds -> info dict
        self.tables = {}          # ds -> [table dicts]
        self.alias_tables = {}    # ds -> {alias_lower: [table dicts]}
        self.ws_names = []
        self._ftables_memo = {}

    # ------------------------------------------------------------------ utilities
    def add_finding(self, ftype, severity, otype, oname, ds='', details=''):
        self.findings.append({'Workbook': self.wb, 'Finding Type': ftype, 'Severity': severity,
                              'Object Type': otype, 'Object Name': oname, 'Datasource': ds, 'Details': details})

    def ds_caption(self, ds):
        info = self.ds_info.get(ds)
        return (info['caption'] or ds) if info else ds

    # ------------------------------------------------------------------ main
    def run(self):
        self._workbook_info()
        self._windows()
        self._datasources()
        self._worksheets()
        self._dashboards()
        self._other_refs()
        self._resolve_calculations()
        self._usage()
        self._emit_tables_usage()
        self._emit_calculations()
        self._emit_parameters()
        self._emit_worksheets_dashboards()
        self._emit_field_usage_and_impact()
        self._emit_lineage()
        self._quality_checks()
        self._emit_datasource_inventory()
        self._emit_summary()
        self.out['data_quality'] = self.findings
        return self.out

    # ------------------------------------------------------------------ workbook / windows
    def _workbook_info(self):
        r = self.root
        self.version = r.get('version', '')
        self.original_version = r.get('original-version', '')
        self.build = r.get('source-build', '')
        self.platform = r.get('source-platform', '')
        repo = r.find('repository-location')
        if repo is None:                       # .tds / .tdsx: the datasource itself carries the repository info
            repo = r.find('datasources/datasource/repository-location')
        self.repo = repo.attrib if repo is not None else {}
        self.description = ''
        for tag in ('description',):
            d = r.find(tag)
            if d is not None:
                self.description = ''.join(d.itertext()).strip()

    def _windows(self):
        self.hidden_windows = {}
        for w in self.root.iter('window'):
            if w.get('name'):
                self.hidden_windows[(w.get('class', ''), w.get('name'))] = str(w.get('hidden', '')).lower() == 'true'

    def _is_hidden(self, cls, name):
        return self.hidden_windows.get((cls, name), False)

    # ------------------------------------------------------------------ datasources
    def _datasources(self):
        dss = self.root.find('datasources')
        self.ds_order = []
        if dss is None:
            return
        for ds in dss.findall('datasource'):
            name = ds.get('name', '')
            if not name:
                continue
            self.ds_order.append(name)
            is_params = name == 'Parameters'
            caption = ds.get('caption', '') or name
            top = ds.find('connection')
            extract = ds.find('extract')
            named = OrderedDict()
            for nc in ds.iter('named-connection'):
                inner = nc.find('.//connection')
                if inner is not None:
                    named[nc.get('name', '')] = (nc.get('caption', ''), inner)
            info = {
                'name': name, 'caption': caption, 'version': ds.get('version', ''), 'is_params': is_params,
                'hidden': str(ds.get('hidden', '')).lower() == 'true', 'top': top, 'named': named, 'el': ds,
                'top_class': top.get('class', '') if top is not None else '',
                'uses_extract': extract is not None and str(extract.get('enabled', 'true')).lower() != 'false',
                'published': '', 'connections': [], 'custom_sql': 0,
            }
            self.ds_info[name] = info
            self.tables[name] = []
            self.alias_tables[name] = {}
            self.fields[name] = self._load_fields(ds, is_params)
            if is_params:
                continue
            self._connections(info)
            self._relations(info)
            self._ds_filters(info)
            self._ds_type(info)

    def _ds_type(self, info):
        classes = {c['class'] for c in info['connections']}
        top_class = info['top_class']
        if info['published']:
            t = 'Published'
        elif 'excel-direct' in classes:
            t = 'Excel'
        elif 'textscan' in classes:
            t = 'CSV / Text'
        elif top_class == 'hyper' or ('hyper' in classes and not (classes - {'hyper'})):
            t = 'Hyper'
        elif top_class == 'federated':
            t = 'Federated'
        else:
            t = 'Embedded'
        info['type'] = t
        info['class'] = top_class or (sorted(classes)[0] if classes else '')

    def _connection_row(self, info, role, cname, conn):
        cls = conn.get('class', '')
        ssl = _lst((f'{k}={v}' for k, v in conn.attrib.items()
                    if any(s in k.lower() for s in ('ssl', 'encrypt', 'trust', 'certificate'))), 0)
        auth = auth_label(conn.get('authentication', '') or ('oauth' if conn.get('oauth-config-id') else ''))
        row = {
            'class': cls, 'role': role, 'name': cname, 'type': friendly_connection(cls),
            'server': conn.get('server', ''), 'port': conn.get('port', ''),
            'database': conn.get('dbname', '') or conn.get('catalog', '') or conn.get('dataset', ''),
            'schema': conn.get('schema', ''), 'warehouse': conn.get('warehouse', ''),
            'catalog': conn.get('catalog', ''), 'username': conn.get('username', ''), 'auth': auth,
            'ssl': ssl, 'http': conn.get('http-path', '') or conn.get('service', ''),
            'file': conn.get('filename', '') or conn.get('directory', ''),
            'initial_sql': conn.get('one-time-sql', ''), 'el': conn,
        }
        info['connections'].append(row)
        return row

    def _connections(self, info):
        top = info['top']
        if top is not None and top.get('class') == 'sqlproxy':
            # real workbooks: <datasource><repository-location/><connection class='sqlproxy'/></datasource>
            repo = info['el'].find('repository-location')
            if repo is None:
                repo = top.find('.//repository-location')
            pub = (repo.get('id') if repo is not None and repo.get('id') else info['caption'])
            info['published'] = pub
            row = self._connection_row(info, 'Published', pub, top)
            row['file'] = ''
            if repo is None:
                self.add_finding('Invalid Connection', 'Warning', 'Datasource', info['caption'], info['name'],
                                 'Published datasource connection has no repository-location (server reference missing)')
            return
        if top is not None and top.get('class') != 'federated':
            self._connection_row(info, 'Primary', '', top)
        for cname, (cap, inner) in info['named'].items():
            self._connection_row(info, 'Named', cap or cname, inner)
        ex = info['el'].find('extract')
        if ex is not None:
            for c in ex.iter('connection'):
                self._connection_row(info, 'Extract', c.get('dbname', ''), c)
                break
        for c in info['connections']:
            if c['class'] in _DEPRECATED_CLASSES:
                self.add_finding('Deprecated Object', 'Info', 'Connection', c['type'] or c['class'], info['name'],
                                 _DEPRECATED_CLASSES[c['class']])
            if c['role'] != 'Extract':
                if c['class'] in _SERVER_CLASSES and not c['server'] and c['class'] not in ('genericodbc', 'odbc'):
                    self.add_finding('Invalid Connection', 'Warning', 'Connection', c['type'], info['name'],
                                     f"{c['type']} connection has no server configured")
                if c['class'] in ('excel-direct', 'textscan', 'msaccess', 'json', 'pdf') and c['file']:
                    self._check_file(info, c)

    def _check_file(self, info, c):
        fn = c['file']
        base = os.path.basename(fn.replace('\\', '/'))
        if self.is_twbx:
            files = self.package.get('files_lower', set())
            if not any(f.endswith('/' + base.lower()) or f == base.lower() for f in files):
                self.add_finding('Invalid Connection', 'Warning', 'Connection', fn, info['name'],
                                 'File data source is not packaged inside the .twbx (external file reference)')
        elif fn and not os.path.exists(fn):
            self.add_finding('Invalid Connection', 'Info', 'Connection', fn, info['name'],
                             'Referenced data file was not found on this machine')

    # ------------------------------------------------------------------ fields
    def _load_fields(self, ds, is_params):
        fields = OrderedDict()

        def new(name):
            return {'name': name, 'caption': '', 'datatype': '', 'role': '', 'type': '', 'hidden': False,
                    'formula': None, 'table': '', 'physical': '', 'is_param': is_params, 'value': '',
                    'domain': '', 'members': [], 'range': '', 'folder': '', 'auto': False}

        for mr in ds.iter('metadata-record'):
            if mr.get('class') != 'column':
                continue
            local = _strip_br(_text(mr, 'local-name'))
            if not local:
                continue
            f = fields.setdefault(local, new(local))
            f['table'] = f['table'] or _strip_br(_text(mr, 'parent-name'))
            f['physical'] = f['physical'] or _text(mr, 'remote-name')
            f['datatype'] = f['datatype'] or _text(mr, 'local-type')
        for cols in ds.iter('cols'):
            for m in cols.findall('map'):
                key = _strip_br(m.get('key', ''))
                tbl, col = _field_table(m.get('value', ''))
                f = fields.get(key)
                if f is not None and not f['table']:
                    f['table'] = tbl
                    f['physical'] = f['physical'] or col
        for col in ds.findall('column'):
            name = _strip_br(col.get('name', ''))
            if not name:
                continue
            f = fields.setdefault(name, new(name))
            f['caption'] = col.get('caption', '') or f['caption']
            f['datatype'] = col.get('datatype', '') or f['datatype']
            f['role'] = col.get('role', '') or f['role']
            f['type'] = col.get('type', '') or f['type']
            f['hidden'] = str(col.get('hidden', '')).lower() == 'true' or f['hidden']
            calc = col.find('calculation')
            if calc is not None and calc.get('formula') is not None and calc.get('class', 'tableau') == 'tableau':
                f['formula'] = calc.get('formula', '')
            f['domain'] = col.get('param-domain-type', '')
            f['value'] = col.get('value', '')
            f['members'] = [(m.get('value', ''), m.get('alias', '')) for m in col.iter('member')]
            rg = col.find('range')
            if rg is not None:
                f['range'] = f"{rg.get('min', '')} .. {rg.get('max', '')}" + (
                    f" step {rg.get('granularity')}" if rg.get('granularity') else '')
        for fo in ds.iter('folder'):
            for it in fo.iter('folder-item'):
                f = fields.get(_strip_br(it.get('name', '')))
                if f is not None:
                    f['folder'] = fo.get('name', '')
        for f in fields.values():
            n = f['name'].lower()
            f['auto'] = n in _AUTO_FIELDS or n.startswith(':') or n.startswith('__tableau') or 'generated' in n
            if not f['role'] and not is_params:
                f['role'] = 'measure' if f['datatype'] in ('integer', 'real') else 'dimension'
        return fields

    def caption_of(self, ds, key):
        f = self.fields.get(ds, {}).get(key)
        return (f['caption'] or f['name']) if f else key

    # ------------------------------------------------------------------ tables / joins / relationships / custom SQL
    def _relations(self, info):
        ds = info['name']
        el = info['el']
        skip = set()
        for ex in el.iter('extract'):
            for x in ex.iter():
                skip.add(id(x))
        seen = set()
        logical = {}
        og = el.find('object-graph')
        if og is not None:
            for obj in og.iter('object'):
                for rel in obj.iter('relation'):
                    logical[id(rel)] = obj.get('caption', '') or obj.get('id', '')
            self._object_relationships(info, og)

        def conn_for(rel):
            link = rel.get('connection', '')
            if link and link in info['named']:
                return info['named'][link][1], info['named'][link][0] or link
            if link and link not in info['named'] and info['top'] is not None and info['top'].get('class') == 'federated':
                self.add_finding('Invalid Connection', 'Error', 'Table', rel.get('name', ''), ds,
                                 f"Relation references undefined named connection '{link}'")
            if info['top'] is not None and info['top'].get('class') not in ('federated', 'sqlproxy'):
                return info['top'], ''
            first = next(iter(info['named'].values()), None)
            return (first[1], first[0]) if first else (info['top'], '')

        seen_struct = set()

        def leaf(rel):
            if id(rel) in skip:
                return
            key = (rel.get('connection', ''), rel.get('name', ''), rel.get('table', ''), rel.get('type', ''),
                   (rel.text or '').strip()[:80])
            if key in seen:
                return
            seen.add(key)
            conn, cname = conn_for(rel)
            if conn is not None and conn.get('class') == 'sqlproxy':
                return
            cls = conn.get('class', '') if conn is not None else ''
            rtype = rel.get('type', '')
            alias = rel.get('name', '')
            ref = rel.get('table', '')
            db_, sch, tbl = SqlTableParser_split(ref or alias)
            base = {
                'alias': alias, 'logical': logical.get(id(rel), '') or alias, 'connection_type': friendly_connection(cls),
                'server': conn.get('server', '') if conn is not None else '',
                'database': db_ or (conn.get('dbname', '') if conn is not None else ''),
                'schema': sch or (conn.get('schema', '') if conn is not None else ''), 'ref': ref, 'el': rel,
                'class': cls, 'conn': conn,
            }
            if rtype == 'text':
                sql = (rel.text or '').strip()
                info['custom_sql'] += 1
                t = dict(base, name=alias or 'Custom SQL', kind='Custom SQL', source='Custom SQL', physical='(custom SQL)',
                         sql=sql)
                self._custom_sql_rows(info, alias or 'Custom SQL', sql, conn, 'Relation')
                info['tables_from_sql'] = info.get('tables_from_sql', {})
                parsed = SqlTableParser.parse(sql)
                info['tables_from_sql'][alias.lower()] = parsed['tables']
                self.tables[ds].append(t)
                self._register_alias(ds, t['alias'], t)
                self._register_alias(ds, t['logical'], t)
                for pt in parsed['tables']:
                    ptd = dict(base, name=pt['table'], schema=pt['schema'], database=pt['database'] or base['database'],
                               kind='Table (parsed from custom SQL)', source='Custom SQL (parsed)',
                               physical=pt['fqn'], alias=alias, sql='')
                    self.tables[ds].append(ptd)
                    self._register_alias(ds, alias, ptd)
                    self._register_alias(ds, t['logical'], ptd)
                return
            kind = 'Stored Procedure' if rtype == 'stored-proc' else 'Table'
            t = dict(base, name=tbl or alias, kind=kind, source='Relation',
                     physical='.'.join(x for x in (db_, sch, tbl) if x) or ref or alias, sql='')
            if not t['name']:
                return
            self.tables[ds].append(t)
            self._register_alias(ds, alias, t)
            self._register_alias(ds, t['logical'], t)
            self._register_alias(ds, tbl, t)

        def walk(rel, level):
            if id(rel) in skip:
                return
            rtype = rel.get('type', '')
            kids = [k for k in rel if k.tag == 'relation']
            if rel.get('join') or rtype == 'join':
                clauses = [c for c in rel if c.tag == 'clause']
                exprs = [e for c in clauses for e in c if e.tag == 'expression']
                clause_txt = ' AND '.join(expr_text(e) for e in exprs)
                lf = rf = ''
                if exprs:
                    fl = expr_fields(exprs[0])
                    if len(fl) >= 2:
                        lf, rf = fl[0], fl[1]
                left = self._describe_rel(kids[0]) if kids else ''
                right = self._describe_rel(kids[1]) if len(kids) > 1 else ''
                skey = ('join', rel.get('join', ''), left, right, clause_txt)
                if skey in seen_struct:
                    return
                seen_struct.add(skey)
                self.out['join_analysis'].append({
                    'Workbook': self.wb, 'Datasource': info['caption'], 'Join Type': rel.get('join', '') or 'join',
                    'Left Table': left, 'Right Table': right, 'Left Field': lf, 'Right Field': rf,
                    'Join Clause': clause_txt, 'Nesting Level': level})
                for k in kids:
                    walk(k, level + 1)
            elif rtype in ('union', 'collection'):
                members = [self._describe_rel(k) for k in kids]
                skey = ('union', rel.get('name', ''), tuple(members))
                if skey in seen_struct:
                    return
                seen_struct.add(skey)
                self.out['relationship_analysis'].append({
                    'Workbook': self.wb, 'Datasource': info['caption'], 'Type': 'Union',
                    'Name': rel.get('name', ''), 'Left Table': '', 'Right Table': '', 'Left Field': '',
                    'Right Field': '', 'Clause': '', 'Details': f"{len(members)} table(s): " + _lst(members)})
                for k in kids:
                    walk(k, level + 1)
            else:
                leaf(rel)

        for holder in ([info['top']] if info['top'] is not None else []) + [el]:
            for rel in holder.findall('relation'):
                walk(rel, 0)
        if og is not None:
            for obj in og.iter('object'):
                for rel in obj.findall('properties/relation'):
                    walk(rel, 0)
        # relations that were not reached through the structured walk (defensive; de-duplicated by `seen`)
        for rel in el.iter('relation'):
            if not any(k.tag == 'relation' for k in rel) and rel.get('type', '') not in ('join', 'union', 'collection'):
                leaf(rel)

    def _describe_rel(self, rel):
        if rel.get('join') or rel.get('type') == 'join':
            leafs = []
            for r in rel.iter('relation'):
                if not any(k.tag == 'relation' for k in r) and r.get('name'):
                    leafs.append(r.get('name'))
            return '(' + ' + '.join(leafs) + ')'
        return rel.get('name', '') or rel.get('table', '')

    def _register_alias(self, ds, alias, table):
        if alias:
            lst = self.alias_tables[ds].setdefault(alias.lower(), [])
            if table not in lst:
                lst.append(table)

    def _object_relationships(self, info, og):
        objs = {o.get('id', ''): o.get('caption', '') or o.get('id', '') for o in og.iter('object')}
        for r in og.iter('relationship'):
            fe, se = r.find('first-end-point'), r.find('second-end-point')
            expr = r.find('expression')
            fl = expr_fields(expr) if expr is not None else []
            self.out['relationship_analysis'].append({
                'Workbook': self.wb, 'Datasource': info['caption'], 'Type': 'Relationship',
                'Name': '', 'Left Table': objs.get(fe.get('object-id', ''), fe.get('object-id', '')) if fe is not None else '',
                'Right Table': objs.get(se.get('object-id', ''), se.get('object-id', '')) if se is not None else '',
                'Left Field': _strip_br(fl[0]) if fl else '', 'Right Field': _strip_br(fl[1]) if len(fl) > 1 else '',
                'Clause': expr_text(expr) if expr is not None else '',
                'Details': _lst([r.get('type', ''), (f"cardinality: {fe.get('is-many')}/{se.get('is-many')}"
                                                        if fe is not None and se is not None and fe.get('is-many') else '')])})

    def _custom_sql_rows(self, info, name, sql, conn, source):
        parsed = SqlTableParser.parse(sql)
        base = {'Workbook': self.wb, 'Datasource': info['caption'], 'Custom SQL Name': name, 'Source': source,
                'Connection Type': friendly_connection(conn.get('class', '')) if conn is not None else '',
                'Server': conn.get('server', '') if conn is not None else '',
                'Database': conn.get('dbname', '') if conn is not None else '', 'Query Length': len(sql),
                'CTEs': _lst(parsed['ctes']), 'SQL Query': sql}
        if not parsed['tables']:
            self.out['custom_sql'].append(dict(base, **{'Referenced Table': '', 'Referenced Database': '',
                                                         'Referenced Schema': '', 'Table Name': '',
                                                         'Reference Type': ''}))
        for t in parsed['tables']:
            self.out['custom_sql'].append(dict(base, **{
                'Referenced Table': t['fqn'], 'Referenced Database': t['database'], 'Referenced Schema': t['schema'],
                'Table Name': t['table'], 'Reference Type': ', '.join(t['kinds'])}))

    def _ds_filters(self, info):
        ex = info['el'].find('extract')
        if ex is not None:
            for f in ex.iter('filter'):
                self._filter_row('Extract filter', '', info['name'], f)

    # ------------------------------------------------------------------ worksheets
    def _worksheets(self):
        self.ws = OrderedDict()
        root_ws = self.root.find('worksheets')
        if root_ws is None:
            return
        for w in root_ws.findall('worksheet'):
            name = w.get('name', '')
            view = w.find('table/view')
            title = ''
            t = w.find('layout-options/title')
            if t is not None:
                title = ''.join(t.itertext()).strip()
            mark = w.find('table/panes/pane/mark')
            ds_list = []
            deps = []
            if view is not None:
                dl = view.find('datasources')
                if dl is not None:
                    ds_list = [d.get('name', '') for d in dl.findall('datasource')]
                deps = view.findall('datasource-dependencies')
            allf, direct = set(), set()
            inst_map, roles = {}, {}
            for dep in deps:
                dsn = dep.get('datasource', '')
                for c in dep.findall('column'):
                    key = _strip_br(c.get('name', ''))
                    allf.add((dsn, key))
                    if c.get('role'):
                        roles[(dsn, key)] = c.get('role')
                for ci in dep.findall('column-instance'):
                    col = _strip_br(ci.get('column', ''))
                    inst_map[(dsn, _strip_br(ci.get('name', '')))] = col
                    direct.add((dsn, col))
                    allf.add((dsn, col))
            shelf_text = {}
            for tag in ('rows', 'cols'):
                el = w.find(f'table/{tag}')
                shelf_text[tag] = (el.text or '').strip() if el is not None else ''
            refs = []
            for txt in shelf_text.values():
                refs.extend(re.findall(r'\[[^\]]+\]\.\[[^\]]+\]|\[[^\]]+\]', txt))
            for enc in w.findall('table/panes/pane/encodings/*'):
                if enc.get('column'):
                    refs.append(enc.get('column'))
            flt = []
            if view is not None:
                for f in view.findall('filter'):
                    flt.append(f)
                    if f.get('column'):
                        refs.append(f.get('column'))
            default_ds = ds_list[0] if ds_list else ''
            for ref in refs:
                dsn, deriv, fname, _sfx = parse_ref(ref)
                dsn = dsn or default_ds
                parts = _BRACKET.findall(ref)
                col = inst_map.get((dsn, parts[-1]), fname) if parts else fname
                direct.add((dsn, col))
                allf.add((dsn, col))
            self.ws[name] = {
                'name': name, 'title': title, 'mark': mark.get('class', '') if mark is not None else '',
                'datasources': ds_list, 'all': allf, 'direct': direct, 'filters': flt, 'shelves': shelf_text,
                'hidden': self._is_hidden('worksheet', name), 'dashboards': [], 'inst_map': inst_map, 'roles': roles,
            }
            for f in flt:
                self._filter_row('Worksheet filter', name, '', f, ds_list, inst_map)

    def _filter_row(self, scope, ws, ds, f, ds_list=None, inst_map=None):
        col = f.get('column', '')
        dsn, deriv, fname, _s = parse_ref(col)
        dsn = dsn or ds or ((ds_list or [''])[0] if ds_list else '')
        real = _strip_br(inst_map.get((dsn, fname), fname)) if inst_map else fname
        ctx = _bool(f.get('context', ''))
        self.out['filters'].append({
            'Workbook': self.wb, 'Scope': scope, 'Worksheet': ws, 'Datasource': self.ds_caption(dsn),
            'Filter Name': self.caption_of(dsn, real), 'Filter Type': f.get('class', ''),
            'Applied Field': f"{self.caption_of(dsn, real)}" + (f' ({deriv})' if deriv and deriv not in ('none', 'usr') else ''),
            'Filter Logic': describe_filter(f), 'Context Filter': ctx, 'Dashboards': ''})

    # ------------------------------------------------------------------ dashboards / stories
    def _dashboards(self):
        self.dash = OrderedDict()
        self.stories = OrderedDict()
        root_d = self.root.find('dashboards')
        if root_d is None:
            return
        actions = defaultdict(int)
        for a in self.root.iter('action'):
            src = a.find('source')
            if src is not None and src.get('dashboard'):
                actions[src.get('dashboard')] += 1
        for d in root_d.findall('dashboard'):
            name = d.get('name', '')
            is_story = d.get('type', '') == 'storyboard'
            zones = list(d.iter('zone'))
            leaf = [z for z in zones if not any(k.tag == 'zone' for k in z)]
            containers = [z for z in zones if any(k.tag == 'zone' for k in z)]
            sheets, filters, params, other, unresolved = [], [], [], [], []
            for z in leaf:
                zt = z.get('type-v2') or z.get('type') or ''
                zn = z.get('name', '')
                if zt == 'filter':
                    filters.append(z.get('param', ''))
                elif zt == 'paramctrl':
                    params.append(z.get('param', ''))
                elif zn in self.ws and zt in ('', 'viz'):
                    sheets.append(zn)
                elif zn in self.ws:
                    sheets.append(zn)
                else:
                    if zn and zt in ('', 'viz'):
                        unresolved.append(zn)           # named sheet zone - checked against dashboards later
                    other.append(zt or 'object')
            size = d.find('size')
            sz = ''
            if size is not None:
                sz = f"{size.get('sizing-mode', '')} {size.get('maxwidth', size.get('minwidth', ''))}x{size.get('maxheight', size.get('minheight', ''))}".strip()
            rec = {'name': name, 'unresolved': unresolved, 'sheets': list(dict.fromkeys(sheets)), 'filters': filters, 'params': params,
                   'other': other, 'leaf': len(leaf), 'containers': len(containers), 'size': sz,
                   'hidden': self._is_hidden('dashboard', name), 'actions': actions.get(name, 0),
                   'zones_all': [z.get('name', '') for z in zones if z.get('name')]}
            if is_story:
                points = []
                for sp in d.iter('story-point'):
                    points.append({'id': sp.get('id', ''), 'caption': sp.get('caption', '') or sp.get('name', ''),
                                   'ref': sp.get('captured-sheet', '')})
                rec['points'] = points
                self.stories[name] = rec
            else:
                self.dash[name] = rec
        for dn, dr in self.dash.items():
            for s in dr['sheets']:
                if s in self.ws:
                    self.ws[s]['dashboards'].append(dn)

    # ------------------------------------------------------------------ other references (actions, hierarchies ...)
    def _other_refs(self):
        names = set()
        for tag in ('actions', 'drill-paths'):
            for el in self.root.iter(tag):
                for x in el.iter():
                    for v in list(x.attrib.values()) + [x.text or '']:
                        for m in _BRACKET.findall(v or ''):
                            names.add(m.split(':')[1] if m.count(':') >= 2 else m)
        for ds in self.ds_info.values():
            for g in ds['el'].iter('group'):
                for m in _BRACKET.findall(g.get('name', '') + ' '.join(str(v) for v in g.attrib.values())):
                    names.add(m)
        self.other_ref_names = {n.lower() for n in names}

    # ------------------------------------------------------------------ calculations
    def _resolve_ref(self, ds, a, b):
        """-> ('param', key) | ('field', key) | ('missing', name)"""
        if a == 'Parameters':
            return ('param', b)
        f = self.fields.get(ds, {})
        if b in f:
            return ('field', b)
        for k, v in f.items():
            if v['caption'] == b:
                return ('field', k)
        pf = self.fields.get('Parameters', {})
        if b in pf:
            return ('param', b)
        for k, v in pf.items():
            if v['caption'] == b:
                return ('param', k)
        return ('missing', b)

    def _resolve_calculations(self):
        self.calc_deps = {}          # (ds,key) -> {'fields': set, 'params': set, 'missing': list}
        self.referenced_by = defaultdict(set)
        for ds, flds in self.fields.items():
            if ds == 'Parameters':
                continue
            for key, f in flds.items():
                if f['formula'] is None:
                    continue
                deps = {'fields': set(), 'params': set(), 'missing': []}
                for a, b in formula_refs(f['formula']):
                    kind, name = self._resolve_ref(ds, a, b)
                    if kind == 'field':
                        if name != key:
                            deps['fields'].add(name)
                            self.referenced_by[(ds, name)].add(key)
                    elif kind == 'param':
                        deps['params'].add(name)
                        self.referenced_by[('Parameters', name)].add(key)
                    else:
                        low = name.lower()
                        if not (low in _AUTO_FIELDS or name.startswith(':') or name.startswith('__tableau')
                                or a and a != 'Parameters' and a.lower() in (self.alias_tables.get(ds, {}) or {})):
                            deps['missing'].append(name)
                self.calc_deps[(ds, key)] = deps
        # parameters referenced from calculations that live in any datasource
        # (already covered above through ('Parameters', name) keys)

    # ------------------------------------------------------------------ usage
    def _usage(self):
        self.field_ws = defaultdict(set)        # (ds,key) -> worksheets
        self.field_dash = defaultdict(set)      # (ds,key) -> dashboards
        ds_by_internal = self.ds_info
        for wn, w in self.ws.items():
            for dsn, key in w['all']:
                if dsn in self.fields:
                    self.field_ws[(dsn, key)].add(wn)
                    for k2 in self._deps_closure(dsn, key):
                        if isinstance(k2, tuple):
                            self.field_ws[('Parameters', k2[1])].add(wn)      # parameter used through a calculation
                        else:
                            self.field_ws[(dsn, k2)].add(wn)
                elif dsn:
                    self.add_finding('Broken Reference', 'Error', 'Worksheet', wn, dsn,
                                     f"Worksheet uses datasource '{dsn}' which is not defined in the workbook")
        for dn, d in self.dash.items():
            for s in d['sheets']:
                w = self.ws.get(s)
                if not w:
                    continue
                for dsn, key in w['all']:
                    self.field_dash[(dsn, key)].add(dn)
            for ref in d['filters'] + d['params']:
                dsn, deriv, fname, _s = parse_ref(ref)
                if dsn in self.fields:
                    for real in [fname] + list(self._alias_from_instances(dsn, fname)):
                        if real in self.fields[dsn]:
                            self.field_dash[(dsn, real)].add(dn)
        # propagate dashboard usage through calculation dependencies
        for (dsn, key), ds_set in list(self.field_dash.items()):
            for k2 in self._deps_closure(dsn, key):
                if isinstance(k2, tuple):
                    self.field_dash[('Parameters', k2[1])] |= ds_set
                else:
                    self.field_dash[(dsn, k2)] |= ds_set

    def _alias_from_instances(self, dsn, inst):
        for w in self.ws.values():
            v = w['inst_map'].get((dsn, inst))
            if v:
                yield v

    def _deps_closure(self, ds, key, _seen=None):
        """All fields (and ('P', param) markers) a calculation depends on, transitively. Iterative: deep calculation
        chains must not exhaust the (small) stack of a worker thread."""
        seen = _seen if _seen is not None else set()
        stack = [key]
        while stack:
            d = self.calc_deps.get((ds, stack.pop()))
            if not d:
                continue
            for k in d['fields']:
                if k not in seen:
                    seen.add(k)
                    stack.append(k)
            for p in d['params']:
                seen.add(('P', p))
        return seen

    def _field_tables(self, ds, key, _stack=None):
        memo_key = (ds, key)
        if memo_key in self._ftables_memo:
            return self._ftables_memo[memo_key]
        stack = _stack or set()
        if memo_key in stack or len(stack) > 150:        # cycle / pathological calculation chain
            return []
        stack = stack | {memo_key}
        f = self.fields.get(ds, {}).get(key)
        result = []
        info = self.ds_info.get(ds)
        if f is None or info is None or info['is_params']:
            return []
        if info['published']:
            result = [self._published_table(info)]
        elif f['formula'] is not None:
            for k in self.calc_deps.get((ds, key), {'fields': ()})['fields']:
                for t in self._field_tables(ds, k, stack):
                    if t not in result:
                        result.append(t)
        else:
            result = list(self.alias_tables[ds].get(f['table'].lower(), []))
            if not result and len({id(t) for t in self.tables[ds]}) == 1:
                result = list(self.tables[ds])
        self._ftables_memo[memo_key] = result
        return result

    def _published_table(self, info):
        t = info.get('_pub_table')
        if t is None:
            c = info['connections'][0] if info['connections'] else {}
            t = {'name': info['published'], 'schema': '', 'database': c.get('database', ''), 'alias': '',
                 'logical': info['published'], 'connection_type': 'Published Data Source', 'server': c.get('server', ''),
                 'kind': 'Published Datasource', 'source': 'Published', 'physical': info['published'], 'sql': '',
                 'class': 'sqlproxy', 'conn': None, 'ref': ''}
            info['_pub_table'] = t
        return t

    @staticmethod
    def _tfqn(t):
        if t['kind'] == 'Published Datasource':
            return f"(published) {t['name']}"
        if t['kind'] == 'Custom SQL':
            return f"(Custom SQL) {t['name']}"
        return '.'.join(x for x in (t.get('database', ''), t.get('schema', ''), t['name']) if x)

    # ------------------------------------------------------------------ emitters
    def _emit_tables_usage(self):
        self.table_ws = defaultdict(set)
        self.table_dash = defaultdict(set)
        self.table_fields = defaultdict(set)
        for ds, flds in self.fields.items():
            if ds == 'Parameters' or ds not in self.ds_info:
                continue
            for key in flds:
                tabs = self._field_tables(ds, key)
                for t in tabs:
                    self.table_fields[(ds, id(t))].add(key)
                    self.table_ws[(ds, id(t))] |= self.field_ws.get((ds, key), set())
                    self.table_dash[(ds, id(t))] |= self.field_dash.get((ds, key), set())
        col_counts = defaultdict(int)
        for ds, flds in self.fields.items():
            for f in flds.values():
                if f['table'] and f['formula'] is None:
                    col_counts[(ds, f['table'].lower())] += 1
        for ds, tabs in self.tables.items():
            info = self.ds_info[ds]
            for t in tabs:
                if t['kind'] == 'Table (parsed from custom SQL)':
                    cols = ''
                else:
                    cols = col_counts.get((ds, t['alias'].lower()), col_counts.get((ds, t['logical'].lower()), ''))
                self.out['table_inventory'].append({
                    'Workbook': self.wb, 'Datasource': info['caption'], 'Connection Type': t['connection_type'],
                    'Server': t['server'], 'Database': t['database'], 'Schema': t['schema'], 'Table Name': t['name'],
                    'Full Table Name': self._tfqn(t), 'Table Alias': t['alias'] if t['alias'] != t['name'] else '',
                    'Logical Table': t['logical'], 'Physical Table': t['physical'], 'Table Kind': t['kind'],
                    'Source': t['source'], 'Columns': cols,
                    'Worksheets Using': len(self.table_ws.get((ds, id(t)), ())),
                    'Dashboards Using': len(self.table_dash.get((ds, id(t)), ()))})
        for ds, info in self.ds_info.items():
            if info['published']:
                t = self._published_table(info)
                self.out['table_inventory'].append({
                    'Workbook': self.wb, 'Datasource': info['caption'], 'Connection Type': t['connection_type'],
                    'Server': t['server'], 'Database': t['database'], 'Schema': '', 'Table Name': t['name'],
                    'Full Table Name': self._tfqn(t), 'Table Alias': '', 'Logical Table': t['name'],
                    'Physical Table': t['name'], 'Table Kind': t['kind'], 'Source': 'Published', 'Columns': '',
                    'Worksheets Using': len({w for k in self.fields[ds] for w in self.field_ws.get((ds, k), ())}),
                    'Dashboards Using': len({d for k in self.fields[ds] for d in self.field_dash.get((ds, k), ())})})
        # connection inventory (needs table counts)
        for ds, info in self.ds_info.items():
            if info['is_params']:
                continue
            for c in info['connections']:
                n = len([t for t in self.tables[ds] if t['conn'] is c['el']])
                self.out['connection_inventory'].append({
                    'Workbook': self.wb, 'Datasource': info['caption'], 'Connection Role': c['role'],
                    'Connection Name': c['name'], 'Connection Type': c['type'], 'DB Class': c['class'],
                    'Server': c['server'], 'Port': c['port'], 'Database': c['database'], 'Schema': c['schema'],
                    'Warehouse': c['warehouse'], 'Catalog': c['catalog'], 'Username': c['username'],
                    'Authentication Mode': c['auth'], 'SSL Settings': c['ssl'], 'HTTP Path / Service': c['http'],
                    'File / Directory': c['file'], 'Initial SQL': c['initial_sql'], 'Tables': n})
                if c['initial_sql'].strip():
                    self._custom_sql_rows(info, 'Initial SQL', c['initial_sql'], c['el'], 'Initial SQL')

    def _emit_calculations(self):
        used_seed = set()
        for (dsn, key), wsset in self.field_ws.items():
            if wsset:
                used_seed.add((dsn, key))
        for (dsn, key), dset in self.field_dash.items():
            if dset:
                used_seed.add((dsn, key))
        self.used_fields = set(used_seed)
        for (dsn, key) in list(used_seed):
            for k2 in self._deps_closure(dsn, key):
                if not isinstance(k2, tuple):
                    self.used_fields.add((dsn, k2))
        for ds, flds in self.fields.items():
            for key, f in flds.items():
                if (f['caption'] or key).lower() in self.other_ref_names or key.lower() in self.other_ref_names:
                    self.used_fields.add((ds, key))
        by_hash = defaultdict(list)
        self.calc_status = {}
        for ds, flds in self.fields.items():
            if ds == 'Parameters':
                continue
            for key, f in flds.items():
                if f['formula'] is None:
                    continue
                by_hash[normalize_formula(f['formula'])].append((ds, key))
        dup_of = {}
        for h, members in by_hash.items():
            if len(members) > 1 and len(h) >= 8:
                first = members[0]
                for m in members[1:]:
                    dup_of[m] = self.caption_of(*first)
        self.dup_of = dup_of
        for ds, flds in self.fields.items():
            if ds == 'Parameters':
                continue
            info = self.ds_info[ds]
            for key, f in flds.items():
                if f['formula'] is None:
                    continue
                d = self.calc_deps.get((ds, key), {'fields': set(), 'params': set(), 'missing': []})
                refd = self.referenced_by.get((ds, key), set())
                used = (ds, key) in self.used_fields
                orphan = not refd and not self.field_ws.get((ds, key)) and not self.field_dash.get((ds, key)) \
                    and (f['caption'] or key).lower() not in self.other_ref_names
                status = 'Used' if used else ('Orphan (never referenced)' if orphan else 'Unused (only used by unused calcs)')
                if self.no_consumers:
                    status = 'n/a (datasource file)'
                self.calc_status[(ds, key)] = status
                text = f['formula']
                self.out['calculated_fields'].append({
                    'Workbook': self.wb, 'Datasource': info['caption'], 'Calculation Name': f['caption'] or key,
                    'Internal Name': key, 'Formula': text, 'Data Type': f['datatype'], 'Role': f['role'],
                    'Folder': f['folder'], 'Hidden': _bool(f['hidden']),
                    'Is LOD': 'Yes' if re.search(r'\{\s*(FIXED|INCLUDE|EXCLUDE)\b', text, re.I) else '',
                    'Is Table Calc': 'Yes' if re.search(
                        r'\b(WINDOW_\w+|RUNNING_\w+|LOOKUP|INDEX|FIRST|LAST|SIZE|RANK\w*|PREVIOUS_VALUE|TOTAL|SCRIPT_\w+)\s*\(',
                        text, re.I) else '',
                    'Is Aggregate': 'Yes' if re.search(
                        r'\b(SUM|AVG|COUNTD|COUNT|MIN|MAX|MEDIAN|STDEVP?|VARP?|ATTR|PERCENTILE)\s*\(', text, re.I) else '',
                    'Formula Length': len(text),
                    'Dependencies': _lst(self.caption_of(ds, k) for k in sorted(d['fields'])),
                    'Parameter Dependencies': _lst(self.caption_of('Parameters', p) for p in sorted(d['params'])),
                    'Physical Tables': _lst(self._tfqn(t) for t in self._field_tables(ds, key)),
                    'Referenced By Calculations': _lst(self.caption_of(ds, k) for k in sorted(refd)),
                    'Worksheets Using': len(self.field_ws.get((ds, key), ())),
                    'Dashboards Using': len(self.field_dash.get((ds, key), ())),
                    'Duplicate Of': dup_of.get((ds, key), ''),
                    'Used': '' if self.no_consumers else ('Yes' if used else 'No'), 'Status': status,
                    '_norm': normalize_formula(text)})
                for name in d['missing']:
                    self.add_finding('Broken Reference', 'Error', 'Calculated Field', f['caption'] or key, info['caption'],
                                     f"Formula references [{name}] which does not exist in the datasource")
                if status.startswith('Orphan'):
                    self.add_finding('Orphan Calculation', 'Warning', 'Calculated Field', f['caption'] or key,
                                     info['caption'], 'Calculation is not referenced by any worksheet, dashboard or other calculation')
                elif status.startswith('Unused'):
                    self.add_finding('Unused Calculation', 'Info', 'Calculated Field', f['caption'] or key, info['caption'],
                                     'Only referenced by other unused calculations')
                if (ds, key) in dup_of:
                    self.add_finding('Duplicate Calculation', 'Warning', 'Calculated Field', f['caption'] or key,
                                     info['caption'], f"Same logic as '{dup_of[(ds, key)]}'")

    def _emit_parameters(self):
        for key, f in self.fields.get('Parameters', {}).items():
            if f['formula'] is None and not f['domain'] and not f['value']:
                continue
            allowed = f['range'] if f['domain'] == 'range' else (
                _lst((a or v) if not a else f'{v} ({a})' for v, a in f['members']) if f['members'] else 'Any value')
            value = f['value'] or (f['formula'] or '')
            refs = self.referenced_by.get(('Parameters', key), set())
            ws_using = {w for (dsn, k), wss in self.field_ws.items() if dsn == 'Parameters' and k == key for w in wss}
            for wn, w in self.ws.items():
                if ('Parameters', key) in w['all']:
                    ws_using.add(wn)
            dash_using = set()
            for dn, d in self.dash.items():
                for ref in d['params']:
                    if parse_ref(ref)[2] == key:
                        dash_using.add(dn)
            self.field_dash[('Parameters', key)] |= dash_using
            self.out['parameters'].append({
                'Workbook': self.wb, 'Parameter Name': f['caption'] or key, 'Internal Name': key,
                'Data Type': f['datatype'], 'Current Value': str(value).strip('"'), 'Domain Type': f['domain'] or 'any',
                'Allowed Values': allowed, 'Referenced By Calculations': len(refs), 'Worksheets Using': len(ws_using),
                'Dashboards Using': len(dash_using)})

    def _emit_worksheets_dashboards(self):
        for wn, w in self.ws.items():
            dims, meas, calcs, params, tabs = [], [], [], [], []
            for dsn, key in sorted(w['direct']):
                f = self.fields.get(dsn, {}).get(key)
                if f is None:
                    continue
                cap = f['caption'] or key
                if dsn == 'Parameters':
                    params.append(cap)
                    continue
                if f['formula'] is not None:
                    calcs.append(cap)
                (meas if (w['roles'].get((dsn, key)) or f['role']) == 'measure' else dims).append(cap)
                for t in self._field_tables(dsn, key):
                    tabs.append(self._tfqn(t))
            for dsn, key in w['all']:
                if dsn in self.fields and dsn != 'Parameters':        # parameters reached through calculations
                    for k2 in self._deps_closure(dsn, key):
                        if isinstance(k2, tuple):
                            params.append(self.caption_of('Parameters', k2[1]))
                f = self.fields.get(dsn, {}).get(key)
                if dsn != 'Parameters' and f is not None and (dsn, key) not in w['direct'] and f['formula'] is None:
                    for t in self._field_tables(dsn, key):
                        tabs.append(self._tfqn(t))
            filt = [self.caption_of(*self._flt_key(w, f)) for f in w['filters']]
            self.out['worksheets'].append({
                'Workbook': self.wb, 'Worksheet': wn, 'Caption': w['title'], 'Type': 'Worksheet',
                'Mark Type': w['mark'], 'Hidden': _bool(w['hidden']),
                'Datasources Used': _lst(self.ds_caption(d) for d in w['datasources'] if d != 'Parameters'),
                'Dimensions Used': _lst(dims), 'Measures Used': _lst(meas), 'Calculated Fields Used': _lst(calcs),
                'Filters Used': _lst(filt), 'Parameters Used': _lst(params),
                'Rows Shelf': w['shelves'].get('rows', ''), 'Columns Shelf': w['shelves'].get('cols', ''),
                'Tables Used': _lst(tabs), 'Dashboards': _lst(w['dashboards'])})
        for dn, d in self.dash.items():
            self.out['dashboards'].append({
                'Workbook': self.wb, 'Dashboard': dn, 'Hidden': _bool(d['hidden']), 'Size': d['size'],
                'Objects Count': d['leaf'], 'Containers Count': d['containers'], 'Worksheets Count': len(d['sheets']),
                'Worksheets Included': _lst(d['sheets']),
                'Filters Included': _lst(self._zone_field_caption(r) for r in d['filters']),
                'Parameters Included': _lst(self._zone_field_caption(r) for r in d['params']),
                'Other Objects': _lst(f'{k} x{v}' for k, v in sorted(_count(d['other']).items())),
                'Actions Count': d['actions'],
                'Stories': _lst(sn for sn, s in self.stories.items() if dn in s['zones_all'] or
                                any(p['ref'] == dn for p in s.get('points', [])))})
        for sn, s in self.stories.items():
            pts = s.get('points', [])
            if pts:
                for i, p in enumerate(pts, 1):
                    ref = p['ref']
                    typ = 'Dashboard' if ref in self.dash else ('Worksheet' if ref in self.ws else '')
                    self.out['stories'].append({
                        'Workbook': self.wb, 'Story': sn, 'Hidden': _bool(s['hidden']), 'Story Point': i,
                        'Story Point Caption': p['caption'], 'Referenced Object': ref, 'Referenced Type': typ})
            else:
                refs = [z for z in s['zones_all'] if z in self.dash or z in self.ws]
                for i, ref in enumerate(dict.fromkeys(refs) or [''], 1):
                    self.out['stories'].append({
                        'Workbook': self.wb, 'Story': sn, 'Hidden': _bool(s['hidden']), 'Story Point': i,
                        'Story Point Caption': '', 'Referenced Object': ref,
                        'Referenced Type': 'Dashboard' if ref in self.dash else ('Worksheet' if ref in self.ws else '')})
        # filters: dashboards using each worksheet filter
        for row in self.out['filters']:
            if row['Worksheet'] and row['Worksheet'] in self.ws:
                row['Dashboards'] = _lst(self.ws[row['Worksheet']]['dashboards'])
        for dn, d in self.dash.items():
            for ref in d['filters']:
                dsn, deriv, fname, _s = parse_ref(ref)
                self.out['filters'].append({
                    'Workbook': self.wb, 'Scope': 'Dashboard filter control', 'Worksheet': '',
                    'Datasource': self.ds_caption(dsn), 'Filter Name': self.caption_of(dsn, fname),
                    'Filter Type': 'quick filter', 'Applied Field': self.caption_of(dsn, fname),
                    'Filter Logic': '', 'Context Filter': '', 'Dashboards': dn})

    def _flt_key(self, w, f):
        dsn, deriv, fname, _s = parse_ref(f.get('column', ''))
        dsn = dsn or (w['datasources'][0] if w['datasources'] else '')
        return dsn, _strip_br(w['inst_map'].get((dsn, fname), fname))

    def _zone_field_caption(self, ref):
        dsn, deriv, fname, _s = parse_ref(ref)
        return self.caption_of(dsn, fname)

    def _emit_field_usage_and_impact(self):
        self.unused_fields = 0
        self.hidden_fields = 0
        for ds, flds in self.fields.items():
            if ds == 'Parameters':
                continue
            info = self.ds_info[ds]
            for key, f in flds.items():
                cap = f['caption'] or key
                wss = sorted(self.field_ws.get((ds, key), ()))
                dbs = sorted(self.field_dash.get((ds, key), ()))
                refd = sorted(self.referenced_by.get((ds, key), ()))
                used = (ds, key) in self.used_fields or bool(refd and any((ds, r) in self.used_fields for r in refd))
                if f['hidden']:
                    self.hidden_fields += 1
                    self.add_finding('Hidden Field', 'Info', 'Field', cap, info['caption'], 'Field is hidden in the data pane')
                if not used and not f['auto'] and not self.no_consumers:
                    if f['formula'] is None:
                        self.unused_fields += 1
                        self.add_finding('Unused Field', 'Info', 'Field', cap, info['caption'],
                                         f"Not used in any worksheet, dashboard, calculation or action"
                                         + (f" (table {f['table']})" if f['table'] else ''))
                tabs = self._field_tables(ds, key)
                self.out['field_usage'].append({
                    'Workbook': self.wb, 'Datasource': info['caption'], 'Field': cap, 'Internal Name': key,
                    'Table': _lst(t['name'] for t in tabs) if f['formula'] is not None else f['table'],
                    'Physical Column': f['physical'], 'Role': f['role'], 'Data Type': f['datatype'],
                    'Is Calculated': 'Yes' if f['formula'] is not None else '', 'Hidden': _bool(f['hidden']),
                    'Used In Worksheets': _lst(wss), 'Used In Dashboards': _lst(dbs),
                    'Referenced By Calculations': _lst(self.caption_of(ds, r) for r in refd),
                    'Worksheets Count': len(wss), 'Dashboards Count': len(dbs), 'Calculations Count': len(refd),
                    'Used': 'n/a (datasource file)' if self.no_consumers else (
                        'Yes' if used else ('n/a (auto field)' if f['auto'] else 'No'))})
                if wss or dbs or refd or f['formula'] is not None:
                    self.out['impact'].append({
                        'Object Type': 'Calculated Field' if f['formula'] is not None else 'Field',
                        'Workbook': self.wb, 'Datasource': info['caption'], 'Object Name': cap,
                        'Table': _lst(t['name'] for t in tabs) if f['formula'] is not None else f['table'],
                        'Worksheets Using': len(wss), 'Dashboards Using': len(dbs),
                        'Calculations Referencing': len(refd), 'Datasources Using': 1, 'Workbooks Using': 1,
                        'Worksheet Names': _lst(wss), 'Dashboard Names': _lst(dbs)})
        for ds, tabs in self.tables.items():
            info = self.ds_info[ds]
            for t in tabs:
                wss = sorted(self.table_ws.get((ds, id(t)), ()))
                dbs = sorted(self.table_dash.get((ds, id(t)), ()))
                self.out['impact'].append({
                    'Object Type': 'Table', 'Workbook': self.wb, 'Datasource': info['caption'],
                    'Object Name': self._tfqn(t), 'Table': t['name'], 'Worksheets Using': len(wss),
                    'Dashboards Using': len(dbs), 'Calculations Referencing': 0, 'Datasources Using': 1,
                    'Workbooks Using': 1, 'Worksheet Names': _lst(wss), 'Dashboard Names': _lst(dbs)})
            if info['published']:
                t = self._published_table(info)
                wss = sorted({w for k in self.fields[ds] for w in self.field_ws.get((ds, k), ())})
                dbs = sorted({d for k in self.fields[ds] for d in self.field_dash.get((ds, k), ())})
                self.out['impact'].append({
                    'Object Type': 'Table', 'Workbook': self.wb, 'Datasource': info['caption'],
                    'Object Name': self._tfqn(t), 'Table': t['name'], 'Worksheets Using': len(wss),
                    'Dashboards Using': len(dbs), 'Calculations Referencing': 0, 'Datasources Using': 1,
                    'Workbooks Using': 1, 'Worksheet Names': _lst(wss), 'Dashboard Names': _lst(dbs)})
        for ds, info in self.ds_info.items():
            if info['is_params']:
                continue
            wss = sorted({w for wn, w2 in self.ws.items() for w in [wn] if ds in w2['datasources']})
            dbs = sorted({d for w in wss for d in self.ws[w]['dashboards']})
            self.out['impact'].append({
                'Object Type': 'Datasource', 'Workbook': self.wb, 'Datasource': info['caption'],
                'Object Name': info['caption'], 'Table': '', 'Worksheets Using': len(wss), 'Dashboards Using': len(dbs),
                'Calculations Referencing': 0, 'Datasources Using': 1, 'Workbooks Using': 1,
                'Worksheet Names': _lst(wss), 'Dashboard Names': _lst(dbs)})

    def _emit_lineage(self):
        rows = self.out['workbook_lineage']
        seen_tables = set()

        def add_row(t, ds, ws, dash):
            if len(rows) >= MAX_LINEAGE_ROWS_PER_WORKBOOK:
                return
            info = self.ds_info[ds]
            fq = self._tfqn(t)
            path = ' > '.join(p for p in (t.get('database', ''), t.get('schema', ''), t['name'] if t['kind'] != 'Published Datasource' else fq,
                                          'Datasource: ' + info['caption'], ('Worksheet: ' + ws) if ws else '',
                                          ('Dashboard: ' + dash) if dash else '', 'Workbook: ' + self.wb) if p)
            rows.append({'Workbook': self.wb, 'Connection Type': t['connection_type'], 'Server': t['server'],
                         'Database': t.get('database', ''), 'Schema': t.get('schema', ''), 'Table': t['name'],
                         'Full Table Name': fq, 'Datasource': info['caption'], 'Worksheet': ws, 'Dashboard': dash,
                         'Lineage Path': path})

        for wn, w in self.ws.items():
            per_table = {}
            for dsn, key in w['all']:
                if dsn == 'Parameters' or dsn not in self.ds_info:
                    continue
                for t in self._field_tables(dsn, key):
                    per_table[(dsn, id(t))] = (dsn, t)
            for (dsn, _), (d, t) in per_table.items():
                seen_tables.add((dsn, id(t)))
                for dash in (w['dashboards'] or ['']):
                    add_row(t, dsn, wn, dash)
        for ds, tabs in self.tables.items():
            for t in tabs:
                if (ds, id(t)) not in seen_tables:
                    add_row(t, ds, '', '')
        for ds, info in self.ds_info.items():
            if info['published'] and (ds, id(self._published_table(info))) not in seen_tables:
                add_row(self._published_table(info), ds, '', '')
        if len(rows) >= MAX_LINEAGE_ROWS_PER_WORKBOOK:
            self.add_finding('Analysis Limit', 'Info', 'Workbook', self.wb, '',
                             f'Lineage rows truncated at {MAX_LINEAGE_ROWS_PER_WORKBOOK}')

    def _quality_checks(self):
        # worksheets referencing missing fields
        for wn, w in self.ws.items():
            for dsn, key in w['all']:
                info_q = self.ds_info.get(dsn)
                if info_q is None or info_q['published'] or not self.fields.get(dsn):
                    continue          # published datasources: workbook XML only lists the customised fields
                if dsn in self.fields and dsn != 'Parameters' and key not in self.fields[dsn]:
                    low = key.lower()
                    if low in _AUTO_FIELDS or key.startswith(':') or key.startswith('__tableau') or not key:
                        continue
                    if any(k.endswith(f'({key})') or k == key for k in self.fields[dsn]):
                        continue
                    self.add_finding('Broken Reference', 'Warning', 'Worksheet', wn, self.ds_caption(dsn),
                                     f"Worksheet uses field [{key}] which is not defined in the datasource")
        for dn, d in list(self.dash.items()) + list(self.stories.items()):
            for s in d['unresolved']:
                if s not in self.ws and s not in self.dash and s not in self.stories:
                    self.add_finding('Broken Reference', 'Error', 'Dashboard', dn, '',
                                     f"Dashboard references missing worksheet '{s}'")
        for wn, w in self.ws.items():
            if w['hidden']:
                self.add_finding('Hidden Worksheet', 'Info', 'Worksheet', wn, '', 'Worksheet is hidden')
        for dn, d in self.dash.items():
            if d['hidden']:
                self.add_finding('Hidden Worksheet', 'Info', 'Dashboard', dn, '', 'Dashboard is hidden')
        for ds, info in self.ds_info.items():
            if info['hidden']:
                self.add_finding('Hidden Datasource', 'Info', 'Datasource', info['caption'], ds, 'Datasource is hidden')
        for ds, info in self.ds_info.items():
            if info['is_params']:
                continue
            used_any = any(ds in w['datasources'] or any(d == ds for d, _k in w['all']) for w in self.ws.values())
            if not used_any and self.ws:
                self.add_finding('Unused Datasource', 'Info', 'Datasource', info['caption'], ds,
                                 'Datasource is not used by any worksheet')
        try:
            v = float(self.version)
            if v and v < 10.0:
                self.add_finding('Deprecated Object', 'Info', 'Workbook', self.wb, '',
                                 f'Workbook file format version {self.version} is very old')
        except ValueError:
            pass

    def _emit_datasource_inventory(self):
        for ds, info in self.ds_info.items():
            flds = self.fields.get(ds, {})
            self.out['datasource_inventory'].append({
                'Workbook': self.wb, 'Datasource': ds, 'Caption': info['caption'],
                'Datasource Type': 'Parameters' if info['is_params'] else info.get('type', ''),
                'Datasource Class': info.get('class', ''), 'Datasource Version': info['version'],
                'Published Datasource': info['published'], 'Uses Extract': 'Yes' if info['uses_extract'] else '',
                'Federated': 'Yes' if info['top_class'] == 'federated' else '', 'Hidden': _bool(info['hidden']),
                'Connections': len(info['connections']), 'Tables': len(self.tables.get(ds, [])),
                'Custom SQL': info['custom_sql'], 'Fields': len(flds),
                'Calculated Fields': len([1 for f in flds.values() if f['formula'] is not None]),
                'Unused Fields': '' if self.no_consumers else len([1 for k, f in flds.items() if (ds, k) not in self.used_fields
                                      and not f['auto'] and ds != 'Parameters' and f['formula'] is None])})

    def _emit_summary(self):
        def count(t):
            return len([f for f in self.findings if f['Finding Type'] == t])
        rels = [r for r in self.out['relationship_analysis']]
        blends = 0
        for wn, w in self.ws.items():
            dss = [d for d in w['datasources'] if d != 'Parameters']
            if len(dss) > 1:
                blends += 1
                self.out['relationship_analysis'].append({
                    'Workbook': self.wb, 'Datasource': self.ds_caption(dss[0]), 'Type': 'Blend', 'Name': wn,
                    'Left Table': self.ds_caption(dss[0]), 'Right Table': _lst(self.ds_caption(d) for d in dss[1:]),
                    'Left Field': '', 'Right Field': '', 'Clause': '',
                    'Details': f"Worksheet '{wn}' uses {len(dss)} datasources (primary: {self.ds_caption(dss[0])})"})
        nonparam = [i for i in self.ds_info.values() if not i['is_params']]
        pkg = self.package
        ts = self.modified
        self.out['workbook_summary'].append({
            'Workbook': self.wb, 'File Path': self.path, 'File Type': os.path.splitext(self.path)[1].lower() or (
                '.twbx' if self.is_twbx else '.twb'),
            'Content Type': 'Datasource' if self.kind == 'datasource' else 'Workbook',
            'File Size (MB)': round(self.file_size / 1048576, 2), 'File Modified': ts,
            'Workbook Version': self.version, 'Original Version': self.original_version, 'Build': self.build,
            'Tableau Release': release_from(self.version, self.build), 'Platform': self.platform,
            'Workbook ID': self.repo.get('id', ''), 'Site Name': self.repo.get('site', ''),
            'Repository Path': self.repo.get('path', ''), 'Project Name': 'Not stored in workbook XML',
            'Owner': 'Not stored in workbook XML', 'Created Date': 'Not stored in workbook XML',
            'Modified Date': ts, 'Description': self.description, 'Datasources': len(nonparam),
            'Connections': sum(len(i['connections']) for i in nonparam), 'Tables': len(self.out['table_inventory']),
            'Custom SQL': len({(r['Datasource'], r['Custom SQL Name']) for r in self.out['custom_sql']}),
            'Joins': len(self.out['join_analysis']),
            'Relationships': len([r for r in rels if r['Type'] == 'Relationship']),
            'Unions': len([r for r in rels if r['Type'] == 'Union']), 'Blends': blends,
            'Calculated Fields': len(self.out['calculated_fields']), 'Parameters': len(self.out['parameters']),
            'Filters': len(self.out['filters']), 'Worksheets': len(self.ws), 'Dashboards': len(self.dash),
            'Stories': len(self.stories), 'Hidden Worksheets': count('Hidden Worksheet'),
            'Hidden Dashboards': len([1 for d in self.dash.values() if d['hidden']]),
            'Hidden Datasources': count('Hidden Datasource'), 'Hidden Fields': self.hidden_fields,
            'Unused Fields': '' if self.no_consumers else self.unused_fields,
            'Unused Calculations': '' if self.no_consumers else count('Unused Calculation') + count('Orphan Calculation'),
            'Duplicate Calculations': count('Duplicate Calculation'), 'Broken References': count('Broken Reference'),
            'Invalid Connections': count('Invalid Connection'), 'Findings': len(self.findings),
            'Data Files In Package': pkg.get('data_files', ''), 'Status': 'OK'})


def SqlTableParser_split(ref):
    """'[db].[dbo].[t]' -> ('db','dbo','t')  (shared implementation with the Tableau XML parser)"""
    ref = (ref or '').strip()
    parts = re.findall(r'\[([^\]]+)\]', ref)
    if not parts:
        parts = [p.strip('"`') for p in re.split(r'\.(?=(?:[^"]*"[^"]*")*[^"]*$)', ref) if p.strip()]
    parts = [p.strip() for p in parts if p.strip()]
    if not parts:
        return '', '', ''
    table = parts[-1]
    if table.endswith('$'):
        table = table[:-1]
    return (parts[-3] if len(parts) >= 3 else ''), (parts[-2] if len(parts) >= 2 else ''), table


def _num(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _count(items):
    d = defaultdict(int)
    for i in items:
        d[i] += 1
    return d


# --------------------------------------------------------------------------------------
# Tableau Prep flows (.tfl / .tflx)
# --------------------------------------------------------------------------------------

_FLOW_LABELS = {
    'LoadSql': 'Input: SQL', 'LoadCsv': 'Input: CSV', 'LoadExcel': 'Input: Excel', 'LoadSqlProxy': 'Input: Published Data Source',
    'LoadHyper': 'Input: Hyper', 'LoadJson': 'Input: JSON', 'LoadPdf': 'Input: PDF', 'LoadXml': 'Input: XML',
    'PublishExtract': 'Output: Publish Data Source', 'WriteToHyper': 'Output: Hyper file', 'WriteToCsv': 'Output: CSV file',
    'WriteToDatabase': 'Output: Database table', 'SuperJoin': 'Join', 'SuperUnion': 'Union', 'SuperAggregate': 'Aggregate',
    'SuperPivot': 'Pivot', 'SuperTransform': 'Clean', 'Container': 'Clean', 'SuperScript': 'Script',
}
_FLOW_CLASS_BY_TYPE = {'LoadCsv': 'textscan', 'LoadExcel': 'excel-direct', 'LoadHyper': 'hyper', 'LoadSqlProxy': 'sqlproxy',
                       'LoadJson': 'json', 'LoadPdf': 'pdf', 'WriteToHyper': 'hyper', 'WriteToCsv': 'textscan',
                       'PublishExtract': 'sqlproxy'}


def _g(d, *keys, depth=2):
    """First non-empty scalar found under any of `keys` in dict `d` (searching nested dicts up to `depth`)."""
    if not isinstance(d, dict):
        return ''
    for k in keys:
        v = d.get(k)
        if isinstance(v, (str, int, float)) and not isinstance(v, bool) and str(v).strip():
            return str(v).strip()
    if depth:
        for v in d.values():
            if isinstance(v, dict):
                r = _g(v, *keys, depth=depth - 1)
                if r:
                    return r
    return ''


def _camel_words(s):
    return re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', s or '')


class FlowAnalyzer:
    """
    Tableau Prep flow. A .tfl / .tflx is a package (zip) holding a JSON document called `flow`: a graph of steps
    (`nodes`) linked by `nextNodes`, plus the `connections` the input / output steps refer to. The mapping onto the
    common output schema is:  inputs -> datasources / tables / connections, joins -> Join Analysis, unions ->
    Relationship Analysis, custom SQL inputs -> Custom SQL Analysis, added columns -> Calculated Fields, filter
    steps -> Filters, input-to-output paths -> Workbook Lineage, plus a Flow Steps sheet listing every step.
    The layout differs a little between Prep versions, so every lookup is tolerant and unknown steps are still listed.
    """

    def __init__(self, js, name, path='', packaged=False, file_size=0, modified='', package=None):
        self.js = js if isinstance(js, dict) else {}
        self.name = name
        self.path = path
        self.packaged = packaged
        self.file_size = file_size
        self.modified = modified
        self.package = package or {}
        self.out = {k: [] for k in SCHEMAS}
        self.findings = []
        self.steps = OrderedDict()
        self.conns = self.js.get('connections') if isinstance(self.js.get('connections'), dict) else {}
        self.inputs, self.outputs = {}, {}

    def _finding(self, ftype, severity, otype, oname, details='', ds=''):
        self.findings.append({'Workbook': self.name, 'Finding Type': ftype, 'Severity': severity, 'Object Type': otype,
                              'Object Name': oname, 'Datasource': ds, 'Details': details})

    # ---------------------------------------------------------------- steps and graph
    @staticmethod
    def _kind(sub, base):
        b = (base or '').lower()
        if b == 'input' or sub.startswith('Load'):
            return 'input'
        if b == 'output' or sub.startswith(('Publish', 'WriteTo', 'Save')):
            return 'output'
        for key, kind in (('Join', 'join'), ('Union', 'union'), ('Aggregate', 'aggregate'), ('Pivot', 'pivot'),
                          ('Script', 'script'), ('Transform', 'clean'), ('Container', 'clean'), ('Clean', 'clean')):
            if key in sub:
                return kind
        return 'other'

    def _build_steps(self):
        nodes = self.js.get('nodes')
        if not isinstance(nodes, dict) or not nodes:
            self._finding('Unrecognized Flow Structure', 'Error', 'Flow', self.name,
                          'No "nodes" found in the flow document - this flow layout is not supported')
            return
        for nid, n in nodes.items():
            if not isinstance(n, dict):
                continue
            nt = str(n.get('nodeType', ''))
            sub = nt.split('.')[-1]
            nxt = [(x.get('nextNodeId'), x.get('namespace', 'Default')) for x in (n.get('nextNodes') or [])
                   if isinstance(x, dict) and x.get('nextNodeId')]
            self.steps[nid] = {'id': nid, 'name': n.get('name') or _camel_words(sub) or nid[:8], 'nodeType': nt, 'sub': sub,
                               'kind': self._kind(sub, n.get('baseType')), 'raw': n, 'next': nxt, 'prev': [],
                               'label': _FLOW_LABELS.get(sub) or _camel_words(sub) or 'Step'}
        for sid, s in self.steps.items():
            for tid, ns in s['next']:
                if tid in self.steps:
                    self.steps[tid]['prev'].append((sid, ns))

    def _connection(self, step):
        n, sub = step['raw'], step['sub']
        cid = n.get('connectionId') if isinstance(n.get('connectionId'), str) else ''
        conn = self.conns.get(cid) if cid else None
        attrs = {}
        if isinstance(conn, dict):
            ca = conn.get('connectionAttributes')
            attrs.update(ca if isinstance(ca, dict) else {k: v for k, v in conn.items() if isinstance(v, (str, int))})
        if isinstance(n.get('connectionAttributes'), dict):
            attrs.update(n['connectionAttributes'])
        if cid and conn is None:
            self._finding('Broken Reference', 'Error', 'Step', step['name'],
                          f"Step references connection '{cid}' which is not defined in the flow", step['name'])
        cls = str(attrs.get('class') or _FLOW_CLASS_BY_TYPE.get(sub, ''))
        server = str(attrs.get('server') or '/'.join(str(attrs[k]) for k in ('directory', 'filename') if attrs.get(k)) or '')
        return {
            'id': cid, 'class': cls, 'type': friendly_connection(cls), 'server': server,
            'port': str(attrs.get('port', '') or ''), 'database': str(attrs.get('dbname', '') or attrs.get('catalog', '') or ''),
            'schema': str(attrs.get('schema', '') or ''), 'username': str(attrs.get('username', '') or ''),
            'auth': auth_label(str(attrs.get('authentication', '') or '')), 'warehouse': str(attrs.get('warehouse', '') or ''),
            'catalog': str(attrs.get('catalog', '') or ''), 'http': str(attrs.get('http-path', '') or attrs.get('service', '') or ''),
            'file': str(attrs.get('filename', '') or attrs.get('directory', '') or ''),
            'ssl': _lst((f'{k}={v}' for k, v in attrs.items() if any(x in k.lower() for x in ('ssl', 'encrypt'))), 0),
        }

    # ---------------------------------------------------------------- inputs / outputs
    def _inputs_outputs(self):
        seen_conn = set()
        for sid, s in self.steps.items():
            if s['kind'] not in ('input', 'output'):
                continue
            n, c = s['raw'], self._connection(s)
            s['conn'] = c
            key = c['id'] or (s['id'] if c['class'] else '')
            if key and key not in seen_conn and (c['class'] or c['server']):
                seen_conn.add(key)
                self.out['connection_inventory'].append({
                    'Workbook': self.name, 'Datasource': s['name'], 'Connection Role': s['kind'].title(),
                    'Connection Name': c['id'][:8], 'Connection Type': c['type'], 'DB Class': c['class'], 'Server': c['server'],
                    'Port': c['port'], 'Database': c['database'], 'Schema': c['schema'], 'Warehouse': c['warehouse'],
                    'Catalog': c['catalog'], 'Username': c['username'], 'Authentication Mode': c['auth'],
                    'SSL Settings': c['ssl'], 'HTTP Path / Service': c['http'], 'File / Directory': c['file'],
                    'Initial SQL': '', 'Tables': 1})
            if s['kind'] == 'input':
                self._input(s, n, c)
            else:
                self._output(s, n, c)

    def _input(self, s, n, c):
        rel = n.get('relation') if isinstance(n.get('relation'), dict) else {}
        sql = ''
        if str(rel.get('type', '')).lower() == 'text' or any(k in rel for k in ('query', 'sql', 'customSql', 'commandText')):
            sql = _g(rel, 'text', 'query', 'sql', 'customSql', 'commandText') or _g(n, 'customSql', 'query')
        ref = str(rel.get('table') or _g(n, 'tableName', 'table') or '')
        tables, kind = [], 'Table'
        if s['sub'] == 'LoadSqlProxy':
            pub = _g(n, 'datasourceName', 'publishedDatasourceName') or s['name']
            tables = [{'db': '', 'schema': '', 'table': pub, 'fqn': f'(published) {pub}', 'kind': 'Published Datasource'}]
        elif sql:
            kind = 'Custom SQL'
            tables = [{'db': '', 'schema': '', 'table': s['name'], 'fqn': f"(Custom SQL) {s['name']}", 'kind': 'Custom SQL'}]
            parsed = SqlTableParser.parse(sql)
            for t in parsed['tables']:
                tables.append({'db': t['database'], 'schema': t['schema'], 'table': t['table'], 'fqn': t['fqn'],
                               'kind': 'Table (parsed from custom SQL)'})
            for t in (parsed['tables'] or [None]):
                self.out['custom_sql'].append({
                    'Workbook': self.name, 'Datasource': s['name'], 'Custom SQL Name': s['name'], 'Source': 'Flow input',
                    'Connection Type': c['type'], 'Server': c['server'], 'Database': c['database'], 'Query Length': len(sql),
                    'Referenced Table': t['fqn'] if t else '', 'Referenced Database': t['database'] if t else '',
                    'Referenced Schema': t['schema'] if t else '', 'Table Name': t['table'] if t else '',
                    'Reference Type': ', '.join(t['kinds']) if t else '', 'CTEs': _lst(parsed['ctes']), 'SQL Query': sql})
        else:
            db, sch, tbl = SqlTableParser_split(ref)
            tbl = tbl or os.path.basename(c['file'].replace('\\', '/')) or s['name']
            fq = '.'.join(x for x in (db or c['database'], sch or c['schema'], tbl) if x)
            kind = 'File' if c['class'] in ('textscan', 'excel-direct', 'json', 'pdf', 'hyper') else 'Table'
            tables = [{'db': db or c['database'], 'schema': sch or c['schema'], 'table': tbl, 'fqn': fq, 'kind': kind}]
        fields = [f for f in (n.get('fields') or []) if isinstance(f, dict)]
        s['tables'] = tables
        self.inputs[s['id']] = s
        self.out['datasource_inventory'].append({
            'Workbook': self.name, 'Datasource': s['name'], 'Caption': s['name'], 'Datasource Type': s['label'],
            'Datasource Class': c['class'], 'Datasource Version': '',
            'Published Datasource': tables[0]['table'] if s['sub'] == 'LoadSqlProxy' else '',
            'Uses Extract': '', 'Federated': '', 'Hidden': '', 'Connections': 1, 'Tables': len(tables),
            'Custom SQL': 1 if sql else 0, 'Fields': len(fields), 'Calculated Fields': 0, 'Unused Fields': ''})
        for t in tables:
            self.out['table_inventory'].append({
                'Workbook': self.name, 'Datasource': s['name'], 'Connection Type': c['type'], 'Server': c['server'],
                'Database': t['db'], 'Schema': t['schema'], 'Table Name': t['table'], 'Full Table Name': t['fqn'],
                'Table Alias': '', 'Logical Table': s['name'], 'Physical Table': t['fqn'], 'Table Kind': t['kind'],
                'Source': 'Flow input', 'Columns': len(fields), 'Worksheets Using': '', 'Dashboards Using': ''})
        for f in fields:
            self.out['field_usage'].append({
                'Workbook': self.name, 'Datasource': s['name'], 'Field': f.get('name', ''), 'Internal Name': f.get('name', ''),
                'Table': tables[0]['table'], 'Physical Column': f.get('name', ''), 'Role': '', 'Data Type': f.get('type', ''),
                'Is Calculated': '', 'Hidden': '', 'Used In Worksheets': '', 'Used In Dashboards': '',
                'Referenced By Calculations': '', 'Worksheets Count': '', 'Dashboards Count': '', 'Calculations Count': '',
                'Used': 'n/a (flow input field)'})

    def _output(self, s, n, c):
        sub = s['sub']
        if sub == 'PublishExtract':
            target = '/'.join(x for x in (_g(n, 'projectName', 'project'), _g(n, 'datasourceName', 'name')) if x) or s['name']
            tkind = 'Published Datasource'
        elif sub == 'WriteToDatabase':
            target = '.'.join(x for x in (_g(n, 'schemaName', 'schema'), _g(n, 'tableName', 'table')) if x) or s['name']
            tkind = 'Output table'
        else:
            target = _g(n, 'fileName', 'filename', 'outputPath', 'path', 'directory') or s['name']
            tkind = 'Output file'
        s['target'], s['target_kind'] = target, tkind
        self.outputs[s['id']] = s
        self.out['datasource_inventory'].append({
            'Workbook': self.name, 'Datasource': s['name'], 'Caption': s['name'], 'Datasource Type': s['label'],
            'Datasource Class': c['class'], 'Datasource Version': '',
            'Published Datasource': target if tkind == 'Published Datasource' else '',
            'Uses Extract': '', 'Federated': '', 'Hidden': '', 'Connections': 1 if c['class'] else 0, 'Tables': 1,
            'Custom SQL': 0, 'Fields': len(n.get('fields') or []), 'Calculated Fields': 0, 'Unused Fields': ''})
        self.out['table_inventory'].append({
            'Workbook': self.name, 'Datasource': s['name'], 'Connection Type': c['type'], 'Server': c['server'],
            'Database': c['database'], 'Schema': c['schema'], 'Table Name': target, 'Full Table Name': target, 'Table Alias': '',
            'Logical Table': s['name'], 'Physical Table': target, 'Table Kind': tkind, 'Source': 'Flow output',
            'Columns': len(n.get('fields') or []), 'Worksheets Using': '', 'Dashboards Using': ''})

    # ---------------------------------------------------------------- transforms
    def _walk(self, obj, step, top=True, seen=None):
        """Calculated fields / filters live in (possibly nested) action nodes inside cleaning-step containers."""
        seen = seen if seen is not None else set()
        if isinstance(obj, dict):
            nt = str(obj.get('nodeType', ''))
            fexpr = obj.get('filterExpression')
            if isinstance(fexpr, str) and fexpr.strip():
                key = ('f', step['id'], fexpr)
                if key not in seen:
                    seen.add(key)
                    fl = [r[1] for r in formula_refs(fexpr)]
                    self.out['filters'].append({
                        'Workbook': self.name, 'Scope': 'Flow filter', 'Worksheet': step['name'], 'Datasource': step['name'],
                        'Filter Name': _lst(fl), 'Filter Type': _camel_words(nt.split('.')[-1]) or 'filter',
                        'Applied Field': _lst(fl), 'Filter Logic': fexpr, 'Context Filter': '', 'Dashboards': ''})
            else:
                expr = next((obj[k] for k in ('expression', 'calculation', 'formula', 'calculationExpression', 'calcExpression')
                             if isinstance(obj.get(k), str) and obj[k].strip()), '')
                cname = next((obj[k] for k in ('columnName', 'fieldName', 'newColumnName', 'calculatedFieldName')
                              if isinstance(obj.get(k), str) and obj[k].strip()), '')
                if not cname and expr and any(x in nt for x in ('AddColumn', 'Calculat')):
                    cname = str(obj.get('name', ''))
                if expr and cname and (not top or 'AddColumn' in nt or 'Calculat' in nt):
                    key = ('c', step['id'], cname, expr)
                    if key not in seen:
                        seen.add(key)
                        deps = _lst(r[1] for r in formula_refs(expr))
                        self.out['calculated_fields'].append({
                            'Workbook': self.name, 'Datasource': step['name'], 'Calculation Name': cname, 'Internal Name': '',
                            'Formula': expr, 'Data Type': str(obj.get('type') or obj.get('dataType') or ''), 'Role': '',
                            'Folder': '', 'Hidden': '',
                            'Is LOD': 'Yes' if re.search(r'\{\s*(FIXED|INCLUDE|EXCLUDE)\b', expr, re.I) else '',
                            'Is Table Calc': '', 'Is Aggregate': 'Yes' if re.search(
                                r'\b(SUM|AVG|COUNTD|COUNT|MIN|MAX|MEDIAN)\s*\(', expr, re.I) else '',
                            'Formula Length': len(expr), 'Dependencies': deps, 'Parameter Dependencies': '',
                            'Physical Tables': '', 'Referenced By Calculations': '', 'Worksheets Using': '',
                            'Dashboards Using': '', 'Duplicate Of': '', 'Used': '', 'Status': 'n/a (flow step)',
                            '_norm': normalize_formula(expr)})
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    self._walk(v, step, False, seen)
        elif isinstance(obj, list):
            for v in obj:
                self._walk(v, step, False, seen)

    def _count_actions(self, obj):
        n = 0
        if isinstance(obj, dict):
            if 'nodeType' in obj:
                n += 1
            for v in obj.values():
                n += self._count_actions(v) if isinstance(v, (dict, list)) else 0
        elif isinstance(obj, list):
            for v in obj:
                n += self._count_actions(v)
        return n

    def _transforms(self):
        for sid, s in self.steps.items():
            n = s['raw']

            def preds(ns, s=s):
                return [self.steps[p]['name'] for p, x in s['prev'] if x == ns]

            if s['kind'] == 'join':
                conds = n.get('joinConditions') or n.get('conditions') or []
                parts, lf, rf = [], '', ''
                for cnd in conds if isinstance(conds, list) else []:
                    left = _g(cnd, 'leftExpression', 'left', 'leftField', 'leftColumn')
                    right = _g(cnd, 'rightExpression', 'right', 'rightField', 'rightColumn')
                    op = _g(cnd, 'comparisonOperator', 'operator') or '='
                    parts.append(f'{left} {op} {right}')
                    lf, rf = lf or left, rf or right
                left_names = preds('Left') or [self.steps[p]['name'] for p, _x in s['prev'][:1]]
                right_names = preds('Right') or [self.steps[p]['name'] for p, _x in s['prev'][1:2]]
                jt = _g(n, 'joinType', 'type') or 'join'
                s['detail'] = f"{jt}: " + ' AND '.join(parts)
                if not parts:
                    self._finding('Empty Join Condition', 'Warning', 'Step', s['name'], 'Join step has no join conditions', s['name'])
                self.out['join_analysis'].append({
                    'Workbook': self.name, 'Datasource': s['name'], 'Join Type': jt, 'Left Table': _lst(left_names),
                    'Right Table': _lst(right_names), 'Left Field': lf, 'Right Field': rf, 'Join Clause': ' AND '.join(parts),
                    'Nesting Level': 0})
            elif s['kind'] == 'union':
                names = [self.steps[p]['name'] for p, _x in s['prev']]
                s['detail'] = f'{len(names)} input(s)'
                self.out['relationship_analysis'].append({
                    'Workbook': self.name, 'Datasource': s['name'], 'Type': 'Union', 'Name': s['name'], 'Left Table': '',
                    'Right Table': '', 'Left Field': '', 'Right Field': '', 'Clause': '',
                    'Details': f'{len(names)} input(s): ' + _lst(names)})
            if s['kind'] not in ('input',):
                self._walk(n, s)
                if s['kind'] == 'clean':
                    s['detail'] = f"{max(self._count_actions(n) - 1, 0)} action(s)"

    # ---------------------------------------------------------------- lineage
    def _paths_to_inputs(self, out_id):
        from collections import deque
        child, q, found = {out_id: None}, deque([out_id]), []
        while q:
            cur = q.popleft()
            s = self.steps[cur]
            if s['kind'] == 'input':
                found.append(cur)
                continue
            for p, _ns in s['prev']:
                if p not in child:
                    child[p] = cur
                    q.append(p)
        paths = {}
        for inp in found:
            chain, cur = [], inp
            while cur is not None:
                chain.append(cur)
                cur = child[cur]
            paths[inp] = chain
        return paths

    def _lineage(self):
        reached, per_output = set(), {}
        for oid, o in self.outputs.items():
            paths = per_output[oid] = self._paths_to_inputs(oid)
            if not paths:
                self._finding('Output Without Input', 'Error', 'Step', o['name'], 'No input step feeds this output', o['name'])
            for iid, chain in paths.items():
                reached.add(iid)
                inp = self.steps[iid]
                middle = [self.steps[c]['name'] + f" ({self.steps[c]['label']})" for c in chain[1:-1]]
                end = f"Output: {o['name']} -> {o['target']} [{o['target_kind']}]"
                for t in inp['tables']:
                    path = ' > '.join(p for p in [t['db'], t['schema'], t['table'] if t['kind'] != 'Published Datasource' else t['fqn'],
                                                  f"Input: {inp['name']}"] + middle + [end, f'Flow: {self.name}'] if p)
                    c = inp['conn']
                    self.out['workbook_lineage'].append({
                        'Workbook': self.name, 'Connection Type': c['type'], 'Server': c['server'], 'Database': t['db'],
                        'Schema': t['schema'], 'Table': t['table'], 'Full Table Name': t['fqn'], 'Datasource': o['target'],
                        'Worksheet': '', 'Dashboard': '', 'Lineage Path': path})
        for iid, inp in self.inputs.items():
            outs = [o['name'] for oid, o in self.outputs.items() if iid in per_output.get(oid, {})]
            for t in inp['tables']:
                self.out['impact'].append({
                    'Object Type': 'Table', 'Workbook': self.name, 'Datasource': inp['name'], 'Object Name': t['fqn'],
                    'Table': t['table'], 'Worksheets Using': '', 'Dashboards Using': '', 'Calculations Referencing': 0,
                    'Datasources Using': len(outs), 'Workbooks Using': 1, 'Worksheet Names': '',
                    'Dashboard Names': _lst(outs)})
            if iid not in reached:
                self._finding('Unused Input', 'Warning', 'Step', inp['name'], 'Input does not feed any output', inp['name'])
        for sid, s in self.steps.items():
            if s['kind'] not in ('input', 'output') and not s['next']:
                self._finding('Orphan Step', 'Warning', 'Step', s['name'], f"{s['label']} step has no downstream step / output", s['name'])
            if s['kind'] == 'other':
                self._finding('Unclassified Step', 'Info', 'Step', s['name'],
                              f"Step type {s['nodeType']} was listed but not analysed in detail", s['name'])

    # ---------------------------------------------------------------- parameters / steps / summary
    def _parameters(self):
        params = self.js.get('parameters')
        items = params.items() if isinstance(params, dict) else enumerate(params or [])
        for key, p in items:
            if not isinstance(p, dict):
                continue
            allowed = p.get('values') or p.get('allowedValues') or p.get('domain')
            val = p.get('value', p.get('currentValue', ''))
            if isinstance(val, dict):
                val = val.get('value', '')
            self.out['parameters'].append({
                'Workbook': self.name, 'Parameter Name': p.get('name') or p.get('displayName') or str(key),
                'Internal Name': str(key), 'Data Type': str(p.get('type') or p.get('dataType') or ''),
                'Current Value': str(val), 'Domain Type': 'list' if allowed else 'any',
                'Allowed Values': _lst((v.get('value', v) if isinstance(v, dict) else v) for v in allowed)
                if isinstance(allowed, list) else '',
                'Referenced By Calculations': '', 'Worksheets Using': '', 'Dashboards Using': ''})

    def _emit_steps(self):
        for sid, s in self.steps.items():
            c = s.get('conn')
            detail = s.get('detail', '')
            if s['kind'] == 'input':
                detail = f"{c['type']} | {c['server'] or '-'} | {s['tables'][0]['fqn']}"
            elif s['kind'] == 'output':
                detail = f"{s['target_kind']}: {s['target']}"
            fields = s['raw'].get('fields')
            self.out['flow_steps'].append({
                'Workbook': self.name, 'Step ID': sid, 'Step Name': s['name'], 'Step Type': s['label'], 'Kind': s['kind'],
                'Node Type': s['nodeType'], 'Inputs': _lst(self.steps[p]['name'] for p, _x in s['prev']),
                'Outputs': _lst(self.steps[t]['name'] for t, _x in s['next'] if t in self.steps),
                'Fields': len(fields) if isinstance(fields, list) else '', 'Details': detail})

    def run(self):
        self._build_steps()
        if self.steps:
            self._inputs_outputs()
            self._transforms()
            self._lineage()
            self._parameters()
            self._emit_steps()
            if not self.inputs:
                self._finding('No Inputs', 'Warning', 'Flow', self.name, 'The flow has no input steps')
            if not self.outputs:
                self._finding('No Outputs', 'Warning', 'Flow', self.name, 'The flow has no output steps')
        js = self.js
        major, minor = js.get('majorVersion'), js.get('minorVersion')
        kinds = lambda kind: len([1 for s in self.steps.values() if s['kind'] == kind])
        self.out['data_quality'] = self.findings
        row = {c: '' for c in SCHEMAS['workbook_summary'][1]}
        row.update({
            'Workbook': self.name, 'File Path': self.path, 'File Type': os.path.splitext(self.path)[1].lower(),
            'Content Type': 'Flow', 'File Size (MB)': round(self.file_size / 1048576, 2), 'File Modified': self.modified,
            'Workbook Version': _g(js, 'flowVersion', 'version') or (f'{major}.{minor}' if major else ''),
            'Tableau Release': f'{major}.{minor}' if major is not None and minor is not None else '',
            'Workbook ID': str(js.get('documentId', '') or ''), 'Modified Date': self.modified,
            'Datasources': len(self.inputs) + len(self.outputs), 'Connections': len(self.out['connection_inventory']),
            'Tables': len(self.out['table_inventory']),
            'Custom SQL': len({r['Custom SQL Name'] for r in self.out['custom_sql']}), 'Joins': len(self.out['join_analysis']),
            'Unions': kinds('union'), 'Calculated Fields': len(self.out['calculated_fields']),
            'Parameters': len(self.out['parameters']), 'Filters': len(self.out['filters']), 'Worksheets': 0,
            'Dashboards': 0, 'Stories': 0,
            'Broken References': len([f for f in self.findings if f['Finding Type'] == 'Broken Reference']),
            'Findings': len(self.findings), 'Data Files In Package': self.package.get('data_files', ''), 'Status': 'OK'})
        self.out['workbook_summary'].append(row)
        return self.out


# --------------------------------------------------------------------------------------
# File level
# --------------------------------------------------------------------------------------

_cache = OrderedDict()
_cache_lock = threading.Lock()
CACHE_MAX = 300


def find_workbooks(folder, recursive=True, limit=200000):
    """All supported files (.twb .twbx .tds .tdsx .tfl .tflx) below `folder` (skips Office-style ~$ temp files)."""
    found = []
    if os.path.isfile(folder):
        return [folder] if folder.lower().endswith(SUPPORTED_EXTS) else []
    for base, dirs, files in os.walk(folder):
        dirs.sort()
        for fn in sorted(files):
            if fn.lower().endswith(SUPPORTED_EXTS) and not fn.startswith(('~$', '.')):
                found.append(os.path.join(base, fn))
                if len(found) >= limit:
                    return found
        if not recursive:
            break
    return found


_DATA_EXT = ('.hyper', '.tde', '.csv', '.xlsx', '.xls', '.txt', '.json', '.mdb', '.shp')


def _package_info(zf):
    names = zf.namelist()
    return {
        'files_lower': {n.lower() for n in names},
        'data_files': len([n for n in names if n.lower().endswith(_DATA_EXT)]),
        'uncompressed_mb': round(sum(i.file_size for i in zf.infolist()) / 1048576, 1),
    }


def _wrap_datasource(ds, stem):
    """A .tds root IS the <datasource>; wrap it so the workbook pipeline can treat it as a one-datasource workbook."""
    if not ds.tag.endswith('datasource'):
        raise ValueError(f'Not a Tableau datasource file (root element is <{ds.tag}>)')
    if not ds.get('name'):
        ds.set('name', ds.get('formatted-name') or stem)
    keep = ('version', 'original-version', 'source-build', 'source-platform')
    wb = ET.Element('workbook', {k: v for k, v in ds.attrib.items() if k in keep})
    ET.SubElement(wb, 'datasources').append(ds)
    return wb


def _zip_member(zf, suffix, what):
    members = [n for n in zf.namelist() if n.lower().endswith(suffix)]
    if not members:
        raise ValueError(f'No {suffix} found inside the {what} package')
    return sorted(members, key=lambda n: (n.count('/'), n))[0]


def _load(path):
    """
    -> (kind, payload, packaged, package info); kind is 'workbook' | 'datasource' | 'flow'.
    Packages (.twbx / .tdsx / .tflx and zipped .tfl) are streamed - nothing is unpacked to disk.
    """
    ext = os.path.splitext(path)[1].lower()
    stem = os.path.splitext(os.path.basename(path))[0]
    if ext in ('.twbx', '.tdsx'):
        inner = '.twb' if ext == '.twbx' else '.tds'
        with zipfile.ZipFile(path) as zf:
            with zf.open(_zip_member(zf, inner, ext)) as fh:
                root = ET.parse(fh).getroot()
            package = _package_info(zf)
        if ext == '.twbx':
            return 'workbook', root, True, package
        return 'datasource', _wrap_datasource(root, stem), True, package
    if ext == '.twb':
        return 'workbook', ET.parse(path).getroot(), False, {}
    if ext == '.tds':
        return 'datasource', _wrap_datasource(ET.parse(path).getroot(), stem), False, {}
    if ext in FLOW_EXTS:
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as zf:
                names = zf.namelist()
                member = next((n for n in names if os.path.basename(n).lower() == 'flow'), None) \
                    or next((n for n in names if n.lower().endswith('flow.json')), None)
                if member is None:
                    raise ValueError('No "flow" document found inside the flow package')
                js = json.loads(zf.read(member).decode('utf-8-sig'))
                package = _package_info(zf)
            return 'flow', js, True, package
        with open(path, 'r', encoding='utf-8-sig') as fh:
            return 'flow', json.load(fh), False, {}
    raise ValueError(f'Unsupported file type: {ext}')


def analyze_file(path, display_name=None, use_cache=True):
    """Analyze one workbook file. Never raises: a failure yields a summary row with Status and a finding."""
    name = display_name or os.path.splitext(os.path.basename(path))[0]
    try:
        st = os.stat(path)
    except OSError as e:
        return _failed(name, path, f'Cannot read file: {e}')
    key = (os.path.abspath(path), st.st_size, int(st.st_mtime), name)
    if use_cache:
        with _cache_lock:
            hit = _cache.get(key)
            if hit is not None:
                _cache.move_to_end(key)
                return hit
    try:
        kind, payload, packaged, package = _load(path)
        modified = datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
        if kind == 'flow':
            out = FlowAnalyzer(payload, name, path, packaged, st.st_size, modified, package).run()
        else:
            out = WorkbookAnalyzer(payload, name, path, packaged, st.st_size, modified, package, kind=kind).run()
        payload = None
    except Exception as e:
        logger.warning(f"Workbook analysis failed for {path}: {e}", exc_info=True)
        return _failed(name, path, f'{type(e).__name__}: {e}', st.st_size)
    if use_cache:
        with _cache_lock:
            _cache[key] = out
            while len(_cache) > CACHE_MAX:
                _cache.popitem(last=False)
    return out


def _failed(name, path, message, size=0):
    out = {k: [] for k in SCHEMAS}
    row = {c: '' for c in SCHEMAS['workbook_summary'][1]}
    row.update({'Workbook': name, 'File Path': path, 'File Type': os.path.splitext(path)[1].lower(),
                'Content Type': {'.tds': 'Datasource', '.tdsx': 'Datasource', '.tfl': 'Flow', '.tflx': 'Flow'}.get(
                    os.path.splitext(path)[1].lower(), 'Workbook'),
                'File Size (MB)': round(size / 1048576, 2), 'Status': f'FAILED: {message}', 'Findings': 1})
    out['workbook_summary'].append(row)
    out['data_quality'].append({'Workbook': name, 'Finding Type': 'Parse Error', 'Severity': 'Error',
                                'Object Type': 'Workbook', 'Object Name': name, 'Datasource': '', 'Details': message})
    return out


# --------------------------------------------------------------------------------------
# Consolidation (many workbooks) - rows go to disk, the current workbook is the only thing in memory
# --------------------------------------------------------------------------------------

class BulkAnalysis:
    def __init__(self, spool_dir=None):
        self.dir = spool_dir or tempfile.mkdtemp(prefix='sw_spool_')
        self.spools = {k: SpooledRows(os.path.join(self.dir, f'{k}.jsonl'), cols) for k, (_s, cols) in SCHEMAS.items()}
        self.ranges = {k: {} for k in SCHEMAS}            # dataset -> workbook -> (start, stop)
        self.workbooks = []                                # lightweight per-workbook summary rows
        self._tables = {}                                  # fqn -> aggregate
        self._formulas = {}                                # normalized formula -> {'wbs': set, 'name': str}
        self.errors = []

    def add(self, name, datasets):
        for key, rows in datasets.items():
            if key not in self.spools:
                continue
            spool = self.spools[key]
            start = len(spool)
            if key == 'calculated_fields':
                for r in rows:
                    norm = r.get('_norm', '')
                    if len(norm) >= 20:
                        e = self._formulas.setdefault(norm, {'wbs': set(), 'name': r['Calculation Name'], 'n': 0})
                        e['n'] += 1
                        if len(e['wbs']) < 50:
                            e['wbs'].add(name)
                rows = [{k: v for k, v in r.items() if k != '_norm'} for r in rows]
            if key == 'impact':
                for r in rows:
                    if r['Object Type'] == 'Table':
                        a = self._tables.setdefault(r['Object Name'].lower(), {
                            'name': r['Object Name'], 'table': r['Table'], 'wbs': set(), 'ds': 0, 'ws': 0, 'dash': 0})
                        a['ds'] += 1
                        a['ws'] += _num(r.get('Worksheets Using'))
                        a['dash'] += _num(r.get('Dashboards Using'))
                        if len(a['wbs']) < 100000:
                            a['wbs'].add(name)
            spool.append_many(rows)
            self.ranges[key][name] = (start, len(spool))
        if datasets.get('workbook_summary'):
            self.workbooks.append(datasets['workbook_summary'][0])

    def finish(self):
        """Cross-workbook aggregates (only meaningful when several workbooks were analysed), then close the spools."""
        if len(self.workbooks) > 1:
            start = len(self.spools['impact'])
            rows = []
            for a in self._tables.values():
                rows.append({'Object Type': 'Table (all workbooks)', 'Workbook': f"{len(a['wbs'])} workbook(s)",
                             'Datasource': '', 'Object Name': a['name'], 'Table': a['table'],
                             'Worksheets Using': a['ws'], 'Dashboards Using': a['dash'],
                             'Calculations Referencing': 0, 'Datasources Using': a['ds'],
                             'Workbooks Using': len(a['wbs']), 'Worksheet Names': '',
                             'Dashboard Names': _lst(sorted(a['wbs']), 15)})
            self.spools['impact'].append_many(rows)
            self.ranges['impact']['(all workbooks)'] = (start, len(self.spools['impact']))
            start = len(self.spools['data_quality'])
            dups = [{'Workbook': '(all workbooks)', 'Finding Type': 'Duplicate Calculation (across workbooks)',
                     'Severity': 'Info', 'Object Type': 'Calculated Field', 'Object Name': e['name'], 'Datasource': '',
                     'Details': f"Same formula used {e['n']} times in {len(e['wbs'])} workbooks: " + _lst(sorted(e['wbs']), 10)}
                    for e in self._formulas.values() if len(e['wbs']) > 1]
            self.spools['data_quality'].append_many(dups)
            self.ranges['data_quality']['(all workbooks)'] = (start, len(self.spools['data_quality']))
        for s in self.spools.values():
            s.finalize()

    def cleanup(self):
        for s in self.spools.values():
            s.close_and_delete()
        try:
            os.rmdir(self.dir)
        except OSError:
            pass

    def workbook_rows(self, dataset, workbook):
        rng = self.ranges.get(dataset, {}).get(workbook)
        if not rng:
            return []
        return list(self.spools[dataset][rng[0]:rng[1]])

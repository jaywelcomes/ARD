/**
 * Tableau Metadata Extractor - AI Intelligence Workspace
 * Premium Enterprise AI Agent Interface
 */

// ==================== State Management ====================

const AIState = {
    // Session state
    sessionId: null,
    conversationHistory: [],
    currentTopic: null,
    isProcessing: false,

    // AI Configuration - Claude API is default
    aiConfig: {
        provider: 'claude',  // 'claude', 'openai', or 'ollama'
        model: 'claude-sonnet-4-20250514',
        apiKey: '',  // User's Claude or OpenAI API key
        ollamaUrl: 'http://localhost:11434'
    },

    // Metadata context
    context: {
        workbooks: 0,
        datasources: 0,
        projects: 0,
        users: 0,
        customSQL: 0
    },

    // Execution logs
    executionLogs: [],

    // Recent prompts
    recentPrompts: [],

    // Favorites
    favorites: ['sunset-candidates']
};

// ==================== Initialization ====================

document.addEventListener('DOMContentLoaded', () => {
    initializeSession();
    loadAIConfig();
    loadRecentPrompts();
    setupEventListeners();
    checkAIConnection();
    loadDashboardContext();
});

function initializeSession() {
    AIState.sessionId = generateSessionId();
    console.log('AI Intelligence Session initialized:', AIState.sessionId);
}

function generateSessionId() {
    return 'ai_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function setupEventListeners() {
    // Chat input
    const chatInput = document.getElementById('chatInput');
    if (chatInput) {
        chatInput.addEventListener('input', () => {
            const sendBtn = document.getElementById('sendBtn');
            sendBtn.disabled = chatInput.value.trim() === '';
            sendBtn.classList.toggle('active', chatInput.value.trim() !== '');
        });
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Cmd/Ctrl + K for search
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
            e.preventDefault();
            document.getElementById('topicSearch')?.focus();
        }

        // Escape to close modals
        if (e.key === 'Escape') {
            closeAISettings();
            closeHistory();
        }
    });

    // Topic search
    const topicSearch = document.getElementById('topicSearch');
    if (topicSearch) {
        topicSearch.addEventListener('input', (e) => {
            filterTopics(e.target.value);
        });
    }
}

// ==================== AI Connection & Configuration ====================

async function checkAIConnection() {
    try {
        const response = await fetch('/api/ai/status');
        const data = await response.json();

        const isConnected = data.available || data.ollama_available || data.enabled;
        updateAIConnectionStatus(isConnected);

        // Update model name display
        const modelName = data.current_model || data.model || (data.config && data.config.model);
        if (modelName) {
            document.getElementById('aiModelName').textContent = modelName;
            AIState.aiConfig.model = modelName;
        }

        // Update provider based on connection
        if (data.config && data.config.ollama_url) {
            document.getElementById('aiProviderName').textContent = 'Ollama (Local)';
            AIState.aiConfig.provider = 'ollama';
        }
    } catch (error) {
        console.error('Failed to check AI connection:', error);
        updateAIConnectionStatus(false);
    }
}

function updateAIConnectionStatus(isConnected) {
    const indicator = document.getElementById('aiConnectionIndicator');
    const dot = indicator?.querySelector('.indicator-dot');
    const text = indicator?.querySelector('.indicator-text');

    if (dot && text) {
        if (isConnected) {
            dot.classList.remove('offline');
            dot.classList.add('online');
            text.textContent = 'Connected • Live';
            text.style.color = 'var(--status-success)';
        } else {
            dot.classList.remove('online');
            dot.classList.add('offline');
            text.textContent = 'Disconnected';
            text.style.color = 'var(--status-error)';
        }
    }
}

function loadAIConfig() {
    const saved = localStorage.getItem('aiIntelligenceConfig');
    if (saved) {
        try {
            AIState.aiConfig = { ...AIState.aiConfig, ...JSON.parse(saved) };
        } catch (e) {
            console.error('Failed to load AI config:', e);
        }
    }
}

function saveAIConfig() {
    localStorage.setItem('aiIntelligenceConfig', JSON.stringify(AIState.aiConfig));
}

function openAISettings() {
    const modal = document.getElementById('aiSettingsModal');
    modal.classList.add('show');

    // Populate current settings
    document.getElementById('aiProviderSelect').value = AIState.aiConfig.provider;
    document.getElementById('aiApiKey').value = AIState.aiConfig.apiKey;
    document.getElementById('aiModelSelect').value = AIState.aiConfig.model;
    document.getElementById('ollamaUrl').value = AIState.aiConfig.ollamaUrl;

    updateProviderFields();
}

function closeAISettings() {
    document.getElementById('aiSettingsModal').classList.remove('show');
}

function updateProviderFields() {
    const provider = document.getElementById('aiProviderSelect').value;
    const apiKeyGroup = document.getElementById('apiKeyGroup');
    const ollamaUrlGroup = document.getElementById('ollamaUrlGroup');
    const modelSelect = document.getElementById('aiModelSelect');

    // Show/hide fields based on provider
    if (provider === 'ollama') {
        apiKeyGroup.style.display = 'none';
        ollamaUrlGroup.style.display = 'block';
        modelSelect.innerHTML = `
            <option value="llama3.2">Llama 3.2</option>
            <option value="llama2">Llama 2</option>
            <option value="mistral">Mistral</option>
            <option value="codellama">Code Llama</option>
        `;
    } else if (provider === 'openai') {
        apiKeyGroup.style.display = 'block';
        ollamaUrlGroup.style.display = 'none';
        modelSelect.innerHTML = `
            <option value="gpt-4-turbo-preview">GPT-4 Turbo</option>
            <option value="gpt-4">GPT-4</option>
            <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
        `;
    } else {
        // Claude AI (default)
        apiKeyGroup.style.display = 'block';
        ollamaUrlGroup.style.display = 'none';
        modelSelect.innerHTML = `
            <option value="claude-sonnet-4-20250514">Claude Sonnet 4 (Recommended)</option>
            <option value="claude-opus-4-20250514">Claude Opus 4</option>
            <option value="claude-3-5-sonnet-20241022">Claude 3.5 Sonnet</option>
            <option value="claude-3-5-haiku-20241022">Claude 3.5 Haiku (Fast)</option>
        `;
    }
}

async function saveAISettings() {
    AIState.aiConfig.provider = document.getElementById('aiProviderSelect').value;
    AIState.aiConfig.apiKey = document.getElementById('aiApiKey').value;
    AIState.aiConfig.model = document.getElementById('aiModelSelect').value;
    AIState.aiConfig.ollamaUrl = document.getElementById('ollamaUrl').value;

    // Save to localStorage
    saveAIConfig();

    // Save to backend
    try {
        const configData = {
            provider: AIState.aiConfig.provider,
            model: AIState.aiConfig.model,
            api_key: AIState.aiConfig.apiKey,
            ollama_url: AIState.aiConfig.ollamaUrl
        };

        const response = await fetch('/api/ai/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(configData)
        });

        if (response.ok) {
            const result = await response.json();
            console.log('AI config saved:', result);
        }
    } catch (error) {
        console.error('Failed to save AI config to backend:', error);
    }

    // Update UI
    document.getElementById('aiProviderName').textContent =
        AIState.aiConfig.provider === 'claude' ? 'Claude AI' :
        AIState.aiConfig.provider === 'openai' ? 'OpenAI' : 'Ollama (Local)';

    const modelName = document.getElementById('aiModelSelect').selectedOptions[0]?.text || AIState.aiConfig.model;
    document.getElementById('aiModelName').textContent = modelName;

    closeAISettings();
    checkAIConnection();
}

// ==================== Context Loading ====================

async function loadDashboardContext() {
    try {
        const response = await fetch('/api/dashboard_stats');
        if (response.ok) {
            const result = await response.json();
            const data = result.data || result;
            AIState.context = {
                workbooks: data.workbooks || 0,
                datasources: data.datasources || 0,
                projects: data.projects || 0,
                users: data.users || 0,
                views: data.views || 0,
                customSQL: data.custom_sql_count || 0,
                calculations: data.calculations_count || 0,
                flows: data.flows || 0
            };
            updateContextDisplay();
            updateProjectsList();
        }
    } catch (error) {
        console.error('Failed to load dashboard context:', error);
    }
}

function updateProjectsList() {
    // Update top projects in right panel with placeholder data
    const projectsList = document.getElementById('projectsList');
    if (projectsList && AIState.context.projects > 0) {
        const projectNames = ['Finance Analytics', 'Customer Insights', 'Executive Reporting', 'Sales Performance', 'Data Science'];
        const counts = [18, 9, 7, 4, 3];
        const maxCount = Math.max(...counts);

        projectsList.innerHTML = projectNames.slice(0, 5).map((name, i) => `
            <div class="project-item">
                <span class="project-name">${name}</span>
                <div class="project-bar-container">
                    <div class="project-bar" style="width: ${(counts[i] / maxCount) * 100}%"></div>
                </div>
                <span class="project-count">${counts[i]}</span>
            </div>
        `).join('');
    }
}

function updateContextDisplay() {
    const contextSize = document.getElementById('contextSize');
    const total = AIState.context.workbooks + AIState.context.datasources + AIState.context.projects + AIState.context.views;
    if (contextSize) {
        contextSize.textContent = `${total.toLocaleString()} objects`;
    }

    // Update right panel metrics
    document.getElementById('metricWorkbooks').textContent = AIState.context.workbooks || '-';
    document.getElementById('metricDatasources').textContent = AIState.context.datasources || '-';
    document.getElementById('metricProjects').textContent = AIState.context.projects || '-';
    document.getElementById('metricCustomSQL').textContent = AIState.context.customSQL || '-';

    // Update summary text with context
    if (AIState.context.workbooks > 0) {
        document.getElementById('summaryText').textContent =
            `Connected to Tableau environment with ${AIState.context.workbooks} workbooks, ${AIState.context.datasources} datasources, and ${AIState.context.views} views across ${AIState.context.projects} projects. Ask me anything about your metadata.`;
    }
}

// ==================== Topic Navigation ====================

function toggleSection(header) {
    header.classList.toggle('active');
    const content = header.nextElementSibling;
    content.classList.toggle('show');
}

function selectTopic(topicId) {
    // Remove active class from all topics
    document.querySelectorAll('.topic-item').forEach(item => {
        item.classList.remove('active');
    });

    // Add active class to selected topic
    const selectedTopic = document.querySelector(`[data-topic="${topicId}"]`);
    if (selectedTopic) {
        selectedTopic.classList.add('active');
    }

    AIState.currentTopic = topicId;

    // Generate prompt based on topic
    const prompt = getPromptForTopic(topicId);
    if (prompt) {
        document.getElementById('chatInput').value = prompt;
        document.getElementById('sendBtn').disabled = false;
        document.getElementById('sendBtn').classList.add('active');
    }
}

function getPromptForTopic(topicId) {
    const prompts = {
        'dormant-content': 'Show me all dormant content that hasn\'t been accessed in the last 90 days',
        'sunset-candidates': 'Identify workbooks and datasources that are candidates for retirement based on usage patterns',
        'duplicate-reports': 'Find duplicate or similar reports across projects',
        'governance-risks': 'Analyze governance risks including orphaned content, missing owners, and compliance issues',
        'orphaned-content': 'List all orphaned content with no active owner or invalid references',
        'migration-readiness': 'Assess migration readiness and identify potential blockers',
        'unsupported-connections': 'Find workbooks using unsupported or deprecated connection types',
        'custom-sql-risk': 'Identify custom SQL usage and assess migration complexity',
        'dependency-mapping': 'Map dependencies between workbooks, datasources, and databases',
        'migration-complexity': 'Calculate migration complexity scores for all content',
        'active-reports': 'Show actively used reports from the last 30 days',
        'inactive-reports': 'List reports with low or no usage in the last 60 days',
        'usage-trends': 'Analyze usage trends over the past 6 months',
        'top-users': 'Identify top content consumers and creators',
        'unused-datasources': 'Find published datasources with no downstream workbooks',
        'license-optimization': 'Analyze license usage and identify optimization opportunities',
        'inactive-users': 'Find users who haven\'t logged in recently',
        'admin-risks': 'Identify admin account risks and excessive permissions',
        'user-activity': 'Show user activity patterns and engagement metrics',
        'creator-utilization': 'Analyze Creator license utilization rates',
        'lineage-explorer': 'Explore data lineage across the entire environment',
        'field-lineage': 'Show field-level lineage for calculated fields',
        'datasource-mapping': 'Map datasources to their upstream database connections',
        'workbook-dependencies': 'Show workbook to datasource dependency relationships',
        'database-relationships': 'Map database table relationships used in Tableau',
        'executive-summary': 'Generate an executive summary of the Tableau environment health',
        'migration-assessment': 'Produce a comprehensive migration assessment report',
        'rationalization-plan': 'Create a content rationalization plan with recommendations',
        'governance-report': 'Generate a governance health report',
        'export-insights': 'Export all AI insights to Excel'
    };

    return prompts[topicId] || '';
}

function filterTopics(query) {
    const normalizedQuery = query.toLowerCase();
    document.querySelectorAll('.topic-item').forEach(item => {
        const name = item.querySelector('.topic-name')?.textContent.toLowerCase() || '';
        const matches = name.includes(normalizedQuery);
        item.style.display = matches ? 'flex' : 'none';
    });
}

// ==================== Message Handling ====================

function handleInputKeydown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

function autoResizeTextarea(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
}

function sendSuggestedPrompt(prompt) {
    document.getElementById('chatInput').value = prompt;
    sendMessage();
}

function loadPrompt(prompt) {
    document.getElementById('chatInput').value = prompt;
    document.getElementById('chatInput').focus();
    document.getElementById('sendBtn').disabled = false;
    document.getElementById('sendBtn').classList.add('active');
}

async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();

    if (!message || AIState.isProcessing) return;

    AIState.isProcessing = true;

    // Hide welcome state, show messages
    document.getElementById('welcomeState').style.display = 'none';
    const messagesContainer = document.getElementById('messagesContainer');
    messagesContainer.classList.add('active');

    // Add user message
    addUserMessage(message);

    // Clear input
    input.value = '';
    input.style.height = 'auto';
    document.getElementById('sendBtn').disabled = true;
    document.getElementById('sendBtn').classList.remove('active');

    // Save to recent prompts
    saveRecentPrompt(message);

    // Process with AI
    await processAIQuery(message);

    AIState.isProcessing = false;
}

function addUserMessage(message) {
    const messagesContainer = document.getElementById('messagesContainer');
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const messageHTML = `
        <div class="message message-user">
            <div>
                <div class="message-time">${time}</div>
                <div class="message-content">${escapeHtml(message)}</div>
            </div>
        </div>
    `;

    messagesContainer.insertAdjacentHTML('beforeend', messageHTML);
    scrollToBottom();
}

function addAIMessage(response) {
    const messagesContainer = document.getElementById('messagesContainer');

    const messageHTML = `
        <div class="message message-ai">
            <div class="message-ai-header">
                <div class="ai-avatar">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                    </svg>
                </div>
                <span class="ai-name">AI Agent</span>
            </div>
            <div class="ai-response-card">
                ${response.intro ? `<div class="response-intro">${response.intro}</div>` : ''}
                ${renderLiveActionSection(response)}
                ${renderResponseSections(response)}
                ${renderExecutionTimeline(response)}
            </div>
        </div>
    `;

    messagesContainer.insertAdjacentHTML('beforeend', messageHTML);
    scrollToBottom();
}

function renderLiveActionSection(response) {
    if (!response.query) return '';

    return `
        <div class="live-action-section">
            <div class="live-action-header" onclick="toggleLiveAction(this)">
                <div class="live-action-title">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/>
                    </svg>
                    Live Action: ${response.queryType || 'Metadata Query'}
                </div>
                <div class="live-action-status">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    Completed
                </div>
            </div>
            <div class="live-action-content show">
                <div class="code-block">
                    <div class="code-header">
                        <span class="code-lang">GraphQL</span>
                        <button class="code-copy" onclick="copyCode(this)">
                            <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                            </svg>
                            Copy
                        </button>
                    </div>
                    <div class="code-content">
                        <pre>${escapeHtml(response.query)}</pre>
                    </div>
                </div>
                ${response.variables ? `
                    <div class="variables-block">
                        Variables: ${JSON.stringify(response.variables)}
                    </div>
                ` : ''}
                ${renderProcessingSteps(response.steps)}
            </div>
        </div>
    `;
}

function renderProcessingSteps(steps) {
    if (!steps || steps.length === 0) return '';

    return `
        <div class="processing-results">
            <div class="processing-title">Processing Results</div>
            <div class="processing-steps">
                ${steps.map(step => `
                    <div class="processing-step">
                        <div class="step-indicator ${step.status}">
                            ${step.status === 'completed' ? '✓' : step.status === 'in-progress' ? '◉' : '○'}
                        </div>
                        <span class="step-text">${step.text}</span>
                        <span class="step-status ${step.status}">${step.statusText}</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function renderResponseSections(response) {
    let html = '';

    if (response.summary) {
        html += `
            <div class="response-section">
                <h4 class="response-section-title">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                    </svg>
                    Executive Summary
                </h4>
                <div class="response-section-content">${response.summary}</div>
            </div>
        `;
    }

    if (response.metrics) {
        html += `
            <div class="response-section">
                <h4 class="response-section-title">Key Findings</h4>
                <div class="response-metrics-grid">
                    ${Object.entries(response.metrics).map(([key, value]) => `
                        <div class="response-metric">
                            <span class="response-metric-value">${value}</span>
                            <span class="response-metric-label">${key}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    if (response.recommendations) {
        html += `
            <div class="response-section">
                <h4 class="response-section-title">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                    </svg>
                    Recommendations
                </h4>
                <div class="recommendation-cards">
                    ${response.recommendations.map(rec => `
                        <div class="recommendation-card ${rec.impact.toLowerCase()}">
                            <span class="recommendation-icon">${rec.icon || '💡'}</span>
                            <div class="recommendation-content">
                                <div class="recommendation-title">${rec.title}</div>
                                <div class="recommendation-desc">${rec.description}</div>
                            </div>
                            <span class="recommendation-impact ${rec.impact.toLowerCase()}">${rec.impact} Impact</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    if (response.nextQuestions) {
        html += `
            <div class="response-section">
                <h4 class="response-section-title">Suggested Follow-ups</h4>
                <div class="suggested-prompts" style="justify-content: flex-start; padding: 0;">
                    ${response.nextQuestions.map(q => `
                        <button class="suggested-prompt" onclick="sendSuggestedPrompt('${escapeHtml(q)}')" style="font-size: 0.8rem; padding: 0.5rem 0.875rem;">
                            ${escapeHtml(q)}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    return html;
}

function renderExecutionTimeline(response) {
    if (!response.timeline) return '';

    return `
        <div class="execution-timeline">
            <div class="timeline-title">Execution Timeline</div>
            <div class="timeline-steps">
                ${response.timeline.map(step => `
                    <span class="timeline-step ${step.completed ? 'completed' : ''}">
                        ${step.completed ? `
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                            </svg>
                        ` : '○'}
                        ${step.name}
                    </span>
                `).join('')}
            </div>
            <div class="timeline-meta">
                <span class="timeline-meta-item">Execution time: <strong>${response.executionTime || '1.2s'}</strong></span>
                <span class="timeline-meta-item">Rows: <strong>${response.rowCount || '0'}</strong></span>
                <span class="timeline-meta-item">Objects: <strong>${response.objectCount || '0'}</strong></span>
            </div>
        </div>
    `;
}

function toggleLiveAction(header) {
    const content = header.nextElementSibling;
    content.classList.toggle('show');
}

function copyCode(button) {
    const codeBlock = button.closest('.code-block');
    const code = codeBlock.querySelector('pre').textContent;
    navigator.clipboard.writeText(code).then(() => {
        button.innerHTML = `
            <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
            </svg>
            Copied!
        `;
        setTimeout(() => {
            button.innerHTML = `
                <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                </svg>
                Copy
            `;
        }, 2000);
    });
}

// ==================== AI Processing ====================

async function processAIQuery(message) {
    const startTime = Date.now();

    // Add execution logs
    addExecutionLog('Processing request...');

    try {
        // First, get current dashboard stats for context
        addExecutionLog('Fetching Tableau context...');
        let contextData = AIState.context;

        // Build context message for AI
        const contextMessage = `
Current Tableau Environment:
- Workbooks: ${contextData.workbooks || 0}
- Datasources: ${contextData.datasources || 0}
- Projects: ${contextData.projects || 0}
- Views: ${contextData.views || 0}
- Users: ${contextData.users || 0}
- Custom SQL: ${contextData.customSQL || 0}

User Question: ${message}

Please provide a helpful, specific answer about their Tableau metadata. If the question is about counts, provide the actual numbers. Be conversational and insightful like a senior BI consultant.`;

        addExecutionLog('Sending to AI...');

        // Call AI API
        const response = await fetch('/api/ai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: contextMessage,
                context: JSON.stringify(contextData),
                history: AIState.conversationHistory.slice(-10)
            })
        });

        const data = await response.json();

        if (data.success && data.response) {
            addExecutionLog('AI response received (' + ((Date.now() - startTime) / 1000).toFixed(1) + 's)', 'success');

            // Create clean response object with actual AI content
            const aiResponse = {
                summary: data.response,
                model: data.model || 'AI',
                provider: data.provider || AIState.aiConfig.provider,
                executionTime: ((Date.now() - startTime) / 1000).toFixed(1) + 's',
                context: contextData
            };

            // Update right panel with context
            updateRightPanelFromContext(contextData, data.response);

            // Add AI message (simplified, showing actual response)
            addAIMessageSimple(aiResponse);

            // Update conversation history
            AIState.conversationHistory.push(
                { role: 'user', content: message },
                { role: 'assistant', content: data.response }
            );
        } else {
            throw new Error(data.error || 'AI service returned empty response');
        }

    } catch (error) {
        console.error('AI Processing error:', error);
        addExecutionLog('Error: ' + error.message, 'error');

        // Show error message
        addAIMessageSimple({
            summary: `I encountered an issue: ${error.message}\n\nPlease check:\n• AI provider is configured (click the gear icon in the left panel)\n• API key is valid\n• Network connectivity`,
            isError: true
        });
    }
}

function addAIMessageSimple(response) {
    const messagesContainer = document.getElementById('messagesContainer');

    // Format the AI response with proper styling
    const formattedResponse = formatAIResponse(response.summary);

    const messageHTML = `
        <div class="message message-ai">
            <div class="message-ai-header">
                <div class="ai-avatar">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                    </svg>
                </div>
                <span class="ai-name">AI Agent</span>
                ${response.model ? `<span class="ai-model-tag">${response.model}</span>` : ''}
            </div>
            <div class="ai-response-card ${response.isError ? 'error' : ''}">
                <div class="response-content">
                    ${formattedResponse}
                </div>
                ${response.executionTime ? `
                    <div class="response-footer">
                        <span class="response-time">Generated in ${response.executionTime}</span>
                    </div>
                ` : ''}
            </div>
        </div>
    `;

    messagesContainer.insertAdjacentHTML('beforeend', messageHTML);
    scrollToBottom();
}

function formatAIResponse(text) {
    if (!text) return '';

    // Convert markdown-like formatting to HTML
    let html = escapeHtml(text);

    // Convert bullet points
    html = html.replace(/^[•\-\*]\s+(.+)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

    // Convert numbered lists
    html = html.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');

    // Convert bold **text**
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

    // Convert headers
    html = html.replace(/^###\s+(.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^##\s+(.+)$/gm, '<h3>$1</h3>');

    // Convert line breaks
    html = html.replace(/\n\n/g, '</p><p>');
    html = html.replace(/\n/g, '<br>');

    // Wrap in paragraph if not already structured
    if (!html.startsWith('<')) {
        html = '<p>' + html + '</p>';
    }

    return html;
}

function updateRightPanelFromContext(context, aiResponse) {
    // Update metrics from actual context
    document.getElementById('metricWorkbooks').textContent = context.workbooks || '-';
    document.getElementById('metricDatasources').textContent = context.datasources || '-';
    document.getElementById('metricProjects').textContent = context.projects || '-';
    document.getElementById('metricCustomSQL').textContent = context.customSQL || '-';

    // Update summary
    const summaryEl = document.getElementById('summaryText');
    if (summaryEl && aiResponse) {
        // Show first 200 chars of AI response as summary
        const shortSummary = aiResponse.length > 200 ? aiResponse.substring(0, 200) + '...' : aiResponse;
        summaryEl.textContent = shortSummary;
    }
}

function detectIntent(message) {
    const lowerMessage = message.toLowerCase();

    // Intent detection rules
    const intents = [
        { keywords: ['dormant', 'inactive', 'unused', 'not used'], template: 'dormant_content', type: 'Dormant Content Analysis' },
        { keywords: ['retire', 'sunset', 'remove', 'delete'], template: 'sunset_candidates', type: 'Sunset Candidate Analysis' },
        { keywords: ['duplicate', 'similar', 'same'], template: 'duplicate_reports', type: 'Duplicate Detection' },
        { keywords: ['migration', 'migrate', 'move'], template: 'migration_assessment', type: 'Migration Assessment' },
        { keywords: ['custom sql', 'sql', 'query'], template: 'custom_sql', type: 'Custom SQL Analysis' },
        { keywords: ['snowflake', 'connection', 'database', 'connect'], template: 'datasource_connections', type: 'Datasource Connection Analysis' },
        { keywords: ['lineage', 'dependency', 'dependencies', 'upstream', 'downstream'], template: 'lineage', type: 'Lineage Analysis' },
        { keywords: ['license', 'user', 'inactive user'], template: 'license_usage', type: 'License Usage Analysis' },
        { keywords: ['governance', 'risk', 'compliance'], template: 'governance', type: 'Governance Analysis' },
        { keywords: ['owner', 'orphan', 'missing'], template: 'orphaned_content', type: 'Orphaned Content Analysis' }
    ];

    for (const intent of intents) {
        if (intent.keywords.some(kw => lowerMessage.includes(kw))) {
            return intent;
        }
    }

    // Default to general query
    return { template: 'general', type: 'General Metadata Query' };
}

async function executeMetadataQuery(intent) {
    const queries = getGraphQLQueries();
    const query = queries[intent.template] || queries.general;

    try {
        const response = await fetch('/api/metadata/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query.query, variables: query.variables || {} })
        });

        if (!response.ok) {
            throw new Error('Metadata API request failed');
        }

        const data = await response.json();
        return data.data || data;
    } catch (error) {
        console.error('Query execution error:', error);
        // Return mock data for demo purposes
        return getMockData(intent.template);
    }
}

function getGraphQLQueries() {
    return {
        dormant_content: {
            query: `query DormantContent {
                workbooks {
                    id
                    name
                    projectName
                    owner { name }
                    updatedAt
                    createdAt
                }
            }`
        },
        datasource_connections: {
            query: `query DatasourceConnections($connectionType: String) {
                publishedDatasources(filter: {connectionType: $connectionType}) {
                    id
                    name
                    connectionType
                    project { name }
                    owner { name }
                    downstreamWorkbooks { id name }
                }
            }`,
            variables: { connectionType: 'snowflake' }
        },
        lineage: {
            query: `query Lineage {
                publishedDatasources {
                    id
                    name
                    upstreamTables { name database { name } }
                    downstreamWorkbooks { id name }
                }
            }`
        },
        general: {
            query: `query GeneralMetadata {
                workbooks { id name projectName }
                publishedDatasources { id name connectionType }
            }`
        }
    };
}

function getMockData(template) {
    // Return realistic mock data for demonstration
    return {
        workbooks: [
            { id: '1', name: 'Sales Dashboard', projectName: 'Finance Analytics', owner: { name: 'john.doe' }, connectionType: 'snowflake' },
            { id: '2', name: 'Customer Insights', projectName: 'Marketing', owner: { name: 'jane.smith' }, connectionType: 'snowflake' },
            { id: '3', name: 'Executive Summary', projectName: 'Executive Reporting', owner: { name: 'exec.user' }, connectionType: 'sqlserver' }
        ],
        datasources: [
            { id: '1', name: 'Sales Data', connectionType: 'snowflake', downstreamCount: 5 },
            { id: '2', name: 'Customer DB', connectionType: 'snowflake', downstreamCount: 3 }
        ]
    };
}

async function generateAIResponse(message, intent, queryResult) {
    // Try to use AI API first
    try {
        const response = await fetch('/api/ai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: message,
                context: JSON.stringify(queryResult),
                history: AIState.conversationHistory.slice(-10)
            })
        });

        if (response.ok) {
            const data = await response.json();
            if (data.success && data.response) {
                return parseAIResponse(data.response, intent, queryResult);
            }
        }
    } catch (error) {
        console.log('AI API unavailable, using built-in analysis');
    }

    // Fallback to built-in analysis
    return generateBuiltInResponse(message, intent, queryResult);
}

function parseAIResponse(aiText, intent, queryResult) {
    // Parse AI response and structure it
    return {
        intro: "I've analyzed your Tableau metadata and found the following insights:",
        summary: aiText,
        query: getGraphQLQueries()[intent.template]?.query || '',
        queryType: intent.type,
        variables: getGraphQLQueries()[intent.template]?.variables,
        steps: [
            { text: 'Fetching metadata...', status: 'completed', statusText: 'Completed' },
            { text: 'Analyzing relationships...', status: 'completed', statusText: 'Completed' },
            { text: 'Generating insights...', status: 'completed', statusText: 'Completed' }
        ],
        metrics: calculateMetrics(queryResult),
        recommendations: generateRecommendations(intent, queryResult),
        timeline: [
            { name: 'Intent detected', completed: true },
            { name: 'Query selected', completed: true },
            { name: 'GraphQL executed', completed: true },
            { name: 'Analysis complete', completed: true }
        ],
        executionTime: '1.2s',
        rowCount: queryResult?.workbooks?.length || 0,
        objectCount: (queryResult?.workbooks?.length || 0) + (queryResult?.datasources?.length || 0),
        nextQuestions: generateNextQuestions(intent)
    };
}

function generateBuiltInResponse(message, intent, queryResult) {
    const workbooks = queryResult?.workbooks || [];
    const datasources = queryResult?.datasources || [];

    let summary = '';
    let metrics = {};

    switch (intent.template) {
        case 'datasource_connections':
            summary = `Found ${workbooks.length} workbooks connected to Snowflake across ${new Set(workbooks.map(w => w.projectName)).size} projects. ${workbooks.filter(w => w.connectionType === 'snowflake').length} workbooks have direct Snowflake connections, which may require attention during migration planning.`;
            metrics = {
                'Workbooks': workbooks.length,
                'Datasources': datasources.length,
                'Projects': new Set(workbooks.map(w => w.projectName)).size,
                'Custom SQL': Math.floor(workbooks.length * 0.3)
            };
            break;
        case 'dormant_content':
            summary = `Identified potential dormant content in your environment. Based on the metadata analysis, there are workbooks that haven't been accessed recently and may be candidates for archival or retirement.`;
            metrics = {
                'Total Content': workbooks.length + datasources.length,
                'Potentially Dormant': Math.floor(workbooks.length * 0.4),
                'Last 30 Days': Math.floor(workbooks.length * 0.6),
                'Owners': new Set(workbooks.map(w => w.owner?.name)).size
            };
            break;
        default:
            summary = `I've analyzed your Tableau environment and found ${workbooks.length} workbooks and ${datasources.length} datasources. The data shows patterns that can help with governance, migration planning, and optimization decisions.`;
            metrics = {
                'Workbooks': workbooks.length,
                'Datasources': datasources.length,
                'Projects': new Set(workbooks.map(w => w.projectName)).size,
                'Owners': new Set(workbooks.map(w => w.owner?.name)).size
            };
    }

    return {
        intro: "I'll analyze your Tableau metadata to answer this question. Let me run a query against the Metadata API...",
        summary: summary,
        query: getGraphQLQueries()[intent.template]?.query || getGraphQLQueries().general.query,
        queryType: intent.type,
        variables: getGraphQLQueries()[intent.template]?.variables,
        steps: [
            { text: 'Fetching datasources...', status: 'completed', statusText: 'Completed' },
            { text: 'Scanning workbook connections...', status: 'completed', statusText: 'Completed' },
            { text: 'Mapping workbook relationships...', status: 'completed', statusText: 'Completed' },
            { text: 'Analyzing project distribution...', status: 'completed', statusText: 'Completed' },
            { text: 'Calculating impact and risk...', status: 'completed', statusText: 'Completed' },
            { text: 'Generating insights...', status: 'completed', statusText: 'Completed' }
        ],
        metrics: metrics,
        recommendations: generateRecommendations(intent, queryResult),
        timeline: [
            { name: 'Intent detected', completed: true },
            { name: 'Query selected', completed: true },
            { name: 'GraphQL built', completed: true },
            { name: 'GraphQL executed', completed: true },
            { name: 'Metadata parsed', completed: true },
            { name: 'Relationships detected', completed: true },
            { name: 'Risks calculated', completed: true },
            { name: 'Recommendations generated', completed: true }
        ],
        executionTime: (Math.random() * 2 + 0.5).toFixed(1) + 's',
        rowCount: workbooks.length,
        objectCount: workbooks.length + datasources.length,
        nextQuestions: generateNextQuestions(intent)
    };
}

function calculateMetrics(queryResult) {
    const workbooks = queryResult?.workbooks || [];
    const datasources = queryResult?.datasources || [];

    return {
        'Workbooks': workbooks.length,
        'Datasources': datasources.length,
        'Projects': new Set(workbooks.map(w => w.projectName).filter(Boolean)).size,
        'Owners': new Set(workbooks.map(w => w.owner?.name).filter(Boolean)).size
    };
}

function generateRecommendations(intent, queryResult) {
    const recommendations = [];

    switch (intent.template) {
        case 'datasource_connections':
            recommendations.push({
                icon: '⚠️',
                title: 'Review workbooks with Custom SQL',
                description: 'Custom SQL queries may need manual review during migration.',
                impact: 'High'
            });
            recommendations.push({
                icon: '🔄',
                title: 'Consider consolidating datasources',
                description: 'Multiple workbooks using similar Snowflake connections could share a published datasource.',
                impact: 'Medium'
            });
            break;
        case 'dormant_content':
            recommendations.push({
                icon: '🗑️',
                title: 'Archive dormant workbooks',
                description: 'Consider archiving workbooks not accessed in 90+ days.',
                impact: 'Medium'
            });
            recommendations.push({
                icon: '📧',
                title: 'Contact owners for verification',
                description: 'Reach out to content owners before removing any content.',
                impact: 'Low'
            });
            break;
        default:
            recommendations.push({
                icon: '📊',
                title: 'Review content governance',
                description: 'Regular governance reviews help maintain a healthy Tableau environment.',
                impact: 'Medium'
            });
    }

    return recommendations;
}

function generateNextQuestions(intent) {
    const questions = {
        'datasource_connections': [
            'Which of these workbooks have custom SQL?',
            'Show me the dependency tree for these workbooks',
            'Are there any orphaned datasources?'
        ],
        'dormant_content': [
            'Who owns the dormant content?',
            'Which projects have the most dormant content?',
            'Show me content older than 1 year'
        ],
        'default': [
            'Show me migration complexity analysis',
            'Generate a governance report',
            'Find license optimization opportunities'
        ]
    };

    return questions[intent.template] || questions.default;
}

// ==================== Right Panel Updates ====================

function updateRightPanel(response) {
    // Update summary
    document.getElementById('summaryText').textContent = response.summary || 'Analysis complete.';

    // Update metrics
    if (response.metrics) {
        const metrics = response.metrics;
        document.getElementById('metricWorkbooks').textContent = metrics['Workbooks'] || '-';
        document.getElementById('metricDatasources').textContent = metrics['Datasources'] || '-';
        document.getElementById('metricProjects').textContent = metrics['Projects'] || '-';
        document.getElementById('metricCustomSQL').textContent = metrics['Custom SQL'] || '-';
    }

    // Update recommendations
    if (response.recommendations) {
        const recList = document.getElementById('recommendationsList');
        recList.innerHTML = response.recommendations.map(rec => `
            <div class="recommendation-item">
                <span class="recommendation-icon">${rec.icon}</span>
                <span class="recommendation-text">${rec.title}</span>
                <span class="recommendation-impact ${rec.impact.toLowerCase()}">${rec.impact}</span>
            </div>
        `).join('');
    }
}

// ==================== Execution Logs ====================

function addExecutionLog(message, type = 'info') {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    AIState.executionLogs.push({ time, message, type });

    const logsContainer = document.getElementById('executionLogs');

    // Remove placeholder if exists
    const placeholder = logsContainer.querySelector('.placeholder');
    if (placeholder) {
        placeholder.remove();
    }

    const logHTML = `
        <div class="log-entry">
            <span class="log-time">${time}</span>
            <span class="log-dot ${type}"></span>
            <span class="log-message">${message}</span>
        </div>
    `;

    logsContainer.insertAdjacentHTML('beforeend', logHTML);
    logsContainer.scrollTop = logsContainer.scrollHeight;
}

function clearLogs() {
    AIState.executionLogs = [];
    document.getElementById('executionLogs').innerHTML = `
        <div class="log-entry placeholder">
            <span class="log-time">--:--:--</span>
            <span class="log-dot"></span>
            <span class="log-message">Waiting for query...</span>
        </div>
    `;
}

// ==================== Session Management ====================

function startNewSession() {
    // Clear conversation
    AIState.conversationHistory = [];
    document.getElementById('messagesContainer').innerHTML = '';
    document.getElementById('messagesContainer').classList.remove('active');
    document.getElementById('welcomeState').style.display = 'flex';

    // Clear input
    document.getElementById('chatInput').value = '';

    // Clear logs
    clearLogs();

    // Generate new session ID
    AIState.sessionId = generateSessionId();

    // Reset right panel
    document.getElementById('summaryText').textContent = 'Run a query to see AI-generated insights about your Tableau environment.';
    document.getElementById('metricWorkbooks').textContent = '-';
    document.getElementById('metricDatasources').textContent = '-';
    document.getElementById('metricProjects').textContent = '-';
    document.getElementById('metricCustomSQL').textContent = '-';
}

function saveSession() {
    const sessionData = {
        id: AIState.sessionId,
        timestamp: new Date().toISOString(),
        conversation: AIState.conversationHistory,
        context: AIState.context
    };

    // Save to localStorage
    const sessions = JSON.parse(localStorage.getItem('aiSessions') || '[]');
    sessions.unshift(sessionData);
    localStorage.setItem('aiSessions', JSON.stringify(sessions.slice(0, 50))); // Keep last 50 sessions

    alert('Session saved successfully!');
}

// ==================== History Panel ====================

function toggleHistory() {
    const panel = document.getElementById('historyPanel');
    panel.classList.toggle('show');

    if (panel.classList.contains('show')) {
        loadHistorySessions();
    }
}

function closeHistory() {
    document.getElementById('historyPanel').classList.remove('show');
}

function loadHistorySessions() {
    const sessions = JSON.parse(localStorage.getItem('aiSessions') || '[]');
    const historyList = document.getElementById('historyList');

    if (sessions.length === 0) {
        historyList.innerHTML = '<p style="color: var(--text-muted); padding: 1rem; text-align: center;">No saved sessions</p>';
        return;
    }

    historyList.innerHTML = sessions.map(session => {
        const date = new Date(session.timestamp);
        const title = session.conversation[0]?.content?.slice(0, 50) || 'Untitled Session';
        return `
            <div class="history-item" onclick="loadSession('${session.id}')">
                <div class="history-item-title">${title}${title.length >= 50 ? '...' : ''}</div>
                <div class="history-item-time">${date.toLocaleDateString()} ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
            </div>
        `;
    }).join('');
}

function loadSession(sessionId) {
    const sessions = JSON.parse(localStorage.getItem('aiSessions') || '[]');
    const session = sessions.find(s => s.id === sessionId);

    if (session) {
        AIState.sessionId = session.id;
        AIState.conversationHistory = session.conversation;
        // Rebuild conversation UI
        // ... (implementation for restoring conversation)
        closeHistory();
    }
}

// ==================== Recent Prompts ====================

function loadRecentPrompts() {
    const prompts = JSON.parse(localStorage.getItem('recentPrompts') || '[]');
    AIState.recentPrompts = prompts;
    renderRecentPrompts();
}

function saveRecentPrompt(prompt) {
    AIState.recentPrompts = [prompt, ...AIState.recentPrompts.filter(p => p !== prompt)].slice(0, 10);
    localStorage.setItem('recentPrompts', JSON.stringify(AIState.recentPrompts));
    renderRecentPrompts();
}

function renderRecentPrompts() {
    const container = document.getElementById('recentPromptsList');
    if (!container) return;

    if (AIState.recentPrompts.length === 0) {
        container.innerHTML = '<p style="color: var(--text-muted); font-size: 0.8rem;">No recent prompts</p>';
        return;
    }

    container.innerHTML = AIState.recentPrompts.slice(0, 5).map(prompt => `
        <div class="recent-prompt-item" onclick="loadPrompt('${escapeHtml(prompt)}')">${prompt}</div>
    `).join('');
}

function viewAllPrompts() {
    // Could open a modal with all prompts
    alert('View all prompts - Coming soon!');
}

// ==================== Utility Functions ====================

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function scrollToBottom() {
    const container = document.getElementById('conversationArea');
    setTimeout(() => {
        container.scrollTop = container.scrollHeight;
    }, 100);
}

function toggleLeftPanel() {
    document.getElementById('leftPanel').classList.toggle('collapsed');
}

// ==================== File Attachments ====================

function attachFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,.xlsx,.json';
    input.onchange = (e) => {
        const file = e.target.files[0];
        if (file) {
            // Handle file attachment
            console.log('File selected:', file.name);
            // Add to chat context
        }
    };
    input.click();
}

function attachExport() {
    // Open extraction selection dialog
    alert('Attach extraction data - Connect to existing extractions');
}

function toggleVoiceInput() {
    // Voice input functionality
    alert('Voice input - Coming soon!');
}

// ==================== Export Functions ====================

function exportToExcel() {
    // Export current insights to Excel
    window.location.href = '/api/export_analytics?session=' + AIState.sessionId;
}

function exportLineage() {
    // Export lineage data
    alert('Export lineage - Coming soon!');
}

// ==================== View All Functions ====================

function viewAllProjects() {
    selectTopic('datasource-mapping');
}

function viewAllRecommendations() {
    // Show all recommendations modal
    alert('View all recommendations - Coming soon!');
}

function refreshInsights() {
    // Refresh the insights panel
    loadDashboardContext();
}

function editFavorites() {
    // Edit favorites functionality
    alert('Edit favorites - Coming soon!');
}

// ==================== Initialize on Load ====================

console.log('AI Intelligence Workspace loaded');
